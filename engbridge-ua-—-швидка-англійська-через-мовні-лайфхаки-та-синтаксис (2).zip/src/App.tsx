import React, { useState, useEffect } from 'react';
import { Header, TabId } from './components/Header';
import { HacksCatalog } from './components/HacksCatalog';
import { MethodsStudio } from './components/MethodsStudio';
import { LevelTest } from './components/LevelTest';
import { MistakesStudio } from './components/MistakesStudio';
import { SentenceBuilder } from './components/SentenceBuilder';
import { SmartDetector } from './components/SmartDetector';
import { QuizTrainer } from './components/QuizTrainer';
import { Flashcards } from './components/Flashcards';
import { Dictionary } from './components/Dictionary';
import { ThematicWordsHub } from './components/ThematicWordsHub';
import { RoleplaySimulator } from './components/RoleplaySimulator';
import { ProfileView } from './components/ProfileView';
import { AuthModal } from './components/AuthModal';
import { AudioSettingsModal } from './components/AudioSettingsModal';
import { ReviewRemindersModal } from './components/ReviewRemindersModal';
import { UserProfile, VocabItem, CefrLevel, SrsCard, MistakeRecord, PlacementQuestion, SentencePuzzle } from './types';
import { setAudioMuted, playSound } from './utils/audio';
import { generateMnemonicForMistake } from './utils/mnemonics';
import {
  loadReminderSettings,
  saveReminderSettings,
  loadTopicReviews,
  computeTopicRetentionStatuses,
  getDueReviewWords,
  shouldTriggerScheduledReminder,
  sendBrowserNotification,
} from './utils/reminderEngine';
import { THEMATIC_CATEGORIES } from './data/thematicWords';

const STORAGE_KEY = 'engbridge_ua_user_profile';

const INITIAL_PROFILE: UserProfile = {
  isLoggedIn: false,
  uid: 'guest-' + Math.random().toString(36).substring(2, 9),
  displayName: 'Гість EngBridge',
  email: '',
  level: 1,
  xp: 0,
  quizScore: 0,
  maxCombo: 0,
  currentCombo: 0,
  correctCount: 0,
  totalAnswered: 0,
  learnedWords: [],
  srsCards: [],
  mistakes: [],
  dailyStreak: 3,
  lastActiveDate: new Date().toISOString().slice(0, 10),
  dailyGoalMinutes: 15,
  todayMinutesSpent: 8,
  cefrLevel: null,
  cefrScore: 0,
};

interface Toast {
  id: string;
  message: string;
  type: 'info' | 'success' | 'error';
}

export default function App() {
  const [currentTab, setCurrentTab] = useState<TabId>('hacks');
  const [isMuted, setIsMuted] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isAudioSettingsOpen, setIsAudioSettingsOpen] = useState(false);
  const [isReviewRemindersOpen, setIsReviewRemindersOpen] = useState(false);
  const [targetReminderTopic, setTargetReminderTopic] = useState<{
    categoryId: string;
    packNumber?: number;
  } | null>(null);
  const [quizCategory, setQuizCategory] = useState('all');
  const [builderLevel, setBuilderLevel] = useState<CefrLevel>('A1');
  const [toasts, setToasts] = useState<Toast[]>([]);

  const [user, setUser] = useState<UserProfile>(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem(STORAGE_KEY);
        if (saved) {
          return { ...INITIAL_PROFILE, ...JSON.parse(saved) };
        }
      } catch {
        // Ignore JSON error
      }
    }
    return INITIAL_PROFILE;
  });

  // Save profile to local storage on change
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(user));
    } catch {
      // Storage unavailable
    }
  }, [user]);

  const showToast = (message: string, type: 'info' | 'success' | 'error' = 'info') => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3200);
  };

  const handleToggleAudio = () => {
    const nextState = !isMuted;
    setIsMuted(nextState);
    setAudioMuted(nextState);
    showToast(nextState ? 'Звук вимкнено' : 'Звук увімкнено', 'info');
  };

  // Live due review metrics for Header badge
  const topicRecords = loadTopicReviews();
  const topicStatuses = computeTopicRetentionStatuses(
    THEMATIC_CATEGORIES,
    user.learnedWords,
    topicRecords,
    {}
  );
  const dueWordsList = getDueReviewWords(user.srsCards, user.mistakes, user.learnedWords);
  const criticalTopicsCount = topicStatuses.filter(
    (t) => t.urgency === 'critical' || t.urgency === 'high'
  ).length;
  const totalDueReviewCount = criticalTopicsCount + dueWordsList.length;

  // Scheduled Daily Review Reminders background checker
  useEffect(() => {
    const checkReminders = () => {
      const settings = loadReminderSettings();
      if (!settings.enabled) return;

      if (shouldTriggerScheduledReminder(settings)) {
        const records = loadTopicReviews();
        const statuses = computeTopicRetentionStatuses(
          THEMATIC_CATEGORIES,
          user.learnedWords,
          records,
          {}
        );
        const dueList = getDueReviewWords(user.srsCards, user.mistakes, user.learnedWords);
        const decaying = statuses.filter((t) => t.urgency === 'critical' || t.urgency === 'high');

        if (decaying.length > 0 || dueList.length > 0) {
          const title = 'EngBridge: Час освітити слова! 🇺🇦';
          const body = `У вас ${decaying.length} тем та ${dueList.length} слів у черзі повторення за кривою Еббінгауза.`;

          if (settings.browserNotificationsEnabled) {
            sendBrowserNotification(title, body);
          }
          if (settings.soundEnabled && !isMuted) {
            playSound('combo');
          }
          showToast(
            `🔔 Нагадування: ${decaying.length} тем та ${dueList.length} слів потребують повторення!`,
            'info'
          );

          saveReminderSettings({
            ...settings,
            lastNotificationDate: new Date().toISOString().slice(0, 10),
          });
        }
      }
    };

    checkReminders();
    const interval = setInterval(checkReminders, 60000);
    return () => clearInterval(interval);
  }, [user.learnedWords, user.srsCards, user.mistakes, isMuted]);

  const addXP = (amount: number) => {
    setUser((prev) => {
      const newXP = prev.xp + amount;
      const nextLevelXp = prev.level * 100;
      let newLevel = prev.level;
      if (newXP >= nextLevelXp) {
        newLevel += 1;
        playSound('combo');
        showToast(`🎉 Вітаємо! Ви досягли Рівня ${newLevel}!`, 'success');
      }
      return {
        ...prev,
        xp: newXP,
        level: newLevel,
      };
    });
  };

  const handleRecordQuizAnswer = (
    isCorrect: boolean,
    points: number,
    item: VocabItem,
    selectedWrongAnswer?: string
  ) => {
    setUser((prev) => {
      const newCombo = isCorrect ? prev.currentCombo + 1 : 0;
      const newMaxCombo = Math.max(prev.maxCombo, newCombo);
      const newScore = prev.quizScore + points;

      // Add to learned words if correct and not already present
      let newLearned = [...prev.learnedWords];
      if (isCorrect && !newLearned.some((w) => w.eng.toLowerCase() === item.eng.toLowerCase())) {
        newLearned.push(item);
      }

      // Update mistakes tracking
      let newMistakes = [...(prev.mistakes || [])];
      const existingIdx = newMistakes.findIndex(
        (m) => m.correctAnswer.toLowerCase() === item.eng.toLowerCase()
      );

      if (isCorrect) {
        if (existingIdx !== -1) {
          const existing = newMistakes[existingIdx];
          const nextConsecutive = existing.consecutiveCorrect + 1;
          newMistakes[existingIdx] = {
            ...existing,
            consecutiveCorrect: nextConsecutive,
            isMastered: nextConsecutive >= 2,
          };
        }
      } else {
        const mnemonic = generateMnemonicForMistake(item.ukr, item.eng, item.category);
        if (existingIdx !== -1) {
          const existing = newMistakes[existingIdx];
          newMistakes[existingIdx] = {
            ...existing,
            errorCount: existing.errorCount + 1,
            consecutiveCorrect: 0,
            isMastered: false,
            userWrongAnswer: selectedWrongAnswer || existing.userWrongAnswer,
            lastMistakeTimestamp: Date.now(),
          };
        } else {
          newMistakes.push({
            id: `vocab-${item.eng.toLowerCase()}-${Date.now()}`,
            type: 'vocab',
            prompt: item.ukr,
            userWrongAnswer: selectedWrongAnswer || '',
            correctAnswer: item.eng,
            explanation: item.rule,
            mnemonicHint: mnemonic,
            category: item.category || 'Лексика',
            errorCount: 1,
            consecutiveCorrect: 0,
            isMastered: false,
            lastMistakeTimestamp: Date.now(),
            vocabItem: item,
          });
        }
      }

      return {
        ...prev,
        quizScore: newScore,
        currentCombo: newCombo,
        maxCombo: newMaxCombo,
        correctCount: prev.correctCount + (isCorrect ? 1 : 0),
        totalAnswered: prev.totalAnswered + 1,
        learnedWords: newLearned,
        mistakes: newMistakes,
      };
    });
    if (points > 0) {
      addXP(points);
    }
  };

  const handleRecordTestMistake = (q: PlacementQuestion, wrongOption: string) => {
    setUser((prev) => {
      const newMistakes = [...(prev.mistakes || [])];
      const qId = String(q.id || q.question);
      const existingIdx = newMistakes.findIndex((m) => m.id === qId || m.prompt === q.question);
      const mnemonic = generateMnemonicForMistake(q.question, q.correct, q.category);

      if (existingIdx !== -1) {
        newMistakes[existingIdx] = {
          ...newMistakes[existingIdx],
          errorCount: newMistakes[existingIdx].errorCount + 1,
          consecutiveCorrect: 0,
          isMastered: false,
          userWrongAnswer: wrongOption,
          lastMistakeTimestamp: Date.now(),
        };
      } else {
        newMistakes.push({
          id: qId,
          type: 'test_question',
          prompt: q.question,
          userWrongAnswer: wrongOption,
          correctAnswer: q.correct,
          explanation: q.ruleHint,
          mnemonicHint: mnemonic,
          category: `${q.cefr || 'Тест'} • ${q.category}`,
          level: q.cefr,
          errorCount: 1,
          consecutiveCorrect: 0,
          isMastered: false,
          lastMistakeTimestamp: Date.now(),
        });
      }
      return { ...prev, mistakes: newMistakes };
    });
  };

  const handleRecordChunkMistake = (mistake: {
    prompt: string;
    userWrongAnswer: string;
    correctAnswer: string;
    explanation: string;
    category?: string;
  }) => {
    setUser((prev) => {
      const newMistakes = [...(prev.mistakes || [])];
      const mId = 'chunk-' + mistake.correctAnswer.toLowerCase().replace(/\s+/g, '-');
      const existingIdx = newMistakes.findIndex((m) => m.id === mId || m.correctAnswer === mistake.correctAnswer);
      if (existingIdx !== -1) {
        newMistakes[existingIdx] = {
          ...newMistakes[existingIdx],
          errorCount: newMistakes[existingIdx].errorCount + 1,
          consecutiveCorrect: 0,
          isMastered: false,
          userWrongAnswer: mistake.userWrongAnswer,
          lastMistakeTimestamp: Date.now(),
        };
      } else {
        newMistakes.push({
          id: mId,
          type: 'test_question',
          prompt: mistake.prompt,
          userWrongAnswer: mistake.userWrongAnswer,
          correctAnswer: mistake.correctAnswer,
          explanation: mistake.explanation,
          mnemonicHint: `Колокація: ${mistake.correctAnswer}. ${mistake.explanation}`,
          category: `Чанки • ${mistake.category || 'Колокація'}`,
          errorCount: 1,
          consecutiveCorrect: 0,
          isMastered: false,
          lastMistakeTimestamp: Date.now(),
        });
      }
      return { ...prev, mistakes: newMistakes };
    });
  };

  const handleRecordSentenceMistake = (puzzle: SentencePuzzle, userSentence: string) => {
    setUser((prev) => {
      const newMistakes = [...(prev.mistakes || [])];
      const pId = puzzle.id || puzzle.ukr;
      const existingIdx = newMistakes.findIndex((m) => m.id === pId);
      const correctSent = puzzle.words.join(' ');
      const mnemonic = `Синтаксична формула: ${puzzle.rule}. Завжди дотримуйтесь схеми SVOMPT.`;

      if (existingIdx !== -1) {
        newMistakes[existingIdx] = {
          ...newMistakes[existingIdx],
          errorCount: newMistakes[existingIdx].errorCount + 1,
          consecutiveCorrect: 0,
          isMastered: false,
          userWrongAnswer: userSentence,
          lastMistakeTimestamp: Date.now(),
        };
      } else {
        newMistakes.push({
          id: pId,
          type: 'syntax_sentence',
          prompt: puzzle.ukr,
          userWrongAnswer: userSentence,
          correctAnswer: correctSent,
          explanation: puzzle.rule,
          mnemonicHint: mnemonic,
          category: 'Синтаксис SVOMPT',
          errorCount: 1,
          consecutiveCorrect: 0,
          isMastered: false,
          lastMistakeTimestamp: Date.now(),
        });
      }
      return { ...prev, mistakes: newMistakes };
    });
  };

  const handleUpdateMistakes = (updated: MistakeRecord[]) => {
    setUser((prev) => ({
      ...prev,
      mistakes: updated,
    }));
  };

  const handleSendMistakesToSrs = (cards: SrsCard[]) => {
    setUser((prev) => {
      const existing = prev.srsCards || [];
      const combined = [...existing];
      for (const c of cards) {
        if (!combined.some((item) => item.word.eng.toLowerCase() === c.word.eng.toLowerCase())) {
          combined.push(c);
        }
      }
      return { ...prev, srsCards: combined };
    });
  };

  const handleSaveWord = (item: VocabItem) => {
    setUser((prev) => {
      if (prev.learnedWords.some((w) => w.eng.toLowerCase() === item.eng.toLowerCase())) {
        return prev;
      }
      return {
        ...prev,
        learnedWords: [...prev.learnedWords, item],
      };
    });
    addXP(10);
  };

  const handleToggleLearnedInDict = (item: VocabItem) => {
    setUser((prev) => {
      const exists = prev.learnedWords.some((w) => w.eng.toLowerCase() === item.eng.toLowerCase());
      if (exists) {
        return {
          ...prev,
          learnedWords: prev.learnedWords.filter((w) => w.eng.toLowerCase() !== item.eng.toLowerCase()),
        };
      } else {
        return {
          ...prev,
          learnedWords: [...prev.learnedWords, item],
        };
      }
    });
    addXP(10);
  };

  const handleRemoveWord = (eng: string) => {
    setUser((prev) => ({
      ...prev,
      learnedWords: prev.learnedWords.filter((w) => w.eng.toLowerCase() !== eng.toLowerCase()),
    }));
  };

  const handleClearVault = () => {
    setUser((prev) => ({
      ...prev,
      learnedWords: [],
    }));
  };

  const handleConfirmLevel = (lvl: CefrLevel, score: number) => {
    setUser((prev) => ({
      ...prev,
      cefrLevel: lvl,
      cefrScore: score,
    }));
  };

  const handleLogin = (data: { displayName: string; email: string }) => {
    setUser((prev) => {
      const updated = {
        ...prev,
        isLoggedIn: true,
        displayName: data.displayName,
        email: data.email,
        xp: prev.xp + 50,
      };
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      } catch {
        // ignore
      }
      return updated;
    });
    playSound('combo');
    showToast(`Вітаємо, ${data.displayName}! Профіль успішно збережено (+50 XP)`, 'success');
  };

  const handleLogout = () => {
    setUser((prev) => {
      const updated = {
        ...prev,
        isLoggedIn: false,
        displayName: 'Гість EngBridge',
        email: '',
      };
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      } catch {
        // ignore
      }
      return updated;
    });
    showToast('Ви вийшли з облікового запису', 'info');
  };

  const handleLaunchModule = (actionCategory: string) => {
    if (actionCategory.startsWith('builder')) {
      const lvl = (actionCategory.replace('builder_', '') as CefrLevel) || 'A1';
      setBuilderLevel(lvl);
      setCurrentTab('builder');
      showToast(`Відкрито Конструктор речень для рівня ${lvl}!`, 'info');
    } else {
      setQuizCategory(actionCategory);
      setCurrentTab('quiz');
      showToast(`Запущено модуль практики для вашої програми!`, 'info');
    }
  };

  const handleLaunchCategoryPractice = (catId: string) => {
    setQuizCategory(catId);
    setCurrentTab('quiz');
    showToast('Запущено тренажер для обраного правила!', 'info');
  };

  const handleUpdateSrsCards = (newCards: SrsCard[]) => {
    setUser((prev) => ({
      ...prev,
      srsCards: newCards,
    }));
  };

  return (
    <div className="bg-slate-950 text-slate-100 min-h-screen flex flex-col selection:bg-blue-600 selection:text-white">
      {/* Header */}
      <Header
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        user={user}
        isAudioMuted={isMuted}
        onToggleAudio={handleToggleAudio}
        onOpenAuth={() => setIsAuthOpen(true)}
        onOpenAudioSettings={() => setIsAudioSettingsOpen(true)}
        onOpenReminders={() => setIsReviewRemindersOpen(true)}
        dueReviewCount={totalDueReviewCount}
      />

      {/* Main Content Area */}
      <main className="flex-grow max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {currentTab === 'hacks' && (
          <HacksCatalog
            onSelectTab={setCurrentTab}
            onLaunchCategoryPractice={handleLaunchCategoryPractice}
          />
        )}

        {currentTab === 'topics' && (
          <ThematicWordsHub
            learnedWords={user.learnedWords}
            onToggleLearned={handleToggleLearnedInDict}
            onRewardXP={addXP}
            onToast={showToast}
            initialCategoryId={targetReminderTopic?.categoryId}
            initialPackNumber={targetReminderTopic?.packNumber}
            onOpenRemindersModal={() => setIsReviewRemindersOpen(true)}
            onRecordMistake={(vocabItem, wrongAnswer) => {
              const prompt = vocabItem.ukr;
              const correct = vocabItem.eng;
              const ruleHint = vocabItem.mnemonicHook || vocabItem.rule;
              setUser((prev) => {
                const existingIndex = prev.mistakes.findIndex(
                  (m) => m.type === 'vocab' && m.prompt === prompt
                );
                let updatedMistakes = [...prev.mistakes];
                if (existingIndex >= 0) {
                  const existing = updatedMistakes[existingIndex];
                  updatedMistakes[existingIndex] = {
                    ...existing,
                    errorCount: existing.errorCount + 1,
                    consecutiveCorrect: 0,
                    isMastered: false,
                    userWrongAnswer: wrongAnswer,
                    lastMistakeTimestamp: Date.now(),
                  };
                } else {
                  const newMistake: MistakeRecord = {
                    id: 'mistake-' + Math.random().toString(36).substring(2, 9),
                    type: 'vocab',
                    prompt,
                    userWrongAnswer: wrongAnswer,
                    correctAnswer: correct,
                    explanation: `Категорія «${vocabItem.category || 'Тема'}»: ${vocabItem.rule}`,
                    mnemonicHint: ruleHint,
                    category: vocabItem.category,
                    level: vocabItem.level || 'A1',
                    errorCount: 1,
                    consecutiveCorrect: 0,
                    isMastered: false,
                    lastMistakeTimestamp: Date.now(),
                    vocabItem,
                  };
                  updatedMistakes = [newMistake, ...updatedMistakes];
                }
                return { ...prev, mistakes: updatedMistakes };
              });
            }}
            onNavigateToQuiz={(cat) => {
              setQuizCategory(cat);
              setCurrentTab('quiz');
            }}
          />
        )}

        {currentTab === 'methods' && (
          <MethodsStudio
            srsCards={user.srsCards}
            onUpdateSrsCards={handleUpdateSrsCards}
            dailyStreak={user.dailyStreak}
            todayMinutes={user.todayMinutesSpent}
            onRewardXP={addXP}
            onToast={showToast}
            userLevel={user.cefrLevel}
            onRecordMistake={handleRecordChunkMistake}
          />
        )}

        {currentTab === 'roleplay' && (
          <RoleplaySimulator
            onRewardXP={addXP}
            onToast={showToast}
            onSaveWord={handleSaveWord}
            userLevel={user.cefrLevel}
          />
        )}

        {currentTab === 'level-test' && (
          <LevelTest
            currentAssessedLevel={user.cefrLevel}
            onConfirmLevel={handleConfirmLevel}
            onOpenAuthModal={() => setIsAuthOpen(true)}
            onLaunchModule={handleLaunchModule}
            onRewardXP={addXP}
            onToast={showToast}
            onRecordMistake={handleRecordTestMistake}
            onNavigateToMistakes={() => setCurrentTab('mistakes')}
          />
        )}

        {currentTab === 'mistakes' && (
          <MistakesStudio
            mistakes={user.mistakes || []}
            onUpdateMistakes={handleUpdateMistakes}
            onSendToSrs={handleSendMistakesToSrs}
            onRewardXP={addXP}
            onToast={showToast}
            onNavigateToTab={setCurrentTab}
          />
        )}

        {currentTab === 'builder' && (
          <SentenceBuilder
            initialLevel={builderLevel}
            onRewardXP={addXP}
            onToast={showToast}
            onRecordMistake={handleRecordSentenceMistake}
          />
        )}

        {currentTab === 'detector' && (
          <SmartDetector onSaveWord={handleSaveWord} onToast={showToast} />
        )}

        {currentTab === 'quiz' && (
          <QuizTrainer
            initialCategory={quizCategory}
            onRecordAnswer={handleRecordQuizAnswer}
            onSelectTab={(tab) => setCurrentTab(tab)}
            comboCount={user.currentCombo}
            totalScore={user.quizScore}
            userMistakes={user.mistakes || []}
          />
        )}

        {currentTab === 'cards' && (
          <Flashcards onMarkLearned={handleSaveWord} onToast={showToast} />
        )}

        {currentTab === 'dictionary' && (
          <Dictionary
            learnedWords={user.learnedWords}
            onToggleLearned={handleToggleLearnedInDict}
            onToast={showToast}
          />
        )}

        {currentTab === 'profile' && (
          <ProfileView
            user={user}
            onOpenAuth={() => setIsAuthOpen(true)}
            onLogout={handleLogout}
            onNavigateToLevelTest={() => setCurrentTab('level-test')}
            onRemoveWord={handleRemoveWord}
            onClearVault={handleClearVault}
            onToast={showToast}
            onOpenReminders={() => setIsReviewRemindersOpen(true)}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-6 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <span>EngBridge UA © 2026. Швидка англійська через синтаксис та алгоритми мовних мостів.</span>
          <div className="flex items-center gap-4 text-slate-400">
            <button onClick={() => setCurrentTab('hacks')} className="hover:text-white transition">
              Лайфхаки
            </button>
            <button onClick={() => setCurrentTab('topics')} className="hover:text-emerald-400 transition text-emerald-300 font-semibold">
              Теми слів
            </button>
            <button onClick={() => setCurrentTab('methods')} className="hover:text-white transition">
              Методики (SRS)
            </button>
            <button onClick={() => setCurrentTab('roleplay')} className="hover:text-purple-400 transition text-purple-300 font-semibold">
              AI Рольова гра
            </button>
            <button onClick={() => setCurrentTab('builder')} className="hover:text-white transition">
              SVOMPT
            </button>
            <button onClick={() => setCurrentTab('level-test')} className="hover:text-white transition">
              A1–C1
            </button>
            <button onClick={() => setCurrentTab('mistakes')} className="hover:text-rose-400 transition text-rose-300 font-semibold">
              Помилки ({user.mistakes ? user.mistakes.filter(m => !m.isMastered).length : 0})
            </button>
            <button onClick={() => setCurrentTab('dictionary')} className="hover:text-white transition">
              Словник
            </button>
          </div>
        </div>
      </footer>

      {/* Auth Modal */}
      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        onLogin={handleLogin}
        onToast={showToast}
        currentUserEmail={user.email}
        isLoggedIn={user.isLoggedIn}
      />

      {/* Google TTS Audio Settings Modal */}
      <AudioSettingsModal
        isOpen={isAudioSettingsOpen}
        onClose={() => setIsAudioSettingsOpen(false)}
        isAudioMuted={isMuted}
        onToggleAudio={handleToggleAudio}
      />

      {/* Review & Reminders Hub Modal */}
      <ReviewRemindersModal
        isOpen={isReviewRemindersOpen}
        onClose={() => setIsReviewRemindersOpen(false)}
        learnedWords={user.learnedWords}
        srsCards={user.srsCards}
        mistakes={user.mistakes}
        onUpdateSrsCards={handleUpdateSrsCards}
        onRewardXP={addXP}
        onToast={showToast}
        onNavigateToTopic={(categoryId, packNumber) => {
          setTargetReminderTopic({ categoryId, packNumber });
          setCurrentTab('topics');
        }}
      />

      {/* Toast Notification Container */}
      <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-2 pointer-events-none">
        {toasts.map((t) => {
          const colors = {
            success: 'bg-emerald-600 text-white border-emerald-500',
            error: 'bg-rose-600 text-white border-rose-500',
            info: 'bg-slate-800 text-slate-100 border-slate-700',
          };
          return (
            <div
              key={t.id}
              className={`px-4 py-2.5 rounded-2xl border shadow-xl text-xs font-bold flex items-center gap-2 pointer-events-auto transition duration-200 ${
                colors[t.type]
              }`}
            >
              <span>{t.message}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
