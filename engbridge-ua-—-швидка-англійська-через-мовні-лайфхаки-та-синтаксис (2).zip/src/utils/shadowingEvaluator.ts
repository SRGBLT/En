import { ShadowingEvaluationResult, ShadowingWordEvaluation } from '../types';

/**
 * Checks if SpeechRecognition (WebKit / standard) is supported in current browser
 */
export function isSpeechRecognitionSupported(): boolean {
  if (typeof window === 'undefined') return false;
  return Boolean(
    (window as any).SpeechRecognition ||
    (window as any).webkitSpeechRecognition
  );
}

export interface MicrophoneRequestResult {
  stream: MediaStream | null;
  error: string | null;
  errorType?: 'not-allowed' | 'not-found' | 'not-readable' | 'overconstrained' | 'iframe-blocked' | 'unsupported' | 'unknown';
  inIframe?: boolean;
}

/**
 * Checks if the current app window is running embedded in an iframe (e.g. AI Studio preview)
 */
export function isRunningInIframe(): boolean {
  if (typeof window === 'undefined') return false;
  try {
    return window.self !== window.top;
  } catch {
    return true;
  }
}

/**
 * Enumerate available audio input devices (microphones)
 */
export async function getAudioInputDevices(): Promise<MediaDeviceInfo[]> {
  if (typeof navigator === 'undefined' || !navigator.mediaDevices?.enumerateDevices) {
    return [];
  }
  try {
    const devices = await navigator.mediaDevices.enumerateDevices();
    return devices.filter((d) => d.kind === 'audioinput');
  } catch {
    return [];
  }
}

/**
 * Request microphone permission explicitly with friendly error messages and fallback strategies
 */
export async function requestMicrophonePermission(preferredDeviceId?: string): Promise<MicrophoneRequestResult> {
  if (typeof navigator === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
    return {
      stream: null,
      error: 'Ваш браузер не підтримує запис аудіо з мікрофона (WebRTC mediaDevices).',
      errorType: 'unsupported',
      inIframe: isRunningInIframe(),
    };
  }

  const inIframe = isRunningInIframe();

  // Attempt 1: with preferred device or standard audio constraints
  try {
    const constraints: MediaStreamConstraints = preferredDeviceId
      ? { audio: { deviceId: { exact: preferredDeviceId } } }
      : {
          audio: {
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true,
          },
        };

    const stream = await navigator.mediaDevices.getUserMedia(constraints);
    return { stream, error: null, inIframe };
  } catch (firstErr: any) {
    // Attempt 2: fallback to simple { audio: true } if constraint was overconstrained or rejected
    try {
      const fallbackStream = await navigator.mediaDevices.getUserMedia({ audio: true });
      return { stream: fallbackStream, error: null, inIframe };
    } catch (err: any) {
      let msg = 'Не вдалося отримати доступ до мікрофона.';
      let errorType: MicrophoneRequestResult['errorType'] = 'unknown';

      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        if (inIframe) {
          errorType = 'iframe-blocked';
          msg =
            'Доступ заблоковано через роботу у вікні передперегляду (iFrame). Якщо ви вже дозволили мікрофон у браузері, відкрийте додаток у новій вкладці для прямого доступу без обмежень фрейму.';
        } else {
          errorType = 'not-allowed';
          msg =
            'Доступ до мікрофона заблоковано в налаштуваннях браузера або системи. Перевірте дозвіл біля адресного рядка сайту (значок 🔒), а також системні налаштування Windows / macOS.';
        }
      } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
        errorType = 'not-found';
        msg = 'Мікрофон не виявлено. Перевірте підключення гарнітури чи мікрофона до комп’ютера.';
      } else if (err.name === 'NotReadableError' || err.name === 'TrackStartError') {
        errorType = 'not-readable';
        msg = 'Мікрофон зайнятий іншою програмою (Zoom, Google Meet, Skype, Discord) або іншою вкладкою.';
      } else if (err.name === 'OverconstrainedError') {
        errorType = 'overconstrained';
        msg = 'Обраний мікрофон не підтримує запитувані параметри звуку.';
      }

      return { stream: null, error: msg, errorType, inIframe };
    }
  }
}

/**
 * Creates an AudioContext-based volume meter (0-100) to show real-time voice activity
 */
export function createAudioLevelMonitor(
  stream: MediaStream,
  onLevelChange: (level: number) => void
): { stop: () => void } {
  try {
    const AudioContextClass =
      window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return { stop: () => {} };

    const audioCtx = new AudioContextClass();
    const analyser = audioCtx.createAnalyser();
    analyser.fftSize = 256;
    analyser.smoothingTimeConstant = 0.5;

    const source = audioCtx.createMediaStreamSource(stream);
    source.connect(analyser);

    const dataArray = new Uint8Array(analyser.frequencyBinCount);
    let animId: number | null = null;
    let isActive = true;

    const tick = () => {
      if (!isActive) return;
      analyser.getByteFrequencyData(dataArray);
      let sum = 0;
      for (let i = 0; i < dataArray.length; i++) {
        sum += dataArray[i];
      }
      const avg = sum / dataArray.length;
      // Scale 0-128 to 0-100 percentage
      const level = Math.min(100, Math.round((avg / 128) * 100));
      onLevelChange(level);
      animId = requestAnimationFrame(tick);
    };

    tick();

    return {
      stop: () => {
        isActive = false;
        if (animId) cancelAnimationFrame(animId);
        try {
          source.disconnect();
          analyser.disconnect();
          audioCtx.close();
        } catch {
          // ignore
        }
      },
    };
  } catch {
    return { stop: () => {} };
  }
}

/**
 * Convert Blob to Base64
 */
export function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      resolve(reader.result as string);
    };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

/**
 * Transcribes audio blob using backend Gemini speech-to-text endpoint
 */
export async function transcribeAudioBlob(
  blob: Blob,
  targetText?: string
): Promise<{ transcript: string; error?: string }> {
  try {
    const base64 = await blobToBase64(blob);
    const res = await fetch('/api/transcribe', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        audioBase64: base64,
        mimeType: blob.type || 'audio/webm',
        targetText,
      }),
    });

    if (res.ok) {
      const data = await res.json();
      return { transcript: (data.transcript || '').trim() };
    }
    return { transcript: '', error: 'Помилка розпізнавання аудіо на сервері' };
  } catch (err: any) {
    return { transcript: '', error: err?.message || 'Помилка мережі' };
  }
}

/**
 * Transcribes an uploaded audio file (.mp3, .wav, .m4a, .webm, .ogg)
 */
export async function transcribeAudioFile(
  file: File,
  targetText?: string
): Promise<{ transcript: string; error?: string }> {
  if (!file) {
    return { transcript: '', error: 'Файл не обрано' };
  }

  // 15MB limit check
  if (file.size > 15 * 1024 * 1024) {
    return { transcript: '', error: 'Розмір аудіофайлу перевищує 15 МБ' };
  }

  let mimeType = file.type || 'audio/webm';
  if (!mimeType || mimeType === 'application/octet-stream') {
    const ext = file.name.split('.').pop()?.toLowerCase();
    if (ext === 'mp3') mimeType = 'audio/mp3';
    else if (ext === 'wav') mimeType = 'audio/wav';
    else if (ext === 'm4a') mimeType = 'audio/m4a';
    else if (ext === 'ogg') mimeType = 'audio/ogg';
    else if (ext === 'webm') mimeType = 'audio/webm';
  }

  return transcribeAudioBlob(file, targetText);
}

/**
 * Creates and starts a speech recognition session with resilient error handling
 */
export function createSpeechRecognizer(
  onTranscriptUpdate: (interim: string, isFinal: boolean) => void,
  onError: (friendlyError: string) => void
): { stop: () => void; recognition: any } | null {
  if (typeof window === 'undefined') return null;

  const SpeechRec = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
  if (!SpeechRec) return null;

  try {
    const recognition = new SpeechRec();
    recognition.lang = 'en-US';
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.maxAlternatives = 1;

    let fullFinalTranscript = '';
    let isExplicitlyStopped = false;

    recognition.onresult = (event: any) => {
      let interimTranscript = '';
      for (let i = event.resultIndex; i < event.results.length; ++i) {
        const item = event.results[i];
        if (item.isFinal) {
          fullFinalTranscript += (fullFinalTranscript ? ' ' : '') + item[0].transcript.trim();
        } else {
          interimTranscript += item[0].transcript;
        }
      }
      const combined = (fullFinalTranscript + ' ' + interimTranscript).trim();
      onTranscriptUpdate(combined, Boolean(fullFinalTranscript && !interimTranscript));
    };

    recognition.onerror = (event: any) => {
      // Map error codes to clear helpful messages
      if (event.error === 'not-allowed' || event.error === 'service-not-allowed') {
        onError('Доступ до мікрофона заблоковано в налаштуваннях браузера. Дозвольте мікрофон біля адресного рядка.');
      } else if (event.error === 'audio-capture') {
        onError('Не вдалося захопити аудіо з мікрофона. Перевірте, чи мікрофон увімкнений та не зайнятий.');
      } else if (event.error === 'network') {
        onError("Помилка зв'язку з хмарним розпізнаванням. Здійснюємо запис звуку через резервний аудіо-модуль.");
      } else if (event.error !== 'no-speech' && event.error !== 'aborted') {
        onError(`Помилка розпізнавання: ${event.error}`);
      }
    };

    recognition.onend = () => {
      // If stopped naturally but user didn't hit stop, restart if still recording
      if (!isExplicitlyStopped) {
        try {
          recognition.start();
        } catch {
          // ignore already started
        }
      }
    };

    recognition.start();

    return {
      stop: () => {
        isExplicitlyStopped = true;
        try {
          recognition.stop();
        } catch {
          // ignore
        }
      },
      recognition,
    };
  } catch (err: any) {
    onError(err?.message || 'Не вдалося ініціалізувати розпізнавач мови');
    return null;
  }
}

function normalizeToken(token: string): string {
  return token
    .toLowerCase()
    .replace(/[.,\/#!$%\^&\*;:{}=\-_`~()?"'’]/g, '')
    .trim();
}

function levenshtein(a: string, b: string): number {
  const m = a.length;
  const n = b.length;
  const dp: number[][] = Array.from({ length: m + 1 }, () => Array(n + 1).fill(0));

  for (let i = 0; i <= m; i++) dp[i][0] = i;
  for (let j = 0; j <= n; j++) dp[0][j] = j;

  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      dp[i][j] = Math.min(
        dp[i - 1][j] + 1,
        dp[i][j - 1] + 1,
        dp[i - 1][j - 1] + cost
      );
    }
  }

  return dp[m][n];
}

/**
 * Local deterministic evaluation algorithm for Shadowing recordings
 */
export function evaluateShadowingLocally(
  targetText: string,
  userTranscript: string,
  connectedSpeechTips: string = ''
): ShadowingEvaluationResult {
  const targetTokens = targetText.split(/\s+/).filter(Boolean);
  const userTokens = userTranscript.split(/\s+/).filter(Boolean);

  const cleanTarget = targetTokens.map(normalizeToken);
  const cleanUser = userTokens.map(normalizeToken);

  let userIdx = 0;
  const wordsComparison: ShadowingWordEvaluation[] = [];
  let exactMatches = 0;
  let similarMatches = 0;

  for (let i = 0; i < targetTokens.length; i++) {
    const rawTarget = targetTokens[i];
    const targetNorm = cleanTarget[i];

    if (!targetNorm) continue;

    // Look ahead in user tokens within a window of 3 tokens
    let bestMatchIdx = -1;
    let minDistance = 999;

    for (let j = userIdx; j < Math.min(cleanUser.length, userIdx + 4); j++) {
      const uNorm = cleanUser[j];
      if (uNorm === targetNorm) {
        bestMatchIdx = j;
        minDistance = 0;
        break;
      }
      const dist = levenshtein(targetNorm, uNorm);
      if (dist < minDistance && dist <= Math.max(1, Math.floor(targetNorm.length * 0.35))) {
        minDistance = dist;
        bestMatchIdx = j;
      }
    }

    if (bestMatchIdx !== -1) {
      const userSpoken = userTokens[bestMatchIdx];
      userIdx = bestMatchIdx + 1;

      if (minDistance === 0) {
        exactMatches++;
        wordsComparison.push({
          word: rawTarget,
          status: 'match',
          spokenWord: userSpoken,
        });
      } else {
        similarMatches++;
        wordsComparison.push({
          word: rawTarget,
          status: 'similar',
          spokenWord: userSpoken,
          note: `почуто: «${userSpoken}»`,
        });
      }
    } else {
      wordsComparison.push({
        word: rawTarget,
        status: 'missing',
        note: 'пропущено слово',
      });
    }
  }

  const totalWords = Math.max(1, targetTokens.length);
  const accuracyScore = Math.min(
    100,
    Math.round(((exactMatches * 1.0 + similarMatches * 0.7) / totalWords) * 100)
  );

  // Fluency: based on completeness and length ratio
  const lengthRatio = Math.min(1, userTokens.length / totalWords);
  const fluencyScore = Math.min(100, Math.round((accuracyScore * 0.7 + lengthRatio * 30)));
  const pronunciationScore = Math.min(100, Math.round(accuracyScore * 0.95 + (exactMatches / totalWords) * 5));

  const overallScore = Math.min(
    100,
    Math.max(10, Math.round(accuracyScore * 0.5 + pronunciationScore * 0.3 + fluencyScore * 0.2))
  );

  // Connected speech analysis
  const connectedSpeechFound: string[] = [];
  const connectedSpeechMissed: string[] = [];

  const lowerUser = userTranscript.toLowerCase();
  const tipsLower = connectedSpeechTips.toLowerCase();

  // Search for phrases mentioned in tips
  const phrasesToCheck = ['wake up', 'cup of', 'focus on', 'going to', 'gonna', 'end of', 'fast-paced'];
  for (const phrase of phrasesToCheck) {
    if (targetText.toLowerCase().includes(phrase)) {
      if (lowerUser.includes(phrase) || (phrase === 'going to' && lowerUser.includes('gonna'))) {
        connectedSpeechFound.push(phrase);
      } else {
        connectedSpeechMissed.push(phrase);
      }
    }
  }

  // Feedback generator in Ukrainian
  let feedbackUa = '';
  if (overallScore >= 90) {
    feedbackUa = `Блискуче виконання! Ваша вимова надзвичайно чітка, а темп відповідає мовленню носія мови (${overallScore}% точності). Всі ключові зв'язки звуків збережені.`;
  } else if (overallScore >= 75) {
    feedbackUa = `Чудовий результат (${overallScore}%). Ви добре вловили загальний ритм фрази. Зверніть увагу на виділені жовтим або пропущені слова, щоб зробити вимову ще природнішою.`;
  } else if (overallScore >= 50) {
    feedbackUa = `Непоганий старт (${overallScore}%). Деякі слова прозвучали нерозбірливо або були пропущені. Спробуйте увімкнути швидкість 0.75x, прослухати зразок ще раз і повторити з акцентом на наголоси.`;
  } else {
    feedbackUa = `Поки що розпізнано небагато слів (${overallScore}%). Перевірте мікрофон, говоріть голосніше та повільніше за диктором, фокусуючись на кожному складі.`;
  }

  const xpEarned = overallScore >= 90 ? 40 : overallScore >= 75 ? 25 : 15;

  return {
    score: overallScore,
    accuracyScore,
    fluencyScore,
    pronunciationScore,
    wordsComparison,
    transcribedText: userTranscript,
    feedbackUa,
    connectedSpeechFound,
    connectedSpeechMissed,
    xpEarned,
  };
}

/**
 * Evaluates shadowing recording by requesting backend AI endpoint,
 * with reliable client-side fallback
 */
export async function evaluateShadowing(
  targetText: string,
  userTranscript: string,
  connectedSpeechTips: string = '',
  phoneticStress: string = '',
  level: string = 'A1'
): Promise<ShadowingEvaluationResult> {
  if (!userTranscript || userTranscript.trim().length === 0) {
    return evaluateShadowingLocally(targetText, '', connectedSpeechTips);
  }

  try {
    const res = await fetch('/api/shadowing/evaluate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        targetText,
        userTranscript,
        connectedSpeechTips,
        phoneticStress,
        level,
      }),
    });

    if (res.ok) {
      const data = await res.json();
      if (data && typeof data.score === 'number') {
        return data as ShadowingEvaluationResult;
      }
    }
  } catch (err) {
    console.warn('Backend shadowing evaluation fallback to local:', err);
  }

  // Fallback to local evaluator
  return evaluateShadowingLocally(targetText, userTranscript, connectedSpeechTips);
}
