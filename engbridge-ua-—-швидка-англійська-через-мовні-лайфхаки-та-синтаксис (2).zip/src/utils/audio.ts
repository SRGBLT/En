// Audio synthesizer & Google TTS Integration
export type GoogleTtsVoice = 'Kore' | 'Puck' | 'Zephyr' | 'Charon' | 'google_translate' | 'browser_google';

export interface AudioSettings {
  voice: GoogleTtsVoice;
  rate: number;
  useGoogleTts: boolean;
}

const SETTINGS_KEY = 'engbridge_tts_settings_v2';

const DEFAULT_SETTINGS: AudioSettings = {
  voice: 'Kore',
  rate: 0.95,
  useGoogleTts: true,
};

let audioCtx: AudioContext | null = null;
let isAudioMuted = false;
let currentAudioElement: HTMLAudioElement | null = null;
let currentSpeakingText: string | null = null;
let isSpeaking = false;

// In-memory cache for audio object URLs to make repeat clicks instant (0ms latency)
const audioBlobCache = new Map<string, string>();

// Event listeners for UI updates (e.g., pulsing speak buttons)
type AudioStateListener = (speaking: boolean, activeText: string | null) => void;
const stateListeners = new Set<AudioStateListener>();

function notifyListeners(): void {
  stateListeners.forEach((fn) => {
    try {
      fn(isSpeaking, currentSpeakingText);
    } catch {
      // Ignore listener error
    }
  });
}

export function subscribeAudioState(listener: AudioStateListener): () => void {
  stateListeners.add(listener);
  listener(isSpeaking, currentSpeakingText);
  return () => {
    stateListeners.delete(listener);
  };
}

export function getAudioSettings(): AudioSettings {
  if (typeof window === 'undefined') return DEFAULT_SETTINGS;
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    const parsed = JSON.parse(raw);
    return {
      voice: parsed.voice || DEFAULT_SETTINGS.voice,
      rate: typeof parsed.rate === 'number' ? parsed.rate : DEFAULT_SETTINGS.rate,
      useGoogleTts: parsed.useGoogleTts !== false,
    };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function updateAudioSettings(updates: Partial<AudioSettings>): AudioSettings {
  const current = getAudioSettings();
  const next: AudioSettings = { ...current, ...updates };
  if (typeof window !== 'undefined') {
    try {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(next));
    } catch {
      // Ignore storage errors
    }
  }
  return next;
}

export function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  if (!audioCtx) {
    const AudioContextClass =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (AudioContextClass) {
      audioCtx = new AudioContextClass();
    }
  }
  if (audioCtx && audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

export function setAudioMuted(muted: boolean): void {
  isAudioMuted = muted;
  if (muted) {
    stopSpeech();
  }
}

export function getAudioMuted(): boolean {
  return isAudioMuted;
}

export function isCurrentlySpeaking(text?: string): boolean {
  if (!isSpeaking) return false;
  if (!text) return isSpeaking;
  return currentSpeakingText?.trim().toLowerCase() === text.trim().toLowerCase();
}

// Stop any in-progress speech playback
export function stopSpeech(): void {
  if (currentAudioElement) {
    try {
      currentAudioElement.pause();
      currentAudioElement.currentTime = 0;
    } catch {
      // Ignore
    }
    currentAudioElement = null;
  }

  if (typeof window !== 'undefined' && window.speechSynthesis) {
    try {
      window.speechSynthesis.cancel();
    } catch {
      // Ignore
    }
  }

  isSpeaking = false;
  currentSpeakingText = null;
  notifyListeners();
}

function playTone(freq: number, type: OscillatorType, duration: number, gainValue = 0.12): void {
  if (isAudioMuted) return;
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, ctx.currentTime);
    gain.gain.setValueAtTime(gainValue, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + duration);
  } catch {
    // Graceful fallback if Web Audio is restricted
  }
}

export function playSound(type: 'click' | 'correct' | 'wrong' | 'combo' | 'trophy'): void {
  if (isAudioMuted) return;
  if (type === 'click') {
    playTone(550, 'sine', 0.05, 0.06);
  } else if (type === 'correct') {
    playTone(523.25, 'triangle', 0.1, 0.12);
    setTimeout(() => playTone(659.25, 'triangle', 0.16, 0.12), 70);
  } else if (type === 'wrong') {
    playTone(280, 'sawtooth', 0.12, 0.09);
    setTimeout(() => playTone(220, 'sawtooth', 0.18, 0.09), 90);
  } else if (type === 'combo') {
    playTone(659.25, 'sine', 0.1, 0.14);
    setTimeout(() => playTone(783.99, 'sine', 0.1, 0.14), 80);
    setTimeout(() => playTone(1046.5, 'sine', 0.22, 0.14), 160);
  } else if (type === 'trophy') {
    playTone(523.25, 'sine', 0.08, 0.15);
    setTimeout(() => playTone(659.25, 'sine', 0.08, 0.15), 90);
    setTimeout(() => playTone(783.99, 'sine', 0.08, 0.15), 180);
    setTimeout(() => playTone(1046.5, 'triangle', 0.35, 0.18), 270);
  }
}

// Clean raw input (strip markdown bolding, transliterations or meta parentheses)
function sanitizeEnglishText(text: string): string {
  return text
    .replace(/\*\*/g, '')
    .replace(/__/g, '')
    .replace(/\[.*?\]/g, '')
    .replace(/[❌✅➔👉💡]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

// Browser Web Speech fallback with prioritization of Google voices
function speakWithBrowserSynthesis(text: string, rate: number): void {
  if (typeof window === 'undefined' || !window.speechSynthesis) return;

  try {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'en-US';
    utterance.rate = Math.max(0.6, Math.min(1.4, rate));

    const voices = window.speechSynthesis.getVoices();
    // Prioritize high-quality Google voices in Chrome / Android
    const googleVoice =
      voices.find((v) => v.name.includes('Google') && (v.lang.startsWith('en-US') || v.lang.startsWith('en-GB'))) ||
      voices.find((v) => v.name.includes('Natural') && v.lang.startsWith('en')) ||
      voices.find((v) => v.lang === 'en-US') ||
      voices.find((v) => v.lang.startsWith('en'));

    if (googleVoice) {
      utterance.voice = googleVoice;
    }

    isSpeaking = true;
    currentSpeakingText = text;
    notifyListeners();

    utterance.onend = () => {
      isSpeaking = false;
      currentSpeakingText = null;
      notifyListeners();
    };

    utterance.onerror = () => {
      isSpeaking = false;
      currentSpeakingText = null;
      notifyListeners();
    };

    window.speechSynthesis.speak(utterance);
  } catch {
    isSpeaking = false;
    currentSpeakingText = null;
    notifyListeners();
  }
}

/**
 * High Quality Google TTS Player
 * Uses server-side Google Gemini Flash Lite TTS / Google Translate TTS endpoint,
 * with immediate in-memory blob caching, playback rate control, and browser fallback.
 */
export async function speakEnglish(
  text: string,
  rateParam?: number,
  options?: { voice?: GoogleTtsVoice; slow?: boolean; forceBrowser?: boolean }
): Promise<void> {
  if (isAudioMuted || !text) return;

  const cleanText = sanitizeEnglishText(text);
  if (!cleanText) return;

  const settings = getAudioSettings();
  const voice = options?.voice || settings.voice;
  const rate =
    options?.slow
      ? 0.75
      : typeof rateParam === 'number'
      ? rateParam
      : settings.rate || 0.95;

  stopSpeech();

  // If user selected browser-only or forceBrowser
  if (options?.forceBrowser || !settings.useGoogleTts || voice === 'browser_google') {
    speakWithBrowserSynthesis(cleanText, rate);
    return;
  }

  const cacheKey = `${voice}:${cleanText.toLowerCase()}`;

  // Helper to start playback on an audio element
  const playAudioUrl = (url: string) => {
    try {
      const audio = new Audio(url);
      currentAudioElement = audio;
      audio.playbackRate = Math.max(0.6, Math.min(1.5, rate));

      isSpeaking = true;
      currentSpeakingText = cleanText;
      notifyListeners();

      audio.onended = () => {
        isSpeaking = false;
        currentSpeakingText = null;
        currentAudioElement = null;
        notifyListeners();
      };

      audio.onerror = () => {
        console.warn('Google TTS audio playback failed, falling back to browser synthesis.');
        currentAudioElement = null;
        speakWithBrowserSynthesis(cleanText, rate);
      };

      audio.play().catch((err) => {
        console.warn('Audio play prevented or interrupted:', err?.message);
        speakWithBrowserSynthesis(cleanText, rate);
      });
    } catch {
      speakWithBrowserSynthesis(cleanText, rate);
    }
  };

  // 1. Check in-memory cache
  if (audioBlobCache.has(cacheKey)) {
    const cachedUrl = audioBlobCache.get(cacheKey)!;
    playAudioUrl(cachedUrl);
    return;
  }

  // 2. Fetch from Google TTS endpoint
  try {
    const response = await fetch(`/api/tts?voice=${encodeURIComponent(voice)}&text=${encodeURIComponent(cleanText)}`);

    if (!response.ok) {
      throw new Error(`TTS server returned status ${response.status}`);
    }

    const blob = await response.blob();
    const objectUrl = URL.createObjectURL(blob);
    audioBlobCache.set(cacheKey, objectUrl);

    playAudioUrl(objectUrl);
  } catch (err: any) {
    console.warn('Could not load Google TTS from server, using local synthesis:', err?.message);
    speakWithBrowserSynthesis(cleanText, rate);
  }
}

export function speakEnglishSlow(text: string): void {
  speakEnglish(text, 0.72, { slow: true });
}
