import { ALL_VOCABULARY } from '../data/hacks';

export interface DetectionResult {
  ukrWord: string;
  engWord: string;
  ipa: string;
  ruleTitle: string;
  ruleExplanation: string;
  isExactMatch: boolean;
  isTrap: boolean;
  trapNote?: string;
}

// Map common Ukrainian words & roots to accurate translations
const MORPHOLOGY_DICTIONARY: Record<string, { eng: string; ipa: string; rule: string; explanation: string }> = {
  безвідповідальний: {
    eng: 'irresponsible',
    ipa: '/ˌɪr.ɪˈspɒn.sə.bəl/',
    rule: 'Префікс «без-» ➔ «ir-» (перед «r»)',
    explanation: 'Корінь responsible починається на літеру «r», тому для заперечення використовується асимільований префікс «ir-».',
  },
  відповідальний: {
    eng: 'responsible',
    ipa: '/rɪˈspɒn.sə.bəl/',
    rule: 'Базове слово',
    explanation: 'Міжнародне прикметникове закінчення -ible для вираження обов\'язку.',
  },
  бездротовий: {
    eng: 'wireless',
    ipa: '/ˈwaɪə.ləs/',
    rule: 'Префікс «без-» ➔ Суфікс «-less»',
    explanation: 'В англійській мові частка відсутності прикріплюється до іменника в кінці (wire + less = wireless).',
  },
  безкоштовний: {
    eng: 'free / costless',
    ipa: '/friː/',
    rule: 'Заперечення вартості',
    explanation: 'В англійській мові вживається слово «free» або суфікс «-less».',
  },
  безмежний: {
    eng: 'limitless / boundless',
    ipa: '/ˈlɪm.ɪt.ləs/',
    rule: 'Префікс «без-» ➔ Суфікс «-less»',
    explanation: 'Іменник limit (межа) з суфіксом відсутності -less утворює прикметник безмежний.',
  },
  безхмарний: {
    eng: 'cloudless',
    ipa: '/ˈklaʊd.ləs/',
    rule: 'Префікс «без-» ➔ Суфікс «-less»',
    explanation: 'Cloud (хмара) + less (без) = cloudless (безхмарний).',
  },
  бездоганний: {
    eng: 'flawless',
    ipa: '/ˈflɔː.ləs/',
    rule: 'Префікс «без-» ➔ Суфікс «-less»',
    explanation: 'Flaw (вада) + less (без) = flawless (бездоганний).',
  },
  безцінний: {
    eng: 'priceless',
    ipa: '/ˈpraɪs.ləs/',
    rule: 'Префікс «без-» ➔ Суфікс «-less»',
    explanation: 'Price (ціна) + less (без) = priceless (настільки цінний, що не має ціни).',
  },
  інформація: {
    eng: 'information',
    ipa: '/ˌɪn.fəˈmeɪ.ʃən/',
    rule: '-ція ➔ -tion',
    explanation: 'Латинський корінь зі стандартною заміною закінчення -ція на -tion. В англійській це незлічуваний іменник!',
  },
  нація: {
    eng: 'nation',
    ipa: '/ˈneɪ.ʃən/',
    rule: '-ція ➔ -tion',
    explanation: 'Класичний латинський іменник із заміною -ція на -tion.',
  },
  ситуація: {
    eng: 'situation',
    ipa: '/ˌsɪtʃ.uˈeɪ.ʃən/',
    rule: '-ція ➔ -tion',
    explanation: 'Міжнародний іменник, суфікс -ція переходить у -tion.',
  },
  традиція: {
    eng: 'tradition',
    ipa: '/trəˈdɪʃ.ən/',
    rule: '-ція ➔ -tion',
    explanation: 'Міжнародне слово, латинський суфікс -tion.',
  },
  організація: {
    eng: 'organization',
    ipa: '/ˌɔː.ɡən.aɪˈzeɪ.ʃən/',
    rule: '-ція ➔ -tion',
    explanation: 'Міжнародний термін зі стандартним переходом -ція у -tion.',
  },
  комунікація: {
    eng: 'communication',
    ipa: '/kəˌmjuː.nɪˈkeɪ.ʃən/',
    rule: '-ція ➔ -tion',
    explanation: 'Латинський суфікс -tion для позначення взаємодії та зв\'язку.',
  },
  романтичний: {
    eng: 'romantic',
    ipa: '/rəʊˈmæn.tɪk/',
    rule: '-чний ➔ -ic',
    explanation: 'Прикметник естетики та культури із заміною -чний на -ic.',
  },
  магічний: {
    eng: 'magical',
    ipa: '/ˈmædʒ.ɪ.kəl/',
    rule: '-ічний ➔ -ical',
    explanation: 'Для низки прикметників суфікс набуває форми -ical (magic ➔ magical).',
  },
  історичний: {
    eng: 'historic / historical',
    ipa: '/hɪˈstɒr.ɪk/',
    rule: '-ичний ➔ -ic / -ical',
    explanation: 'Historic — значущий в історії; Historical — той, що належить до минулих подій.',
  },
  реальність: {
    eng: 'reality',
    ipa: '/riˈæl.ə.ti/',
    rule: '-ість ➔ -ity',
    explanation: 'Абстрактний іменник властивості. Латинське закінчення -ість переходить у -ity.',
  },
  активність: {
    eng: 'activity',
    ipa: '/ækˈtɪv.ə.ti/',
    rule: '-ість ➔ -ity',
    explanation: 'Active (активний) + ity (-ість) = activity (активність).',
  },
  темрява: {
    eng: 'darkness',
    ipa: '/ˈdɑːk.nəs/',
    rule: '-ість / -ота ➔ -ness',
    explanation: 'Германський корінь dark + суфікс стану -ness.',
  },
  доброта: {
    eng: 'kindness',
    ipa: '/ˈkaɪnd.nəs/',
    rule: '-ота ➔ -ness',
    explanation: 'Kind (добрий) + ness = kindness (доброта).',
  },
  глобальний: {
    eng: 'global',
    ipa: '/ˈɡləʊ.bəl/',
    rule: '-альний ➔ -al',
    explanation: 'Міжнародне прикметникове закінчення -al (globe ➔ global).',
  },
  центральний: {
    eng: 'central',
    ipa: '/ˈsen.trəl/',
    rule: '-альний ➔ -al',
    explanation: 'Міжнародний прикметник: centre ➔ central.',
  },
  активний: {
    eng: 'active',
    ipa: '/ˈæk.tɪv/',
    rule: '-ивний ➔ -ive',
    explanation: 'Прикметник потенціалу дії із заміною -ивний на -ive.',
  },
  прогресивний: {
    eng: 'progressive',
    ipa: '/prəˈɡres.ɪv/',
    rule: '-ивний ➔ -ive',
    explanation: 'Міжнародний прикметник розвитку: progress ➔ progressive.',
  },
  перезавантажити: {
    eng: 'restart / reboot',
    ipa: '/ˌriːˈstɑːt/',
    rule: 'Префікс «пере-» ➔ «re-»',
    explanation: 'Префікс re- передає дію відновлення або повторного запуску процесу.',
  },
  переписати: {
    eng: 'rewrite',
    ipa: '/ˌriːˈraɪt/',
    rule: 'Префікс «пере-» ➔ «re-»',
    explanation: 'Write (писати) + re- (пере-) = rewrite (переписати).',
  },
  переосмислити: {
    eng: 'rethink',
    ipa: '/ˌriːˈθɪŋk/',
    rule: 'Префікс «пере-» ➔ «re-»',
    explanation: 'Think (думати) + re- (пере-) = rethink (переосмислити).',
  },
  переспати: {
    eng: 'oversleep',
    ipa: '/ˌəʊ.vəˈsliːp/',
    rule: 'Префікс «пере-» ➔ «over-»',
    explanation: 'Надлишок часу сну (проспати) виражається префіксом over-.',
  },
  переїсти: {
    eng: 'overeat',
    ipa: '/ˌəʊ.vəˈriːt/',
    rule: 'Префікс «пере-» ➔ «over-»',
    explanation: 'Надлишок їжі передається англійським префіксом over-.',
  },
  журналіст: {
    eng: 'journalist',
    ipa: '/ˈdʒɜː.nə.lɪst/',
    rule: 'Діяч ➔ -ist',
    explanation: 'Позначення професії за латинською моделлю: -іст переходить у -ist.',
  },
  комфортний: {
    eng: 'comfortable',
    ipa: '/ˈkʌm.fə.tə.bəl/',
    rule: '-абельний ➔ -able',
    explanation: 'Суфікс придатності або зручності: comfort + able = comfortable.',
  },
  розвиток: {
    eng: 'development',
    ipa: '/dɪˈvel.əp.mənt/',
    rule: 'Іменник дії ➔ -ment',
    explanation: 'Суфікс -ment утворює іменник від дієслова develop (розвивати).',
  },
  магазин: {
    eng: 'shop / store',
    ipa: '/ʃɒp/',
    rule: '⚠️ Пастка «Фальшивий друг»',
    explanation: 'ОБЕРЕЖНО! «Magazine» англійською означає журнал, а магазин — це «shop» або «store».',
  },
  журнал: {
    eng: 'magazine',
    ipa: '/ˌmæɡ.əˈziːn/',
    rule: '⚠️ Пастка «Фальшивий друг»',
    explanation: '«Magazine» — це журнал, а не крамниця! Не плутайте зі словом shop.',
  },
  тканина: {
    eng: 'fabric',
    ipa: '/ˈfæb.rɪk/',
    rule: '⚠️ Пастка «Фальшивий друг»',
    explanation: '«Fabric» означає тканина. Фабрика англійською — «factory».',
  },
  точний: {
    eng: 'accurate',
    ipa: '/ˈæk.jə.rət/',
    rule: '⚠️ Пастка «Фальшивий друг»',
    explanation: '«Accurate» означає точний або достовірний. Акуратний (охайний) — це «neat» або «tidy».',
  },
  шеф: {
    eng: 'boss / manager',
    ipa: '/bɒs/',
    rule: '⚠️ Пастка «Фальшивий друг»',
    explanation: '«Chef» в англійській мові — це виключно шеф-кухар! Керівник — це «boss».',
  },
  актуальний: {
    eng: 'relevant / current',
    ipa: '/ˈrel.ə.vənt/',
    rule: '⚠️ Пастка «Фальшивий друг»',
    explanation: '«Actual» англійською означає реальний/фактичний. Актуальний (на часі) — це «relevant».',
  },
};

// Normalize word (strip case, trailing punctuation, and common Ukrainian inflection suffixes)
function normalizeUkr(str: string): string {
  let cleaned = str.trim().toLowerCase().replace(/[.,!?:;()"'-]/g, '');
  // Lemmatize common case inflections for -ція
  if (cleaned.endsWith('ції') || cleaned.endsWith('цію') || cleaned.endsWith('цією')) {
    cleaned = cleaned.replace(/(ції|цію|цією)$/, 'ція');
  }
  // Lemmatize -чний
  if (cleaned.endsWith('чного') || cleaned.endsWith('чному') || cleaned.endsWith('чним') || cleaned.endsWith('чна') || cleaned.endsWith('чне') || cleaned.endsWith('чні')) {
    cleaned = cleaned.replace(/(чного|чному|чним|чна|чне|чні)$/, 'чний');
  }
  // Lemmatize -альний
  if (cleaned.endsWith('ального') || cleaned.endsWith('альному') || cleaned.endsWith('альна') || cleaned.endsWith('альне') || cleaned.endsWith('альні')) {
    cleaned = cleaned.replace(/(ального|альному|альна|альне|альні)$/, 'альний');
  }
  // Lemmatize -ивний
  if (cleaned.endsWith('ивного') || cleaned.endsWith('ивному') || cleaned.endsWith('ивна') || cleaned.endsWith('ивне') || cleaned.endsWith('ивні')) {
    cleaned = cleaned.replace(/(ивного|ивному|ивна|ивне|ивні)$/, 'ивний');
  }
  // Lemmatize -овий
  if (cleaned.endsWith('ового') || cleaned.endsWith('овому') || cleaned.endsWith('ова') || cleaned.endsWith('ове') || cleaned.endsWith('ові')) {
    cleaned = cleaned.replace(/(ового|овому|ова|ове|ові)$/, 'овий');
  }
  return cleaned;
}

export function analyzeWord(rawQuery: string): DetectionResult | null {
  const query = rawQuery.trim();
  if (!query) return null;
  const normalized = normalizeUkr(query);

  // 1. Direct match in dictionary
  if (MORPHOLOGY_DICTIONARY[normalized]) {
    const item = MORPHOLOGY_DICTIONARY[normalized];
    const isTrap = item.rule.includes('Пастка') || normalized === 'магазин';
    return {
      ukrWord: rawQuery.trim(),
      engWord: item.eng,
      ipa: item.ipa,
      ruleTitle: item.rule,
      ruleExplanation: item.explanation,
      isExactMatch: true,
      isTrap,
      trapNote: isTrap ? item.explanation : undefined,
    };
  }

  // 2. Exact match in all vocabulary
  const vocabMatch = ALL_VOCABULARY.find(
    (v) =>
      v.ukr.toLowerCase() === normalized ||
      normalizeUkr(v.ukr) === normalized ||
      v.ukr.toLowerCase().includes(normalized)
  );
  if (vocabMatch) {
    return {
      ukrWord: rawQuery.trim(),
      engWord: vocabMatch.eng,
      ipa: vocabMatch.ipa,
      ruleTitle: vocabMatch.rule,
      ruleExplanation: vocabMatch.trap
        ? `⚠️ Застереження: ${vocabMatch.trap}`
        : `Слово відповідає мовному правилу: ${vocabMatch.rule}.`,
      isExactMatch: true,
      isTrap: Boolean(vocabMatch.trap),
      trapNote: vocabMatch.trap,
    };
  }

  // 3. Algorithmic morphological detection
  if (normalized.startsWith('без')) {
    const root = normalized.slice(3);
    if (root.startsWith('р') || root.startsWith('r')) {
      return {
        ukrWord: rawQuery.trim(),
        engWord: 'ir-[корінь] або [корінь]-less',
        ipa: '/ˌɪr-... / ...ləs/',
        ruleTitle: 'Префікс «без-» ➔ «ir-» (перед r) або «-less»',
        ruleExplanation: `Слово починається з частки «без-». Перед коренями на «р» вживається префікс «ir-» (irresponsible), або суфікс «-less».`,
        isExactMatch: false,
        isTrap: false,
      };
    }
    return {
      ukrWord: rawQuery.trim(),
      engWord: `[корінь]-less`,
      ipa: '/...ləs/',
      ruleTitle: 'Префікс «без-» ➔ Суфікс «-less»',
      ruleExplanation: `В англійській мові відсутність ознаки формується додаванням суфікса «-less» до іменника (end ➔ endless, wire ➔ wireless, cloud ➔ cloudless).`,
      isExactMatch: false,
      isTrap: false,
    };
  }

  if (normalized.endsWith('ція') || normalized.endsWith('сія')) {
    return {
      ukrWord: rawQuery.trim(),
      engWord: `[корінь]-tion / -sion`,
      ipa: '/...ʃən/',
      ruleTitle: 'Закінчення «-ція / -сія» ➔ «-tion / -sion»',
      ruleExplanation: `Латинський суфікс віддієслівних іменників. Майже всі українські слова на «-ція» відповідають англійським на «-tion» (nation, communication, generation).`,
      isExactMatch: false,
      isTrap: false,
    };
  }

  if (normalized.endsWith('чний') || normalized.endsWith('ічний')) {
    return {
      ukrWord: rawQuery.trim(),
      engWord: `[корінь]-ic / -ical`,
      ipa: '/...ɪk / ...ɪkəl/',
      ruleTitle: 'Закінчення «-чний» ➔ «-ic / -ical»',
      ruleExplanation: `Прикметники науки, культури, філософії перетворюються на «-ic» (dynamic, romantic) або «-ical» (magical, practical).`,
      isExactMatch: false,
      isTrap: false,
    };
  }

  if (normalized.endsWith('ість')) {
    return {
      ukrWord: rawQuery.trim(),
      engWord: `[корінь]-ity / -ness`,
      ipa: '/...əti / ...nəs/',
      ruleTitle: 'Закінчення «-ість» ➔ «-ity / -ness»',
      ruleExplanation: `Латинські абстрактні іменники якості набувають суфікса «-ity» (reality, activity), а германські — суфікса «-ness» (darkness, sadness).`,
      isExactMatch: false,
      isTrap: false,
    };
  }

  if (normalized.endsWith('альний') || normalized.endsWith('яльний')) {
    return {
      ukrWord: rawQuery.trim(),
      engWord: `[корінь]-al`,
      ipa: '/...əl/',
      ruleTitle: 'Закінчення «-альний» ➔ «-al»',
      ruleExplanation: `Міжнародні прикметники мають прямий англійський відповідник із суфіксом «-al» (global, central, legal, virtual, formal).`,
      isExactMatch: false,
      isTrap: false,
    };
  }

  if (normalized.endsWith('ивний') || normalized.endsWith('івний')) {
    return {
      ukrWord: rawQuery.trim(),
      engWord: `[корінь]-ive`,
      ipa: '/...ɪv/',
      ruleTitle: 'Закінчення «-ивний» ➔ «-ive»',
      ruleExplanation: `Прикметники дії та потенціалу переходять у «-ive» (active, progressive, attractive, creative).`,
      isExactMatch: false,
      isTrap: false,
    };
  }

  if (normalized.startsWith('пере')) {
    return {
      ukrWord: rawQuery.trim(),
      engWord: `re-[корінь] / over-[корінь]`,
      ipa: '/riː-... / ˌəʊvə-.../',
      ruleTitle: 'Префікс «пере-» ➔ «re-» (повтор) або «over-» (надлишок)',
      ruleExplanation: `Якщо «пере-» означає повторну дію (переписати, перезавантажити) — використовуйте «re-» (rewrite, restart). Якщо надлишок (переїсти, проспати) — використовуйте «over-» (overeat, oversleep).`,
      isExactMatch: false,
      isTrap: false,
    };
  }

  // Fallback analysis
  return {
    ukrWord: rawQuery.trim(),
    engWord: rawQuery.trim(),
    ipa: '/—/',
    ruleTitle: 'Загальний мовний міст',
    ruleExplanation: `Це слово аналізується за загальним словниковим правилом. Спробуйте слова з характерними закінченнями (-ція, -чний, -ість, -альний, без-, пере-).`,
    isExactMatch: false,
    isTrap: false,
  };
}
