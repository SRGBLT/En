/**
 * Mnemonic Engine for Ukrainian English Learners
 * Generates sticky mental hooks, visual anchors, and contrast warnings
 * to help users easily remember difficult vocabulary, false friends, and syntax rules.
 */

export interface MnemonicHook {
  key: string; // normalized word or pattern
  hook: string; // The mnemonic rhyme or association
  visualImage: string; // Visual scene to imagine
  trapWarning: string; // What not to confuse it with
}

export const COMMON_MNEMONICS: Record<string, MnemonicHook> = {
  actual: {
    key: 'actual',
    hook: '«Actual» — це ACT (дія), тобто ФАКТИЧНИЙ! Актуальний англійською — це «relevant».',
    visualImage: 'Уявіть поліцейського детектива, який шукає «фактичні (actual) докази», а не новини.',
    trapWarning: '⚠️ НЕ «актуальний», а «РЕАЛЬНИЙ / ФАКТИЧНИЙ»!',
  },
  sympathetic: {
    key: 'sympathetic',
    hook: '«Sympathy» = СПІВЧУТТЯ! Sympathetic — це той, хто співчуває та розуміє ваше горе.',
    visualImage: 'Уявіть друга, який обіймає вас і слухає зі співчуттям (sympathetic hug).',
    trapWarning: '⚠️ НЕ «симпатичний (вродливий)», а «СПІВЧУТЛИВИЙ»!',
  },
  receipt: {
    key: 'receipt',
    hook: '«Receipt» має тиху букву «p» і означає ЧЕК або квитанцію! А кулінарний рецепт — це «recipe»!',
    visualImage: 'Касир у супермаркеті відриває паперовий чек (receipt) після оплати карткою.',
    trapWarning: '⚠️ НЕ «рецепт лікаря/страви», а «ТОВАРНИЙ ЧЕК / КВИТАНЦІЯ»!',
  },
  fabric: {
    key: 'fabric',
    hook: '«Fabric» — це ТКАНИНА (фабрика робить тканину). Завод або фабрика — це «factory»!',
    visualImage: 'Кравець торкається м\'якої шовкової тканини (soft fabric) на столі.',
    trapWarning: '⚠️ НЕ «завод/фабрика», а «ТКАНИНА»!',
  },
  accurate: {
    key: 'accurate',
    hook: '«Accurate» — це ТОЧНИЙ (як снайперський приціл accuracy). Охайний або чистий — це «neat»!',
    visualImage: 'Стрілець влучає точно в яблучко 10/10 — це «accurate shot».',
    trapWarning: '⚠️ НЕ «акуратний/охайний», а «ТОЧНИЙ / ВИВІРЕНИЙ»!',
  },
  magazine: {
    key: 'magazine',
    hook: '«Magazine» — це глянець або журнал з фотографіями! Магазин англійською — «shop» чи «store».',
    visualImage: 'Глянцевий модний журнал (fashion magazine) на журнальному столику.',
    trapWarning: '⚠️ НЕ «продуктовий магазин», а «ГЛЯНЦЕВИЙ ЖУРНАЛ»!',
  },
  preservative: {
    key: 'preservative',
    hook: '«Preserve» — зберігати їжу. «Preservative» — це харчовий консервант у соці або консервах.',
    visualImage: 'Банка солоних огірків з етикеткою «No artificial preservatives» (без консервантів).',
    trapWarning: '⚠️ НЕ засіб контрацепції, а «ХАРЧОВИЙ КОНСЕРВАНТ»!',
  },
  sensible: {
    key: 'sensible',
    hook: '«Sense» = здоровий глузд. «Sensible» — це розважливий/розумний. А «sensitive» — це чутливий/вразливий.',
    visualImage: 'Керівник спокійно зважує всі ризики та приймає розважливе рішення (sensible decision).',
    trapWarning: '⚠️ НЕ «сенситивний/чутливий», а «РОЗСУДЛИВИЙ / РОЗУМНИЙ»!',
  },
  'make a decision': {
    key: 'make a decision',
    hook: 'Рішення ми СТВОРЮЄМО з нуля, тому завжди «MAKE a decision» (не do)!',
    visualImage: 'Уявіть, що ви берете цеглини і будуєте (make) тверде рішення.',
    trapWarning: '⚠️ Заборонено казати «do a decision» чи «take a decision» (у стандартах US/UK).',
  },
  'take a break': {
    key: 'take a break',
    hook: 'Перерву ми БЕРЕМО собі, щоб відпочити: «TAKE a break»!',
    visualImage: 'Ви берете в руки чашку запашної кави та йдете на 15 хвилин відпочити.',
    trapWarning: '⚠️ НЕ «make a break» і НЕ «do a break»!',
  },
  'interested in': {
    key: 'interested in',
    hook: 'Ми занурюємося В середину теми (IN): «interested IN something»!',
    visualImage: 'Ви пірнаєте В глибину книги з головою (dive IN).',
    trapWarning: '⚠️ НЕ «interested with» і НЕ «interested about»!',
  },
  'look forward to': {
    key: 'look forward to',
    hook: 'Дивимося вперед ДО події: «look forward to + V-ing (герундієм)».',
    visualImage: 'Ви дивитеся у бінокль уперед на пляж і море (looking forward to travelling).',
    trapWarning: '⚠️ Завжди дієслово з -ING після to: «looking forward to meeting you»!',
  },
  'hardly had': {
    key: 'hardly had',
    hook: 'Hardly/Scarcely на початку — це шок і подив! Тому порядок слів перевертається: «Hardly had I... when».',
    visualImage: 'Щойно ви переступили поріг — і бабахнув салют здивування.',
    trapWarning: '⚠️ Після Hardly завжди інверсія (Had + Хто + V3) і сполучник WHEN (не than)!',
  },
  eventually: {
    key: 'eventually',
    hook: '«Eventually» — це ЗРЕДОЮ / В КІНЦІ КІНЦІВ (Event = подія закінчилася). Якщо треба «можливо / раптом» — це «possibly» чи «incidentally»!',
    visualImage: 'Марафонець після важкого забігу врешті-решт (eventually) перетинає фінішну лінію.',
    trapWarning: '⚠️ НЕ «у разі потреби», а «ВРЕШТІ-РЕШТ / КІНЕЦЬ КІНЦЕМ»!',
  },
  chef: {
    key: 'chef',
    hook: '«Chef» — це шеф-кухар у ковпаку на кухні! Начальник на роботі — це «boss» або «chief»!',
    visualImage: 'Кухар у білому ковпаку куштує крем-суп у ресторані.',
    trapWarning: '⚠️ НЕ «начальник/бос», а «ШЕФ-КУХАР»!',
  },
  complexion: {
    key: 'complexion',
    hook: '«Complexion» — це колір і стан шкіри обличчя! Статура тіла — це «physique» або «build»!',
    visualImage: 'Дівчина наносить крем на обличчя для сяючого кольору шкіри (glowing complexion).',
    trapWarning: '⚠️ НЕ «комплекція фігури», а «КОЛІР ШКІРИ ОБЛИЧЧЯ»!',
  },
  intelligent: {
    key: 'intelligent',
    hook: '«Intelligent» — це РОЗУМНИЙ / КМІТЛИВИЙ (Intellect). Ввічливий та вихований — це «polite» або «well-mannered»!',
    visualImage: 'Вчений вирішує складну задачу з фізики на дошці.',
    trapWarning: '⚠️ НЕ «інтелігентний/вихований», а «РОЗУМНИЙ / З ВИСОКИМ IQ»!',
  },
  'make a mistake': {
    key: 'make a mistake',
    hook: 'Помилка — це новий результат нашої дії, тому завжди «MAKE a mistake» (ніколи не do)!',
    visualImage: 'Школяр пише олівцем у зошиті та стирає гумкою помилку.',
    trapWarning: '⚠️ Заборонено казати «do a mistake»!',
  },
  'depend on': {
    key: 'depend on',
    hook: 'Залежність спирається НА щось зверху (ON): «depend ON»! В українській «від», але в англійській «НА»!',
    visualImage: 'Місток спирається на опори (depends ON pillars).',
    trapWarning: '⚠️ НЕ «depend from» і НЕ «depend of»!',
  },
  'pay attention to': {
    key: 'pay attention to',
    hook: 'Увагу ми «оплачуємо» монетами часу (PAY) і спрямовуємо ДО мети (TO): «pay attention TO»!',
    visualImage: 'Кидаєте монетку уваги у скриньку лектора біля дошки.',
    trapWarning: '⚠️ НЕ «give attention on»!',
  },
};

/**
 * Generates an automatic tailored mnemonic explanation for any word or test mistake
 */
export function generateMnemonicForMistake(
  wordOrPrompt: string,
  correctAnswer: string,
  category?: string
): string {
  const norm = (correctAnswer || wordOrPrompt).toLowerCase().trim();

  // 1. Direct hit in common mnemonics
  for (const [key, item] of Object.entries(COMMON_MNEMONICS)) {
    if (norm.includes(key) || wordOrPrompt.toLowerCase().includes(key)) {
      return item.hook;
    }
  }

  // 2. Suffix -tion rule
  if (norm.endsWith('tion')) {
    return `💡 Правило мовного мосту: будь-яке українське слово на «-ція» стає англійським «-tion» з наголосом на передостанній склад (${norm}).`;
  }

  // 3. Suffix -less rule
  if (norm.endsWith('less')) {
    return `💡 Лайфхак пам'яті: українське «без-» перетворюється на хвостик «-less» (wire ➔ wireless, sleep ➔ sleepless). «Less» означає менше / нуль!`;
  }

  // 4. Prefix re- rule
  if (norm.startsWith('re')) {
    return `💡 Лайфхак пам'яті: префікс «re-» означає ПОВТОРЕННЯ або відновлення дії (re-start = повторний старт, re-load = перезавантаження).`;
  }

  // 5. Conditionals rule
  if (category?.includes('Conditional') || wordOrPrompt.includes('If ')) {
    return `💡 Золоте правило умовних речень: після частки IF заборонено ставити WILL! У 1st Conditional — Present Simple (rains), у 2nd — Past Simple (had).`;
  }

  // 6. Collocations make vs do
  if (category?.includes('Make vs Do') || norm === 'make' || norm === 'do') {
    return `💡 Формула пам'яті: «MAKE» використовується для створення нового результату (make a decision, make a mistake, make coffee). «DO» — для рутинних обов'язків (do homework, do business).`;
  }

  // 7. General fallback mnemonic
  return `💡 Асоціація для запам'ятовування: зв'яжіть «${correctAnswer}» із яскравою життєвою дією. Повторіть уголос 3 рази англійською з акцентом на правильний звук.`;
}
