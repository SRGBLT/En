import {
  ReminderSettings,
  TopicRetentionStatus,
  TopicReviewRecord,
  SrsCard,
  MistakeRecord,
  VocabItem,
  ThematicCategoryInfo,
  ThematicWord,
} from '../types';
import { THEMATIC_CATEGORIES, THEMATIC_WORDS, getWordsByCategory } from '../data/thematicWords';

export const REMINDER_SETTINGS_STORAGE_KEY = 'engbridge_reminder_settings_v1';
export const TOPIC_REVIEWS_STORAGE_KEY = 'engbridge_topic_reviews_v1';

export const DEFAULT_REMINDER_SETTINGS: ReminderSettings = {
  enabled: true,
  browserNotificationsEnabled: false,
  reminderTime: '19:00',
  frequency: 'daily',
  remindTopicsDecaying: true,
  remindSrsWords: true,
  remindMistakes: true,
  soundEnabled: true,
};

// Load saved reminder settings
export function loadReminderSettings(): ReminderSettings {
  if (typeof window === 'undefined') return DEFAULT_REMINDER_SETTINGS;
  try {
    const raw = localStorage.getItem(REMINDER_SETTINGS_STORAGE_KEY);
    if (raw) {
      return { ...DEFAULT_REMINDER_SETTINGS, ...JSON.parse(raw) };
    }
  } catch {
    // fallback
  }
  return DEFAULT_REMINDER_SETTINGS;
}

// Save reminder settings
export function saveReminderSettings(settings: ReminderSettings): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(REMINDER_SETTINGS_STORAGE_KEY, JSON.stringify(settings));
  } catch {
    // ignore
  }
}

// Load topic review records
export function loadTopicReviews(): Record<string, TopicReviewRecord> {
  if (typeof window === 'undefined') return {};
  try {
    const raw = localStorage.getItem(TOPIC_REVIEWS_STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch {
    // fallback
  }
  return {};
}

// Save topic review records
export function saveTopicReviews(records: Record<string, TopicReviewRecord>): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(TOPIC_REVIEWS_STORAGE_KEY, JSON.stringify(records));
  } catch {
    // ignore
  }
}

// Record a completed review session for a topic
export function recordTopicReview(
  categoryId: string,
  packNumber: number = 1
): Record<string, TopicReviewRecord> {
  const current = loadTopicReviews();
  const existing = current[categoryId];
  const now = Date.now();

  const masteredPacks = new Set(existing?.masteredPacks || []);
  masteredPacks.add(packNumber);

  const updated: TopicReviewRecord = {
    categoryId,
    lastReviewedAt: now,
    reviewCount: (existing?.reviewCount || 0) + 1,
    masteredPacks: Array.from(masteredPacks),
  };

  const nextRecords = {
    ...current,
    [categoryId]: updated,
  };

  saveTopicReviews(nextRecords);
  return nextRecords;
}

/**
 * Calculates Ebbinghaus memory retention (0-100%) based on:
 * - days elapsed since last review
 * - strength multiplier based on repetition count
 */
export function calculateEbbinghausRetention(
  daysPassed: number,
  reviewCount: number = 0
): number {
  if (daysPassed <= 0.15) return 100; // Reviewed within last ~4 hours

  // Base memory stability increases with each repetition
  // Review 0: stability = 1.2 days
  // Review 1: stability = 2.5 days
  // Review 2: stability = 5.0 days
  // Review 3+: stability = 10.0+ days
  const stability = 1.2 + reviewCount * 1.8;

  // Formula: R = 100 * exp(-days / stability)
  const retention = 100 * Math.exp(-daysPassed / stability);
  return Math.max(5, Math.min(100, Math.round(retention)));
}

/**
 * Compute retention status for all thematic categories
 */
export function computeTopicRetentionStatuses(
  categories: ThematicCategoryInfo[],
  learnedWords: VocabItem[],
  topicReviewRecords: Record<string, TopicReviewRecord>,
  unlockedPacks: Record<string, number>
): TopicRetentionStatus[] {
  const now = Date.now();
  const msInDay = 24 * 60 * 60 * 1000;

  return categories.map((cat) => {
    const record = topicReviewRecords[cat.id];
    const catWords = getWordsByCategory(cat.id);
    const catLearned = catWords.filter((w) =>
      learnedWords.some((lw) => lw.eng.toLowerCase() === w.eng.toLowerCase())
    );

    const highestUnlocked = unlockedPacks[cat.id] || 1;
    const reviewCount = record?.reviewCount || 0;

    let daysPassed = 0;
    let lastReviewedAt = 0;

    if (record?.lastReviewedAt) {
      lastReviewedAt = record.lastReviewedAt;
      daysPassed = Math.max(0, (now - lastReviewedAt) / msInDay);
    } else if (catLearned.length > 0 || highestUnlocked > 1) {
      // User has touched this category earlier, estimate ~4 days ago if no exact timestamp
      daysPassed = 4;
      lastReviewedAt = now - 4 * msInDay;
    } else {
      // Category not yet started
      daysPassed = 0;
      lastReviewedAt = 0;
    }

    let retentionPercent = 100;
    let urgency: TopicRetentionStatus['urgency'] = 'fresh';
    let statusLabel = 'Нова тема';

    if (lastReviewedAt > 0) {
      retentionPercent = calculateEbbinghausRetention(daysPassed, reviewCount);

      if (retentionPercent < 30) {
        urgency = 'critical';
        statusLabel = `Критично (${Math.round(daysPassed)} дн. тому)`;
      } else if (retentionPercent < 55) {
        urgency = 'high';
        statusLabel = `Підзабуто (${Math.round(daysPassed)} дн. тому)`;
      } else if (retentionPercent < 80) {
        urgency = 'medium';
        statusLabel = `Пора освітити (${Math.round(daysPassed)} дн. тому)`;
      } else {
        urgency = 'fresh';
        statusLabel = daysPassed < 1 ? 'Свіжо закріплено' : 'Міцна пам’ять';
      }
    } else {
      // Brand new topic
      retentionPercent = 100;
      urgency = 'fresh';
      statusLabel = 'Готова до старту';
    }

    // Number of words recommended to review
    const dueWordsCount =
      urgency === 'critical' || urgency === 'high'
        ? Math.min(10, Math.max(5, catLearned.length || 10))
        : urgency === 'medium'
        ? Math.min(6, Math.max(3, catLearned.length || 5))
        : 0;

    return {
      categoryId: cat.id,
      title: cat.title,
      engTitle: cat.engTitle,
      icon: cat.icon,
      color: cat.color,
      lastReviewedAt,
      daysPassed: Math.round(daysPassed * 10) / 10,
      retentionPercent,
      urgency,
      statusLabel,
      dueWordsCount,
      totalWordsLearned: catLearned.length,
      recommendedPack: Math.min(highestUnlocked, 30),
    };
  });
}

/**
 * Filter and assemble words due for Spaced Repetition (SRS)
 */
export interface DueWordItem {
  word: VocabItem;
  source: 'srs' | 'mistake' | 'thematic';
  priority: number; // Higher means more urgent
  reason: string;
  categoryTitle?: string;
}

export function getDueReviewWords(
  srsCards: SrsCard[],
  mistakes: MistakeRecord[],
  learnedWords: VocabItem[]
): DueWordItem[] {
  const now = Date.now();
  const seenEng = new Set<string>();
  const dueItems: DueWordItem[] = [];

  // 1. Unmastered Mistakes (Highest priority)
  const activeMistakes = mistakes
    .filter((m) => !m.isMastered)
    .sort((a, b) => b.errorCount - a.errorCount || b.lastMistakeTimestamp - a.lastMistakeTimestamp);

  for (const m of activeMistakes) {
    const engLower = m.correctAnswer.toLowerCase();
    if (!seenEng.has(engLower)) {
      seenEng.add(engLower);
      const vocab: VocabItem = m.vocabItem || {
        eng: m.correctAnswer,
        ukr: m.prompt,
        ipa: '',
        rule: m.explanation || 'Помилка на тесті',
        category: m.category,
        level: m.level || 'A1',
      };
      dueItems.push({
        word: vocab,
        source: 'mistake',
        priority: 100 + m.errorCount * 10,
        reason: `Помилка (${m.errorCount}×): ${m.explanation ? m.explanation.slice(0, 45) : 'потребує закріплення'}`,
      });
    }
  }

  // 2. SRS Cards due based on Leitner Box
  const dueCards = srsCards
    .filter((c) => c.dueDate <= now)
    .sort((a, b) => a.dueDate - b.dueDate);

  for (const c of dueCards) {
    const engLower = c.word.eng.toLowerCase();
    if (!seenEng.has(engLower)) {
      seenEng.add(engLower);
      const daysOverdue = Math.max(0, Math.round((now - c.dueDate) / (24 * 60 * 60 * 1000)));
      dueItems.push({
        word: c.word,
        source: 'srs',
        priority: 50 + (4 - c.box) * 10 + daysOverdue,
        reason: `Box ${c.box} • Термін настав${daysOverdue > 0 ? ` (+${daysOverdue} дн.)` : ''}`,
      });
    }
  }

  // 3. Fallback: if user has learned words but none overdue yet, add early learned words
  if (dueItems.length < 5 && learnedWords.length > 0) {
    for (const lw of learnedWords.slice(0, 8)) {
      const engLower = lw.eng.toLowerCase();
      if (!seenEng.has(engLower)) {
        seenEng.add(engLower);
        dueItems.push({
          word: lw,
          source: 'thematic',
          priority: 20,
          reason: 'Профілактичне закріплення з особистого словника',
        });
      }
    }
  }

  return dueItems.sort((a, b) => b.priority - a.priority);
}

/**
 * Check if today's reminder should be triggered based on scheduled time
 */
export function shouldTriggerScheduledReminder(settings: ReminderSettings): boolean {
  if (!settings.enabled) return false;

  const todayStr = new Date().toISOString().slice(0, 10);
  if (settings.lastNotificationDate === todayStr) {
    return false; // Already notified today
  }

  // Frequency check
  const dayOfWeek = new Date().getDay(); // 0 is Sunday, 6 is Saturday
  if (settings.frequency === 'weekdays' && (dayOfWeek === 0 || dayOfWeek === 6)) {
    return false;
  }

  // Check current time against reminderTime (e.g. "19:00")
  const [targetHour, targetMinute] = settings.reminderTime.split(':').map(Number);
  const now = new Date();
  const currentHour = now.getHours();
  const currentMinute = now.getMinutes();

  if (currentHour > targetHour || (currentHour === targetHour && currentMinute >= targetMinute)) {
    return true;
  }

  return false;
}

/**
 * Request Browser Web Notification permission
 */
export async function requestNotificationPermission(): Promise<NotificationPermission> {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'denied';
  }
  try {
    const permission = await Notification.requestPermission();
    return permission;
  } catch {
    return 'denied';
  }
}

/**
 * Send a Browser Web Notification
 */
export function sendBrowserNotification(
  title: string,
  body: string,
  tag: string = 'engbridge-review-reminder'
): boolean {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return false;
  }
  if (Notification.permission !== 'granted') {
    return false;
  }

  try {
    const notification = new Notification(title, {
      body,
      tag,
      icon: '/favicon.ico',
      badge: '/favicon.ico',
    });

    notification.onclick = () => {
      window.focus();
      notification.close();
    };

    return true;
  } catch {
    return false;
  }
}
