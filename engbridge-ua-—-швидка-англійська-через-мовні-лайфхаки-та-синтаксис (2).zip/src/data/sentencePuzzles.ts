import { CefrLevel, SentencePuzzle } from '../types';

export const SENTENCE_PUZZLES: Record<CefrLevel, SentencePuzzle[]> = {
  "A1": [
    {
      "id": "a1-1",
      "ukr": "Ми п'ємо каву вдома вранці.",
      "words": [
        "We",
        "drink",
        "coffee",
        "at home",
        "in the morning"
      ],
      "rule": "SVOMPT: Subject (We) + Verb (drink) + Object (coffee) + Place (at home) + Time (in the morning).",
      "category": "affirmative",
      "categoryLabel": "Ствердження SVOMPT",
      "alternativeOrders": [
        [
          "In the morning",
          "we",
          "drink",
          "coffee",
          "at home"
        ]
      ],
      "slots": [
        {
          "word": "We",
          "role": "Subject"
        },
        {
          "word": "drink",
          "role": "Verb"
        },
        {
          "word": "coffee",
          "role": "Object"
        },
        {
          "word": "at home",
          "role": "Place"
        },
        {
          "word": "in the morning",
          "role": "Time"
        }
      ]
    },
    {
      "id": "a1-2",
      "ukr": "Він читає книги в бібліотеці щодня.",
      "words": [
        "He",
        "reads",
        "books",
        "in the library",
        "every day"
      ],
      "rule": "Час (every day) обов'язково йде після місця (in the library).",
      "category": "affirmative",
      "categoryLabel": "Ствердження SVOMPT",
      "alternativeOrders": [
        [
          "Every day",
          "he",
          "reads",
          "books",
          "in the library"
        ]
      ],
      "slots": [
        {
          "word": "He",
          "role": "Subject"
        },
        {
          "word": "reads",
          "role": "Verb"
        },
        {
          "word": "books",
          "role": "Object"
        },
        {
          "word": "in the library",
          "role": "Place"
        },
        {
          "word": "every day",
          "role": "Time"
        }
      ]
    },
    {
      "id": "a1-3",
      "ukr": "Вона грає на гітарі у своїй кімнаті ввечері.",
      "words": [
        "She",
        "plays",
        "the guitar",
        "in her room",
        "in the evening"
      ],
      "rule": "Дієслово у 3-й особі однини (plays) + додаток + місце + час.",
      "category": "affirmative",
      "categoryLabel": "Ствердження SVOMPT",
      "alternativeOrders": [
        [
          "In the evening",
          "she",
          "plays",
          "the guitar",
          "in her room"
        ]
      ],
      "slots": [
        {
          "word": "She",
          "role": "Subject"
        },
        {
          "word": "plays",
          "role": "Verb"
        },
        {
          "word": "the guitar",
          "role": "Object"
        },
        {
          "word": "in her room",
          "role": "Place"
        },
        {
          "word": "in the evening",
          "role": "Time"
        }
      ]
    },
    {
      "id": "a1-4",
      "ukr": "Вони купують свіжі яблука на ринку щосуботи.",
      "words": [
        "They",
        "buy",
        "fresh apples",
        "at the market",
        "every Saturday"
      ],
      "rule": "Прямий порядок слів: хто ➔ що роблять ➔ що ➔ де ➔ коли.",
      "category": "affirmative",
      "categoryLabel": "Ствердження SVOMPT",
      "slots": [
        {
          "word": "They",
          "role": "Subject"
        },
        {
          "word": "buy",
          "role": "Verb"
        },
        {
          "word": "fresh apples",
          "role": "Object"
        },
        {
          "word": "at the market",
          "role": "Place"
        },
        {
          "word": "every Saturday",
          "role": "Time"
        }
      ]
    },
    {
      "id": "a1-5",
      "ukr": "Я не їм м'ясо на вечерю.",
      "words": [
        "I",
        "do not eat",
        "meat",
        "for dinner"
      ],
      "rule": "Заперечення в Present Simple: Subject + do not + V1 + Object + Time/Context.",
      "category": "negative",
      "categoryLabel": "Заперечення",
      "slots": [
        {
          "word": "I",
          "role": "Subject"
        },
        {
          "word": "do not eat",
          "role": "Verb"
        },
        {
          "word": "meat",
          "role": "Object"
        },
        {
          "word": "for dinner",
          "role": "Time"
        }
      ]
    },
    {
      "id": "a1-6",
      "ukr": "Ти розмовляєш англійською на роботі?",
      "words": [
        "Do",
        "you",
        "speak",
        "English",
        "at work"
      ],
      "rule": "Загальне запитання: Допоміжне Do + Subject + Verb + Object + Place?",
      "category": "question",
      "categoryLabel": "Питання (Do you)",
      "slots": [
        {
          "word": "Do",
          "role": "Auxiliary"
        },
        {
          "word": "you",
          "role": "Subject"
        },
        {
          "word": "speak",
          "role": "Verb"
        },
        {
          "word": "English",
          "role": "Object"
        },
        {
          "word": "at work",
          "role": "Place"
        }
      ]
    },
    {
      "id": "a1-7",
      "ukr": "Де вони живуть улітку?",
      "words": [
        "Where",
        "do",
        "they",
        "live",
        "in summer"
      ],
      "rule": "Спеціальне запитання: Wh-word + do/does + Subject + Verb + Time?",
      "category": "question",
      "categoryLabel": "Wh- Питання",
      "slots": [
        {
          "word": "Where",
          "role": "Auxiliary"
        },
        {
          "word": "do",
          "role": "Auxiliary"
        },
        {
          "word": "they",
          "role": "Subject"
        },
        {
          "word": "live",
          "role": "Verb"
        },
        {
          "word": "in summer",
          "role": "Time"
        }
      ]
    },
    {
      "id": "a1-8",
      "ukr": "Мій брат дивиться новини онлайн пізно ввечері.",
      "words": [
        "My brother",
        "watches",
        "news",
        "online",
        "late at night"
      ],
      "rule": "Subject (My brother) + Verb (watches) + Object (news) + Place (online) + Time (late at night).",
      "category": "affirmative",
      "categoryLabel": "Ствердження SVOMPT",
      "slots": [
        {
          "word": "My brother",
          "role": "Subject"
        },
        {
          "word": "watches",
          "role": "Verb"
        },
        {
          "word": "news",
          "role": "Object"
        },
        {
          "word": "online",
          "role": "Place"
        },
        {
          "word": "late at night",
          "role": "Time"
        }
      ]
    },
    {
      "id": "a1-9",
      "ukr": "Я вчу нові англійські слова вдома щовечора.",
      "words": [
        "I",
        "learn",
        "new English words",
        "at home",
        "every evening"
      ],
      "rule": "Дотримуйтесь SVOMPT: додаток (new words) передує місцю (at home) та часу (every evening).",
      "category": "affirmative",
      "categoryLabel": "Ствердження SVOMPT",
      "slots": [
        {
          "word": "I",
          "role": "Subject"
        },
        {
          "word": "learn",
          "role": "Verb"
        },
        {
          "word": "new English words",
          "role": "Object"
        },
        {
          "word": "at home",
          "role": "Place"
        },
        {
          "word": "every evening",
          "role": "Time"
        }
      ]
    },
    {
      "id": "a1-10",
      "ukr": "Вона не п'є солодкий чай після шостої години.",
      "words": [
        "She",
        "does not drink",
        "sweet tea",
        "after six o'clock"
      ],
      "rule": "Для 3-ї особи (he/she/it) заперечення будується з does not + базове дієслово без -s.",
      "category": "negative",
      "categoryLabel": "Заперечення (does not)",
      "slots": [
        {
          "word": "She",
          "role": "Subject"
        },
        {
          "word": "does not drink",
          "role": "Verb"
        },
        {
          "word": "sweet tea",
          "role": "Object"
        },
        {
          "word": "after six o'clock",
          "role": "Time"
        }
      ]
    },
    {
      "id": "a1-11",
      "ukr": "Твій друг працює в офісі у Києві?",
      "words": [
        "Does",
        "your friend",
        "work",
        "in the office",
        "in Kyiv"
      ],
      "rule": "Питання з 3-ю особою: Does + підмет + дієслово в початковій формі + обставини місця.",
      "category": "question",
      "categoryLabel": "Питання (Does)",
      "slots": [
        {
          "word": "Does",
          "role": "Auxiliary"
        },
        {
          "word": "your friend",
          "role": "Subject"
        },
        {
          "word": "work",
          "role": "Verb"
        },
        {
          "word": "in the office",
          "role": "Place"
        },
        {
          "word": "in Kyiv",
          "role": "Place"
        }
      ]
    },
    {
      "id": "a1-12",
      "ukr": "Коли ти зазвичай снідаєш у вихідні?",
      "words": [
        "When",
        "do",
        "you",
        "eat breakfast",
        "on weekends"
      ],
      "rule": "Wh-питання: Питальне слово (When) + do + підмет (you) + дія (eat breakfast) + час (on weekends).",
      "category": "question",
      "categoryLabel": "Wh- Питання",
      "slots": [
        {
          "word": "When",
          "role": "Auxiliary"
        },
        {
          "word": "do",
          "role": "Auxiliary"
        },
        {
          "word": "you",
          "role": "Subject"
        },
        {
          "word": "eat breakfast",
          "role": "Verb"
        },
        {
          "word": "on weekends",
          "role": "Time"
        }
      ]
    },
    {
      "id": "a1-13",
      "ukr": "Ми гуляємо в зеленому парку після роботи.",
      "words": [
        "We",
        "walk",
        "in the green park",
        "after work"
      ],
      "rule": "Підмет (We) + дія (walk) + місце (in the park) + час (after work). Обставини не розривають дієслово.",
      "category": "affirmative",
      "categoryLabel": "Ствердження SVOMPT",
      "slots": [
        {
          "word": "We",
          "role": "Subject"
        },
        {
          "word": "walk",
          "role": "Verb"
        },
        {
          "word": "in the green park",
          "role": "Place"
        },
        {
          "word": "after work",
          "role": "Time"
        }
      ]
    },
    {
      "id": "a1-14",
      "ukr": "Діти дивляться смішні мультфільми у вітальні зараз.",
      "words": [
        "The children",
        "watch",
        "funny cartoons",
        "in the living room",
        "right now"
      ],
      "rule": "Хто (The children) + дія (watch) + прямий додаток (funny cartoons) + де + коли.",
      "category": "affirmative",
      "categoryLabel": "Ствердження SVOMPT",
      "slots": [
        {
          "word": "The children",
          "role": "Subject"
        },
        {
          "word": "watch",
          "role": "Verb"
        },
        {
          "word": "funny cartoons",
          "role": "Object"
        },
        {
          "word": "in the living room",
          "role": "Place"
        },
        {
          "word": "right now",
          "role": "Time"
        }
      ]
    },
    {
      "id": "a1-15",
      "ukr": "Він не знає відповідь на це питання.",
      "words": [
        "He",
        "does not know",
        "the answer",
        "to this question"
      ],
      "rule": "Дієслово know не використовується з закінченням -s після does not.",
      "category": "negative",
      "categoryLabel": "Заперечення",
      "slots": [
        {
          "word": "He",
          "role": "Subject"
        },
        {
          "word": "does not know",
          "role": "Verb"
        },
        {
          "word": "the answer",
          "role": "Object"
        },
        {
          "word": "to this question",
          "role": "Condition"
        }
      ]
    },
    {
      "id": "a1-16",
      "ukr": "О котрій годині зачиняється магазин увечері?",
      "words": [
        "What time",
        "does",
        "the shop",
        "close",
        "in the evening"
      ],
      "rule": "Складне питальне слово (What time) + does + підмет (the shop) + дієслово (close) + час.",
      "category": "question",
      "categoryLabel": "Wh- Питання",
      "slots": [
        {
          "word": "What time",
          "role": "Auxiliary"
        },
        {
          "word": "does",
          "role": "Auxiliary"
        },
        {
          "word": "the shop",
          "role": "Subject"
        },
        {
          "word": "close",
          "role": "Verb"
        },
        {
          "word": "in the evening",
          "role": "Time"
        }
      ]
    },
    {
      "id": "a1-17",
      "ukr": "Мій колега надсилає важливі листи щоранку.",
      "words": [
        "My colleague",
        "sends",
        "important emails",
        "every morning"
      ],
      "rule": "3-я особа (colleague = he/she) вимагає закінчення -s у дієслові: sends.",
      "category": "affirmative",
      "categoryLabel": "Ствердження SVOMPT",
      "slots": [
        {
          "word": "My colleague",
          "role": "Subject"
        },
        {
          "word": "sends",
          "role": "Verb"
        },
        {
          "word": "important emails",
          "role": "Object"
        },
        {
          "word": "every morning",
          "role": "Time"
        }
      ]
    },
    {
      "id": "a1-18",
      "ukr": "Вони не мають автомобіля в місті.",
      "words": [
        "They",
        "do not have",
        "a car",
        "in the city"
      ],
      "rule": "Заперечення з дієсловом have у простому теперішньому часі: do not have.",
      "category": "negative",
      "categoryLabel": "Заперечення",
      "slots": [
        {
          "word": "They",
          "role": "Subject"
        },
        {
          "word": "do not have",
          "role": "Verb"
        },
        {
          "word": "a car",
          "role": "Object"
        },
        {
          "word": "in the city",
          "role": "Place"
        }
      ]
    },
    {
      "id": "a1-19",
      "ukr": "Чому ти замовляєш піцу пізно вночі?",
      "words": [
        "Why",
        "do",
        "you",
        "order",
        "pizza",
        "late at night"
      ],
      "rule": "Спеціальне питання: Why + do + you + дієслово (order) + додаток (pizza) + обставина часу.",
      "category": "question",
      "categoryLabel": "Wh- Питання",
      "slots": [
        {
          "word": "Why",
          "role": "Auxiliary"
        },
        {
          "word": "do",
          "role": "Auxiliary"
        },
        {
          "word": "you",
          "role": "Subject"
        },
        {
          "word": "order",
          "role": "Verb"
        },
        {
          "word": "pizza",
          "role": "Object"
        },
        {
          "word": "late at night",
          "role": "Time"
        }
      ]
    },
    {
      "id": "a1-20",
      "ukr": "Студенти уважно слухають викладача на уроці.",
      "words": [
        "The students",
        "listen to",
        "the teacher",
        "carefully",
        "in class"
      ],
      "rule": "SVOMPT: Subject (students) + Verb (listen to) + Object (teacher) + Manner (carefully) + Place (in class).",
      "category": "affirmative",
      "categoryLabel": "Ствердження SVOMPT",
      "slots": [
        {
          "word": "The students",
          "role": "Subject"
        },
        {
          "word": "listen to",
          "role": "Verb"
        },
        {
          "word": "the teacher",
          "role": "Object"
        },
        {
          "word": "carefully",
          "role": "Manner"
        },
        {
          "word": "in class",
          "role": "Place"
        }
      ]
    },
    {
      "id": "a1-21",
      "ukr": "Вона готує смачну кашу на кухні щодня.",
      "words": [
        "She",
        "cooks",
        "delicious porridge",
        "in the kitchen",
        "every day"
      ],
      "rule": "Обставина місця (in the kitchen) стоїть перед обставиною часу (every day).",
      "category": "affirmative",
      "categoryLabel": "Ствердження SVOMPT",
      "slots": [
        {
          "word": "She",
          "role": "Subject"
        },
        {
          "word": "cooks",
          "role": "Verb"
        },
        {
          "word": "delicious porridge",
          "role": "Object"
        },
        {
          "word": "in the kitchen",
          "role": "Place"
        },
        {
          "word": "every day",
          "role": "Time"
        }
      ]
    },
    {
      "id": "a1-22",
      "ukr": "Ми не дивимося телевізор у будні дні.",
      "words": [
        "We",
        "do not watch",
        "television",
        "on weekdays"
      ],
      "rule": "Subject + do not + watch + television + on weekdays.",
      "category": "negative",
      "categoryLabel": "Заперечення",
      "slots": [
        {
          "word": "We",
          "role": "Subject"
        },
        {
          "word": "do not watch",
          "role": "Verb"
        },
        {
          "word": "television",
          "role": "Object"
        },
        {
          "word": "on weekdays",
          "role": "Time"
        }
      ]
    },
    {
      "id": "a1-23",
      "ukr": "Скільки чашок кави ти п'єш щодня?",
      "words": [
        "How many cups of coffee",
        "do",
        "you",
        "drink",
        "every day"
      ],
      "rule": "Питальне словосполучення + do + підмет + дієслово + час.",
      "category": "question",
      "categoryLabel": "Wh- Питання",
      "slots": [
        {
          "word": "How many cups of coffee",
          "role": "Object"
        },
        {
          "word": "do",
          "role": "Auxiliary"
        },
        {
          "word": "you",
          "role": "Subject"
        },
        {
          "word": "drink",
          "role": "Verb"
        },
        {
          "word": "every day",
          "role": "Time"
        }
      ]
    },
    {
      "id": "a1-24",
      "ukr": "Мій тато ремонтує велосипед у гаражі у неділю.",
      "words": [
        "My dad",
        "fixes",
        "the bicycle",
        "in the garage",
        "on Sunday"
      ],
      "rule": "Закінчення дієслова на -es (fixes) після шиплячого звуку [ks] для 3-ї особи однини.",
      "category": "affirmative",
      "categoryLabel": "Ствердження SVOMPT",
      "slots": [
        {
          "word": "My dad",
          "role": "Subject"
        },
        {
          "word": "fixes",
          "role": "Verb"
        },
        {
          "word": "the bicycle",
          "role": "Object"
        },
        {
          "word": "in the garage",
          "role": "Place"
        },
        {
          "word": "on Sunday",
          "role": "Time"
        }
      ]
    },
    {
      "id": "a1-25",
      "ukr": "Я люблю гуляти з собакою біля озера.",
      "words": [
        "I",
        "like to walk",
        "with my dog",
        "near the lake"
      ],
      "rule": "Дієслово like з інфінітивом to walk + супровідний додаток + місце.",
      "category": "affirmative",
      "categoryLabel": "Ствердження SVOMPT",
      "slots": [
        {
          "word": "I",
          "role": "Subject"
        },
        {
          "word": "like to walk",
          "role": "Verb"
        },
        {
          "word": "with my dog",
          "role": "Object"
        },
        {
          "word": "near the lake",
          "role": "Place"
        }
      ]
    },
    {
      "id": "a1-26",
      "ukr": "Вона не грає у футбол з друзями.",
      "words": [
        "She",
        "does not play",
        "football",
        "with friends"
      ],
      "rule": "Заперечення: She + does not + play (без артикля перед назвами видів спорту).",
      "category": "negative",
      "categoryLabel": "Заперечення",
      "slots": [
        {
          "word": "She",
          "role": "Subject"
        },
        {
          "word": "does not play",
          "role": "Verb"
        },
        {
          "word": "football",
          "role": "Object"
        },
        {
          "word": "with friends",
          "role": "Manner"
        }
      ]
    },
    {
      "id": "a1-27",
      "ukr": "Твої батьки розмовляють французькою мовою вдома?",
      "words": [
        "Do",
        "your parents",
        "speak",
        "French",
        "at home"
      ],
      "rule": "Your parents — множина (they), тому допоміжне дієслово — Do (не Does).",
      "category": "question",
      "categoryLabel": "Питання (Do)",
      "slots": [
        {
          "word": "Do",
          "role": "Auxiliary"
        },
        {
          "word": "your parents",
          "role": "Subject"
        },
        {
          "word": "speak",
          "role": "Verb"
        },
        {
          "word": "French",
          "role": "Object"
        },
        {
          "word": "at home",
          "role": "Place"
        }
      ]
    },
    {
      "id": "a1-28",
      "ukr": "Ми завжди купуємо свіжий хліб у цій пекарні.",
      "words": [
        "We",
        "always buy",
        "fresh bread",
        "in this bakery"
      ],
      "rule": "Прислівник частоти always ставиться безпосередньо перед смисловим дієсловом buy.",
      "category": "affirmative",
      "categoryLabel": "Ствердження SVOMPT",
      "slots": [
        {
          "word": "We",
          "role": "Subject"
        },
        {
          "word": "always buy",
          "role": "Verb"
        },
        {
          "word": "fresh bread",
          "role": "Object"
        },
        {
          "word": "in this bakery",
          "role": "Place"
        }
      ]
    },
    {
      "id": "a1-29",
      "ukr": "Він рідко п'є газовану воду в дорозі.",
      "words": [
        "He",
        "rarely drinks",
        "sparkling water",
        "on the road"
      ],
      "rule": "Прислівник частоти rarely перед смисловим дієсловом drinks (зі збереженням закінчення -s).",
      "category": "affirmative",
      "categoryLabel": "Ствердження SVOMPT",
      "slots": [
        {
          "word": "He",
          "role": "Subject"
        },
        {
          "word": "rarely drinks",
          "role": "Verb"
        },
        {
          "word": "sparkling water",
          "role": "Object"
        },
        {
          "word": "on the road",
          "role": "Place"
        }
      ]
    },
    {
      "id": "a1-30",
      "ukr": "Хто живе у цьому старому будинку?",
      "words": [
        "Who",
        "lives",
        "in this old house"
      ],
      "rule": "Питання до підмета з Who: прямий порядок слів без do/does, дієслово з закінченням -s.",
      "category": "question",
      "categoryLabel": "Питання до підмета (Who)",
      "slots": [
        {
          "word": "Who",
          "role": "Subject"
        },
        {
          "word": "lives",
          "role": "Verb"
        },
        {
          "word": "in this old house",
          "role": "Place"
        }
      ]
    }
  ],
  "A2": [
    {
      "id": "a2-1",
      "ukr": "Ми не пішли в парк учора, тому що йшов дощ.",
      "words": [
        "We",
        "did not go",
        "to the park",
        "yesterday",
        "because",
        "it rained"
      ],
      "rule": "Past Simple заперечення (did not go) + обставини + сполучник причини (because).",
      "category": "affirmative",
      "categoryLabel": "Past Simple & Conjunctions",
      "slots": [
        {
          "word": "We",
          "role": "Subject"
        },
        {
          "word": "did not go",
          "role": "Verb"
        },
        {
          "word": "to the park",
          "role": "Place"
        },
        {
          "word": "yesterday",
          "role": "Time"
        },
        {
          "word": "because",
          "role": "Connector"
        },
        {
          "word": "it rained",
          "role": "Condition"
        }
      ]
    },
    {
      "id": "a2-2",
      "ukr": "Тобі слід зателефонувати лікарю прямо зараз.",
      "words": [
        "You",
        "should call",
        "the doctor",
        "right now"
      ],
      "rule": "Модальне дієслово should + базове дієслово без to (call).",
      "category": "affirmative",
      "categoryLabel": "Модальні дієслова (should)",
      "slots": [
        {
          "word": "You",
          "role": "Subject"
        },
        {
          "word": "should call",
          "role": "Verb"
        },
        {
          "word": "the doctor",
          "role": "Object"
        },
        {
          "word": "right now",
          "role": "Time"
        }
      ]
    },
    {
      "id": "a2-3",
      "ukr": "Вона може швидко плавати в басейні.",
      "words": [
        "She",
        "can swim",
        "fast",
        "in the pool"
      ],
      "rule": "Subject (She) + Modal (can) + Verb (swim) + Manner (fast) + Place (in the pool).",
      "category": "affirmative",
      "categoryLabel": "Модальні дієслова (can)",
      "slots": [
        {
          "word": "She",
          "role": "Subject"
        },
        {
          "word": "can swim",
          "role": "Verb"
        },
        {
          "word": "fast",
          "role": "Manner"
        },
        {
          "word": "in the pool",
          "role": "Place"
        }
      ]
    },
    {
      "id": "a2-4",
      "ukr": "Якщо завтра буде сонячно, ми поїдемо на пляж.",
      "words": [
        "If",
        "it is sunny tomorrow",
        "we will go",
        "to the beach"
      ],
      "rule": "1st Conditional: If + Present Simple (it is), Future (will go) у головній частині.",
      "category": "conditional",
      "categoryLabel": "1st Conditional",
      "slots": [
        {
          "word": "If",
          "role": "Connector"
        },
        {
          "word": "it is sunny tomorrow",
          "role": "Condition"
        },
        {
          "word": "we will go",
          "role": "Verb"
        },
        {
          "word": "to the beach",
          "role": "Place"
        }
      ]
    },
    {
      "id": "a2-5",
      "ukr": "Я збираюся відвідати моїх бабусю й дідуся цими вихідними.",
      "words": [
        "I",
        "am going to visit",
        "my grandparents",
        "this weekend"
      ],
      "rule": "Конструкція to be going to для запланованих намірів у майбутньому.",
      "category": "affirmative",
      "categoryLabel": "Конструкція be going to",
      "slots": [
        {
          "word": "I",
          "role": "Subject"
        },
        {
          "word": "am going to visit",
          "role": "Verb"
        },
        {
          "word": "my grandparents",
          "role": "Object"
        },
        {
          "word": "this weekend",
          "role": "Time"
        }
      ]
    },
    {
      "id": "a2-6",
      "ukr": "Ти бачив мій телефон на столі вранці?",
      "words": [
        "Did",
        "you",
        "see",
        "my phone",
        "on the table",
        "this morning"
      ],
      "rule": "Past Simple запитання: Did + Subject + V1 (see) + Object + Place + Time?",
      "category": "question",
      "categoryLabel": "Past Simple запитання",
      "slots": [
        {
          "word": "Did",
          "role": "Auxiliary"
        },
        {
          "word": "you",
          "role": "Subject"
        },
        {
          "word": "see",
          "role": "Verb"
        },
        {
          "word": "my phone",
          "role": "Object"
        },
        {
          "word": "on the table",
          "role": "Place"
        },
        {
          "word": "this morning",
          "role": "Time"
        }
      ]
    },
    {
      "id": "a2-7",
      "ukr": "Він не мусить приходити на зустріч завтра.",
      "words": [
        "He",
        "does not have to come",
        "to the meeting",
        "tomorrow"
      ],
      "rule": "Відсутність необхідності: does not have to (не плутати з забороною mustn't).",
      "category": "negative",
      "categoryLabel": "Модальні дієслова (have to)",
      "slots": [
        {
          "word": "He",
          "role": "Subject"
        },
        {
          "word": "does not have to come",
          "role": "Verb"
        },
        {
          "word": "to the meeting",
          "role": "Place"
        },
        {
          "word": "tomorrow",
          "role": "Time"
        }
      ]
    },
    {
      "id": "a2-8",
      "ukr": "Хоча надворі було холодно, вони пішли на прогулянку.",
      "words": [
        "Although",
        "it was cold outside",
        "they",
        "went for a walk"
      ],
      "rule": "Сполучник поступки Although + підрядне речення + головне речення.",
      "category": "affirmative",
      "categoryLabel": "Сполучники поступки",
      "slots": [
        {
          "word": "Although",
          "role": "Connector"
        },
        {
          "word": "it was cold outside",
          "role": "Condition"
        },
        {
          "word": "they",
          "role": "Subject"
        },
        {
          "word": "went for a walk",
          "role": "Verb"
        }
      ]
    },
    {
      "id": "a2-9",
      "ukr": "Я купив новий ноутбук в онлайн-магазині минулого тижня.",
      "words": [
        "I",
        "bought",
        "a new laptop",
        "in the online store",
        "last week"
      ],
      "rule": "Past Simple правильне вживання: неправильне дієслово bought (V2) + прямий додаток + місце + час.",
      "category": "affirmative",
      "categoryLabel": "Past Simple",
      "slots": [
        {
          "word": "I",
          "role": "Subject"
        },
        {
          "word": "bought",
          "role": "Verb"
        },
        {
          "word": "a new laptop",
          "role": "Object"
        },
        {
          "word": "in the online store",
          "role": "Place"
        },
        {
          "word": "last week",
          "role": "Time"
        }
      ]
    },
    {
      "id": "a2-10",
      "ukr": "Вона не змогла знайти свої ключі вчора ввечері.",
      "words": [
        "She",
        "could not find",
        "her keys",
        "at home",
        "yesterday evening"
      ],
      "rule": "Модальне could not (минулий час від can) + дієслово без частки to.",
      "category": "negative",
      "categoryLabel": "Модальні дієслова (could)",
      "slots": [
        {
          "word": "She",
          "role": "Subject"
        },
        {
          "word": "could not find",
          "role": "Verb"
        },
        {
          "word": "her keys",
          "role": "Object"
        },
        {
          "word": "at home",
          "role": "Place"
        },
        {
          "word": "yesterday evening",
          "role": "Time"
        }
      ]
    },
    {
      "id": "a2-11",
      "ukr": "Куди ти поїдеш у відпустку наступного місяця?",
      "words": [
        "Where",
        "will",
        "you",
        "travel",
        "for vacation",
        "next month"
      ],
      "rule": "Future Simple питання: Where + will + підмет (you) + інфінітив (travel) + мета + час.",
      "category": "question",
      "categoryLabel": "Future Simple питання",
      "slots": [
        {
          "word": "Where",
          "role": "Auxiliary"
        },
        {
          "word": "will",
          "role": "Auxiliary"
        },
        {
          "word": "you",
          "role": "Subject"
        },
        {
          "word": "travel",
          "role": "Verb"
        },
        {
          "word": "for vacation",
          "role": "Condition"
        },
        {
          "word": "next month",
          "role": "Time"
        }
      ]
    },
    {
      "id": "a2-12",
      "ukr": "Він зараз розмовляє по телефону зі своїм менеджером.",
      "words": [
        "He",
        "is speaking",
        "on the phone",
        "with his manager",
        "at the moment"
      ],
      "rule": "Present Continuous: to be (is) + V-ing для дії, яка відбувається просто зараз.",
      "category": "affirmative",
      "categoryLabel": "Present Continuous",
      "slots": [
        {
          "word": "He",
          "role": "Subject"
        },
        {
          "word": "is speaking",
          "role": "Verb"
        },
        {
          "word": "on the phone",
          "role": "Manner"
        },
        {
          "word": "with his manager",
          "role": "Object"
        },
        {
          "word": "at the moment",
          "role": "Time"
        }
      ]
    },
    {
      "id": "a2-13",
      "ukr": "Ми не повинні запізнюватися на рейс в аеропорту.",
      "words": [
        "We",
        "must not be late",
        "for our flight",
        "at the airport"
      ],
      "rule": "Сувора заборона: must not (mustn't) + be late + обставина місця.",
      "category": "negative",
      "categoryLabel": "Модальні дієслова (must not)",
      "slots": [
        {
          "word": "We",
          "role": "Subject"
        },
        {
          "word": "must not be late",
          "role": "Verb"
        },
        {
          "word": "for our flight",
          "role": "Condition"
        },
        {
          "word": "at the airport",
          "role": "Place"
        }
      ]
    },
    {
      "id": "a2-14",
      "ukr": "Якщо ти попросиш про допомогу, колеги підтримають тебе.",
      "words": [
        "If",
        "you ask for help",
        "colleagues",
        "will support you"
      ],
      "rule": "1st Conditional: If + Present Simple (you ask), will + V1 (will support you).",
      "category": "conditional",
      "categoryLabel": "1st Conditional",
      "slots": [
        {
          "word": "If",
          "role": "Connector"
        },
        {
          "word": "you ask for help",
          "role": "Condition"
        },
        {
          "word": "colleagues",
          "role": "Subject"
        },
        {
          "word": "will support you",
          "role": "Verb"
        }
      ]
    },
    {
      "id": "a2-15",
      "ukr": "Потяг прибув на вокзал вчасно сьогодні вранці.",
      "words": [
        "The train",
        "arrived",
        "at the railway station",
        "on time",
        "this morning"
      ],
      "rule": "SVOMPT: Subject (train) + Verb (arrived) + Place (station) + Manner (on time) + Time (this morning).",
      "category": "affirmative",
      "categoryLabel": "Past Simple",
      "slots": [
        {
          "word": "The train",
          "role": "Subject"
        },
        {
          "word": "arrived",
          "role": "Verb"
        },
        {
          "word": "at the railway station",
          "role": "Place"
        },
        {
          "word": "on time",
          "role": "Manner"
        },
        {
          "word": "this morning",
          "role": "Time"
        }
      ]
    },
    {
      "id": "a2-16",
      "ukr": "Чому вона не відповіла на твій дзвінок учора?",
      "words": [
        "Why",
        "did",
        "she",
        "not answer",
        "your phone call",
        "yesterday"
      ],
      "rule": "Заперечне питання у минулому часі: Why + did + she + not answer + додаток + час.",
      "category": "question",
      "categoryLabel": "Wh- Питання (Past)",
      "slots": [
        {
          "word": "Why",
          "role": "Auxiliary"
        },
        {
          "word": "did",
          "role": "Auxiliary"
        },
        {
          "word": "she",
          "role": "Subject"
        },
        {
          "word": "not answer",
          "role": "Verb"
        },
        {
          "word": "your phone call",
          "role": "Object"
        },
        {
          "word": "yesterday",
          "role": "Time"
        }
      ]
    },
    {
      "id": "a2-17",
      "ukr": "Цей ресторан дорожчий за кафе через дорогу.",
      "words": [
        "This restaurant",
        "is more expensive than",
        "the small cafe",
        "across the street"
      ],
      "rule": "Ступені порівняння багатоскладових прикметників: more expensive than + місце.",
      "category": "affirmative",
      "categoryLabel": "Порівняння прикметників",
      "slots": [
        {
          "word": "This restaurant",
          "role": "Subject"
        },
        {
          "word": "is more expensive than",
          "role": "Verb"
        },
        {
          "word": "the small cafe",
          "role": "Object"
        },
        {
          "word": "across the street",
          "role": "Place"
        }
      ]
    },
    {
      "id": "a2-18",
      "ukr": "Я хотів би забронювати столик на двох сьогодні ввечері.",
      "words": [
        "I",
        "would like to book",
        "a table for two",
        "at the restaurant",
        "tonight"
      ],
      "rule": "Ввічливе прохання: would like to + інфінітив + додаток + місце + час.",
      "category": "affirmative",
      "categoryLabel": "Ввічливі форми (would like)",
      "slots": [
        {
          "word": "I",
          "role": "Subject"
        },
        {
          "word": "would like to book",
          "role": "Verb"
        },
        {
          "word": "a table for two",
          "role": "Object"
        },
        {
          "word": "at the restaurant",
          "role": "Place"
        },
        {
          "word": "tonight",
          "role": "Time"
        }
      ]
    },
    {
      "id": "a2-19",
      "ukr": "Коли я прийшов додому, мама готувала вечерю.",
      "words": [
        "When",
        "I arrived home",
        "my mother",
        "was preparing dinner"
      ],
      "rule": "Past Continuous для тривалої дії (was preparing), перерваної короткою дією у Past Simple (arrived).",
      "category": "affirmative",
      "categoryLabel": "Past Continuous & Past Simple",
      "slots": [
        {
          "word": "When",
          "role": "Connector"
        },
        {
          "word": "I arrived home",
          "role": "Condition"
        },
        {
          "word": "my mother",
          "role": "Subject"
        },
        {
          "word": "was preparing dinner",
          "role": "Verb"
        }
      ]
    },
    {
      "id": "a2-20",
      "ukr": "Він вирішив змінити свою професію два роки тому.",
      "words": [
        "He",
        "decided to change",
        "his profession",
        "two years ago"
      ],
      "rule": "Дієслово decide вимагає після себе інфінітива з часткою to: decided to change.",
      "category": "affirmative",
      "categoryLabel": "Past Simple з інфінітивом",
      "slots": [
        {
          "word": "He",
          "role": "Subject"
        },
        {
          "word": "decided to change",
          "role": "Verb"
        },
        {
          "word": "his profession",
          "role": "Object"
        },
        {
          "word": "two years ago",
          "role": "Time"
        }
      ]
    },
    {
      "id": "a2-21",
      "ukr": "Ти коли-небудь пробував традиційну японську їжу?",
      "words": [
        "Have",
        "you",
        "ever tried",
        "traditional Japanese food"
      ],
      "rule": "Present Perfect життєвого досвіду: Have + Subject + ever + V3 (tried).",
      "category": "question",
      "categoryLabel": "Present Perfect питання",
      "slots": [
        {
          "word": "Have",
          "role": "Auxiliary"
        },
        {
          "word": "you",
          "role": "Subject"
        },
        {
          "word": "ever tried",
          "role": "Verb"
        },
        {
          "word": "traditional Japanese food",
          "role": "Object"
        }
      ]
    },
    {
      "id": "a2-22",
      "ukr": "Ми не зможемо завершити звіт до кінця дня.",
      "words": [
        "We",
        "will not be able to finish",
        "the report",
        "by the end of the day"
      ],
      "rule": "Майбутній час від can: will not be able to + початкова форма дієслова.",
      "category": "negative",
      "categoryLabel": "Модальні дієслова у Future",
      "slots": [
        {
          "word": "We",
          "role": "Subject"
        },
        {
          "word": "will not be able to finish",
          "role": "Verb"
        },
        {
          "word": "the report",
          "role": "Object"
        },
        {
          "word": "by the end of the day",
          "role": "Time"
        }
      ]
    },
    {
      "id": "a2-23",
      "ukr": "Вона почувається втомленою, тому йде спати раніше.",
      "words": [
        "She",
        "feels tired",
        "so",
        "she goes to bed earlier"
      ],
      "rule": "Сполучник результату so з'єднує дві прості граматичні основи.",
      "category": "affirmative",
      "categoryLabel": "Складносурядне речення (so)",
      "slots": [
        {
          "word": "She",
          "role": "Subject"
        },
        {
          "word": "feels tired",
          "role": "Verb"
        },
        {
          "word": "so",
          "role": "Connector"
        },
        {
          "word": "she goes to bed earlier",
          "role": "Condition"
        }
      ]
    },
    {
      "id": "a2-24",
      "ukr": "Скільки часу займає дорога до центру міста?",
      "words": [
        "How long",
        "does it take",
        "to get to the city center"
      ],
      "rule": "Безособова конструкція: How long does it take + infinitive.",
      "category": "question",
      "categoryLabel": "Спеціальні питання (How long)",
      "slots": [
        {
          "word": "How long",
          "role": "Time"
        },
        {
          "word": "does it take",
          "role": "Verb"
        },
        {
          "word": "to get to the city center",
          "role": "Place"
        }
      ]
    },
    {
      "id": "a2-25",
      "ukr": "Тобі не слід пити холодну воду, коли болить горло.",
      "words": [
        "You",
        "should not drink",
        "cold water",
        "when your throat hurts"
      ],
      "rule": "Порада/застереження: should not + V1 + додаток + підрядне часу з when.",
      "category": "negative",
      "categoryLabel": "Модальні дієслова (should not)",
      "slots": [
        {
          "word": "You",
          "role": "Subject"
        },
        {
          "word": "should not drink",
          "role": "Verb"
        },
        {
          "word": "cold water",
          "role": "Object"
        },
        {
          "word": "when your throat hurts",
          "role": "Condition"
        }
      ]
    },
    {
      "id": "a2-26",
      "ukr": "Вони планують орендувати квартиру в центрі наступного року.",
      "words": [
        "They",
        "plan to rent",
        "a modern apartment",
        "in the center",
        "next year"
      ],
      "rule": "Subject (They) + plan to rent + Object (apartment) + Place (center) + Time (next year).",
      "category": "affirmative",
      "categoryLabel": "Ствердження SVOMPT",
      "slots": [
        {
          "word": "They",
          "role": "Subject"
        },
        {
          "word": "plan to rent",
          "role": "Verb"
        },
        {
          "word": "a modern apartment",
          "role": "Object"
        },
        {
          "word": "in the center",
          "role": "Place"
        },
        {
          "word": "next year",
          "role": "Time"
        }
      ]
    },
    {
      "id": "a2-27",
      "ukr": "Хто допоміг тобі підготувати цю презентацію вчора?",
      "words": [
        "Who",
        "helped you",
        "prepare this presentation",
        "yesterday"
      ],
      "rule": "Питання до підмета у минулому часі: Who + V2 (helped you) + інфінітив без to + час.",
      "category": "question",
      "categoryLabel": "Питання до підмета (Who in Past)",
      "slots": [
        {
          "word": "Who",
          "role": "Subject"
        },
        {
          "word": "helped you",
          "role": "Verb"
        },
        {
          "word": "prepare this presentation",
          "role": "Object"
        },
        {
          "word": "yesterday",
          "role": "Time"
        }
      ]
    },
    {
      "id": "a2-28",
      "ukr": "Я звик прокидатися о сьомій ранку щодня.",
      "words": [
        "I",
        "am used to waking up",
        "at seven o'clock",
        "every day"
      ],
      "rule": "Конструкція to be used to + V-ing означає звичку до чогось.",
      "category": "affirmative",
      "categoryLabel": "Конструкція be used to",
      "slots": [
        {
          "word": "I",
          "role": "Subject"
        },
        {
          "word": "am used to waking up",
          "role": "Verb"
        },
        {
          "word": "at seven o'clock",
          "role": "Time"
        },
        {
          "word": "every day",
          "role": "Time"
        }
      ]
    },
    {
      "id": "a2-29",
      "ukr": "Він не пам'ятає, куди поклав свій паспорт.",
      "words": [
        "He",
        "does not remember",
        "where he put his passport"
      ],
      "rule": "Непряме питання: після where прямий порядок слів (he put, а не did he put).",
      "category": "negative",
      "categoryLabel": "Непрямий порядок слів",
      "slots": [
        {
          "word": "He",
          "role": "Subject"
        },
        {
          "word": "does not remember",
          "role": "Verb"
        },
        {
          "word": "where he put his passport",
          "role": "Condition"
        }
      ]
    },
    {
      "id": "a2-30",
      "ukr": "Якщо погода не покращиться, ми залишимося вдома.",
      "words": [
        "Unless",
        "the weather improves",
        "we",
        "will stay at home"
      ],
      "rule": "Сполучник Unless означає «якщо не» (if not) і не потребує додаткового заперечення.",
      "category": "conditional",
      "categoryLabel": "Умовні речення (Unless)",
      "slots": [
        {
          "word": "Unless",
          "role": "Connector"
        },
        {
          "word": "the weather improves",
          "role": "Condition"
        },
        {
          "word": "we",
          "role": "Subject"
        },
        {
          "word": "will stay at home",
          "role": "Verb"
        }
      ]
    }
  ],
  "B1": [
    {
      "id": "b1-1",
      "ukr": "Якби у мене було більше часу, я б частіше подорожував.",
      "words": [
        "If",
        "I had",
        "more time",
        "I would travel",
        "more often"
      ],
      "rule": "2nd Conditional: If + Past Simple (had), would + V1 (travel). Частка would після if заборонена.",
      "category": "conditional",
      "categoryLabel": "2nd Conditional",
      "slots": [
        {
          "word": "If",
          "role": "Connector"
        },
        {
          "word": "I had",
          "role": "Condition"
        },
        {
          "word": "more time",
          "role": "Object"
        },
        {
          "word": "I would travel",
          "role": "Verb"
        },
        {
          "word": "more often",
          "role": "Manner"
        }
      ]
    },
    {
      "id": "b1-2",
      "ukr": "Цей міст був збудований інженерами минулого року.",
      "words": [
        "This bridge",
        "was built",
        "by engineers",
        "last year"
      ],
      "rule": "Passive Voice: was/were + V3 (built) + виконавець через «by».",
      "category": "affirmative",
      "categoryLabel": "Пасивний стан (Past Simple)",
      "slots": [
        {
          "word": "This bridge",
          "role": "Subject"
        },
        {
          "word": "was built",
          "role": "Verb"
        },
        {
          "word": "by engineers",
          "role": "Object"
        },
        {
          "word": "last year",
          "role": "Time"
        }
      ]
    },
    {
      "id": "b1-3",
      "ukr": "Ми вже завершили цей проєкт до обіду.",
      "words": [
        "We",
        "have already finished",
        "this project",
        "by noon"
      ],
      "rule": "Present Perfect: have/has + V3 з маркером already між допоміжним і основним дієсловом.",
      "category": "affirmative",
      "categoryLabel": "Present Perfect",
      "slots": [
        {
          "word": "We",
          "role": "Subject"
        },
        {
          "word": "have already finished",
          "role": "Verb"
        },
        {
          "word": "this project",
          "role": "Object"
        },
        {
          "word": "by noon",
          "role": "Time"
        }
      ]
    },
    {
      "id": "b1-4",
      "ukr": "Вона запитала мене, чи можу я допомогти їй.",
      "words": [
        "She",
        "asked me",
        "if",
        "I could help her"
      ],
      "rule": "Reported Speech: непряме запитання з if/whether без інверсії та узгодженням часів (can ➔ could).",
      "category": "affirmative",
      "categoryLabel": "Непряма мова (Reported Speech)",
      "slots": [
        {
          "word": "She",
          "role": "Subject"
        },
        {
          "word": "asked me",
          "role": "Verb"
        },
        {
          "word": "if",
          "role": "Connector"
        },
        {
          "word": "I could help her",
          "role": "Condition"
        }
      ]
    },
    {
      "id": "b1-5",
      "ukr": "Він живе в цьому місті вже понад десять років.",
      "words": [
        "He",
        "has lived",
        "in this city",
        "for more than ten years"
      ],
      "rule": "Present Perfect з прийменником for для позначення тривалості періоду дії дотепер.",
      "category": "affirmative",
      "categoryLabel": "Present Perfect з «for»",
      "slots": [
        {
          "word": "He",
          "role": "Subject"
        },
        {
          "word": "has lived",
          "role": "Verb"
        },
        {
          "word": "in this city",
          "role": "Place"
        },
        {
          "word": "for more than ten years",
          "role": "Time"
        }
      ]
    },
    {
      "id": "b1-6",
      "ukr": "Людина, яка створила цю програму, є генієм.",
      "words": [
        "The person",
        "who developed this software",
        "is",
        "a true genius"
      ],
      "rule": "Означальне речення (Relative Clause) з займенником who для людей.",
      "category": "affirmative",
      "categoryLabel": "Означальні речення (Relative Clause)",
      "slots": [
        {
          "word": "The person",
          "role": "Subject"
        },
        {
          "word": "who developed this software",
          "role": "Condition"
        },
        {
          "word": "is",
          "role": "Verb"
        },
        {
          "word": "a true genius",
          "role": "Object"
        }
      ]
    },
    {
      "id": "b1-7",
      "ukr": "Вам не дозволено паркувати авто перед входом.",
      "words": [
        "You",
        "are not allowed to park",
        "your car",
        "in front of the entrance"
      ],
      "rule": "Конструкція be not allowed to для формальної заборони замість mustn't.",
      "category": "negative",
      "categoryLabel": "Пасивні заборони",
      "slots": [
        {
          "word": "You",
          "role": "Subject"
        },
        {
          "word": "are not allowed to park",
          "role": "Verb"
        },
        {
          "word": "your car",
          "role": "Object"
        },
        {
          "word": "in front of the entrance",
          "role": "Place"
        }
      ]
    },
    {
      "id": "b1-8",
      "ukr": "Він міг би скласти іспит, якби вчився наполегливіше.",
      "words": [
        "He",
        "could pass the exam",
        "if",
        "he studied harder"
      ],
      "rule": "2nd Conditional: could замінює would для вираження фізичної можливості у нереальному теперішньому.",
      "category": "conditional",
      "categoryLabel": "2nd Conditional з «could»",
      "slots": [
        {
          "word": "He",
          "role": "Subject"
        },
        {
          "word": "could pass the exam",
          "role": "Verb"
        },
        {
          "word": "if",
          "role": "Connector"
        },
        {
          "word": "he studied harder",
          "role": "Condition"
        }
      ]
    },
    {
      "id": "b1-9",
      "ukr": "Нові документи ще не були підписані директором.",
      "words": [
        "The new documents",
        "have not been signed",
        "by the director",
        "yet"
      ],
      "rule": "Present Perfect Passive: have/has not been + V3 + виконавець (by) + маркер yet наприкінці.",
      "category": "negative",
      "categoryLabel": "Пасивний стан (Present Perfect)",
      "slots": [
        {
          "word": "The new documents",
          "role": "Subject"
        },
        {
          "word": "have not been signed",
          "role": "Verb"
        },
        {
          "word": "by the director",
          "role": "Object"
        },
        {
          "word": "yet",
          "role": "Time"
        }
      ]
    },
    {
      "id": "b1-10",
      "ukr": "Якби я знав його номер, я б зателефонував йому прямо зараз.",
      "words": [
        "If",
        "I knew his phone number",
        "I would call him",
        "immediately"
      ],
      "rule": "2nd Conditional: If + Past Simple (knew), would + bare infinitive (would call him) + manner/time.",
      "category": "conditional",
      "categoryLabel": "2nd Conditional",
      "slots": [
        {
          "word": "If",
          "role": "Connector"
        },
        {
          "word": "I knew his phone number",
          "role": "Condition"
        },
        {
          "word": "I would call him",
          "role": "Verb"
        },
        {
          "word": "immediately",
          "role": "Time"
        }
      ]
    },
    {
      "id": "b1-11",
      "ukr": "Вона пояснила, що вона забула надіслати файл вчасно.",
      "words": [
        "She",
        "explained that",
        "she had forgotten",
        "to send the file",
        "on time"
      ],
      "rule": "Past Perfect у непрямій мові: had forgotten позначає дію, яка сталася перед поясненням.",
      "category": "affirmative",
      "categoryLabel": "Past Perfect & Непряма мова",
      "slots": [
        {
          "word": "She",
          "role": "Subject"
        },
        {
          "word": "explained that",
          "role": "Connector"
        },
        {
          "word": "she had forgotten",
          "role": "Verb"
        },
        {
          "word": "to send the file",
          "role": "Object"
        },
        {
          "word": "on time",
          "role": "Time"
        }
      ]
    },
    {
      "id": "b1-12",
      "ukr": "Чому ти ще не подав заявку на цю вакансію?",
      "words": [
        "Why",
        "have",
        "you",
        "not applied for",
        "this job",
        "yet"
      ],
      "rule": "Present Perfect спеціальне заперечне питання: Why + have + you + not applied + Object + yet.",
      "category": "question",
      "categoryLabel": "Present Perfect питання",
      "slots": [
        {
          "word": "Why",
          "role": "Auxiliary"
        },
        {
          "word": "have",
          "role": "Auxiliary"
        },
        {
          "word": "you",
          "role": "Subject"
        },
        {
          "word": "not applied for",
          "role": "Verb"
        },
        {
          "word": "this job",
          "role": "Object"
        },
        {
          "word": "yet",
          "role": "Time"
        }
      ]
    },
    {
      "id": "b1-13",
      "ukr": "Книга, яку ти мені порекомендував, надзвичайно цікава.",
      "words": [
        "The book",
        "that you recommended to me",
        "is",
        "extremely interesting"
      ],
      "rule": "Defining Relative Clause: that/which приєднує уточнення безпосередньо до іменника.",
      "category": "affirmative",
      "categoryLabel": "Означальні речення (that)",
      "slots": [
        {
          "word": "The book",
          "role": "Subject"
        },
        {
          "word": "that you recommended to me",
          "role": "Condition"
        },
        {
          "word": "is",
          "role": "Verb"
        },
        {
          "word": "extremely interesting",
          "role": "Object"
        }
      ]
    },
    {
      "id": "b1-14",
      "ukr": "Він раніше жив у Лондоні, але тепер живе в Україні.",
      "words": [
        "He",
        "used to live",
        "in London",
        "but now",
        "he lives in Ukraine"
      ],
      "rule": "Конструкція used to + V1 позначає минулу звичку або стан, якого більше немає.",
      "category": "affirmative",
      "categoryLabel": "Конструкція used to",
      "slots": [
        {
          "word": "He",
          "role": "Subject"
        },
        {
          "word": "used to live",
          "role": "Verb"
        },
        {
          "word": "in London",
          "role": "Place"
        },
        {
          "word": "but now",
          "role": "Connector"
        },
        {
          "word": "he lives in Ukraine",
          "role": "Condition"
        }
      ]
    },
    {
      "id": "b1-15",
      "ukr": "Ми могли б зустрітися раніше, якби ви не застрягли в заторі.",
      "words": [
        "We",
        "could meet earlier",
        "if",
        "you were not stuck in traffic"
      ],
      "rule": "2nd Conditional: could meet + if + Past Simple (were not stuck).",
      "category": "conditional",
      "categoryLabel": "2nd Conditional",
      "slots": [
        {
          "word": "We",
          "role": "Subject"
        },
        {
          "word": "could meet earlier",
          "role": "Verb"
        },
        {
          "word": "if",
          "role": "Connector"
        },
        {
          "word": "you were not stuck in traffic",
          "role": "Condition"
        }
      ]
    },
    {
      "id": "b1-16",
      "ukr": "Тобі краще не говорити з ним про це сьогодні.",
      "words": [
        "You",
        "had better not speak",
        "to him",
        "about this topic",
        "today"
      ],
      "rule": "Конструкція had better not + bare infinitive виражає наполегливу пораду/попередження.",
      "category": "negative",
      "categoryLabel": "Конструкція had better",
      "slots": [
        {
          "word": "You",
          "role": "Subject"
        },
        {
          "word": "had better not speak",
          "role": "Verb"
        },
        {
          "word": "to him",
          "role": "Object"
        },
        {
          "word": "about this topic",
          "role": "Condition"
        },
        {
          "word": "today",
          "role": "Time"
        }
      ]
    },
    {
      "id": "b1-17",
      "ukr": "Чи знаєте ви, де знаходиться найближча станція метро?",
      "words": [
        "Do you know",
        "where",
        "the nearest subway station",
        "is located"
      ],
      "rule": "Indirect Question (Ввічливе непряме питання): після where прямий порядок слів (підмет ➔ дієслово).",
      "category": "question",
      "categoryLabel": "Непрямі запитання (Indirect Questions)",
      "slots": [
        {
          "word": "Do you know",
          "role": "Auxiliary"
        },
        {
          "word": "where",
          "role": "Connector"
        },
        {
          "word": "the nearest subway station",
          "role": "Subject"
        },
        {
          "word": "is located",
          "role": "Verb"
        }
      ]
    },
    {
      "id": "b1-18",
      "ukr": "Незважаючи на дощ, матч не було скасовано.",
      "words": [
        "In spite of the rain",
        "the football match",
        "was not canceled",
        "by the referee"
      ],
      "rule": "In spite of + іменник (the rain) + пасивний стан у заперечній формі: was not canceled.",
      "category": "negative",
      "categoryLabel": "Прийменники поступки (In spite of)",
      "slots": [
        {
          "word": "In spite of the rain",
          "role": "Condition"
        },
        {
          "word": "the football match",
          "role": "Subject"
        },
        {
          "word": "was not canceled",
          "role": "Verb"
        },
        {
          "word": "by the referee",
          "role": "Object"
        }
      ]
    },
    {
      "id": "b1-19",
      "ukr": "Я з нетерпінням чекаю на зустріч з вами наступного тижня.",
      "words": [
        "I",
        "am looking forward to meeting",
        "you in person",
        "next week"
      ],
      "rule": "Фразове дієслово look forward to вимагає герундія (-ing): to meeting you.",
      "category": "affirmative",
      "categoryLabel": "Герундій після прийменників",
      "slots": [
        {
          "word": "I",
          "role": "Subject"
        },
        {
          "word": "am looking forward to meeting",
          "role": "Verb"
        },
        {
          "word": "you in person",
          "role": "Object"
        },
        {
          "word": "next week",
          "role": "Time"
        }
      ]
    },
    {
      "id": "b1-20",
      "ukr": "Будівля наразі ремонтується будівельниками.",
      "words": [
        "The historical building",
        "is currently being renovated",
        "by construction workers"
      ],
      "rule": "Present Continuous Passive: is/are being + V3 (renovated) для дії, що відбувається прямо зараз.",
      "category": "affirmative",
      "categoryLabel": "Пасивний стан (Present Continuous)",
      "slots": [
        {
          "word": "The historical building",
          "role": "Subject"
        },
        {
          "word": "is currently being renovated",
          "role": "Verb"
        },
        {
          "word": "by construction workers",
          "role": "Object"
        }
      ]
    },
    {
      "id": "b1-21",
      "ukr": "Він не прийде на вечірку, якщо ви його особисто не запросите.",
      "words": [
        "He",
        "will not come to the party",
        "unless",
        "you invite him personally"
      ],
      "rule": "1st Conditional з unless: головна частина з will not + unless + Present Simple.",
      "category": "conditional",
      "categoryLabel": "1st Conditional з Unless",
      "slots": [
        {
          "word": "He",
          "role": "Subject"
        },
        {
          "word": "will not come to the party",
          "role": "Verb"
        },
        {
          "word": "unless",
          "role": "Connector"
        },
        {
          "word": "you invite him personally",
          "role": "Condition"
        }
      ]
    },
    {
      "id": "b1-22",
      "ukr": "Вона не пам'ятає, о котрій годині починається презентація.",
      "words": [
        "She",
        "does not remember",
        "what time",
        "the presentation starts"
      ],
      "rule": "У підрядному реченні після what time зберігається прямий порядок слів (presentation starts).",
      "category": "negative",
      "categoryLabel": "Підрядні речення",
      "slots": [
        {
          "word": "She",
          "role": "Subject"
        },
        {
          "word": "does not remember",
          "role": "Verb"
        },
        {
          "word": "what time",
          "role": "Connector"
        },
        {
          "word": "the presentation starts",
          "role": "Condition"
        }
      ]
    },
    {
      "id": "b1-23",
      "ukr": "Як довго ви вже працюєте над цим завданням?",
      "words": [
        "How long",
        "have you been working",
        "on this difficult task"
      ],
      "rule": "Present Perfect Continuous: How long + have you been working для процесу, що триває з минулого.",
      "category": "question",
      "categoryLabel": "Present Perfect Continuous",
      "slots": [
        {
          "word": "How long",
          "role": "Time"
        },
        {
          "word": "have you been working",
          "role": "Verb"
        },
        {
          "word": "on this difficult task",
          "role": "Object"
        }
      ]
    },
    {
      "id": "b1-24",
      "ukr": "Він уникає розмов про свої невдачі на роботі.",
      "words": [
        "He",
        "avoids talking",
        "about his past mistakes",
        "at work"
      ],
      "rule": "Дієслово avoid вимагає вживання герундія (-ing): avoids talking.",
      "category": "affirmative",
      "categoryLabel": "Герундій (Gerund)",
      "slots": [
        {
          "word": "He",
          "role": "Subject"
        },
        {
          "word": "avoids talking",
          "role": "Verb"
        },
        {
          "word": "about his past mistakes",
          "role": "Object"
        },
        {
          "word": "at work",
          "role": "Place"
        }
      ]
    },
    {
      "id": "b1-25",
      "ukr": "Вони не знали, що ми вже прибули в готель.",
      "words": [
        "They",
        "did not know that",
        "we had already arrived",
        "at the hotel"
      ],
      "rule": "Узгодження часів: дія минула (did not know), а передминула — Past Perfect (had already arrived).",
      "category": "negative",
      "categoryLabel": "Past Perfect & Узгодження часів",
      "slots": [
        {
          "word": "They",
          "role": "Subject"
        },
        {
          "word": "did not know that",
          "role": "Connector"
        },
        {
          "word": "we had already arrived",
          "role": "Verb"
        },
        {
          "word": "at the hotel",
          "role": "Place"
        }
      ]
    },
    {
      "id": "b1-26",
      "ukr": "Якби я був на вашому місці, я б прийняв цю пропозицію.",
      "words": [
        "If",
        "I were in your shoes",
        "I would accept",
        "this job offer"
      ],
      "rule": "Умовний спосіб: If I were... (не was у формальній англійській), I would accept.",
      "category": "conditional",
      "categoryLabel": "2nd Conditional (If I were you)",
      "slots": [
        {
          "word": "If",
          "role": "Connector"
        },
        {
          "word": "I were in your shoes",
          "role": "Condition"
        },
        {
          "word": "I would accept",
          "role": "Verb"
        },
        {
          "word": "this job offer",
          "role": "Object"
        }
      ]
    },
    {
      "id": "b1-27",
      "ukr": "Чи могли б ви сказати мені, скільки коштує цей квиток?",
      "words": [
        "Could you tell me",
        "how much",
        "this plane ticket",
        "costs"
      ],
      "rule": "Ввічливе непряме запитання: Could you tell me how much + Subject + Verb (costs, без does).",
      "category": "question",
      "categoryLabel": "Ввічливі непрямі питання",
      "slots": [
        {
          "word": "Could you tell me",
          "role": "Auxiliary"
        },
        {
          "word": "how much",
          "role": "Object"
        },
        {
          "word": "this plane ticket",
          "role": "Subject"
        },
        {
          "word": "costs",
          "role": "Verb"
        }
      ]
    },
    {
      "id": "b1-28",
      "ukr": "Команда наполегливо працювала, щоб запустити сервіс вчасно.",
      "words": [
        "The team",
        "worked hard",
        "in order to launch",
        "the new service",
        "on schedule"
      ],
      "rule": "Підрядне мети з in order to + інфінітив.",
      "category": "affirmative",
      "categoryLabel": "Підрядні речення мети",
      "slots": [
        {
          "word": "The team",
          "role": "Subject"
        },
        {
          "word": "worked hard",
          "role": "Verb"
        },
        {
          "word": "in order to launch",
          "role": "Manner"
        },
        {
          "word": "the new service",
          "role": "Object"
        },
        {
          "word": "on schedule",
          "role": "Time"
        }
      ]
    },
    {
      "id": "b1-29",
      "ukr": "Ніхто не повідомив нас про зміни в розкладі вчора.",
      "words": [
        "Nobody",
        "informed us",
        "about the schedule changes",
        "yesterday"
      ],
      "rule": "В англійській мові дозволене лише ОДНЕ заперечення: Nobody + ствердна форма дієслова (informed).",
      "category": "negative",
      "categoryLabel": "Одинарне заперечення (Nobody)",
      "slots": [
        {
          "word": "Nobody",
          "role": "Subject"
        },
        {
          "word": "informed us",
          "role": "Verb"
        },
        {
          "word": "about the schedule changes",
          "role": "Condition"
        },
        {
          "word": "yesterday",
          "role": "Time"
        }
      ]
    },
    {
      "id": "b1-30",
      "ukr": "Ви готові замовити десерт чи хочете рахунок?",
      "words": [
        "Are you ready to order dessert",
        "or",
        "would you like the bill"
      ],
      "rule": "Альтернативне питання з двома рівноправними частинами через сполучник or.",
      "category": "question",
      "categoryLabel": "Альтернативні питання",
      "slots": [
        {
          "word": "Are you ready to order dessert",
          "role": "Condition"
        },
        {
          "word": "or",
          "role": "Connector"
        },
        {
          "word": "would you like the bill",
          "role": "Verb"
        }
      ]
    }
  ],
  "B2": [
    {
      "id": "b2-1",
      "ukr": "Якби ми виїхали раніше, ми б не запізнилися на літак.",
      "words": [
        "If",
        "we had left earlier",
        "we would not have missed",
        "our flight"
      ],
      "rule": "3rd Conditional (минуле): If + Past Perfect (had left), would have + V3 у головній частині.",
      "category": "conditional",
      "categoryLabel": "3rd Conditional",
      "slots": [
        {
          "word": "If",
          "role": "Connector"
        },
        {
          "word": "we had left earlier",
          "role": "Condition"
        },
        {
          "word": "we would not have missed",
          "role": "Verb"
        },
        {
          "word": "our flight",
          "role": "Object"
        }
      ]
    },
    {
      "id": "b2-2",
      "ukr": "Цю проблему слід було вирішити ще до запуску проєкту.",
      "words": [
        "This issue",
        "should have been solved",
        "before the project launch"
      ],
      "rule": "Modal Perfect Passive: should have been + V3 для критики невиконаної дії в минулому.",
      "category": "affirmative",
      "categoryLabel": "Modal Perfect Passive",
      "slots": [
        {
          "word": "This issue",
          "role": "Subject"
        },
        {
          "word": "should have been solved",
          "role": "Verb"
        },
        {
          "word": "before the project launch",
          "role": "Time"
        }
      ]
    },
    {
      "id": "b2-3",
      "ukr": "Рідко коли я бачив таку дивовижну архітектуру.",
      "words": [
        "Seldom",
        "have",
        "I seen",
        "such breathtaking architecture"
      ],
      "rule": "Часткова інверсія: заперечний прислівник Seldom на початку вимагає порядку запитання (have + I + seen).",
      "category": "advanced",
      "categoryLabel": "Інверсія (Seldom have I)",
      "slots": [
        {
          "word": "Seldom",
          "role": "Auxiliary"
        },
        {
          "word": "have",
          "role": "Auxiliary"
        },
        {
          "word": "I seen",
          "role": "Verb"
        },
        {
          "word": "such breathtaking architecture",
          "role": "Object"
        }
      ]
    },
    {
      "id": "b2-4",
      "ukr": "Якби я вчив англійську в дитинстві, я б зараз вільно нею володів.",
      "words": [
        "If",
        "I had studied English in childhood",
        "I would speak it fluently",
        "now"
      ],
      "rule": "Mixed Conditional: Умова в минулому (had studied) впливає на результат у теперішньому (would speak now).",
      "category": "conditional",
      "categoryLabel": "Mixed Conditional",
      "slots": [
        {
          "word": "If",
          "role": "Connector"
        },
        {
          "word": "I had studied English in childhood",
          "role": "Condition"
        },
        {
          "word": "I would speak it fluently",
          "role": "Verb"
        },
        {
          "word": "now",
          "role": "Time"
        }
      ]
    },
    {
      "id": "b2-5",
      "ukr": "Те, що нам дійсно потрібно, це чіткий план дій.",
      "words": [
        "What",
        "we really need",
        "is",
        "a transparent action plan"
      ],
      "rule": "Wh-Cleft Sentence для акценту: What-clause + is/was + головна думка.",
      "category": "advanced",
      "categoryLabel": "Cleft Sentences (What-clause)",
      "slots": [
        {
          "word": "What",
          "role": "Connector"
        },
        {
          "word": "we really need",
          "role": "Subject"
        },
        {
          "word": "is",
          "role": "Verb"
        },
        {
          "word": "a transparent action plan",
          "role": "Object"
        }
      ]
    },
    {
      "id": "b2-6",
      "ukr": "Я шкодую, що не погодився на ту пропозицію роботи.",
      "words": [
        "I wish",
        "I had accepted",
        "that attractive job offer"
      ],
      "rule": "Wish про минуле вимагає Past Perfect (had accepted) для вираження жалю.",
      "category": "affirmative",
      "categoryLabel": "Конструкція «I wish» (Past Perfect)",
      "slots": [
        {
          "word": "I wish",
          "role": "Subject"
        },
        {
          "word": "I had accepted",
          "role": "Verb"
        },
        {
          "word": "that attractive job offer",
          "role": "Object"
        }
      ]
    },
    {
      "id": "b2-7",
      "ukr": "За жодних обставин клієнти не повинні повідомляти паролі.",
      "words": [
        "Under no circumstances",
        "should",
        "customers share",
        "their security passwords"
      ],
      "rule": "Інверсія після негативної фрази Under no circumstances: модальне should + підмет + V1.",
      "category": "advanced",
      "categoryLabel": "Інверсія (Under no circumstances)",
      "slots": [
        {
          "word": "Under no circumstances",
          "role": "Condition"
        },
        {
          "word": "should",
          "role": "Modal"
        },
        {
          "word": "customers share",
          "role": "Verb"
        },
        {
          "word": "their security passwords",
          "role": "Object"
        }
      ]
    },
    {
      "id": "b2-8",
      "ukr": "Він заперечував, що брав участь у тій шахрайській схемі.",
      "words": [
        "He",
        "denied having taken part",
        "in that fraudulent scheme"
      ],
      "rule": "Дієслово deny з Perfect Gerund (having taken part) для дії, що передувала запереченню.",
      "category": "negative",
      "categoryLabel": "Perfect Gerund",
      "slots": [
        {
          "word": "He",
          "role": "Subject"
        },
        {
          "word": "denied having taken part",
          "role": "Verb"
        },
        {
          "word": "in that fraudulent scheme",
          "role": "Place"
        }
      ]
    },
    {
      "id": "b2-9",
      "ukr": "Мало того, що він запізнився, він ще й забув звіт.",
      "words": [
        "Not only",
        "did he arrive late",
        "but he also forgot",
        "the financial report"
      ],
      "rule": "Інверсія з Not only... but also: після Not only вживається питальний порядок слів (did he arrive).",
      "category": "advanced",
      "categoryLabel": "Інверсія (Not only... but also)",
      "slots": [
        {
          "word": "Not only",
          "role": "Connector"
        },
        {
          "word": "did he arrive late",
          "role": "Condition"
        },
        {
          "word": "but he also forgot",
          "role": "Verb"
        },
        {
          "word": "the financial report",
          "role": "Object"
        }
      ]
    },
    {
      "id": "b2-10",
      "ukr": "Якби вона попередила нас заздалегідь, ми б уникнули цієї помилки.",
      "words": [
        "Had she warned us in advance",
        "we would have avoided",
        "this critical mistake"
      ],
      "rule": "Інвертований умовний спосіб 3-го типу без if: Had she warned us замість If she had warned us.",
      "category": "conditional",
      "categoryLabel": "Інвертований 3rd Conditional (Had...)",
      "slots": [
        {
          "word": "Had she warned us in advance",
          "role": "Condition"
        },
        {
          "word": "we would have avoided",
          "role": "Verb"
        },
        {
          "word": "this critical mistake",
          "role": "Object"
        }
      ]
    },
    {
      "id": "b2-11",
      "ukr": "Саме під час кризи компанія виявила свої слабкі місця.",
      "words": [
        "It was during the crisis that",
        "the company",
        "discovered",
        "its major vulnerabilities"
      ],
      "rule": "It-cleft sentence для виділення обставини: It was [focus] that [rest of sentence].",
      "category": "advanced",
      "categoryLabel": "Cleft Sentences (It was... that)",
      "slots": [
        {
          "word": "It was during the crisis that",
          "role": "Condition"
        },
        {
          "word": "the company",
          "role": "Subject"
        },
        {
          "word": "discovered",
          "role": "Verb"
        },
        {
          "word": "its major vulnerabilities",
          "role": "Object"
        }
      ]
    },
    {
      "id": "b2-12",
      "ukr": "Він, напевно, забув зарядити свій телефон перед виходом.",
      "words": [
        "He",
        "must have forgotten to charge",
        "his smartphone",
        "before leaving"
      ],
      "rule": "Логічний висновок про минуле: must have + V3 (forgotten) виражає 95% впевненість.",
      "category": "affirmative",
      "categoryLabel": "Модальне припущення (Must have V3)",
      "slots": [
        {
          "word": "He",
          "role": "Subject"
        },
        {
          "word": "must have forgotten to charge",
          "role": "Verb"
        },
        {
          "word": "his smartphone",
          "role": "Object"
        },
        {
          "word": "before leaving",
          "role": "Time"
        }
      ]
    },
    {
      "id": "b2-13",
      "ukr": "Вона не могла не погодитися з цими вагомими аргументами.",
      "words": [
        "She",
        "could not help agreeing",
        "with these compelling arguments"
      ],
      "rule": "Ідіоматична конструкція cannot help + V-ing (не можу не робити).",
      "category": "negative",
      "categoryLabel": "Конструкція can't help doing",
      "slots": [
        {
          "word": "She",
          "role": "Subject"
        },
        {
          "word": "could not help agreeing",
          "role": "Verb"
        },
        {
          "word": "with these compelling arguments",
          "role": "Object"
        }
      ]
    },
    {
      "id": "b2-14",
      "ukr": "Якби не його підтримка, ми б ніколи не досягли успіху.",
      "words": [
        "But for his constant support",
        "we",
        "would never have succeeded"
      ],
      "rule": "Конструкція But for + іменник замінює умовне If it had not been for...",
      "category": "conditional",
      "categoryLabel": "Умовні конструкції (But for)",
      "slots": [
        {
          "word": "But for his constant support",
          "role": "Condition"
        },
        {
          "word": "we",
          "role": "Subject"
        },
        {
          "word": "would never have succeeded",
          "role": "Verb"
        }
      ]
    },
    {
      "id": "b2-15",
      "ukr": "Вважається, що цей стартап залучив мільйон доларів інвестицій.",
      "words": [
        "The innovative startup",
        "is believed to have raised",
        "one million dollars in funding"
      ],
      "rule": "Complex Subject (Складний підмет): is believed + to have raised (Perfect Infinitive).",
      "category": "affirmative",
      "categoryLabel": "Complex Subject",
      "slots": [
        {
          "word": "The innovative startup",
          "role": "Subject"
        },
        {
          "word": "is believed to have raised",
          "role": "Verb"
        },
        {
          "word": "one million dollars in funding",
          "role": "Object"
        }
      ]
    },
    {
      "id": "b2-16",
      "ukr": "Ледве ми увійшли до будівлі, як спрацювала пожежна тривога.",
      "words": [
        "Hardly",
        "had we entered the building",
        "when",
        "the fire alarm went off"
      ],
      "rule": "Інверсія: Hardly + had + Subject + V3 + when + Past Simple.",
      "category": "advanced",
      "categoryLabel": "Інверсія (Hardly had... when)",
      "slots": [
        {
          "word": "Hardly",
          "role": "Auxiliary"
        },
        {
          "word": "had we entered the building",
          "role": "Condition"
        },
        {
          "word": "when",
          "role": "Connector"
        },
        {
          "word": "the fire alarm went off",
          "role": "Verb"
        }
      ]
    },
    {
      "id": "b2-17",
      "ukr": "Він поводиться так, ніби він є власником цієї компанії.",
      "words": [
        "He",
        "acts as though",
        "he owned",
        "the entire enterprise"
      ],
      "rule": "Підрядне порівняння з as if / as though: вимагає форми Past Simple (owned) для нереального стану.",
      "category": "affirmative",
      "categoryLabel": "Конструкція as though",
      "slots": [
        {
          "word": "He",
          "role": "Subject"
        },
        {
          "word": "acts as though",
          "role": "Verb"
        },
        {
          "word": "he owned",
          "role": "Condition"
        },
        {
          "word": "the entire enterprise",
          "role": "Object"
        }
      ]
    },
    {
      "id": "b2-18",
      "ukr": "Не мало сенсу сперечатися з людиною, яка не слухає.",
      "words": [
        "There was no point in arguing",
        "with someone",
        "who refused to listen"
      ],
      "rule": "There is no point in + V-ing (герундій).",
      "category": "negative",
      "categoryLabel": "Стійкі конструкції (no point in doing)",
      "slots": [
        {
          "word": "There was no point in arguing",
          "role": "Verb"
        },
        {
          "word": "with someone",
          "role": "Object"
        },
        {
          "word": "who refused to listen",
          "role": "Condition"
        }
      ]
    },
    {
      "id": "b2-19",
      "ukr": "Як ви вважаєте, хто відповідальний за ці технічні несправності?",
      "words": [
        "Who",
        "do you think",
        "is responsible for",
        "these technical glitches"
      ],
      "rule": "Ввідна фраза do you think вставляється всередину спеціального запитання без зміни порядку.",
      "category": "question",
      "categoryLabel": "Питання з ввідними фразами",
      "slots": [
        {
          "word": "Who",
          "role": "Subject"
        },
        {
          "word": "do you think",
          "role": "Auxiliary"
        },
        {
          "word": "is responsible for",
          "role": "Verb"
        },
        {
          "word": "these technical glitches",
          "role": "Object"
        }
      ]
    },
    {
      "id": "b2-20",
      "ukr": "За умови, що ви підпишете договір, ми надамо знижку.",
      "words": [
        "Provided that",
        "you sign the agreement",
        "we",
        "will grant a ten percent discount"
      ],
      "rule": "Provided that = If у діловій англійській мові; в підрядному вживається Present Simple.",
      "category": "conditional",
      "categoryLabel": "Умовні сполучники (Provided that)",
      "slots": [
        {
          "word": "Provided that",
          "role": "Connector"
        },
        {
          "word": "you sign the agreement",
          "role": "Condition"
        },
        {
          "word": "we",
          "role": "Subject"
        },
        {
          "word": "will grant a ten percent discount",
          "role": "Verb"
        }
      ]
    },
    {
      "id": "b2-21",
      "ukr": "Він змусив мене переписати весь документ з самого початку.",
      "words": [
        "He",
        "made me rewrite",
        "the entire document",
        "from scratch"
      ],
      "rule": "Complex Object з make: make + somebody + bare infinitive (rewrite БЕЗ to).",
      "category": "affirmative",
      "categoryLabel": "Complex Object з «make»",
      "slots": [
        {
          "word": "He",
          "role": "Subject"
        },
        {
          "word": "made me rewrite",
          "role": "Verb"
        },
        {
          "word": "the entire document",
          "role": "Object"
        },
        {
          "word": "from scratch",
          "role": "Manner"
        }
      ]
    },
    {
      "id": "b2-22",
      "ukr": "Вам давно пора прийняти остаточне рішення щодо проєкту.",
      "words": [
        "It is high time",
        "you made",
        "a definitive decision",
        "regarding the project"
      ],
      "rule": "Конструкція It is high time + підмет + Past Simple (made) для вираження запізнілої дії.",
      "category": "affirmative",
      "categoryLabel": "Конструкція It is high time",
      "slots": [
        {
          "word": "It is high time",
          "role": "Time"
        },
        {
          "word": "you made",
          "role": "Verb"
        },
        {
          "word": "a definitive decision",
          "role": "Object"
        },
        {
          "word": "regarding the project",
          "role": "Condition"
        }
      ]
    },
    {
      "id": "b2-23",
      "ukr": "Вони навряд чи погодяться на такі невигідні умови контракту.",
      "words": [
        "They",
        "are unlikely to agree to",
        "such unfavorable terms",
        "of the contract"
      ],
      "rule": "Конструкція be unlikely to + infinitive виражає низьку ймовірність події.",
      "category": "negative",
      "categoryLabel": "Ймовірність (be unlikely to)",
      "slots": [
        {
          "word": "They",
          "role": "Subject"
        },
        {
          "word": "are unlikely to agree to",
          "role": "Verb"
        },
        {
          "word": "such unfavorable terms",
          "role": "Object"
        },
        {
          "word": "of the contract",
          "role": "Condition"
        }
      ]
    },
    {
      "id": "b2-24",
      "ukr": "Чому ви не повідомили юридичний відділ одразу після інциденту?",
      "words": [
        "Why",
        "did you not notify",
        "the legal department",
        "immediately after the incident"
      ],
      "rule": "Заперечне питання у формі Past Simple з повним комплексом обставин часу.",
      "category": "question",
      "categoryLabel": "Заперечні питання",
      "slots": [
        {
          "word": "Why",
          "role": "Auxiliary"
        },
        {
          "word": "did you not notify",
          "role": "Verb"
        },
        {
          "word": "the legal department",
          "role": "Object"
        },
        {
          "word": "immediately after the incident",
          "role": "Time"
        }
      ]
    },
    {
      "id": "b2-25",
      "ukr": "Якби ми не були настільки зайняті, ми б відвідали семінар учора.",
      "words": [
        "If",
        "we were not so busy",
        "we would have attended",
        "the seminar yesterday"
      ],
      "rule": "Mixed Conditional (тип 2): постійна умова (were not busy) ➔ результат у минулому (would have attended).",
      "category": "conditional",
      "categoryLabel": "Mixed Conditional",
      "slots": [
        {
          "word": "If",
          "role": "Connector"
        },
        {
          "word": "we were not so busy",
          "role": "Condition"
        },
        {
          "word": "we would have attended",
          "role": "Verb"
        },
        {
          "word": "the seminar yesterday",
          "role": "Object"
        }
      ]
    },
    {
      "id": "b2-26",
      "ukr": "Ніде в іншому місці ви не знайдете такої відданої команди.",
      "words": [
        "Nowhere else",
        "will",
        "you find",
        "such a dedicated team of professionals"
      ],
      "rule": "Інверсія після Nowhere else: допоміжне will + підмет (you) + інфінітив (find).",
      "category": "advanced",
      "categoryLabel": "Інверсія (Nowhere else)",
      "slots": [
        {
          "word": "Nowhere else",
          "role": "Place"
        },
        {
          "word": "will",
          "role": "Auxiliary"
        },
        {
          "word": "you find",
          "role": "Verb"
        },
        {
          "word": "such a dedicated team of professionals",
          "role": "Object"
        }
      ]
    },
    {
      "id": "b2-27",
      "ukr": "Я б волів, щоб ви не обговорювали конфіденційні деталі публічно.",
      "words": [
        "I would rather",
        "you did not discuss",
        "confidential details",
        "in public"
      ],
      "rule": "Конструкція would rather + підмет + Past Simple (did not discuss) для побажання іншим.",
      "category": "negative",
      "categoryLabel": "Конструкція would rather",
      "slots": [
        {
          "word": "I would rather",
          "role": "Subject"
        },
        {
          "word": "you did not discuss",
          "role": "Verb"
        },
        {
          "word": "confidential details",
          "role": "Object"
        },
        {
          "word": "in public",
          "role": "Place"
        }
      ]
    },
    {
      "id": "b2-28",
      "ukr": "Хіба ти не пам'ятаєш, що ми вже обговорювали це питання минулого вівторка?",
      "words": [
        "Do you not recall",
        "that we already discussed",
        "this matter",
        "last Tuesday"
      ],
      "rule": "Риторичне заперечне питання: Do you not recall that + підрядне минулого часу.",
      "category": "question",
      "categoryLabel": "Риторичні заперечні запитання",
      "slots": [
        {
          "word": "Do you not recall",
          "role": "Verb"
        },
        {
          "word": "that we already discussed",
          "role": "Condition"
        },
        {
          "word": "this matter",
          "role": "Object"
        },
        {
          "word": "last Tuesday",
          "role": "Time"
        }
      ]
    },
    {
      "id": "b2-29",
      "ukr": "Після того, як він провів ретельне тестування, розробник розгорнув оновлення.",
      "words": [
        "Having conducted thorough testing",
        "the developer",
        "deployed the update",
        "to the production server"
      ],
      "rule": "Participle Clause: Having conducted замінює After he had conducted.",
      "category": "advanced",
      "categoryLabel": "Дієприкметникові звороти (Having done)",
      "slots": [
        {
          "word": "Having conducted thorough testing",
          "role": "Condition"
        },
        {
          "word": "the developer",
          "role": "Subject"
        },
        {
          "word": "deployed the update",
          "role": "Verb"
        },
        {
          "word": "to the production server",
          "role": "Place"
        }
      ]
    },
    {
      "id": "b2-30",
      "ukr": "Ніколи раніше громада не виявляла такої надзвичайної солідарності.",
      "words": [
        "Never before",
        "had",
        "the community demonstrated",
        "such remarkable solidarity"
      ],
      "rule": "Інверсія: Never before + had + підмет + V3 для драматичного підсилення.",
      "category": "advanced",
      "categoryLabel": "Інверсія (Never before)",
      "slots": [
        {
          "word": "Never before",
          "role": "Time"
        },
        {
          "word": "had",
          "role": "Auxiliary"
        },
        {
          "word": "the community demonstrated",
          "role": "Verb"
        },
        {
          "word": "such remarkable solidarity",
          "role": "Object"
        }
      ]
    }
  ],
  "C1": [
    {
      "id": "c1-1",
      "ukr": "Ледве ми підписали угоду, як ринок обвалився.",
      "words": [
        "Hardly",
        "had we signed",
        "the agreement",
        "when the market collapsed"
      ],
      "rule": "Hardly had + Subject + V3... when + Past Simple. Класична C1 інверсія негативного прислівника.",
      "category": "advanced",
      "categoryLabel": "Інверсія (Hardly had... when)",
      "slots": [
        {
          "word": "Hardly",
          "role": "Auxiliary"
        },
        {
          "word": "had we signed",
          "role": "Verb"
        },
        {
          "word": "the agreement",
          "role": "Object"
        },
        {
          "word": "when the market collapsed",
          "role": "Condition"
        }
      ]
    },
    {
      "id": "c1-2",
      "ukr": "Тільки після того, як вона завершила презентацію, колеги усвідомили масштаб проблеми.",
      "words": [
        "Only after she had finished the presentation",
        "did",
        "the team realize",
        "the problem scale"
      ],
      "rule": "Інверсія після 'Only after': допоміжне did виноситься перед підметом у головному реченні.",
      "category": "advanced",
      "categoryLabel": "Інверсія (Only after... did)",
      "slots": [
        {
          "word": "Only after she had finished the presentation",
          "role": "Condition"
        },
        {
          "word": "did",
          "role": "Auxiliary"
        },
        {
          "word": "the team realize",
          "role": "Verb"
        },
        {
          "word": "the problem scale",
          "role": "Object"
        }
      ]
    },
    {
      "id": "c1-3",
      "ukr": "Якби ви повідомили нас завчасно, ми б вжили необхідних заходів.",
      "words": [
        "Had",
        "you notified us in advance",
        "we would have taken",
        "the necessary precautions"
      ],
      "rule": "Inverted Conditional: 'Had you notified' замість 'If you had notified'.",
      "category": "conditional",
      "categoryLabel": "Інвертований умовний стан (Had you...)",
      "slots": [
        {
          "word": "Had",
          "role": "Auxiliary"
        },
        {
          "word": "you notified us in advance",
          "role": "Condition"
        },
        {
          "word": "we would have taken",
          "role": "Verb"
        },
        {
          "word": "the necessary precautions",
          "role": "Object"
        }
      ]
    },
    {
      "id": "c1-4",
      "ukr": "Ні в якому разі ви не повинні передавати ці дані третім особам.",
      "words": [
        "On no account",
        "must",
        "you disclose",
        "this sensitive information",
        "to third parties"
      ],
      "rule": "Negative inversion: On no account + modal must + Subject + Verb + Object + Place.",
      "category": "advanced",
      "categoryLabel": "Інверсія (On no account)",
      "slots": [
        {
          "word": "On no account",
          "role": "Condition"
        },
        {
          "word": "must",
          "role": "Modal"
        },
        {
          "word": "you disclose",
          "role": "Verb"
        },
        {
          "word": "this sensitive information",
          "role": "Object"
        },
        {
          "word": "to third parties",
          "role": "Place"
        }
      ]
    },
    {
      "id": "c1-5",
      "ukr": "Те, що мене найбільше вразило, це їхня неймовірна стійкість.",
      "words": [
        "What struck me most",
        "was",
        "their incredible resilience",
        "during the crisis"
      ],
      "rule": "Pseudo-cleft sentence: What clause + was + Predicate noun phrase + Context.",
      "category": "advanced",
      "categoryLabel": "Cleft Sentences (What struck me)",
      "slots": [
        {
          "word": "What struck me most",
          "role": "Subject"
        },
        {
          "word": "was",
          "role": "Verb"
        },
        {
          "word": "their incredible resilience",
          "role": "Object"
        },
        {
          "word": "during the crisis",
          "role": "Time"
        }
      ]
    },
    {
      "id": "c1-6",
      "ukr": "Вкрай важливо, щоб кожен кандидат надав оригінальні документи.",
      "words": [
        "It is imperative that",
        "every applicant",
        "submit",
        "original credentials"
      ],
      "rule": "Present Subjunctive: після 'It is imperative that' дієслово вживається в базовій формі (submit, НЕ submits!).",
      "category": "advanced",
      "categoryLabel": "Subjunctive Mood (Умовний спосіб)",
      "slots": [
        {
          "word": "It is imperative that",
          "role": "Condition"
        },
        {
          "word": "every applicant",
          "role": "Subject"
        },
        {
          "word": "submit",
          "role": "Verb"
        },
        {
          "word": "original credentials",
          "role": "Object"
        }
      ]
    },
    {
      "id": "c1-7",
      "ukr": "Лише тоді, коли почався аудит, випливли приховані збитки.",
      "words": [
        "Only when the audit began",
        "did",
        "the hidden financial losses",
        "come to light"
      ],
      "rule": "Only when clause ➔ допоміжне did ➔ підмет ➔ смислове дієслово come to light.",
      "category": "advanced",
      "categoryLabel": "Інверсія (Only when)",
      "slots": [
        {
          "word": "Only when the audit began",
          "role": "Condition"
        },
        {
          "word": "did",
          "role": "Auxiliary"
        },
        {
          "word": "the hidden financial losses",
          "role": "Subject"
        },
        {
          "word": "come to light",
          "role": "Verb"
        }
      ]
    },
    {
      "id": "c1-8",
      "ukr": "Провівши аналіз даних, команда представила свої висновки раді директорів.",
      "words": [
        "Having completed the data analysis",
        "the team",
        "presented their findings",
        "to the board"
      ],
      "rule": "Perfect Participle Clause: Having + V3 виражає дію, що передувала головній.",
      "category": "advanced",
      "categoryLabel": "Дієприкметникові звороти (Participle Clause)",
      "slots": [
        {
          "word": "Having completed the data analysis",
          "role": "Condition"
        },
        {
          "word": "the team",
          "role": "Subject"
        },
        {
          "word": "presented their findings",
          "role": "Verb"
        },
        {
          "word": "to the board",
          "role": "Place"
        }
      ]
    },
    {
      "id": "c1-9",
      "ukr": "Не встигли вони оголосити про злиття, як вартість акцій стрімко зросла.",
      "words": [
        "No sooner",
        "had they announced the merger",
        "than",
        "the stock prices surged"
      ],
      "rule": "Інверсія: No sooner had + Subject + V3 + than + Past Simple (зверніть увагу: саме than, не when!).",
      "category": "advanced",
      "categoryLabel": "Інверсія (No sooner... than)",
      "slots": [
        {
          "word": "No sooner",
          "role": "Auxiliary"
        },
        {
          "word": "had they announced the merger",
          "role": "Condition"
        },
        {
          "word": "than",
          "role": "Connector"
        },
        {
          "word": "the stock prices surged",
          "role": "Verb"
        }
      ]
    },
    {
      "id": "c1-10",
      "ukr": "Якби не виникли непередбачені обставини, ми б запустили продукт вчасно.",
      "words": [
        "Were it not for unforeseen circumstances",
        "we would have launched",
        "the product",
        "on schedule"
      ],
      "rule": "Інвертований умовний стан: Were it not for [noun] замінює If it were not for...",
      "category": "conditional",
      "categoryLabel": "Інвертований Conditional (Were it not for)",
      "slots": [
        {
          "word": "Were it not for unforeseen circumstances",
          "role": "Condition"
        },
        {
          "word": "we would have launched",
          "role": "Verb"
        },
        {
          "word": "the product",
          "role": "Object"
        },
        {
          "word": "on schedule",
          "role": "Time"
        }
      ]
    },
    {
      "id": "c1-11",
      "ukr": "Керівництво вимагає, щоб кожен звіт був перевірений незалежним аудитором.",
      "words": [
        "Management demands that",
        "every single report",
        "be verified",
        "by an external auditor"
      ],
      "rule": "Subjunctive Mood у пасивному стані: demands that + Subject + be + V3 (НЕ is verified!).",
      "category": "advanced",
      "categoryLabel": "Subjunctive Mood Passive",
      "slots": [
        {
          "word": "Management demands that",
          "role": "Condition"
        },
        {
          "word": "every single report",
          "role": "Subject"
        },
        {
          "word": "be verified",
          "role": "Verb"
        },
        {
          "word": "by an external auditor",
          "role": "Object"
        }
      ]
    },
    {
      "id": "c1-12",
      "ukr": "Лише рідко коли генеральний директор особисто втручається в оперативні питання.",
      "words": [
        "Only rarely",
        "does",
        "the chief executive officer intervene",
        "in routine operational matters"
      ],
      "rule": "Інверсія з Only rarely: допоміжне does виноситься перед підметом у теперішньому часі.",
      "category": "advanced",
      "categoryLabel": "Інверсія (Only rarely does)",
      "slots": [
        {
          "word": "Only rarely",
          "role": "Time"
        },
        {
          "word": "does",
          "role": "Auxiliary"
        },
        {
          "word": "the chief executive officer intervene",
          "role": "Verb"
        },
        {
          "word": "in routine operational matters",
          "role": "Place"
        }
      ]
    },
    {
      "id": "c1-13",
      "ukr": "Якби вам знадобилася додаткова інформація, будь ласка, звертайтеся до нашого відділу.",
      "words": [
        "Should you require further information",
        "please do not hesitate to contact",
        "our department"
      ],
      "rule": "Інвертований умовний стан 1-го типу: Should you require замість If you require (високий реєстр ввічливості).",
      "category": "conditional",
      "categoryLabel": "Інвертований Conditional (Should you...)",
      "slots": [
        {
          "word": "Should you require further information",
          "role": "Condition"
        },
        {
          "word": "please do not hesitate to contact",
          "role": "Verb"
        },
        {
          "word": "our department",
          "role": "Object"
        }
      ]
    },
    {
      "id": "c1-14",
      "ukr": "Будучи добре обізнаними про ризики, інвестори все ж вирішили продовжити співпрацю.",
      "words": [
        "Being fully aware of the financial risks",
        "the investors",
        "nevertheless chose to proceed",
        "with the venture"
      ],
      "rule": "Present Participle Clause (Being fully aware) для вираження причини чи супутньої обставини.",
      "category": "advanced",
      "categoryLabel": "Participle Clause (Being aware)",
      "slots": [
        {
          "word": "Being fully aware of the financial risks",
          "role": "Condition"
        },
        {
          "word": "the investors",
          "role": "Subject"
        },
        {
          "word": "nevertheless chose to proceed",
          "role": "Verb"
        },
        {
          "word": "with the venture",
          "role": "Object"
        }
      ]
    },
    {
      "id": "c1-15",
      "ukr": "Вони навіть не здогадувалися, що за ними ретельно стежили.",
      "words": [
        "Little",
        "did",
        "they suspect",
        "that they were being closely monitored"
      ],
      "rule": "Негативна інверсія з Little: Little did they suspect = They didn't suspect at all.",
      "category": "advanced",
      "categoryLabel": "Інверсія (Little did they...)",
      "slots": [
        {
          "word": "Little",
          "role": "Auxiliary"
        },
        {
          "word": "did",
          "role": "Auxiliary"
        },
        {
          "word": "they suspect",
          "role": "Verb"
        },
        {
          "word": "that they were being closely monitored",
          "role": "Condition"
        }
      ]
    },
    {
      "id": "c1-16",
      "ukr": "Я наполягаю на тому, щоб він пояснив причини своєї раптової відставки.",
      "words": [
        "I insist that",
        "he explain",
        "the underlying reasons for",
        "his abrupt resignation"
      ],
      "rule": "Mandative Subjunctive: I insist that + he explain (без закінчення -s для 3-ї особи!).",
      "category": "advanced",
      "categoryLabel": "Subjunctive (insist that)",
      "slots": [
        {
          "word": "I insist that",
          "role": "Condition"
        },
        {
          "word": "he explain",
          "role": "Verb"
        },
        {
          "word": "the underlying reasons for",
          "role": "Object"
        },
        {
          "word": "his abrupt resignation",
          "role": "Condition"
        }
      ]
    },
    {
      "id": "c1-17",
      "ukr": "Якби не його своєчасне втручання, переговори зазнали б повного краху.",
      "words": [
        "Had it not been for his timely intervention",
        "the negotiations",
        "would have collapsed completely"
      ],
      "rule": "Інверсія умовного речення 3-го типу: Had it not been for + noun замість If it had not been for...",
      "category": "conditional",
      "categoryLabel": "Умовні конструкції (Had it not been for)",
      "slots": [
        {
          "word": "Had it not been for his timely intervention",
          "role": "Condition"
        },
        {
          "word": "the negotiations",
          "role": "Subject"
        },
        {
          "word": "would have collapsed completely",
          "role": "Verb"
        }
      ]
    },
    {
      "id": "c1-18",
      "ukr": "Він не лише спростував звинувачення, але й надав переконливі докази.",
      "words": [
        "Not only",
        "did he refute the allegations",
        "but he also presented",
        "irrefutable evidence"
      ],
      "rule": "Інверсія Not only did he refute... but he also presented... для емфатичного протиставлення.",
      "category": "advanced",
      "categoryLabel": "Інверсія (Not only... but also)",
      "slots": [
        {
          "word": "Not only",
          "role": "Connector"
        },
        {
          "word": "did he refute the allegations",
          "role": "Condition"
        },
        {
          "word": "but he also presented",
          "role": "Verb"
        },
        {
          "word": "irrefutable evidence",
          "role": "Object"
        }
      ]
    },
    {
      "id": "c1-19",
      "ukr": "Тільки після того, як збитки перевищили мільйон, правління визнало кризу.",
      "words": [
        "Not until the losses exceeded one million",
        "did",
        "the board acknowledge",
        "the crisis severity"
      ],
      "rule": "Інверсія Not until [time/clause] did + Subject + Verb: інверсія застосовується в головній частині.",
      "category": "advanced",
      "categoryLabel": "Інверсія (Not until... did)",
      "slots": [
        {
          "word": "Not until the losses exceeded one million",
          "role": "Condition"
        },
        {
          "word": "did",
          "role": "Auxiliary"
        },
        {
          "word": "the board acknowledge",
          "role": "Verb"
        },
        {
          "word": "the crisis severity",
          "role": "Object"
        }
      ]
    },
    {
      "id": "c1-20",
      "ukr": "Будучи попередженим про погіршення погодних умов, капітан змінив маршрут судна.",
      "words": [
        "Having been warned about the worsening storm",
        "the captain",
        "altered the ship's course",
        "immediately"
      ],
      "rule": "Passive Perfect Participle Clause: Having been + V3 для вираження дії, здійсненої над підметом раніше.",
      "category": "advanced",
      "categoryLabel": "Passive Participle Clause",
      "slots": [
        {
          "word": "Having been warned about the worsening storm",
          "role": "Condition"
        },
        {
          "word": "the captain",
          "role": "Subject"
        },
        {
          "word": "altered the ship's course",
          "role": "Verb"
        },
        {
          "word": "immediately",
          "role": "Time"
        }
      ]
    },
    {
      "id": "c1-21",
      "ukr": "Яка б не виникла проблема, ми знайдемо ефективне рішення.",
      "words": [
        "Whatever difficulties may arise",
        "we",
        "will formulate an effective solution",
        "promptly"
      ],
      "rule": "Допустове підрядне з Whatever + noun + may arise + головна частина.",
      "category": "conditional",
      "categoryLabel": "Допустові речення (Whatever... may)",
      "slots": [
        {
          "word": "Whatever difficulties may arise",
          "role": "Condition"
        },
        {
          "word": "we",
          "role": "Subject"
        },
        {
          "word": "will formulate an effective solution",
          "role": "Verb"
        },
        {
          "word": "promptly",
          "role": "Time"
        }
      ]
    },
    {
      "id": "c1-22",
      "ukr": "За жодних умов секретні ключі не повинні зберігатися у відкритому коді.",
      "words": [
        "In no way",
        "should",
        "secret API keys be stored",
        "in publicly accessible repositories"
      ],
      "rule": "Інверсія після In no way: модальне should + підмет + пасивний стан (be stored) + місце.",
      "category": "advanced",
      "categoryLabel": "Інверсія (In no way should)",
      "slots": [
        {
          "word": "In no way",
          "role": "Condition"
        },
        {
          "word": "should",
          "role": "Modal"
        },
        {
          "word": "secret API keys be stored",
          "role": "Verb"
        },
        {
          "word": "in publicly accessible repositories",
          "role": "Place"
        }
      ]
    },
    {
      "id": "c1-23",
      "ukr": "Те, що вони прагнули приховати, стало відомо всім через кілька днів.",
      "words": [
        "What they attempted to conceal",
        "became",
        "common knowledge",
        "within a matter of days"
      ],
      "rule": "Wh-cleft структура як підмет речення: What-clause + Verb + Predicate + Time phrase.",
      "category": "advanced",
      "categoryLabel": "Cleft Sentences (What they...)",
      "slots": [
        {
          "word": "What they attempted to conceal",
          "role": "Subject"
        },
        {
          "word": "became",
          "role": "Verb"
        },
        {
          "word": "common knowledge",
          "role": "Object"
        },
        {
          "word": "within a matter of days",
          "role": "Time"
        }
      ]
    },
    {
      "id": "c1-24",
      "ukr": "Я рекомендую, щоб кандидат пройшов поглиблене технічне інтерв'ю.",
      "words": [
        "I recommend that",
        "the candidate",
        "undergo",
        "an intensive technical evaluation"
      ],
      "rule": "Subjunctive після recommend that: the candidate undergo (без -s, базова форма інфінітива).",
      "category": "advanced",
      "categoryLabel": "Subjunctive (recommend that)",
      "slots": [
        {
          "word": "I recommend that",
          "role": "Condition"
        },
        {
          "word": "the candidate",
          "role": "Subject"
        },
        {
          "word": "undergo",
          "role": "Verb"
        },
        {
          "word": "an intensive technical evaluation",
          "role": "Object"
        }
      ]
    },
    {
      "id": "c1-25",
      "ukr": "Якби він погодився на ту пропозицію раніше, він би зараз очолював департамент.",
      "words": [
        "Had he accepted that proposal earlier",
        "he would currently head",
        "the entire global department"
      ],
      "rule": "Інвертований Mixed Conditional (Had he accepted ➔ would head now).",
      "category": "conditional",
      "categoryLabel": "Інвертований Mixed Conditional",
      "slots": [
        {
          "word": "Had he accepted that proposal earlier",
          "role": "Condition"
        },
        {
          "word": "he would currently head",
          "role": "Verb"
        },
        {
          "word": "the entire global department",
          "role": "Object"
        }
      ]
    },
    {
      "id": "c1-26",
      "ukr": "Ніколи ще регуляторні органи не накладали таких суворих штрафів.",
      "words": [
        "At no time",
        "did",
        "the regulatory authorities impose",
        "such stringent penalties"
      ],
      "rule": "Інверсія після At no time: допоміжне did + підмет + infinitive (impose).",
      "category": "advanced",
      "categoryLabel": "Інверсія (At no time did)",
      "slots": [
        {
          "word": "At no time",
          "role": "Time"
        },
        {
          "word": "did",
          "role": "Auxiliary"
        },
        {
          "word": "the regulatory authorities impose",
          "role": "Verb"
        },
        {
          "word": "such stringent penalties",
          "role": "Object"
        }
      ]
    },
    {
      "id": "c1-27",
      "ukr": "Саме завдяки наполегливій праці інженерів проєкт було реалізовано вчасно.",
      "words": [
        "It was thanks to the engineers' dedication that",
        "the complex architecture",
        "was delivered successfully"
      ],
      "rule": "It-cleft для емфази: It was thanks to [noun phrase] that [clause].",
      "category": "advanced",
      "categoryLabel": "Cleft Sentences (It was thanks to)",
      "slots": [
        {
          "word": "It was thanks to the engineers' dedication that",
          "role": "Condition"
        },
        {
          "word": "the complex architecture",
          "role": "Subject"
        },
        {
          "word": "was delivered successfully",
          "role": "Verb"
        }
      ]
    },
    {
      "id": "c1-28",
      "ukr": "Чи варто було б нам переглянути архітектуру до початку наступного спринту?",
      "words": [
        "Would it not be advisable for us to reevaluate",
        "the system architecture",
        "before the next sprint"
      ],
      "rule": "Високий академічний та діловий регістр: Would it not be advisable for us to + V1 + Object + Time.",
      "category": "question",
      "categoryLabel": "Ділові складні запитання",
      "slots": [
        {
          "word": "Would it not be advisable for us to reevaluate",
          "role": "Verb"
        },
        {
          "word": "the system architecture",
          "role": "Object"
        },
        {
          "word": "before the next sprint",
          "role": "Time"
        }
      ]
    },
    {
      "id": "c1-29",
      "ukr": "Яким би складним не здавалося це завдання, команда вирішить його бездоганно.",
      "words": [
        "However daunting the challenge may seem",
        "the engineering team",
        "will overcome it",
        "effortlessly"
      ],
      "rule": "Допустовий зворот: However + прикметник (daunting) + підмет + may seem, головне речення.",
      "category": "conditional",
      "categoryLabel": "Допустові речення (However + adj)",
      "slots": [
        {
          "word": "However daunting the challenge may seem",
          "role": "Condition"
        },
        {
          "word": "the engineering team",
          "role": "Subject"
        },
        {
          "word": "will overcome it",
          "role": "Verb"
        },
        {
          "word": "effortlessly",
          "role": "Manner"
        }
      ]
    },
    {
      "id": "c1-30",
      "ukr": "Тільки тоді, коли всі перевірки безпеки будуть завершені, система перейде в робочий режим.",
      "words": [
        "Only upon completion of all security audits",
        "will",
        "the distributed platform go live"
      ],
      "rule": "Інверсія після прийменникового звороту Only upon completion: will + підмет + go live.",
      "category": "advanced",
      "categoryLabel": "Інверсія (Only upon... will)",
      "slots": [
        {
          "word": "Only upon completion of all security audits",
          "role": "Condition"
        },
        {
          "word": "will",
          "role": "Auxiliary"
        },
        {
          "word": "the distributed platform go live",
          "role": "Verb"
        }
      ]
    }
  ]
};
