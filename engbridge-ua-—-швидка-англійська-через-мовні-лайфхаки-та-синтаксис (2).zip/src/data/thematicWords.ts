import { ThematicWord, ThematicCategoryInfo, VocabItem, CefrLevel } from '../types';
import { ANIMALS_WORDS } from './thematic/animals';
import { CITY_WORDS } from './thematic/city';
import { CLOTHES_WORDS } from './thematic/clothes';
import { EDUCATION_WORDS } from './thematic/education';
import { EMOTIONS_WORDS } from './thematic/emotions';
import { FAMILY_WORDS } from './thematic/family';
import { FINANCE_WORDS } from './thematic/finance';
import { FOOD_WORDS } from './thematic/food';
import { HEALTH_WORDS } from './thematic/health';
import { HOME_WORDS } from './thematic/home';
import { NATURE_WORDS } from './thematic/nature';
import { SLANG_WORDS } from './thematic/slang';
import { SPORTS_WORDS } from './thematic/sports';
import { TECH_WORDS } from './thematic/tech';
import { TRAVEL_WORDS } from './thematic/travel';
import { WORK_WORDS } from './thematic/work';

export const THEMATIC_CATEGORIES: ThematicCategoryInfo[] = [
  {
    id: 'animals',
    title: 'Тварини та Фауна',
    engTitle: 'Animals & Wildlife',
    icon: '🐾',
    description: 'Домашні улюбленці, дикі звірі, морські глибини, птахи та комахи з яскравими асоціаціями.',
    color: 'from-amber-500/20 via-orange-500/10 to-transparent',
    badgeBg: 'bg-amber-500/10 text-amber-300 border-amber-500/30',
    accentColor: 'text-amber-400',
    levelRange: 'A1 – B2',
  },
  {
    id: 'home',
    title: 'Дім, Побут та Затишок',
    engTitle: 'Home & Everyday Living',
    icon: '🏠',
    description: 'Кімнати, меблі, техніка, ремонт, кухонний інвентар і щоденний домашній комфорт.',
    color: 'from-blue-500/20 via-sky-500/10 to-transparent',
    badgeBg: 'bg-blue-500/10 text-blue-300 border-blue-500/30',
    accentColor: 'text-blue-400',
    levelRange: 'A1 – B2',
  },
  {
    id: 'work',
    title: 'Робота, Карʼєра та Бізнес',
    engTitle: 'Work, Career & Office',
    icon: '💼',
    description: 'Співбесіди, дедлайни, переговори, посади, звіти, ремоут-ворк та контракти.',
    color: 'from-indigo-500/20 via-purple-500/10 to-transparent',
    badgeBg: 'bg-indigo-500/10 text-indigo-300 border-indigo-500/30',
    accentColor: 'text-indigo-400',
    levelRange: 'A2 – B2',
  },
  {
    id: 'food',
    title: 'Їжа, Кулінарія та Ресторан',
    engTitle: 'Food, Dining & Cooking',
    icon: '🍽️',
    description: 'Смаки, інгредієнти, рецепти, замовлення страв у ресторані, напої та посуд.',
    color: 'from-emerald-500/20 via-teal-500/10 to-transparent',
    badgeBg: 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30',
    accentColor: 'text-emerald-400',
    levelRange: 'A1 – B2',
  },
  {
    id: 'travel',
    title: 'Подорожі, Аеропорт та Транспорт',
    engTitle: 'Travel & Transport',
    icon: '✈️',
    description: 'Аеропорти, квитки, багаж, готелі, навігація в незнайомому місті та екскурсії.',
    color: 'from-cyan-500/20 via-blue-500/10 to-transparent',
    badgeBg: 'bg-cyan-500/10 text-cyan-300 border-cyan-500/30',
    accentColor: 'text-cyan-400',
    levelRange: 'A1 – B2',
  },
  {
    id: 'emotions',
    title: 'Емоції, Почуття та Характер',
    engTitle: 'Emotions & Character',
    icon: '💭',
    description: 'Від захвату й вдячності до розгубленості, спокою, впевненості та рису характеру.',
    color: 'from-rose-500/20 via-pink-500/10 to-transparent',
    badgeBg: 'bg-rose-500/10 text-rose-300 border-rose-500/30',
    accentColor: 'text-rose-400',
    levelRange: 'A2 – B2',
  },
  {
    id: 'health',
    title: 'Здоровʼя, Тіло та Медицина',
    engTitle: 'Health & Wellness',
    icon: '🩺',
    description: 'Симптоми, візит до лікаря, аптека, м’язи, одужання, перша допомога та сон.',
    color: 'from-red-500/20 via-rose-500/10 to-transparent',
    badgeBg: 'bg-red-500/10 text-red-300 border-red-500/30',
    accentColor: 'text-red-400',
    levelRange: 'A2 – B2',
  },
  {
    id: 'tech',
    title: 'Технології, IT та Гаджети',
    engTitle: 'Tech, IT & Digital',
    icon: '💻',
    description: 'Програми, штучний інтелект, бази даних, пристрої, кібербезпека та оновлення.',
    color: 'from-violet-500/20 via-purple-500/10 to-transparent',
    badgeBg: 'bg-violet-500/10 text-violet-300 border-violet-500/30',
    accentColor: 'text-violet-400',
    levelRange: 'A2 – B2',
  },
  {
    id: 'city',
    title: 'Місто, Шопінг та Локації',
    engTitle: 'City, Shopping & Places',
    icon: '🏙️',
    description: 'Вулиці, каси, чеки, знижки, пішохідні переходи, хмарочоси та райони.',
    color: 'from-yellow-500/20 via-amber-500/10 to-transparent',
    badgeBg: 'bg-yellow-500/10 text-yellow-300 border-yellow-500/30',
    accentColor: 'text-yellow-400',
    levelRange: 'A1 – B1',
  },
  {
    id: 'nature',
    title: 'Природа, Погода та Довкілля',
    engTitle: 'Nature, Weather & Outdoors',
    icon: '🌲',
    description: 'Гроза, веселка, океан, гори, клімат, світанок та захист навколишнього середовища.',
    color: 'from-green-500/20 via-emerald-500/10 to-transparent',
    badgeBg: 'bg-green-500/10 text-green-300 border-green-500/30',
    accentColor: 'text-green-400',
    levelRange: 'A2 – B2',
  },
  {
    id: 'family',
    title: 'Сімʼя, Стосунки та Люди',
    engTitle: 'Family & Relationships',
    icon: '👨‍👩‍👧‍👦',
    description: 'Родичі, дружба, довіра, виховання дітей, взаємоповага та покоління.',
    color: 'from-fuchsia-500/20 via-pink-500/10 to-transparent',
    badgeBg: 'bg-fuchsia-500/10 text-fuchsia-300 border-fuchsia-500/30',
    accentColor: 'text-fuchsia-400',
    levelRange: 'A1 – B2',
  },
  {
    id: 'clothes',
    title: 'Одяг, Стиль та Мода',
    engTitle: 'Clothes, Style & Fashion',
    icon: '👗',
    description: 'Гардероб, тканини, взуття, аксесуари, примірка, фасони та щоденний лук.',
    color: 'from-purple-500/20 via-indigo-500/10 to-transparent',
    badgeBg: 'bg-purple-500/10 text-purple-300 border-purple-500/30',
    accentColor: 'text-purple-400',
    levelRange: 'A1 – B1',
  },
  {
    id: 'sports',
    title: 'Спорт, Хобі та Дозвілля',
    engTitle: 'Sports, Hobbies & Fitness',
    icon: '⚽',
    description: 'Тренування, витривалість, турніри, настільні ігри, відпочинок і туризм.',
    color: 'from-lime-500/20 via-green-500/10 to-transparent',
    badgeBg: 'bg-lime-500/10 text-lime-300 border-lime-500/30',
    accentColor: 'text-lime-400',
    levelRange: 'A1 – B2',
  },
  {
    id: 'education',
    title: 'Освіта, Навчання та Наука',
    engTitle: 'Education & Study',
    icon: '🎓',
    description: 'Лекції, стипендії, диплом, екзамени, дослідження, розуміння та менторство.',
    color: 'from-teal-500/20 via-cyan-500/10 to-transparent',
    badgeBg: 'bg-teal-500/10 text-teal-300 border-teal-500/30',
    accentColor: 'text-teal-400',
    levelRange: 'A2 – B2',
  },
  {
    id: 'finance',
    title: 'Гроші, Фінанси та Банкінг',
    engTitle: 'Money, Finance & Banking',
    icon: '💳',
    description: 'Бюджет, інвестиції, іпотека, заощадження, чеки, валюта та прибуток.',
    color: 'from-emerald-500/20 via-yellow-500/10 to-transparent',
    badgeBg: 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30',
    accentColor: 'text-emerald-400',
    levelRange: 'A2 – B2',
  },
  {
    id: 'slang',
    title: 'Жива Мова, Ідіоми та Сленг',
    engTitle: 'Idioms & Spoken English',
    icon: '💬',
    description: 'Крилаті вирази, популярні сленгові фрази та ідіоми для невимушеної бесіди.',
    color: 'from-orange-500/20 via-rose-500/10 to-transparent',
    badgeBg: 'bg-orange-500/10 text-orange-300 border-orange-500/30',
    accentColor: 'text-orange-400',
    levelRange: 'B1 – C1',
  },
];

export function isAuthenticWord(w: ThematicWord): boolean {
  if (!w || !w.eng || !w.ukr) return false;
  const eng = w.eng.trim().toLowerCase();
  const ukr = w.ukr.trim().toLowerCase();
  if (eng.length < 2 || ukr.length < 2) return false;
  // Strictly filter out synthetic dummy patterns
  if (/concept_|core_|advanced_|practical_|term_\d|_\d+$/.test(eng)) return false;
  if (ukr.includes('поняття (') || ukr.includes('термін (') || ukr.includes('#') || ukr.includes('concept_')) return false;
  return true;
}

const RAW_THEMATIC_WORDS: ThematicWord[] = [
  ...ANIMALS_WORDS,
  ...HOME_WORDS,
  ...WORK_WORDS,
  ...FOOD_WORDS,
  ...TRAVEL_WORDS,
  ...EMOTIONS_WORDS,
  ...HEALTH_WORDS,
  ...TECH_WORDS,
  ...CITY_WORDS,
  ...NATURE_WORDS,
  ...FAMILY_WORDS,
  ...CLOTHES_WORDS,
  ...SPORTS_WORDS,
  ...EDUCATION_WORDS,
  ...FINANCE_WORDS,
  ...SLANG_WORDS,
];

export const THEMATIC_WORDS: ThematicWord[] = RAW_THEMATIC_WORDS.filter(isAuthenticWord);

export function getWordsByCategory(category: string): ThematicWord[] {
  if (category === 'all') return THEMATIC_WORDS;
  return THEMATIC_WORDS.filter((w) => w.category === category);
}

export function getWordsByCategoryAndPack(category: string, packNumber: number): ThematicWord[] {
  return THEMATIC_WORDS.filter((w) => w.category === category && (w.pack === packNumber || (!w.pack && packNumber === 1)));
}

export function getCategoryInfo(categoryId: string): ThematicCategoryInfo | undefined {
  return THEMATIC_CATEGORIES.find((c) => c.id === categoryId);
}

// Convert ThematicWord to generic VocabItem for shared use in Flashcards, Quiz, Dictionary
export function toVocabItem(word: ThematicWord): VocabItem {
  return {
    id: word.id,
    ukr: word.ukr,
    eng: word.eng,
    ipa: word.ipa,
    rule: word.rule,
    category: word.category,
    level: word.level,
    emoji: word.emoji,
    exampleEn: word.exampleEn,
    exampleUa: word.exampleUa,
    mnemonicHook: word.mnemonicHook,
    collocations: word.collocations,
  };
}

export const ALL_THEMATIC_VOCAB_ITEMS: VocabItem[] = THEMATIC_WORDS.map(toVocabItem);

