import { ShadowingExercise, ChunkItem, MicroStory, SrsCard, VocabItem } from '../types';

export const SHADOWING_EXERCISES: ShadowingExercise[] = [
  {
    id: 'sh-1',
    title: 'Ранкова рутина та кава (Daily Rhythm)',
    level: 'A1',
    category: 'daily',
    text: "I usually wake up at seven and make a fresh cup of coffee before starting my workday.",
    translation: "Зазвичай я прокидаюся о сьомій і готую свіжу чашку кави перед початком робочого дня.",
    connectedSpeechTips: "wake‿up зливається в /weɪ.kʌp/, cup‿of звучить як /kʌ.pəv/, and скорочується до /ən/.",
    phoneticStress: "I US-u-al-ly WAKE up at SEV-en and MAKE a FRESH cup of COF-fee be-FORE START-ing my WORK-day.",
  },
  {
    id: 'sh-2',
    title: 'Швидкий IT-стендап (Tech Standup)',
    level: 'A2',
    category: 'business',
    text: "Yesterday I finalized the user profile module, and today I am going to focus on optimizing the database queries.",
    translation: "Учора я завершив модуль профілю користувача, а сьогодні зосереджуся на оптимізації запитів до бази даних.",
    connectedSpeechTips: "going to редукується до /ɡənə/ (gonna), focus‿on зливається як /ˈfəʊ.kə.sɒn/.",
    phoneticStress: "YES-ter-day I FI-nal-ized the US-er PRO-file MOD-ule, and to-DAY I'm GO-ing to FO-cus on OP-ti-miz-ing the DA-ta-base QUE-ries.",
  },
  {
    id: 'sh-3',
    title: 'Обговорення стратегії проєкту (Project Strategy)',
    level: 'B1',
    category: 'business',
    text: "If we prioritize the mobile experience now, we will significantly improve customer retention by the end of the quarter.",
    translation: "Якщо ми зараз надамо пріоритет мобільному досвіду, ми суттєво покращимо утримання клієнтів до кінця кварталу.",
    connectedSpeechTips: "end‿of‿the звучить як один безперервний потік /ˈen.dəv.ðə/, by the редукується.",
    phoneticStress: "If we pri-OR-i-tize the MO-bile ex-PE-ri-ence NOW, we will sig-NIF-i-cant-ly im-PROVE CUS-tom-er re-TEN-tion by the END of the QUAR-ter.",
  },
  {
    id: 'sh-4',
    title: 'Співбесіда: розповідь про сильні сторони (Job Interview)',
    level: 'B2',
    category: 'interview',
    text: "I thrive in fast-paced environments where cross-functional collaboration and creative problem-solving are essential.",
    translation: "Я продуктивно працюю у швидкому темпі, де взаємодія між командами та творче вирішення проблем є ключовими.",
    connectedSpeechTips: "fast-paced‿environments зливається через t-linking, and‿creative скорочується.",
    phoneticStress: "I THRIVE in FAST-paced en-VI-ron-ments where CROSS-func-tion-al col-lab-o-RA-tion and CRE-a-tive PROB-lem-solv-ing are es-SEN-tial.",
  },
  {
    id: 'sh-5',
    title: 'Аеропорт та непередбачувані затримки (Airport Delay)',
    level: 'B1',
    category: 'travel',
    text: "Excuse me, could you please tell me which gate the flight to London Heathrow is boarding at?",
    translation: "Перепрошую, чи не могли б ви підказати, біля якого виходу на посадку проводиться посадка на рейс до Лондона Хітроу?",
    connectedSpeechTips: "could‿you переходить у /kʊ.dʒuː/, is‿boarding‿at плавно лінкується.",
    phoneticStress: "ex-CUSE me, could you PLEASE TELL me which GATE the FLIGHT to LON-don HEATH-row is BOARD-ing at?",
  },
  {
    id: 'sh-6',
    title: 'Експертна переконлива промова (Executive Pitch)',
    level: 'C1',
    category: 'business',
    text: "Not only did we surpass our quarterly milestones, but we also laid the groundwork for sustainable international expansion.",
    translation: "Ми не лише перевиконали квартальні цілі, а й заклали міцний фундамент для сталого міжнародного масштабування.",
    connectedSpeechTips: "Інверсійне did‿we звучить швидко /ˈdɪd.wi/, laid‿the зливається через інтердентальний перехід.",
    phoneticStress: "NOT ON-ly did we sur-PASS our QUAR-ter-ly MILE-stones, but we AL-so LAID the GROUND-work for sus-TAIN-a-ble in-ter-NA-tion-al ex-PAN-sion.",
  },
];

export { CHUNK_ITEMS } from './chunksData';

export const MICRO_STORIES: MicroStory[] = [
  {
    id: 'ms-1',
    title: 'The Smart Traveler (Розумний мандрівник)',
    level: 'A2',
    ukrSummary: 'Історія про Олену, яка вирушила до Лондона і використала мовні мости для миттєвого порозуміння.',
    content: [
      {
        en: "Olena packed her bag and arrived at the central station early in the morning.",
        ua: "Олена спакувала валізу та прибула на центральний вокзал рано-вранці.",
      },
      {
        en: "She needed accurate information about her flight reservation.",
        ua: "Їй була потрібна точна інформація про бронювання рейсу.",
      },
      {
        en: "Instead of being nervous, she remembered the SVOMPT rule and spoke calmly to the officer.",
        ua: "Замість того, щоб хвилюватися, вона згадала правило SVOMPT і спокійно заговорила з офіцером.",
      },
      {
        en: "The communication was effortless because both languages share so many international roots.",
        ua: "Спілкування було легким, адже обидві мови мають стільки спільних міжнародних коренів.",
      },
    ],
    comprehensionQuestion: {
      question: "Чому Олені вдалося легко поспілкуватися з офіцером?",
      options: [
        "Вона використала спільні мовні мости та чіткий порядок слів",
        "Вона мовчки показала свій паспорт",
        "Вона найняла професійного гіда-перекладача",
        "Офіцер розмовляв українською мовою",
      ],
      correct: "Вона використала спільні мовні мости та чіткий порядок слів",
      explanation: "Олена згадала синтаксичне правило SVOMPT та міжнародні латинські корені слів (information, communication).",
    },
  },
  {
    id: 'ms-2',
    title: 'The Breakthrough Pitch (Проривний пітч)',
    level: 'B1',
    ukrSummary: 'Команда стартапу готує виступ перед інвесторами та перемагає завдяки чітким мовним чанкам.',
    content: [
      {
        en: "Max and his team were preparing for an international startup demonstration.",
        ua: "Макс та його команда готувалися до міжнародної демонстрації стартапу.",
      },
      {
        en: "Instead of translating complex Ukrainian idioms literally, they relied on natural English chunks like 'take into account' and 'make a decision'.",
        ua: "Замість дослівного перекладу складних українських ідіом, вони використали природні англійські чанки на зразок 'take into account' та 'make a decision'.",
      },
      {
        en: "The investors were impressed by their clarity and immediately offered a strategic partnership.",
        ua: "Інвестори були вражені ясністю презентації та одразу запропонували стратегічне партнерство.",
      },
    ],
    comprehensionQuestion: {
      question: "Який прийом допоміг стартаперам справити враження на інвесторів?",
      options: [
        "Використання готових природних мовних чанків замість калькування",
        "Штучне ускладнення термінології",
        "Читання тексту з папірця без зорового контакту",
        "Використання виключно мови жестів",
      ],
      correct: "Використання готових природних мовних чанків замість калькування",
      explanation: "Лексичний підхід (використання колокацій) позбавляє мовлення неприродних калькованих помилок.",
    },
  },
  {
    id: 'ms-3',
    title: 'The Power of Inversion (Сила стилю C1)',
    level: 'B2',
    ukrSummary: 'Про те, як застосування інверсії та розщеплених речень змінило академічний виступ професора.',
    content: [
      {
        en: "Hardly had the conference started when the auditorium fell into complete silence.",
        ua: "Щойно конференція розпочалася, як аудиторія занурилася в абсолютну тишу.",
      },
      {
        en: "What astonished the delegates most was the irrefutable evidence presented on climate adaptation.",
        ua: "Найбільше делегатів вразили беззаперечні докази, представлені щодо кліматичної адаптації.",
      },
      {
        en: "By mastering rhetorical inversion, the speaker held everyone's undivided attention until the very last sentence.",
        ua: "Опанувавши риторичну інверсію, спікер тримав безроздільну увагу кожного до останнього речення.",
      },
    ],
    comprehensionQuestion: {
      question: "Яка граматична конструкція на початку тексту підкреслює миттєвість події?",
      options: [
        "Hardly had ... when (Negative Inversion)",
        "Past Continuous тривалий час",
        "Passive Voice у майбутньому часі",
        "Прямий наказ в Imperative Mood",
      ],
      correct: "Hardly had ... when (Negative Inversion)",
      explanation: "Конструкція 'Hardly had the conference started when...' — це класична стилістична інверсія рівня C1.",
    },
  },
];

// Spaced Repetition (SRS) helper based on Leitner Box algorithm
export function createInitialSrsCard(word: VocabItem): SrsCard {
  const now = Date.now();
  return {
    word,
    intervalDays: 1,
    repetitions: 0,
    easeFactor: 2.5,
    dueDate: now,
    lastReviewed: now,
    box: 1,
  };
}

export function updateSrsCardGrade(
  card: SrsCard,
  grade: 'hard' | 'good' | 'easy'
): SrsCard {
  const now = Date.now();
  let nextBox: 1 | 2 | 3 | 4 = card.box;
  let nextInterval = card.intervalDays;

  if (grade === 'hard') {
    nextBox = 1;
    nextInterval = 1;
  } else if (grade === 'good') {
    if (nextBox < 4) nextBox = (nextBox + 1) as 1 | 2 | 3 | 4;
    nextInterval = nextBox === 1 ? 1 : nextBox === 2 ? 3 : nextBox === 3 ? 7 : 14;
  } else if (grade === 'easy') {
    nextBox = Math.min(4, nextBox + 1) as 1 | 2 | 3 | 4;
    nextInterval = nextBox === 4 ? 30 : nextBox === 3 ? 14 : 7;
  }

  const msInDay = 24 * 60 * 60 * 1000;
  return {
    ...card,
    box: nextBox,
    intervalDays: nextInterval,
    repetitions: card.repetitions + 1,
    lastReviewed: now,
    dueDate: now + nextInterval * msInDay,
  };
}
