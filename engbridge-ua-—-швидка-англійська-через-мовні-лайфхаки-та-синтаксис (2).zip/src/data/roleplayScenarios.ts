import { RoleplayScenario } from '../types';

export const ROLEPLAY_SCENARIOS: RoleplayScenario[] = [
  {
    id: 'london_cafe',
    title: "Кав'ярня в Лондоні",
    engTitle: "London Coffee Shop & Pastry",
    category: 'daily',
    level: 'A1',
    avatarEmoji: '☕',
    avatarBg: 'from-amber-600 to-orange-700',
    characterName: 'Oliver',
    characterRole: 'Barista at Monmouth Coffee',
    location: 'Covent Garden, London',
    descriptionUa:
      "Зробіть ранкове замовлення: оберіть каву з особливим молоком, розпитайте про свіжу випічку, уточніть пароль від Wi-Fi та розрахуйтеся.",
    initialMessageEn:
      "Good morning! Welcome to Monmouth Coffee. What can I get freshly brewed for you today?",
    initialMessageUa:
      "Доброго ранку! Ласкаво просимо до Monmouth Coffee. Що для вас свіжо заварити сьогодні?",
    systemPrompt:
      "You are Oliver, a friendly, warm, and authentic London barista at Monmouth Coffee in Covent Garden. You speak in natural conversational British English suitable for an A1-A2 learner. Keep your answers relatively short (1-3 sentences) and ask engaging follow-up questions about their order. If they order coffee, ask what kind of milk or size they prefer, suggest pastries, tell the Wi-Fi password (MonmouthGuest2026), and handle payment with contactless card.",
    missions: [
      {
        id: 'm1',
        textUa: "Привітатися та замовити каву (наприклад, Flat White або Latte)",
        textEn: "Order a coffee with specific milk/size",
        completed: false,
      },
      {
        id: 'm2',
        textUa: "Запитати про свіжу випічку або десерт (croissant, muffin тощо)",
        textEn: "Ask about fresh pastries or snacks",
        completed: false,
      },
      {
        id: 'm3',
        textUa: "Запитати пароль від безкоштовного Wi-Fi",
        textEn: "Ask for the Wi-Fi password",
        completed: false,
      },
      {
        id: 'm4',
        textUa: "Сплатити замовлення безконтактною карткою та подякувати",
        textEn: "Pay contactless and say thank you",
        completed: false,
      },
    ],
    keyVocabulary: [
      { en: "I'd like a flat white with oat milk", ua: "Я б хотів флет вайт на вівсяному молоці", tip: "Ввічлива форма I'd like замість наказового I want" },
      { en: "Could I have that to go, please?", ua: "Чи можу я взяти це з собою (на винос)?", tip: "to go (або takeaway у Британії)" },
      { en: "What's the Wi-Fi password here?", ua: "Який тут пароль від Wi-Fi?" },
      { en: "Can I pay by card / contactless?", ua: "Чи можу я сплатити карткою / безконтактно?" },
    ],
  },
  {
    id: 'tech_interview',
    title: "IT Технічна та HR Співбесіда",
    engTitle: "Tech & Behavioral Job Interview",
    category: 'interview',
    level: 'B1',
    avatarEmoji: '💼',
    avatarBg: 'from-blue-600 to-indigo-700',
    characterName: 'Sarah',
    characterRole: 'Lead Engineer & Hiring Manager',
    location: 'FinTech Startup, London / Remote',
    descriptionUa:
      "Пройдіть інтерв'ю англійською: розкажіть про свій досвід, розв'язання складного багу за методом STAR, командну взаємодію та поставте запитання про процеси в компанії.",
    initialMessageEn:
      "Hi there! Thanks for joining today's interview. We are really excited about your profile. To kick things off, could you briefly introduce yourself and share what you've been working on recently?",
    initialMessageUa:
      "Привіт! Дякую, що приєдналися до сьогоднішньої співбесіди. Ми дуже зацікавлені вашим профілем. Для початку, чи не могли б ви коротко розповісти про себе і над чим ви працювали останнім часом?",
    systemPrompt:
      "You are Sarah, a Lead Engineer and Hiring Manager at an international FinTech company. You are conducting an English technical and behavioral interview for a software developer/IT specialist. Be professional, encouraging, but probe deeper. Ask them about their recent projects, how they handled a tough technical bug or architectural decision, their experience with Agile/scrum, and invite them to ask questions about company culture.",
    missions: [
      {
        id: 'm1',
        textUa: "Коротко презентувати свій досвід та технологічний стек (3-4 речення)",
        textEn: "Give an elevator pitch of your background and stack",
        completed: false,
      },
      {
        id: 'm2',
        textUa: "Описати складний челендж або баг та як ви його вирішили",
        textEn: "Explain a tough bug or challenge you resolved",
        completed: false,
      },
      {
        id: 'm3',
        textUa: "Розповісти про комунікацію в команді під час дедлайнів",
        textEn: "Explain how you handle team communication and deadlines",
        completed: false,
      },
      {
        id: 'm4',
        textUa: "Поставити вдумливе запитання про архітектуру чи команду компанії",
        textEn: "Ask a thoughtful question about engineering culture",
        completed: false,
      },
    ],
    keyVocabulary: [
      { en: "Over the past three years, I've focused on...", ua: "Протягом останніх трьох років я фокусувався на..." },
      { en: "The main bottleneck was database latency", ua: "Головним вузьким місцем була затримка бази даних" },
      { en: "We adopted a microservices approach to scale", ua: "Ми перейшли до мікросервісного підходу для масштабування" },
      { en: "What does the typical onboarding process look like?", ua: "Як виглядає типовий процес онбордингу?" },
    ],
  },
  {
    id: 'airport_immigration',
    title: "Паспортний контроль в аеропорту",
    engTitle: "Airport Border & Customs Control",
    category: 'travel',
    level: 'A2',
    avatarEmoji: '✈️',
    avatarBg: 'from-sky-600 to-blue-800',
    characterName: 'Officer Davies',
    characterRole: 'UK Border Force Officer',
    location: 'London Heathrow Airport, Terminal 5',
    descriptionUa:
      "Впевнено пройдіть інтерв'ю на прикордонному контролі: поясніть мету візиту, тривалість перебування, місце проживання та наявність зворотного квитка.",
    initialMessageEn:
      "Good afternoon. Passports and landing documents, please. What is the primary purpose of your visit to the United Kingdom?",
    initialMessageUa:
      "Доброго дня. Паспорти та супровідні документи, будь ласка. Яка основна мета вашого візиту до Сполученого Королівства?",
    systemPrompt:
      "You are Officer Davies, a professional and strict but fair UK Border Force officer at London Heathrow Terminal 5. You ask clear, official questions about: purpose of travel (tourism, conference, business), length of stay, accommodation address, proof of return ticket, and financial sufficiency. Maintain an authoritative yet polite British official tone.",
    missions: [
      {
        id: 'm1',
        textUa: "Чітко назвати мету поїздки (туризм, конференція, відвідування друзів)",
        textEn: "State the purpose of your trip clearly",
        completed: false,
      },
      {
        id: 'm2',
        textUa: "Вказати тривалість перебування (наприклад, 10 днів)",
        textEn: "Specify the duration of your stay",
        completed: false,
      },
      {
        id: 'm3',
        textUa: "Повідомити назву або адресу готелю/апартаментів",
        textEn: "Provide your accommodation details",
        completed: false,
      },
      {
        id: 'm4',
        textUa: "Підтвердити наявність зворотного квитка та страховки",
        textEn: "Confirm your return ticket",
        completed: false,
      },
    ],
    keyVocabulary: [
      { en: "I'm visiting for tourism and a tech conference", ua: "Я приїхав з туристичною метою та на технічну конференцію" },
      { en: "I'll be staying for twelve days in total", ua: "Я пробуду тут загалом дванадцять днів" },
      { en: "Here is my hotel reservation and return ticket", ua: "Ось моя бронь готелю та зворотний квиток" },
      { en: "I have booked an Airbnb near South Kensington", ua: "Я забронював житло на Airbnb біля Південного Кенсінгтона" },
    ],
  },
  {
    id: 'it_daily_standup',
    title: "Щоденний IT-стендап (Daily Scrum)",
    engTitle: "Daily IT Standup & Blockers",
    category: 'work',
    level: 'B1',
    avatarEmoji: '💻',
    avatarBg: 'from-emerald-600 to-teal-800',
    characterName: 'Alex',
    characterRole: 'Scrum Master & Product Lead',
    location: 'Remote Slack / Google Meet Standup',
    descriptionUa:
      "Поділіться статусом за класичною формулою: що зроблено вчора, що в планах на сьогодні, та чи є якісь блокери або залежності від колег.",
    initialMessageEn:
      "Hey team, good to see everyone! Let's get our morning standup rolling. You're up first — what did you wrap up yesterday, and what's on your radar for today?",
    initialMessageUa:
      "Привіт усім, радий бачити! Почнімо наш ранковий стендап. Ти перший — що ти закрив учора і що у твоїх планах на сьогодні?",
    systemPrompt:
      "You are Alex, an energetic and supportive Agile Scrum Master / Product Lead on a software engineering team. You listen to the user's standup update (yesterday, today, blockers). Ask relevant tech follow-ups (e.g. PR review status, unit tests, QA deployment, API integration blockers) and help unblock issues efficiently.",
    missions: [
      {
        id: 'm1',
        textUa: "Розповісти, над яким таском або фічею ви працювали вчора",
        textEn: "Report what you accomplished yesterday",
        completed: false,
      },
      {
        id: 'm2',
        textUa: "Окреслити завдання на сьогодні (Today I'm planning to...)",
        textEn: "Outline your agenda for today",
        completed: false,
      },
      {
        id: 'm3',
        textUa: "Згадати блокер або попросити про Code Review (PR)",
        textEn: "Mention a blocker or ask for code review",
        completed: false,
      },
      {
        id: 'm4',
        textUa: "Погодити час короткого зідзвону 1-на-1 (sync up / drop a line)",
        textEn: "Propose a quick sync or call with a teammate",
        completed: false,
      },
    ],
    keyVocabulary: [
      { en: "Yesterday I merged the authentication pull request", ua: "Учора я змерджив PR з автентифікацією" },
      { en: "Today I'm going to focus on optimizing the database queries", ua: "Сьогодні я зосереджуся на оптимізації запитів до бази" },
      { en: "I'm currently blocked by the third-party payment API", ua: "Я наразі заблокований стороннім платіжним API" },
      { en: "Could someone take a look at my PR when free?", ua: "Чи міг би хтось глянути мій PR, коли звільниться?" },
    ],
  },
  {
    id: 'hotel_checkin',
    title: "Готель: Заселення та сервіс",
    engTitle: "Hotel Check-in & Room Request",
    category: 'travel',
    level: 'A2',
    avatarEmoji: '🏨',
    avatarBg: 'from-violet-600 to-purple-800',
    characterName: 'Marco',
    characterRole: 'Front Desk Concierge',
    location: 'The Kensington Grand Hotel, London',
    descriptionUa:
      "Заселіться в номер, розпитайте про сніданок, попросіть тихий номер на високому поверсі та повідомте про неробочий кондиціонер.",
    initialMessageEn:
      "Good evening, welcome to The Kensington Grand Hotel! How may I assist you with your reservation tonight?",
    initialMessageUa:
      "Доброго вечора, ласкаво просимо до The Kensington Grand Hotel! Чим можу допомогти щодо вашого бронювання сьогодні?",
    systemPrompt:
      "You are Marco, a polite and attentive hotel concierge in London. Help the user check in, check their booking under their name, assign a room, explain breakfast hours (7am-10am) and gym access, respond courteously to special requests like extra pillows or quiet rooms, and swiftly offer a solution if they report an issue.",
    missions: [
      {
        id: 'm1',
        textUa: "Сказати про наявність броні та назвати своє ім'я",
        textEn: "Check in with reservation name",
        completed: false,
      },
      {
        id: 'm2',
        textUa: "Попросити тихий номер з гарним краєвидом (quiet room on a high floor)",
        textEn: "Request a quiet room or upgrade",
        completed: false,
      },
      {
        id: 'm3',
        textUa: "Уточнити час сніданку та розташування ресторану",
        textEn: "Ask about breakfast timing and location",
        completed: false,
      },
      {
        id: 'm4',
        textUa: "Повідомити про дрібну проблему в номері (наприклад, потрібні додаткові рушники)",
        textEn: "Report an issue or request amenities",
        completed: false,
      },
    ],
    keyVocabulary: [
      { en: "I have a reservation under the name of...", ua: "У мене бронь на ім'я..." },
      { en: "Is breakfast included in my room rate?", ua: "Чи входить сніданок у вартість номеру?" },
      { en: "Could we have two extra towels brought up?", ua: "Чи не могли б ви принести два додаткових рушники?" },
      { en: "What time is checkout tomorrow morning?", ua: "О котрій годині виселення завтра вранці?" },
    ],
  },
  {
    id: 'doctor_pharmacy',
    title: "Аптека та Візит до лікаря (NHS)",
    engTitle: "Pharmacy & Describing Symptoms",
    category: 'daily',
    level: 'B1',
    avatarEmoji: '🏥',
    avatarBg: 'from-rose-600 to-pink-800',
    characterName: 'Clara',
    characterRole: 'Pharmacist & Healthcare Advisor',
    location: 'Boots Pharmacy, Central London',
    descriptionUa:
      "Опишіть нездужання (головний біль, застуда, алергія), дізнайтеся правильне дозування ліків та попередьте про чутливість до антибіотиків.",
    initialMessageEn:
      "Hello! Welcome to Boots Pharmacy. You look a bit under the weather — how can I help you feel better today?",
    initialMessageUa:
      "Вітаю! Ласкаво просимо до Boots Pharmacy. Схоже, вам не дуже добре — як я можу допомогти вам почуватися краще сьогодні?",
    systemPrompt:
      "You are Clara, a knowledgeable and empathetic London pharmacist. Ask the user about their specific symptoms (headache, sore throat, fever, stomach upset), how long they've had them, any existing allergies, recommend over-the-counter remedies (paracetamol, ibuprofen, antihistamines), explain dosages clearly, and advise seeing a GP if symptoms persist.",
    missions: [
      {
        id: 'm1',
        textUa: "Описати симптоми (біль у горлі, нежить або ломота в тілі)",
        textEn: "Describe your symptoms and pain level",
        completed: false,
      },
      {
        id: 'm2',
        textUa: "Зазначити, скільки днів тривають симптоми (for the past 2 days)",
        textEn: "State how long you've felt ill",
        completed: false,
      },
      {
        id: 'm3',
        textUa: "Уточнити правила прийому: до чи після їжі (before or after meals)",
        textEn: "Ask about dosage and meal instructions",
        completed: false,
      },
      {
        id: 'm4',
        textUa: "Запитати, чи викликає цей препарат сонливість (drowsiness)",
        textEn: "Ask if the medicine causes drowsiness",
        completed: false,
      },
    ],
    keyVocabulary: [
      { en: "I've had a persistent sore throat and a fever", ua: "У мене стійкий біль у горлі та температура" },
      { en: "Does this medication cause any drowsiness?", ua: "Чи викликають ці ліки сонливість?" },
      { en: "How many tablets should I take per day?", ua: "Скільки таблеток мені слід приймати на день?" },
      { en: "I'm allergic to penicillin", ua: "У мене алергія на пеніцилін" },
    ],
  },
];
