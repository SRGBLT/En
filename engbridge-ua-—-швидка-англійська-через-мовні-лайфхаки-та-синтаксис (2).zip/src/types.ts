export type HackCategory = 'all' | 'suffix' | 'prefix' | 'traps';

export type CefrLevel = 'A1' | 'A2' | 'B1' | 'B2' | 'C1';

export interface LinguisticHack {
  id: string;
  type: 'suffix' | 'prefix' | 'traps';
  title: string;
  description: string;
  formula: string;
  tag: string;
  badgeColor: string;
  examplesCount: string;
}

export interface VocabItem {
  id?: string;
  ukr: string;
  eng: string;
  ipa: string;
  rule: string;
  trap?: string;
  category?: string;
  level?: CefrLevel;
  emoji?: string;
  exampleEn?: string;
  exampleUa?: string;
  mnemonicHook?: string;
  collocations?: string[];
}

export interface ThematicWord extends VocabItem {
  id: string;
  category: string;
  ukr: string;
  eng: string;
  ipa: string;
  rule: string;
  level: CefrLevel;
  emoji: string;
  exampleEn: string;
  exampleUa: string;
  collocations: string[];
  mnemonicHook: string;
  pack?: number;
}

export interface ThematicCategoryInfo {
  id: string;
  title: string;
  engTitle: string;
  icon: string;
  description: string;
  color: string;
  badgeBg: string;
  accentColor: string;
  levelRange: string;
}

export interface SentencePuzzle {
  id?: string;
  ukr: string;
  words: string[];
  rule: string;
  category?: 'affirmative' | 'negative' | 'question' | 'conditional' | 'advanced';
  categoryLabel?: string;
  alternativeOrders?: string[][];
  slots?: { word: string; role: 'Subject' | 'Verb' | 'Object' | 'Manner' | 'Place' | 'Time' | 'Connector' | 'Modal' | 'Condition' | 'Auxiliary' }[];
}

export interface SyntaxInfo {
  badge: string;
  formula: string;
  trapNote: string;
}

export type SkillCompetency = 'grammar' | 'syntax' | 'lexical' | 'bridges';

export interface PlacementQuestion {
  id?: number | string;
  category: string;
  question: string;
  desc: string;
  options: string[];
  correct: string;
  ruleHint: string;
  cefr?: CefrLevel;
  tier?: 'foundation' | 'intermediate' | 'advanced';
  skill?: SkillCompetency;
  shuffledOptions?: string[];
}

export interface CurriculumModule {
  title: string;
  desc: string;
  badge: string;
  actionCategory: string;
}

export interface LevelCurriculum {
  title: string;
  tagline: string;
  description: string;
  modules: CurriculumModule[];
}

export interface SrsCard {
  word: VocabItem;
  intervalDays: number;
  repetitions: number;
  easeFactor: number;
  dueDate: number;
  lastReviewed: number;
  box: 1 | 2 | 3 | 4;
}

export interface ShadowingExercise {
  id: string;
  title: string;
  level: CefrLevel;
  text: string;
  translation: string;
  connectedSpeechTips: string;
  phoneticStress: string;
  category: 'daily' | 'business' | 'interview' | 'travel';
}

export interface ShadowingWordEvaluation {
  word: string;
  status: 'match' | 'similar' | 'missing' | 'extra';
  spokenWord?: string;
  note?: string;
}

export interface ShadowingEvaluationResult {
  score: number; // 0 - 100
  accuracyScore: number;
  fluencyScore: number;
  pronunciationScore: number;
  wordsComparison: ShadowingWordEvaluation[];
  transcribedText: string;
  feedbackUa: string;
  connectedSpeechFound: string[];
  connectedSpeechMissed: string[];
  xpEarned: number;
}


export type ChunkCategory =
  | 'all'
  | 'make_vs_do'
  | 'take_have_get'
  | 'business_chunks'
  | 'conversation_starters'
  | 'connectors'
  | 'idiomatic_collocations';

export interface ChunkItem {
  id: string;
  chunk: string;
  ukr: string;
  typicalMistake: string;
  exampleSent: string;
  category: 'make_vs_do' | 'take_have_get' | 'business_chunks' | 'conversation_starters' | 'connectors' | 'idiomatic_collocations';
  level?: CefrLevel;
  blankSent?: string;
  options?: string[];
  correctWord?: string;
  explanation?: string;
}

export interface MicroStory {
  id: string;
  title: string;
  level: CefrLevel;
  ukrSummary: string;
  content: { en: string; ua: string }[];
  comprehensionQuestion: {
    question: string;
    options: string[];
    correct: string;
    explanation: string;
  };
}

export interface MistakeRecord {
  id: string;
  type: 'vocab' | 'test_question' | 'syntax_sentence';
  prompt: string;
  userWrongAnswer: string;
  correctAnswer: string;
  explanation: string;
  mnemonicHint: string;
  category?: string;
  level?: CefrLevel;
  errorCount: number;
  consecutiveCorrect: number;
  isMastered: boolean;
  lastMistakeTimestamp: number;
  vocabItem?: VocabItem;
}

export interface UserProfile {
  isLoggedIn: boolean;
  uid: string;
  displayName: string;
  email: string;
  level: number;
  xp: number;
  quizScore: number;
  maxCombo: number;
  currentCombo: number;
  correctCount: number;
  totalAnswered: number;
  learnedWords: VocabItem[];
  srsCards: SrsCard[];
  mistakes: MistakeRecord[];
  dailyStreak: number;
  lastActiveDate: string;
  dailyGoalMinutes: number;
  todayMinutesSpent: number;
  cefrLevel: CefrLevel | null;
  cefrScore: number;
  reminderSettings?: ReminderSettings;
  topicReviewRecords?: Record<string, TopicReviewRecord>;
}

export interface ReminderSettings {
  enabled: boolean;
  browserNotificationsEnabled: boolean;
  reminderTime: string; // e.g. "19:00"
  frequency: 'daily' | 'every_other_day' | 'weekdays';
  remindTopicsDecaying: boolean;
  remindSrsWords: boolean;
  remindMistakes: boolean;
  soundEnabled: boolean;
  lastNotificationDate?: string;
}

export interface TopicReviewRecord {
  categoryId: string;
  lastReviewedAt: number;
  reviewCount: number;
  masteredPacks?: number[];
}

export interface TopicRetentionStatus {
  categoryId: string;
  title: string;
  engTitle: string;
  icon: string;
  color: string;
  lastReviewedAt: number;
  daysPassed: number;
  retentionPercent: number; // 0 - 100%
  urgency: 'critical' | 'high' | 'medium' | 'fresh';
  statusLabel: string;
  dueWordsCount: number;
  totalWordsLearned: number;
  recommendedPack: number;
}

export interface RoleplayMission {
  id: string;
  textUa: string;
  textEn: string;
  completed: boolean;
}

export interface RoleplayScenario {
  id: string;
  title: string;
  engTitle: string;
  category: 'daily' | 'work' | 'travel' | 'interview' | 'social' | 'custom';
  level: CefrLevel;
  avatarEmoji: string;
  avatarBg: string;
  characterName: string;
  characterRole: string;
  location: string;
  descriptionUa: string;
  initialMessageEn: string;
  initialMessageUa: string;
  systemPrompt: string;
  missions: RoleplayMission[];
  keyVocabulary: { en: string; ua: string; tip?: string }[];
}

export interface RoleplayFeedback {
  hasMistakes: boolean;
  corrections?: string[];
  betterAlternative?: string;
  linguisticTipUa?: string;
}

export interface RoleplayMessage {
  id: string;
  sender: 'ai' | 'user';
  textEn: string;
  textUa?: string;
  timestamp: number;
  audioUrl?: string;
  suggestedResponses?: { en: string; ua: string }[];
  feedbackOnUser?: RoleplayFeedback;
}

export interface RoleplayReport {
  score: number; // 0 - 100
  assessedLevel: CefrLevel;
  taskCompletionPercent: number;
  fluencyScore: number;
  grammarScore: number;
  vocabularyScore: number;
  strengthsUa: string[];
  mistakesAnalyzed: { userSaid: string; correction: string; explanationUa: string }[];
  recommendedVocabulary: { en: string; ua: string }[];
  overallSummaryUa: string;
  xpEarned: number;
}

