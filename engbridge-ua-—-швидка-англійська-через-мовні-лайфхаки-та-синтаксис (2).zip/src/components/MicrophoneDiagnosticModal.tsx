import React, { useState, useEffect, useRef } from 'react';
import {
  Mic,
  MicOff,
  AlertCircle,
  CheckCircle2,
  ExternalLink,
  Volume2,
  RefreshCw,
  X,
  HelpCircle,
  Laptop,
  Apple,
  FileAudio,
  ShieldAlert,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import {
  isRunningInIframe,
  getAudioInputDevices,
  requestMicrophonePermission,
  createAudioLevelMonitor,
  createSpeechRecognizer,
  isSpeechRecognitionSupported,
} from '../utils/shadowingEvaluator';

interface MicrophoneDiagnosticModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectDeviceId?: (deviceId: string) => void;
  selectedDeviceId?: string;
}

export const MicrophoneDiagnosticModal: React.FC<MicrophoneDiagnosticModalProps> = ({
  isOpen,
  onClose,
  onSelectDeviceId,
  selectedDeviceId = '',
}) => {
  const [devices, setDevices] = useState<MediaDeviceInfo[]>([]);
  const [activeDeviceId, setActiveDeviceId] = useState<string>(selectedDeviceId);
  const [isTesting, setIsTesting] = useState(false);
  const [audioLevel, setAudioLevel] = useState(0);
  const [testTranscript, setTestTranscript] = useState('');
  const [permissionStatus, setPermissionStatus] = useState<'prompt' | 'granted' | 'denied' | 'unknown'>('unknown');
  const [testError, setTestError] = useState<string | null>(null);
  const [showFaq, setShowFaq] = useState(true);

  const streamRef = useRef<MediaStream | null>(null);
  const monitorRef = useRef<{ stop: () => void } | null>(null);
  const recognizerRef = useRef<{ stop: () => void } | null>(null);

  const inIframe = isRunningInIframe();

  // Load devices and permission status on open
  useEffect(() => {
    if (!isOpen) {
      stopTest();
      return;
    }

    const checkStatus = async () => {
      // Check query permission if supported
      if (typeof navigator !== 'undefined' && (navigator as any).permissions?.query) {
        try {
          const res = await (navigator as any).permissions.query({ name: 'microphone' });
          setPermissionStatus(res.state);
          res.onchange = () => {
            setPermissionStatus(res.state);
          };
        } catch {
          // not supported on some platforms
        }
      }

      // Enumerate audio devices
      const list = await getAudioInputDevices();
      setDevices(list);
    };

    checkStatus();
  }, [isOpen]);

  const stopTest = () => {
    if (monitorRef.current) {
      monitorRef.current.stop();
      monitorRef.current = null;
    }
    if (recognizerRef.current) {
      recognizerRef.current.stop();
      recognizerRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    setIsTesting(false);
    setAudioLevel(0);
  };

  const handleStartTest = async () => {
    stopTest();
    setTestError(null);
    setTestTranscript('');

    const res = await requestMicrophonePermission(activeDeviceId || undefined);
    if (!res.stream) {
      setTestError(res.error || 'Не вдалося отримати потік з мікрофона.');
      setPermissionStatus('denied');
      return;
    }

    streamRef.current = res.stream;
    setPermissionStatus('granted');
    setIsTesting(true);

    // Refresh devices list since permissions are now granted
    const updatedDevices = await getAudioInputDevices();
    setDevices(updatedDevices);

    // Start volume monitor
    const mon = createAudioLevelMonitor(res.stream, (lvl) => {
      setAudioLevel(lvl);
    });
    monitorRef.current = mon;

    // Optional speech recognition test
    if (isSpeechRecognitionSupported()) {
      const rec = createSpeechRecognizer(
        (text) => {
          setTestTranscript(text);
        },
        (recErr) => {
          console.warn('Speech test note:', recErr);
        }
      );
      recognizerRef.current = rec;
    }
  };

  const handleDeviceChange = (devId: string) => {
    setActiveDeviceId(devId);
    if (onSelectDeviceId) {
      onSelectDeviceId(devId);
    }
    if (isTesting) {
      stopTest();
    }
  };

  const handleOpenInNewTab = () => {
    if (typeof window !== 'undefined') {
      window.open(window.location.href, '_blank', 'noopener,noreferrer');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-2xl max-h-[90vh] bg-slate-900 border border-slate-700/80 rounded-3xl shadow-2xl overflow-hidden flex flex-col text-slate-100">
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-slate-800 flex items-center justify-between bg-slate-900/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white shadow-lg shadow-indigo-500/25">
              <Mic className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-black text-white flex items-center gap-2">
                Діагностика та тест мікрофона
              </h2>
              <p className="text-xs text-slate-400">
                Перевірка доступу, тестування чутливості та вирішення блокувань
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              stopTest();
              onClose();
            }}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-6 flex-1 text-sm">
          {/* Status Diagnostic Bar */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {/* 1. Browser API Support */}
            <div className="p-3.5 rounded-2xl bg-slate-800/60 border border-slate-700/60 space-y-1">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                Web Audio API
              </span>
              <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-400">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>Підтримується</span>
              </div>
            </div>

            {/* 2. Environment / iFrame check */}
            <div
              className={`p-3.5 rounded-2xl border space-y-1 ${
                inIframe
                  ? 'bg-amber-500/10 border-amber-500/40 text-amber-300'
                  : 'bg-emerald-500/10 border-emerald-500/40 text-emerald-300'
              }`}
            >
              <span className="text-[10px] font-bold uppercase tracking-wider opacity-80">
                Середовище запуску
              </span>
              <div className="flex items-center gap-1.5 text-xs font-bold">
                {inIframe ? (
                  <>
                    <ShieldAlert className="w-4 h-4 shrink-0 text-amber-400" />
                    <span>iFrame (Передперегляд)</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                    <span>Пряма вкладка (Native)</span>
                  </>
                )}
              </div>
            </div>

            {/* 3. Browser Permission State */}
            <div className="p-3.5 rounded-2xl bg-slate-800/60 border border-slate-700/60 space-y-1">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                Дозвіл у браузері
              </span>
              <div className="flex items-center gap-1.5 text-xs font-bold">
                {permissionStatus === 'granted' ? (
                  <span className="text-emerald-400 flex items-center gap-1">
                    <CheckCircle2 className="w-4 h-4" /> Надано (Granted)
                  </span>
                ) : permissionStatus === 'denied' ? (
                  <span className="text-rose-400 flex items-center gap-1">
                    <MicOff className="w-4 h-4" /> Заблоковано (Denied)
                  </span>
                ) : (
                  <span className="text-amber-400 flex items-center gap-1">
                    <AlertCircle className="w-4 h-4" /> Очікує запиту (Prompt)
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* iFrame Notice with Instant Action */}
          {inIframe && (
            <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-500/15 via-orange-500/10 to-amber-500/15 border border-amber-500/30 space-y-2">
              <div className="flex items-center gap-2 text-amber-300 font-bold text-xs">
                <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
                <span>Чому пише «Заблоковано», якщо ви дозволили мікрофон?</span>
              </div>
              <p className="text-slate-300 text-xs leading-relaxed">
                Додаток зараз працює у вбудованому вікні (<strong>iFrame</strong>) AI Studio Build. Браузер Chrome та Safari часто блокують доступ до мікрофона для внутрішніх фреймів, навіть якщо ви натиснули «Дозволити» для головного сайту.
              </p>
              <div className="pt-1">
                <button
                  onClick={handleOpenInNewTab}
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-xs flex items-center gap-2 shadow-lg shadow-amber-500/20 transition cursor-pointer"
                >
                  <ExternalLink className="w-4 h-4" />
                  Відкрити тренажер у новій вкладці (Без обмежень iFrame)
                </button>
              </div>
            </div>
          )}

          {/* Live Audio Meter & Mic Test */}
          <div className="p-5 rounded-2xl bg-slate-800/50 border border-slate-700 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-indigo-300 flex items-center gap-1.5">
                  <Volume2 className="w-4 h-4 text-indigo-400" />
                  Живий тест чутливості мікрофона
                </h3>
                <p className="text-[11px] text-slate-400">
                  Увімкніть тест і скажіть будь-яке слово, щоб перевірити індикатор звуку
                </p>
              </div>

              <div className="flex items-center gap-2">
                {isTesting ? (
                  <button
                    onClick={stopTest}
                    className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center gap-2 transition cursor-pointer shadow-md shadow-rose-600/20"
                  >
                    <MicOff className="w-4 h-4" />
                    Зупинити тест
                  </button>
                ) : (
                  <button
                    onClick={handleStartTest}
                    className="px-4 py-2 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-bold text-xs flex items-center gap-2 transition cursor-pointer shadow-lg shadow-indigo-600/25"
                  >
                    <Mic className="w-4 h-4" />
                    Почати тест звуку
                  </button>
                )}
              </div>
            </div>

            {/* Device Selector */}
            {devices.length > 0 && (
              <div className="space-y-1.5">
                <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                  Обраний мікрофон (Пристрій вводу):
                </label>
                <select
                  value={activeDeviceId}
                  onChange={(e) => handleDeviceChange(e.target.value)}
                  className="w-full bg-slate-850 border border-slate-750 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                >
                  <option value="">За замовчуванням (Default System Microphone)</option>
                  {devices.map((d, idx) => (
                    <option key={d.deviceId || idx} value={d.deviceId}>
                      {d.label || `Мікрофон #${idx + 1}`}
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* Error Message if Test Failed */}
            {testError && (
              <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <span className="leading-relaxed">{testError}</span>
              </div>
            )}

            {/* VU Meter & Wave Indicator */}
            {isTesting && (
              <div className="space-y-3 pt-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-300 flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
                    Рівень сигналу: {audioLevel}%
                  </span>
                  <span className="text-[11px] text-slate-400">
                    {audioLevel > 5 ? '🟢 Звук надходить чудово!' : '⚪ Скажіть щось голосніше...'}
                  </span>
                </div>

                {/* Progress VU Bar */}
                <div className="h-4 w-full bg-slate-900 rounded-full overflow-hidden p-0.5 border border-slate-700 flex">
                  <div
                    className={`h-full rounded-full transition-all duration-75 ${
                      audioLevel > 70
                        ? 'bg-gradient-to-r from-emerald-500 via-amber-400 to-rose-500'
                        : audioLevel > 20
                        ? 'bg-gradient-to-r from-emerald-500 to-teal-400'
                        : 'bg-emerald-600'
                    }`}
                    style={{ width: `${Math.max(4, audioLevel)}%` }}
                  />
                </div>

                {/* Animated Sound Wave Bars */}
                <div className="flex items-center justify-center gap-1.5 py-2">
                  {[12, 24, 38, 55, 75, 45, 30, 60, 80, 50, 25, 40, 20].map((h, i) => {
                    const scaled = Math.min(48, Math.max(6, Math.round((h * audioLevel) / 35)));
                    return (
                      <span
                        key={i}
                        className={`w-1 rounded-full transition-all duration-100 ${
                          audioLevel > 15
                            ? 'bg-gradient-to-t from-indigo-500 via-purple-400 to-pink-400'
                            : 'bg-slate-700'
                        }`}
                        style={{ height: `${scaled}px` }}
                      />
                    );
                  })}
                </div>

                {/* Live Transcript Test Box */}
                <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 text-xs space-y-1">
                  <div className="text-[10px] uppercase font-bold text-slate-400">
                    Тестове розпізнавання мови в реальному часі:
                  </div>
                  <div className="text-white font-medium min-h-[20px]">
                    {testTranscript ? (
                      <span className="text-emerald-300 font-bold">"{testTranscript}"</span>
                    ) : (
                      <span className="text-slate-500 italic">
                        Скажіть, наприклад: "Hello world" або "Testing my voice"...
                      </span>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Step-by-Step Resolution Guide (Accordion) */}
          <div className="p-4 rounded-2xl bg-slate-850 border border-slate-750 space-y-3">
            <button
              onClick={() => setShowFaq(!showFaq)}
              className="w-full flex items-center justify-between text-left font-bold text-xs uppercase tracking-wider text-slate-300 hover:text-white transition cursor-pointer"
            >
              <span className="flex items-center gap-2">
                <HelpCircle className="w-4 h-4 text-indigo-400" />
                Як розблокувати мікрофон: 3 головні кроки
              </span>
              {showFaq ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>

            {showFaq && (
              <div className="space-y-3 pt-2 text-xs text-slate-300">
                {/* 1. Address Bar Lock */}
                <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700/80 space-y-1">
                  <div className="font-bold text-white flex items-center gap-2">
                    <span className="w-5 h-5 rounded-lg bg-indigo-600/30 text-indigo-300 flex items-center justify-center text-[11px] font-black">
                      1
                    </span>
                    Значок замочка 🔒 в адресному рядку браузера
                  </div>
                  <p className="text-slate-300 text-[11px] leading-relaxed pl-7">
                    Натисніть на значок <strong>🔒 або налаштувань сайту</strong> зліва від адреси вгорі екрана. Переконайтеся, що перемикач «Мікрофон» встановлено у положення <strong>«Дозволити» (Allow)</strong>.
                  </p>
                </div>

                {/* 2. System Level Permissions */}
                <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700/80 space-y-2">
                  <div className="font-bold text-white flex items-center gap-2">
                    <span className="w-5 h-5 rounded-lg bg-indigo-600/30 text-indigo-300 flex items-center justify-center text-[11px] font-black">
                      2
                    </span>
                    Системні налаштування операційної системи (macOS / Windows)
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pl-7">
                    <div className="p-2.5 rounded-lg bg-slate-900/60 border border-slate-750 text-[11px] space-y-1">
                      <div className="font-bold text-sky-400 flex items-center gap-1.5">
                        <Apple className="w-3.5 h-3.5" />
                        Apple macOS:
                      </div>
                      <p className="text-slate-400 text-[10px] leading-relaxed">
                        Системні параметри → Приватність і безпека → Мікрофон → Увімкніть перемикач для <strong>Google Chrome</strong> або вашого браузера.
                      </p>
                    </div>
                    <div className="p-2.5 rounded-lg bg-slate-900/60 border border-slate-750 text-[11px] space-y-1">
                      <div className="font-bold text-blue-400 flex items-center gap-1.5">
                        <Laptop className="w-3.5 h-3.5" />
                        Windows 10 / 11:
                      </div>
                      <p className="text-slate-400 text-[10px] leading-relaxed">
                        Параметри → Конфіденційність → Мікрофон → Увімкніть «Дозволити програмам доступ до мікрофона» та «Дозволити класичним програмам».
                      </p>
                    </div>
                  </div>
                </div>

                {/* 3. New Tab Direct Access */}
                <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700/80 space-y-1">
                  <div className="font-bold text-white flex items-center gap-2">
                    <span className="w-5 h-5 rounded-lg bg-indigo-600/30 text-indigo-300 flex items-center justify-center text-[11px] font-black">
                      3
                    </span>
                    Відкрити в окремому вікні (Прямий дозвіл без фреймів)
                  </div>
                  <p className="text-slate-300 text-[11px] leading-relaxed pl-7">
                    Якщо попередні кроки виконано, але мікрофон усе одно блокується — відкрийте тренажер за прямою URL-адресою в новій вкладці браузера, щоб уникнути обмежень вбудованого фрейму.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 sm:p-5 border-t border-slate-800 bg-slate-900/90 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <span className="w-2 h-2 rounded-full bg-emerald-400 shrink-0" />
            <span>Готові до практики мовлення та Shadowing</span>
          </div>

          <div className="flex items-center gap-2.5 w-full sm:w-auto">
            {inIframe && (
              <button
                onClick={handleOpenInNewTab}
                className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                Нова вкладка
              </button>
            )}
            <button
              onClick={() => {
                stopTest();
                onClose();
              }}
              className="flex-1 sm:flex-none px-6 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white text-xs font-bold shadow-lg shadow-indigo-600/20 transition cursor-pointer"
            >
              Зберегти та закрити
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
