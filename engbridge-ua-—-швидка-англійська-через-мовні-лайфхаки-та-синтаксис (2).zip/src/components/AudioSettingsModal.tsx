import React, { useState, useEffect } from 'react';
import {
  Volume2,
  VolumeX,
  Sparkles,
  Play,
  Check,
  X,
  Sliders,
  Radio,
  Gauge,
  Headphones,
  RotateCcw,
  Mic,
} from 'lucide-react';
import {
  getAudioSettings,
  updateAudioSettings,
  speakEnglish,
  stopSpeech,
  subscribeAudioState,
  isCurrentlySpeaking,
  GoogleTtsVoice,
  AudioSettings,
} from '../utils/audio';
import { MicrophoneDiagnosticModal } from './MicrophoneDiagnosticModal';

interface AudioSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  isAudioMuted: boolean;
  onToggleAudio: () => void;
}

interface VoiceOption {
  id: GoogleTtsVoice;
  title: string;
  tag: string;
  description: string;
  gender: 'female' | 'male' | 'neutral';
  isPopular?: boolean;
}

const VOICE_OPTIONS: VoiceOption[] = [
  {
    id: 'Kore',
    title: 'Google Kore',
    tag: 'Studio AI • Жіночий',
    description: 'Кришталево чиста вимова, природна інтонація носія американської англійської.',
    gender: 'female',
    isPopular: true,
  },
  {
    id: 'Puck',
    title: 'Google Puck',
    tag: 'Studio AI • Чоловічий',
    description: 'Живий та енергійний тембр, ідеальний для сучасних діалогів та чанків.',
    gender: 'male',
    isPopular: true,
  },
  {
    id: 'Zephyr',
    title: 'Google Zephyr',
    tag: 'Studio AI • Теплий',
    description: 'Збалансований, спокійний та м’який голос для комфортного тренування.',
    gender: 'neutral',
  },
  {
    id: 'Charon',
    title: 'Google Charon',
    tag: 'Studio AI • Глибокий',
    description: 'Впевнений, низький та виразний тон із чітким акцентуванням кожного звуку.',
    gender: 'male',
  },
  {
    id: 'google_translate',
    title: 'Google Classic TTS',
    tag: 'Класичний Google',
    description: 'Еталонний голос Google Translate. Максимально швидкий відгук.',
    gender: 'neutral',
  },
  {
    id: 'browser_google',
    title: 'Локальний Google Voice',
    tag: 'WebSpeech Chrome',
    description: 'Синтезатор вашого браузера (працює миттєво без інтернет-трафіку).',
    gender: 'neutral',
  },
];

const SAMPLE_PHRASES = [
  'Make a tough decision and keep moving forward.',
  'Could you please give me a hand with this task?',
  'Practice makes perfect, so never give up.',
  'Take care of yourself and have a wonderful day!',
];

export const AudioSettingsModal: React.FC<AudioSettingsModalProps> = ({
  isOpen,
  onClose,
  isAudioMuted,
  onToggleAudio,
}) => {
  const [settings, setSettings] = useState<AudioSettings>(getAudioSettings);
  const [speaking, setSpeaking] = useState<boolean>(false);
  const [currentText, setCurrentText] = useState<string | null>(null);
  const [testPhrase, setTestPhrase] = useState<string>(SAMPLE_PHRASES[0]);
  const [isMicDiagnosticOpen, setIsMicDiagnosticOpen] = useState<boolean>(false);

  useEffect(() => {
    if (isOpen) {
      setSettings(getAudioSettings());
    }
  }, [isOpen]);

  useEffect(() => {
    const unsubscribe = subscribeAudioState((isSpk, txt) => {
      setSpeaking(isSpk);
      setCurrentText(txt);
    });
    return unsubscribe;
  }, []);

  if (!isOpen) return null;

  const handleSelectVoice = (voiceId: GoogleTtsVoice) => {
    const updated = updateAudioSettings({ voice: voiceId });
    setSettings(updated);
    // Instant preview
    speakEnglish('Google TTS ready', updated.rate, { voice: voiceId });
  };

  const handleRateChange = (newRate: number) => {
    const updated = updateAudioSettings({ rate: newRate });
    setSettings(updated);
  };

  const handleToggleGoogleTts = () => {
    const updated = updateAudioSettings({ useGoogleTts: !settings.useGoogleTts });
    setSettings(updated);
  };

  const handlePlayTestPhrase = () => {
    if (speaking) {
      stopSpeech();
    } else {
      speakEnglish(testPhrase, settings.rate, { voice: settings.voice });
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="p-4 sm:p-6 border-b border-slate-800 flex items-center justify-between bg-slate-900/60 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-sky-400 flex items-center justify-center text-white shadow-lg shadow-blue-500/20">
              <Headphones className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg sm:text-xl font-black text-white tracking-tight">
                  Озвучка Google TTS
                </h2>
                <span className="px-2 py-0.5 rounded-full bg-blue-500/15 border border-blue-500/30 text-[10px] font-black uppercase text-blue-400 tracking-wider">
                  HD Audio
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Студійні AI-голоси для природного тренування слуху та вимови
              </p>
            </div>
          </div>
          
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-xl bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700 flex items-center justify-center transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="p-4 sm:p-6 space-y-6 overflow-y-auto">

          {/* Master Mute & Provider Banner */}
          <div className="p-4 rounded-2xl bg-slate-800/60 border border-slate-700/60 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <button
                onClick={onToggleAudio}
                className={`w-11 h-11 rounded-xl flex items-center justify-center transition shadow-md ${
                  isAudioMuted
                    ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                    : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                }`}
              >
                {isAudioMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
              </button>
              <div>
                <p className="text-sm font-bold text-white">
                  {isAudioMuted ? 'Звук повністю вимкнено' : 'Звук у додатку активний'}
                </p>
                <p className="text-xs text-slate-400">
                  {isAudioMuted
                    ? 'Натисніть для увімкнення звукових ефектів та вимови'
                    : 'Всі картки, конструктор і чанки озвучуються обраним Google TTS'}
                </p>
              </div>
            </div>

            <button
              onClick={handleToggleGoogleTts}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 self-start sm:self-center ${
                settings.useGoogleTts
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-500/25'
                  : 'bg-slate-700 text-slate-300 hover:text-white'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              {settings.useGoogleTts ? 'Google AI TTS: Увімкнено' : 'Google AI TTS: Вимкнено'}
            </button>
          </div>

          {/* Voice Selector Grid */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <Radio className="w-4 h-4 text-blue-400" />
                Виберіть голос носія мови
              </label>
              <span className="text-[11px] text-slate-500">6 доступних профілів</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {VOICE_OPTIONS.map((voice) => {
                const isSelected = settings.voice === voice.id;
                return (
                  <div
                    key={voice.id}
                    onClick={() => handleSelectVoice(voice.id)}
                    className={`p-3.5 rounded-2xl border transition-all cursor-pointer relative flex flex-col justify-between ${
                      isSelected
                        ? 'bg-blue-900/30 border-blue-500 shadow-md shadow-blue-900/20'
                        : 'bg-slate-800/40 border-slate-700/60 hover:bg-slate-800/80 hover:border-slate-600'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-black text-white">{voice.title}</span>
                          {voice.isPopular && (
                            <span className="px-1.5 py-0.5 rounded-md bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[9px] font-black uppercase">
                              ТОП
                            </span>
                          )}
                        </div>
                        {isSelected ? (
                          <div className="w-5 h-5 rounded-full bg-blue-500 text-white flex items-center justify-center">
                            <Check className="w-3 h-3 stroke-[3]" />
                          </div>
                        ) : (
                          <span className="text-[10px] font-bold text-slate-500">Обрати</span>
                        )}
                      </div>

                      <span className="inline-block px-2 py-0.5 rounded-md bg-slate-700/60 text-slate-300 text-[10px] font-bold mb-1.5">
                        {voice.tag}
                      </span>
                      
                      <p className="text-[11px] text-slate-400 leading-snug">
                        {voice.description}
                      </p>
                    </div>

                    <div className="mt-2.5 pt-2 border-t border-slate-700/40 flex items-center justify-between text-[11px]">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          speakEnglish('Hello! This is ' + voice.title, settings.rate, { voice: voice.id });
                        }}
                        className="text-blue-400 hover:text-blue-300 font-bold flex items-center gap-1"
                      >
                        <Play className="w-3 h-3 fill-current" />
                        Демонстрація
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Speed / Rate Controls */}
          <div className="p-4 rounded-2xl bg-slate-800/40 border border-slate-700/60 space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <Gauge className="w-4 h-4 text-emerald-400" />
                Швидкість вимови: {Math.round(settings.rate * 100)}%
              </label>
              <button
                onClick={() => handleRateChange(0.95)}
                className="text-[11px] font-bold text-slate-400 hover:text-white flex items-center gap-1"
              >
                <RotateCcw className="w-3 h-3" />
                Скинути (95%)
              </button>
            </div>

            {/* Slider */}
            <input
              type="range"
              min="0.7"
              max="1.25"
              step="0.05"
              value={settings.rate}
              onChange={(e) => handleRateChange(parseFloat(e.target.value))}
              className="w-full accent-blue-500 cursor-pointer h-2 bg-slate-700 rounded-lg appearance-none"
            />

            {/* Preset Buttons */}
            <div className="grid grid-cols-4 gap-2 pt-1">
              {[
                { label: '0.75x Повільно', val: 0.75 },
                { label: '0.90x Навчання', val: 0.9 },
                { label: '1.00x Носій', val: 1.0 },
                { label: '1.15x Швидко', val: 1.15 },
              ].map((p) => (
                <button
                  key={p.val}
                  onClick={() => handleRateChange(p.val)}
                  className={`py-1.5 px-2 rounded-xl text-[11px] font-bold border transition ${
                    Math.abs(settings.rate - p.val) < 0.03
                      ? 'bg-blue-600 text-white border-blue-500 shadow-sm'
                      : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>

          {/* Interactive Test Player */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-blue-900/20 to-indigo-900/20 border border-blue-500/30 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-blue-300 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-amber-300" />
                Тестове речення для перевірки
              </span>
              {speaking && (
                <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-400 animate-pulse">
                  <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                  Відтворення...
                </div>
              )}
            </div>

            <div className="flex flex-col sm:flex-row gap-2">
              <select
                value={testPhrase}
                onChange={(e) => setTestPhrase(e.target.value)}
                className="flex-1 bg-slate-800 text-white text-xs rounded-xl px-3 py-2 border border-slate-700 focus:outline-none focus:border-blue-500"
              >
                {SAMPLE_PHRASES.map((ph, idx) => (
                  <option key={idx} value={ph}>
                    {ph}
                  </option>
                ))}
              </select>

              <button
                onClick={handlePlayTestPhrase}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs font-bold shadow-lg shadow-blue-500/20 flex items-center justify-center gap-2 transition shrink-0 cursor-pointer"
              >
                {speaking ? (
                  <>
                    <VolumeX className="w-4 h-4" />
                    Зупинити
                  </>
                ) : (
                  <>
                    <Volume2 className="w-4 h-4" />
                    Озвучити Google TTS
                  </>
                )}
              </button>
            </div>

            {/* Sound waves visualizer when speaking */}
            {speaking && (
              <div className="flex items-center justify-center gap-1 py-1">
                <span className="w-1 h-3 bg-blue-400 rounded-full animate-bounce [animation-delay:0ms]"></span>
                <span className="w-1 h-5 bg-indigo-400 rounded-full animate-bounce [animation-delay:150ms]"></span>
                <span className="w-1 h-7 bg-amber-400 rounded-full animate-bounce [animation-delay:300ms]"></span>
                <span className="w-1 h-4 bg-sky-400 rounded-full animate-bounce [animation-delay:450ms]"></span>
                <span className="w-1 h-6 bg-emerald-400 rounded-full animate-bounce [animation-delay:200ms]"></span>
              </div>
            )}
          </div>

        </div>

        {/* Footer */}
        <div className="p-4 sm:p-5 border-t border-slate-800 bg-slate-900/80 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setIsMicDiagnosticOpen(true)}
              className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-indigo-300 hover:text-white text-xs font-bold transition flex items-center gap-1.5 border border-slate-750 cursor-pointer"
            >
              <Mic className="w-3.5 h-3.5" />
              Діагностика мікрофона
            </button>
            <div className="hidden sm:flex items-center gap-2 text-xs text-slate-400 font-medium">
              <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
              Зберігається автоматично
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition shadow-md shadow-blue-500/25 cursor-pointer"
          >
            Готово
          </button>
        </div>

      </div>

      {/* Mic Diagnostic Modal */}
      <MicrophoneDiagnosticModal
        isOpen={isMicDiagnosticOpen}
        onClose={() => setIsMicDiagnosticOpen(false)}
      />
    </div>
  );
};
