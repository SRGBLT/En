import React, { useState, useMemo } from 'react';
import {
  Layers,
  ChevronLeft,
  ChevronRight,
  Volume2,
  CheckCircle2,
  Sparkles,
  RotateCw,
  Lightbulb,
} from 'lucide-react';
import { ALL_VOCABULARY } from '../data/hacks';
import { ALL_THEMATIC_VOCAB_ITEMS, THEMATIC_CATEGORIES } from '../data/thematicWords';
import { VocabItem } from '../types';
import { playSound, speakEnglish } from '../utils/audio';

interface FlashcardsProps {
  onMarkLearned: (item: VocabItem) => void;
  onToast: (msg: string, type: 'info' | 'success' | 'error') => void;
}

export const Flashcards: React.FC<FlashcardsProps> = ({ onMarkLearned, onToast }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);

  const allCombinedCards = useMemo(() => {
    return [...ALL_VOCABULARY, ...ALL_THEMATIC_VOCAB_ITEMS];
  }, []);

  const filteredCards = useMemo(() => {
    if (selectedCategory === 'all') return allCombinedCards;
    return allCombinedCards.filter((c) => c.category === selectedCategory);
  }, [allCombinedCards, selectedCategory]);

  const card = filteredCards[currentIndex] || filteredCards[0];

  const handleCategoryChange = (cat: string) => {
    playSound('click');
    setSelectedCategory(cat);
    setCurrentIndex(0);
    setIsFlipped(false);
  };

  const handleFlip = () => {
    playSound('click');
    const nextState = !isFlipped;
    setIsFlipped(nextState);
    if (nextState && card) {
      speakEnglish(card.eng);
    }
  };

  const handleNext = () => {
    playSound('click');
    setIsFlipped(false);
    if (filteredCards.length > 0) {
      setCurrentIndex((prev) => (prev + 1) % filteredCards.length);
    }
  };

  const handlePrev = () => {
    playSound('click');
    setIsFlipped(false);
    if (filteredCards.length > 0) {
      setCurrentIndex((prev) => (prev - 1 + filteredCards.length) % filteredCards.length);
    }
  };

  const handleSpeak = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (card) speakEnglish(card.eng);
  };

  const handleMarkLearned = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (card) {
      playSound('correct');
      onMarkLearned(card);
      onToast(`«${card.eng}» збережено у Скарбничку! (+10 XP)`, 'success');
      handleNext();
    }
  };

  if (!card) return null;

  return (
    <section className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 max-w-xl mx-auto">
        <div>
          <h2 className="text-2xl font-black text-white flex items-center gap-2">
            <Layers className="w-6 h-6 text-indigo-400" />
            <span>3D Флеш-картки</span>
          </h2>
          <p className="text-xs text-slate-400">Клікніть на картку для перевороту</p>
        </div>
        <div className="text-xs font-bold text-slate-400 bg-slate-900 px-3 py-1.5 rounded-xl border border-slate-800">
          Картка <span className="text-blue-400 font-black">{currentIndex + 1}</span> з{' '}
          <span>{filteredCards.length}</span>
        </div>
      </div>

      {/* Category Filter Selector */}
      <div className="max-w-xl mx-auto">
        <select
          value={selectedCategory}
          onChange={(e) => handleCategoryChange(e.target.value)}
          className="w-full px-3.5 py-2.5 rounded-2xl bg-slate-900 border border-slate-800 text-xs sm:text-sm font-semibold text-slate-200 focus:outline-none focus:border-blue-500 cursor-pointer shadow-lg"
        >
          <option value="all">Усі картки ({allCombinedCards.length})</option>
          <optgroup label="🐾 Тематичні сфери слів">
            {THEMATIC_CATEGORIES.map((cat) => (
              <option key={cat.id} value={cat.id}>
                {cat.icon} {cat.title} ({cat.engTitle})
              </option>
            ))}
          </optgroup>
          <optgroup label="⚡ Лайфхаки суфіксів та префіксів">
            <option value="tion">Суфікс -tion / -sion</option>
            <option value="less">Суфікс -less / ir-</option>
            <option value="ic">Суфікс -ic / -ical</option>
            <option value="ity">Суфікс -ity / -ness</option>
            <option value="al">Суфікс -al</option>
            <option value="ive">Суфікс -ive</option>
            <option value="ist">Діячі -ist / -or / -er</option>
            <option value="able">-абельний -able / -ible</option>
            <option value="ment">Іменники дій -ment</option>
            <option value="re">Префікс re-</option>
            <option value="over">Префікс over-</option>
            <option value="false_friends">⚠️ Фальшиві друзі</option>
          </optgroup>
        </select>
      </div>

      {/* 3D Flippable Card */}
      <div className="max-w-xl mx-auto h-80 sm:h-96 perspective-1000 cursor-pointer" onClick={handleFlip}>
        <div
          className={`w-full h-full relative transform-style-3d transition-transform duration-500 rounded-3xl shadow-2xl border border-slate-800 bg-slate-900 ${
            isFlipped ? 'rotate-y-180' : ''
          }`}
        >
          {/* Front Face (Ukrainian) */}
          <div className="absolute inset-0 backface-hidden p-8 flex flex-col justify-between rounded-3xl bg-gradient-to-br from-slate-900 via-slate-900 to-indigo-950/40 border border-slate-800">
            <div className="flex items-center justify-between">
              <span className="px-3 py-1 rounded-xl text-xs font-bold bg-blue-500/10 text-blue-400 border border-blue-500/20">
                {card.rule}
              </span>
              <span className="text-2xl">{card.emoji || '↻'}</span>
            </div>

            <div className="text-center space-y-2">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500 block">
                Українське слово
              </span>
              <h3 className="text-3xl sm:text-4xl font-black text-white tracking-tight">{card.ukr}</h3>
              <p className="text-xs text-slate-400">Згадайте англійське слово</p>
            </div>

            <div className="flex items-center justify-center text-xs text-slate-500 gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>EngBridge Flashcards • Клікніть щоб перевернути</span>
            </div>
          </div>

          {/* Back Face (English + Details) */}
          <div className="absolute inset-0 backface-hidden rotate-y-180 p-8 flex flex-col justify-between rounded-3xl bg-gradient-to-br from-blue-950/80 via-slate-900 to-slate-900 border border-blue-500/30">
            <div className="flex items-center justify-between">
              <span className="px-3 py-1 rounded-xl text-xs font-bold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                {card.rule}
              </span>
              <button
                onClick={handleSpeak}
                className="p-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white transition"
              >
                <Volume2 className="w-4 h-4" />
              </button>
            </div>

            <div className="text-center space-y-2">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block">
                Англійський відповідник
              </span>
              <h3 className="text-3xl sm:text-4xl font-black text-blue-400 tracking-tight">{card.eng}</h3>
              {card.ipa && <p className="text-sm text-slate-300 font-mono">{card.ipa}</p>}

              {card.mnemonicHook && (
                <div className="mt-2 px-3 py-1.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-200 font-medium max-w-sm mx-auto flex items-center gap-1.5 text-left">
                  <Lightbulb className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span>{card.mnemonicHook}</span>
                </div>
              )}
            </div>

            <div className="flex items-center justify-between pt-2">
              <button
                onClick={handleMarkLearned}
                className="text-xs font-bold text-emerald-400 hover:text-emerald-300 flex items-center gap-1.5 transition"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Позначити як вивчене (+10 XP)</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Controls */}
      <div className="max-w-xl mx-auto flex items-center justify-between gap-3 pt-2">
        <button
          onClick={handlePrev}
          className="px-5 py-3 rounded-2xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-200 font-bold text-sm flex items-center gap-2 transition"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Назад</span>
        </button>
        <button
          onClick={handleFlip}
          className="px-4 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs flex items-center gap-1.5 transition"
        >
          <RotateCw className="w-4 h-4" />
          <span>Перевернути</span>
        </button>
        <button
          onClick={handleNext}
          className="px-5 py-3 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm flex items-center gap-2 shadow-lg shadow-blue-500/20 transition"
        >
          <span>Вперед</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </section>
  );
};
