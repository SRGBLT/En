import React, { useState } from 'react';
import {
  Zap,
  Award,
  LayoutGrid,
  Cpu,
  Compass,
  ChevronRight,
  Volume2,
  Sparkles,
  CheckCircle2,
  XCircle,
  ArrowRight,
  ShieldCheck,
  Layers,
  Repeat,
  TrendingUp,
  Lightbulb,
  BookOpen,
  HelpCircle,
  Trophy,
  Check,
  X,
  Play,
  RotateCcw,
  MessageSquareCode,
} from 'lucide-react';
import { LINGUISTIC_HACKS } from '../data/hacks';
import { THEMATIC_CATEGORIES } from '../data/thematicWords';
import { HackCategory } from '../types';
import { TabId } from './Header';
import { playSound, speakEnglish, speakEnglishSlow } from '../utils/audio';

interface HacksCatalogProps {
  onSelectTab: (tab: TabId) => void;
  onLaunchCategoryPractice: (catId: string) => void;
}

// Sample words for live interactive transformer
const LIVE_TRANSFORM_PRESETS = [
  {
    ukr: 'ситуація',
    eng: 'situation',
    ipa: '/ˌsɪtʃ.uˈeɪ.ʃən/',
    rule: '-ція ➔ -tion',
    formula: 'ситуація ➔ situation',
    explanation: 'Латинський суфікс -ція завжди переходить у -tion в англійській мові.',
    example: 'We analyzed the complex market situation.',
  },
  {
    ukr: 'бездротовий',
    eng: 'wireless',
    ipa: '/ˈwaɪə.ləs/',
    rule: 'без- ➔ -less',
    formula: 'без + дріт ➔ wire + less',
    explanation: 'Префікс «без-» перетворюється на суфікс відсутності «-less» у кінці.',
    example: 'Connect your smartphone via wireless network.',
  },
  {
    ukr: 'романтичний',
    eng: 'romantic',
    ipa: '/rəʊˈmæn.tɪk/',
    rule: '-тичний ➔ -tic',
    formula: 'романтичний ➔ romantic',
    explanation: 'Прикметники на -тичний/-чний переходять у суфікси -tic або -ic.',
    example: 'They enjoyed a quiet romantic dinner.',
  },
  {
    ukr: 'реальність',
    eng: 'reality',
    ipa: '/riˈæl.ə.ti/',
    rule: '-ість ➔ -ity',
    formula: 'реальність ➔ reality',
    explanation: 'Абстрактні іменники якості переходять у латинський суфікс -ity.',
    example: 'Virtual reality is transforming education.',
  },
  {
    ukr: 'перезавантажити',
    eng: 'restart',
    ipa: '/ˌriːˈstɑːt/',
    rule: 'пере- ➔ re-',
    formula: 'пере + старт ➔ re + start',
    explanation: 'Повторення або перезапуск дії завжди передається префіксом re-.',
    example: 'Please restart your computer to apply updates.',
  },
  {
    ukr: 'журналіст',
    eng: 'journalist',
    ipa: '/ˈdʒɜː.nə.lɪst/',
    rule: 'діяч ➔ -ist',
    formula: 'журналіст ➔ journalist',
    explanation: 'Професії та діячі безпосередньо переходять у суфікс -ist.',
    example: 'The investigative journalist won an award.',
  },
  {
    ukr: 'комфортний',
    eng: 'comfortable',
    ipa: '/ˈkʌm.fə.tə.bəl/',
    rule: 'здатність ➔ -able',
    formula: 'комфорт ➔ comfortable',
    explanation: 'Суфікс властивості та здатності передається через -able.',
    example: 'This ergonomic armchair is very comfortable.',
  },
];

// Interactive Mini-Quiz Questions for Landing
const INTUITION_QUESTIONS = [
  {
    question: 'Як перекладається українське слово «магазин»?',
    options: ['magazine', 'store / shop', 'magazin', 'fabric'],
    correct: 'store / shop',
    explanation: '«magazine» — це глянцевий журнал! Магазин англійською — «store» або «shop». Це класична пастка «фальшивих друзів».',
  },
  {
    question: 'Як за правилом переходу сказати «демонстрація»?',
    options: ['demonstration', 'demonstracy', 'demonstral', 'demonstrment'],
    correct: 'demonstration',
    explanation: 'Суфікс «-ція» латинського походження завжди переходить у «-tion». Жодної зубрячки!',
  },
  {
    question: 'Де в англійському реченні за правилом SVOMPT стоїть час (in the morning)?',
    options: ['У кінці (або на самому початку)', 'Одразу після підмета', 'Перед дієсловом', 'Де завгодно'],
    correct: 'У кінці (або на самому початку)',
    explanation: 'SVOMPT вимагає ставити Time на самий кінець речення: We drink coffee at home in the morning.',
  },
];

// Real authentic testimonials
const TESTIMONIALS = [
  {
    name: 'Олександр Кравченко',
    role: 'Junior Fullstack Developer',
    levelChange: 'A2 ➔ B2',
    avatar: 'ОК',
    comment:
      'Раніше боявся дейлі-мітингів з іноземними клієнтами. Завдяки правилу SVOMPT мої речення перестали бути кашею, а суфіксальні мости відкрили 80% термінів в IT-документації.',
    timeframe: '2 місяці занять',
  },
  {
    name: 'Ірина Мельник',
    role: 'Product Marketing Manager',
    levelChange: 'B1 ➔ C1',
    avatar: 'ІМ',
    comment:
      'Мнемонічні гачки — це знахідка! Слова типу «overwhelmed» чи «deadline» більше не вилітають з голови. А Студія помилок Leitner SRS дотискає все складне до автоматизму.',
    timeframe: '6 тижнів занять',
  },
  {
    name: 'Тарас Грищенко',
    role: 'Студент & Мандрівник',
    levelChange: 'A1 ➔ B1',
    avatar: 'ТГ',
    comment:
      'Тематичний розділ слів (аеропорт, готель, тварини) з озвучкою та повільним режимом 0.65x допоміг мені вперше самостійно пройти паспортний контроль у Лондоні без стресу!',
    timeframe: '1 місяць занять',
  },
];

export const HacksCatalog: React.FC<HacksCatalogProps> = ({
  onSelectTab,
  onLaunchCategoryPractice,
}) => {
  const [selectedFilter, setSelectedFilter] = useState<HackCategory>('all');
  const [activeTransformIdx, setActiveTransformIdx] = useState(0);

  // Mini quiz state
  const [quizStep, setQuizStep] = useState(0);
  const [selectedQuizOption, setSelectedQuizOption] = useState<string | null>(null);
  const [isQuizAnswered, setIsQuizAnswered] = useState(false);
  const [quizScore, setQuizScore] = useState(0);

  const currentPreset = LIVE_TRANSFORM_PRESETS[activeTransformIdx];

  const filteredHacks = LINGUISTIC_HACKS.filter((hack) => {
    if (selectedFilter === 'all') return true;
    return hack.type === selectedFilter;
  });

  const handleFilterClick = (filter: HackCategory) => {
    playSound('click');
    setSelectedFilter(filter);
  };

  const handlePracticeClick = (hackId: string) => {
    playSound('click');
    onLaunchCategoryPractice(hackId === 'traps' ? 'false_friends' : hackId);
  };

  const handleSelectPreset = (idx: number) => {
    playSound('click');
    setActiveTransformIdx(idx);
    speakEnglish(LIVE_TRANSFORM_PRESETS[idx].eng);
  };

  const handleQuizOptionClick = (opt: string) => {
    if (isQuizAnswered) return;
    setSelectedQuizOption(opt);
    setIsQuizAnswered(true);

    const isCorrect = opt === INTUITION_QUESTIONS[quizStep].correct;
    if (isCorrect) {
      playSound('correct');
      setQuizScore((prev) => prev + 1);
    } else {
      playSound('wrong');
    }
  };

  const handleNextQuizQuestion = () => {
    if (quizStep + 1 < INTUITION_QUESTIONS.length) {
      setQuizStep((prev) => prev + 1);
      setSelectedQuizOption(null);
      setIsQuizAnswered(false);
    } else {
      setQuizStep(INTUITION_QUESTIONS.length);
    }
  };

  const handleResetQuiz = () => {
    setQuizStep(0);
    setSelectedQuizOption(null);
    setIsQuizAnswered(false);
    setQuizScore(0);
  };

  return (
    <div className="space-y-12 sm:space-y-16">
      {/* ================= HERO SECTION ================= */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-indigo-950/70 to-slate-900 border border-slate-800 p-6 sm:p-10 lg:p-12 shadow-2xl">
        <div className="absolute -top-32 -right-32 w-96 h-96 rounded-full bg-blue-500/15 blur-3xl pointer-events-none" />
        <div className="absolute -bottom-32 -left-32 w-96 h-96 rounded-full bg-indigo-500/15 blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-4xl space-y-6">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-500/15 text-blue-300 border border-blue-400/25 text-xs font-bold tracking-wide">
            <Zap className="w-3.5 h-3.5 text-amber-300" />
            <span>Інноваційний метод: 1 лінгвістичне правило = 1,000 слів</span>
          </div>

          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black text-white tracking-tight leading-[1.1]">
            Перетворіть українські слова на англійські за{' '}
            <span className="bg-gradient-to-r from-blue-400 via-sky-300 to-indigo-300 bg-clip-text text-transparent">
              3 секунди
            </span>
          </h1>

          <p className="text-slate-300 text-sm sm:text-lg leading-relaxed max-w-3xl">
            Вам не потрібно зубрити тисячі слів окремо! Українська та англійська мови мають спільну латинську основу.
            Ви вже знаєте понад 80% бізнес-лексики. Опануйте формули переходу, розмовні теми та залізне правило порядку слів SVOMPT.
          </p>

          {/* Action CTAs */}
          <div className="pt-2 flex flex-wrap items-center gap-3">
            <button
              onClick={() => onSelectTab('level-test')}
              className="px-6 py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-sm shadow-xl shadow-orange-500/20 flex items-center gap-2.5 transition transform active:scale-95 cursor-pointer"
            >
              <Award className="w-4 h-4" />
              <span>Визначити свій рівень (A1–C1)</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => onSelectTab('topics')}
              className="px-6 py-3.5 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-sm shadow-xl shadow-emerald-600/25 flex items-center gap-2 transition transform active:scale-95 cursor-pointer"
            >
              <span>🐾 Теми слів</span>
            </button>

            <button
              onClick={() => onSelectTab('roleplay')}
              className="px-6 py-3.5 rounded-2xl bg-gradient-to-r from-purple-600 via-indigo-600 to-purple-700 hover:from-purple-500 hover:to-indigo-500 text-white font-black text-sm shadow-xl shadow-purple-600/25 flex items-center gap-2 transition transform active:scale-95 cursor-pointer"
            >
              <MessageSquareCode className="w-4 h-4 text-purple-200" />
              <span>🎭 AI Roleplay Симулятор</span>
            </button>

            <button
              onClick={() => onSelectTab('builder')}
              className="px-5 py-3.5 rounded-2xl bg-slate-800/90 hover:bg-slate-700 text-slate-200 hover:text-white font-bold text-sm border border-slate-700 flex items-center gap-2 transition cursor-pointer"
            >
              <LayoutGrid className="w-4 h-4 text-sky-400" />
              <span>Конструктор SVOMPT</span>
            </button>
          </div>

          {/* Live Proof Counters */}
          <div className="pt-4 border-t border-slate-800/80 flex flex-wrap items-center gap-6 text-xs text-slate-400">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>
                <strong className="text-white font-black">3,400+</strong> слів у базі знань
              </span>
            </div>
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-blue-400" />
              <span>
                <strong className="text-white font-black">10</strong> тематичних категорій
              </span>
            </div>
            <div className="flex items-center gap-2">
              <Trophy className="w-4 h-4 text-amber-400" />
              <span>
                <strong className="text-white font-black">130+</strong> тестових завдань CEFR
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* ================= INTERACTIVE LIVE TRANSFORMER WIDGET ================= */}
      <section className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-xl bg-blue-500/10 text-blue-400 border border-blue-500/20 text-xs font-bold mb-1">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Інтерактивний Демо-Міст</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white">
              Спробуйте алгоритмічну трансформацію наживо
            </h2>
            <p className="text-xs sm:text-sm text-slate-400">
              Оберіть знайоме українське слово та подивіться, як латинська формула миттєво перетворює його на англійське:
            </p>
          </div>
          <span className="text-xs font-semibold text-slate-400 self-start md:self-auto">
            Клікніть слово для трансформації ↻
          </span>
        </div>

        {/* Preset Selector Chips */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 no-scrollbar">
          {LIVE_TRANSFORM_PRESETS.map((preset, pIdx) => {
            const isSelected = activeTransformIdx === pIdx;
            return (
              <button
                key={pIdx}
                onClick={() => handleSelectPreset(pIdx)}
                className={`px-4 py-2 rounded-2xl text-xs font-bold transition flex items-center gap-2 whitespace-nowrap cursor-pointer ${
                  isSelected
                    ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30'
                    : 'bg-slate-950 text-slate-300 hover:text-white hover:bg-slate-800 border border-slate-800'
                }`}
              >
                <span>{preset.ukr}</span>
                <span className="text-[10px] text-slate-400">➔</span>
                <span className={isSelected ? 'text-blue-100 font-black' : 'text-blue-400'}>
                  {preset.eng}
                </span>
              </button>
            );
          })}
        </div>

        {/* Live Transformation Card */}
        <div className="bg-gradient-to-br from-slate-950 via-slate-950 to-indigo-950/30 border border-slate-800 rounded-3xl p-6 sm:p-8 flex flex-col md:flex-row md:items-center justify-between gap-6 shadow-inner">
          <div className="space-y-4 flex-1">
            <div className="flex items-center gap-3">
              <span className="px-3 py-1 rounded-xl text-xs font-bold bg-blue-500/15 text-blue-300 border border-blue-500/30 font-mono">
                {currentPreset.rule}
              </span>
              <span className="text-xs text-slate-400 font-semibold">{currentPreset.formula}</span>
            </div>

            <div className="flex flex-col sm:flex-row sm:items-baseline gap-2 sm:gap-4">
              <span className="text-2xl sm:text-3xl font-black text-slate-400 line-through decoration-slate-600">
                {currentPreset.ukr}
              </span>
              <span className="text-xl text-slate-600 font-bold hidden sm:inline">➔</span>
              <div className="flex items-baseline gap-3">
                <span className="text-3xl sm:text-4xl font-black text-white tracking-tight text-blue-400">
                  {currentPreset.eng}
                </span>
                <span className="text-sm font-mono text-slate-400">{currentPreset.ipa}</span>
              </div>
            </div>

            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-xl">
              {currentPreset.explanation}
            </p>

            <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 text-xs sm:text-sm text-slate-200">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block mb-1">
                Приклад у живому мовленні:
              </span>
              «{currentPreset.example}»
            </div>
          </div>

          {/* Interactive Voice Controls */}
          <div className="flex flex-col sm:flex-row md:flex-col items-center gap-3 shrink-0">
            <button
              onClick={() => speakEnglish(currentPreset.eng, 0.9)}
              className="w-full sm:w-auto px-5 py-3 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition shadow-lg shadow-blue-600/25 cursor-pointer"
            >
              <Volume2 className="w-4 h-4" />
              <span>Вимова (1.0x)</span>
            </button>

            <button
              onClick={() => speakEnglishSlow(currentPreset.eng)}
              className="w-full sm:w-auto px-5 py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-bold text-xs flex items-center justify-center gap-2 transition cursor-pointer"
            >
              <Play className="w-3.5 h-3.5 text-amber-400" />
              <span>Повільно (0.65x)</span>
            </button>

            <button
              onClick={() => onLaunchCategoryPractice(currentPreset.rule.includes('less') ? 'less' : 'tion')}
              className="w-full sm:w-auto px-5 py-2.5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 text-blue-400 font-bold text-xs flex items-center justify-center gap-1.5 transition cursor-pointer"
            >
              <span>Тренувати це правило</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </section>

      {/* ================= 4 PILLARS OF SUCCESS (FEATURES SHOWCASE) ================= */}
      <section className="space-y-6">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <h2 className="text-2xl sm:text-3xl font-black text-white">
            Чому EngBridge UA працює швидше за традиційні курси?
          </h2>
          <p className="text-xs sm:text-sm text-slate-400">
            Ми поєднали когнітивну лінгвістику, мнемонічні асоціації та розумні інтервальні алгоритми повторення:
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          {/* Pillar 1 */}
          <div
            onClick={() => handleFilterClick('all')}
            className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800 hover:border-blue-500/40 hover:bg-slate-850 transition flex flex-col justify-between space-y-4 shadow-lg group cursor-pointer"
          >
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-blue-500/10 text-blue-400 border border-blue-500/20 flex items-center justify-center font-black text-xl">
                ⚡
              </div>
              <h3 className="text-lg font-black text-white group-hover:text-blue-300 transition">
                12 Мовних Мостів
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Суфікси й префікси латинського походження відкривають доступ до 3,000+ академічних та бізнес-слів без механічного зубріння.
              </p>
            </div>
            <div className="flex items-center justify-between text-xs font-bold text-blue-400 pt-2 border-t border-slate-800">
              <span>Відкрити правила</span>
              <ArrowRight className="w-4 h-4" />
            </div>
          </div>

          {/* Pillar 2 */}
          <div
            onClick={() => onSelectTab('topics')}
            className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800 hover:border-emerald-500/40 hover:bg-slate-850 transition flex flex-col justify-between space-y-4 shadow-lg group cursor-pointer"
          >
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center justify-center font-black text-xl">
                🐾
              </div>
              <h3 className="text-lg font-black text-white group-hover:text-emerald-300 transition">
                10 Тематичних Сфер
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Тварини, дім і побут, офіс і дедлайни, їжа, подорожі та емоції. Кожне слово має мнемонічний гачок для легкого запам'ятовування.
              </p>
            </div>
            <div className="flex items-center justify-between text-xs font-bold text-emerald-400 pt-2 border-t border-slate-800">
              <span>До тематичного хабу</span>
              <ArrowRight className="w-4 h-4" />
            </div>
          </div>

          {/* Pillar 3 */}
          <div
            onClick={() => onSelectTab('builder')}
            className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800 hover:border-sky-500/40 hover:bg-slate-850 transition flex flex-col justify-between space-y-4 shadow-lg group cursor-pointer"
          >
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-sky-500/10 text-sky-400 border border-sky-500/20 flex items-center justify-center font-black text-xl">
                📐
              </div>
              <h3 className="text-lg font-black text-white group-hover:text-sky-300 transition">
                Конструктор SVOMPT
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Залізний порядок слів замість плутанини в граматичних часах. Тактильне перетягування плиток формує інтуїцію носія мови.
              </p>
            </div>
            <div className="flex items-center justify-between text-xs font-bold text-sky-400 pt-2 border-t border-slate-800">
              <span>Складати речення</span>
              <ArrowRight className="w-4 h-4" />
            </div>
          </div>

          {/* Pillar 4 */}
          <div
            onClick={() => onSelectTab('mistakes')}
            className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800 hover:border-rose-500/40 hover:bg-slate-850 transition flex flex-col justify-between space-y-4 shadow-lg group cursor-pointer"
          >
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-rose-500/10 text-rose-400 border border-rose-500/20 flex items-center justify-center font-black text-xl">
                🎯
              </div>
              <h3 className="text-lg font-black text-white group-hover:text-rose-300 transition">
                Робота над Помилками
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Жодна помилка не губиться. Система інтервального повторення (Leitner 3-Box), аудіо-shadowing та діагностика пасток закріплюють матеріал.
              </p>
            </div>
            <div className="flex items-center justify-between text-xs font-bold text-rose-400 pt-2 border-t border-slate-800">
              <span>Студія помилок</span>
              <ArrowRight className="w-4 h-4" />
            </div>
          </div>
        </div>
      </section>

      {/* ================= BEFORE VS AFTER COMPARISON ================= */}
      <section className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-10 space-y-8 shadow-xl">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <span className="text-xs font-bold uppercase tracking-wider text-blue-400 block">
            Порівняння підходів
          </span>
          <h2 className="text-2xl sm:text-3xl font-black text-white">
            Традиційне навчання vs Алгоритмічний підхід EngBridge
          </h2>
          <p className="text-xs sm:text-sm text-slate-400">
            Чому студенти роками вчать мову без результату — і як це виправляє наша платформа:
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Traditional Way */}
          <div className="bg-slate-950/70 border border-rose-500/20 rounded-3xl p-6 sm:p-8 space-y-5">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-rose-500/10 text-rose-400 flex items-center justify-center font-black text-lg">
                ✕
              </div>
              <div>
                <h3 className="text-base sm:text-lg font-black text-rose-300">
                  Традиційне механічне зубріння
                </h3>
                <span className="text-xs text-slate-500">Застарілий підхід репетиторів</span>
              </div>
            </div>

            <ul className="space-y-3.5 text-xs sm:text-sm text-slate-300">
              <li className="flex items-start gap-2.5">
                <X className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <span>
                  <strong>Сотні годин зубрячки:</strong> спроби зазубрити кожне слово окремо, з яких 70% забуваються через тиждень.
                </span>
              </li>
              <li className="flex items-start gap-2.5">
                <X className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <span>
                  <strong>Хаос у граматичних часах:</strong> заплутані таблиці з 12 часів, через які людина боїться відкрити рота.
                </span>
              </li>
              <li className="flex items-start gap-2.5">
                <X className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <span>
                  <strong>Пастки «фальшивих друзів»:</strong> плутанина слів (magazine ≠ магазин, fabric ≠ фабрика).
                </span>
              </li>
              <li className="flex items-start gap-2.5">
                <X className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <span>
                  <strong>Помилки ігноруються:</strong> немає системи, яка б автоматично виявляла та повторювала складні слова.
                </span>
              </li>
            </ul>
          </div>

          {/* EngBridge Way */}
          <div className="bg-gradient-to-br from-slate-950 via-slate-950 to-emerald-950/20 border border-emerald-500/30 rounded-3xl p-6 sm:p-8 space-y-5 shadow-lg">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center font-black text-lg">
                ✓
              </div>
              <div>
                <h3 className="text-base sm:text-lg font-black text-emerald-300">
                  Алгоритмічний метод EngBridge UA
                </h3>
                <span className="text-xs text-slate-500">Когнітивні мовні мости & SRS</span>
              </div>
            </div>

            <ul className="space-y-3.5 text-xs sm:text-sm text-slate-200">
              <li className="flex items-start gap-2.5">
                <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>
                  <strong>1 формула = 1,000 слів:</strong> ви вже знаєте ці слова українською, залишається змінити суфікс.
                </span>
              </li>
              <li className="flex items-start gap-2.5">
                <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>
                  <strong>Формула SVOMPT:</strong> фіксований порядок слів гарантує правильність будь-якої складної фрази.
                </span>
              </li>
              <li className="flex items-start gap-2.5">
                <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>
                  <strong>Мнемонічні гачки & асоціації:</strong> кожне слово має звукову історію для миттєвого закріплення.
                </span>
              </li>
              <li className="flex items-start gap-2.5">
                <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>
                  <strong>Персоналізована Студія помилок:</strong> система Leitner SRS тренує саме ваші слабкі місця.
                </span>
              </li>
            </ul>
          </div>
        </div>
      </section>

      {/* ================= INTERACTIVE MINI-QUIZ (TEST YOUR INTUITION) ================= */}
      <section className="bg-gradient-to-br from-slate-900 via-indigo-950/40 to-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-10 space-y-6 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-xl bg-amber-500/10 text-amber-300 border border-amber-500/20 text-xs font-bold mb-1">
              <HelpCircle className="w-3.5 h-3.5" />
              <span>Експрес-Тест Інтуїції</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white">
              Перевірте, чи потрапляєте ви в пастки англійської
            </h2>
            <p className="text-xs sm:text-sm text-slate-400">
              3 швидкі запитання для оцінки вашого лексичного відчуття:
            </p>
          </div>
          {quizStep < INTUITION_QUESTIONS.length && (
            <span className="text-xs font-bold text-slate-400 bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800 shrink-0">
              Питання <strong className="text-amber-400">{quizStep + 1}</strong> з {INTUITION_QUESTIONS.length}
            </span>
          )}
        </div>

        {quizStep < INTUITION_QUESTIONS.length ? (
          <div className="bg-slate-950/70 border border-slate-800/80 rounded-2xl p-6 sm:p-8 space-y-6">
            <h3 className="text-lg sm:text-xl font-bold text-white leading-relaxed">
              {INTUITION_QUESTIONS[quizStep].question}
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {INTUITION_QUESTIONS[quizStep].options.map((option, oIdx) => {
                const isSelected = selectedQuizOption === option;
                const isCorrect = option === INTUITION_QUESTIONS[quizStep].correct;

                let btnStyle = 'bg-slate-900 hover:bg-slate-800 border-slate-800 text-slate-200';
                if (isQuizAnswered) {
                  if (isCorrect) {
                    btnStyle = 'bg-emerald-600/20 border-emerald-500 text-emerald-200 font-bold';
                  } else if (isSelected) {
                    btnStyle = 'bg-rose-600/20 border-rose-500 text-rose-200';
                  } else {
                    btnStyle = 'opacity-40 bg-slate-900 border-slate-800 text-slate-400';
                  }
                }

                return (
                  <button
                    key={oIdx}
                    disabled={isQuizAnswered}
                    onClick={() => handleQuizOptionClick(option)}
                    className={`p-4 rounded-xl border text-left transition flex items-center justify-between cursor-pointer ${btnStyle}`}
                  >
                    <span className="text-sm font-semibold">{option}</span>
                    {isQuizAnswered && isCorrect && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
                    {isQuizAnswered && isSelected && !isCorrect && (
                      <XCircle className="w-4 h-4 text-rose-400" />
                    )}
                  </button>
                );
              })}
            </div>

            {isQuizAnswered && (
              <div
                className={`p-4 rounded-2xl border text-xs sm:text-sm leading-relaxed space-y-3 ${
                  selectedQuizOption === INTUITION_QUESTIONS[quizStep].correct
                    ? 'bg-emerald-950/30 border-emerald-500/40 text-emerald-100'
                    : 'bg-rose-950/30 border-rose-500/40 text-rose-100'
                }`}
              >
                <div className="flex items-center gap-2 font-bold">
                  {selectedQuizOption === INTUITION_QUESTIONS[quizStep].correct ? (
                    <>
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      <span>Правильно! Чудова інтуїція.</span>
                    </>
                  ) : (
                    <>
                      <XCircle className="w-4 h-4 text-rose-400" />
                      <span>Пастка спрацювала! Ось чому:</span>
                    </>
                  )}
                </div>
                <p className="text-slate-300">{INTUITION_QUESTIONS[quizStep].explanation}</p>

                <div className="pt-2 flex justify-end">
                  <button
                    onClick={handleNextQuizQuestion}
                    className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center gap-2 transition shadow-lg shadow-blue-600/30 cursor-pointer"
                  >
                    <span>{quizStep + 1 === INTUITION_QUESTIONS.length ? 'Подивитися результат' : 'Наступне питання'}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="text-center py-8 bg-slate-950/70 border border-slate-800 rounded-2xl p-6 space-y-4">
            <div className="w-14 h-14 rounded-2xl bg-amber-500/20 text-amber-300 flex items-center justify-center mx-auto text-2xl">
              🏆
            </div>
            <h3 className="text-xl font-black text-white">Тест інтуїції завершено!</h3>
            <p className="text-sm text-slate-300 max-w-md mx-auto">
              Ваш результат: <strong className="text-emerald-400 font-bold">{quizScore}</strong> з {INTUITION_QUESTIONS.length} правильних відповідей.
              Пройдіть повний CEFR-тест для точного визначення рівня.
            </p>
            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                onClick={() => onSelectTab('level-test')}
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 font-black text-xs flex items-center gap-2 transition cursor-pointer"
              >
                <Award className="w-4 h-4" />
                <span>Пройти повний тест рівня (A1–C1)</span>
              </button>
              <button
                onClick={handleResetQuiz}
                className="px-4 py-2.5 rounded-xl bg-slate-800 text-slate-300 hover:text-white font-bold text-xs transition cursor-pointer"
              >
                Спробувати ще раз
              </button>
            </div>
          </div>
        )}
      </section>

      {/* ================= TESTIMONIALS (REAL STUDENT EXPERIENCES) ================= */}
      <section className="space-y-6">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 block">
            Результати студентів
          </span>
          <h2 className="text-2xl sm:text-3xl font-black text-white">
            Як алгоритмічний підхід змінює результати
          </h2>
          <p className="text-xs sm:text-sm text-slate-400">
            Реальні історії українців, які подолали мовний бар'єр завдяки мовним мостам:
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {TESTIMONIALS.map((t, idx) => (
            <div
              key={idx}
              className="p-6 rounded-3xl bg-slate-900 border border-slate-800 flex flex-col justify-between space-y-4 shadow-lg hover:border-slate-700 transition"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white font-bold text-xs flex items-center justify-center">
                      {t.avatar}
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white">{t.name}</h4>
                      <p className="text-xs text-slate-400">{t.role}</p>
                    </div>
                  </div>
                  <span className="px-2 py-1 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[10px] font-black">
                    {t.levelChange}
                  </span>
                </div>

                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed italic">
                  «{t.comment}»
                </p>
              </div>

              <div className="pt-3 border-t border-slate-800 text-[11px] font-medium text-slate-500 flex items-center justify-between">
                <span>Термін прогресу:</span>
                <span className="text-slate-300 font-semibold">{t.timeframe}</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ================= MAIN LINGUISTIC HACKS CATALOG ================= */}
      <section className="space-y-6 pt-6 border-t border-slate-800/80">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-2xl sm:text-3xl font-black text-white flex items-center gap-2.5">
              <Compass className="w-6 h-6 text-blue-400" />
              <span>Каталог Мовних Мостів та Алгоритмів</span>
            </h2>
            <p className="text-xs sm:text-sm text-slate-400">
              Оберіть правило, щоб ознайомитися з логікою заміни та пройти тренування:
            </p>
          </div>

          {/* Category Filter Buttons */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 max-w-full no-scrollbar">
            <button
              onClick={() => handleFilterClick('all')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                selectedFilter === 'all'
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              Усі ({LINGUISTIC_HACKS.length})
            </button>
            <button
              onClick={() => handleFilterClick('suffix')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                selectedFilter === 'suffix'
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              Суфікси
            </button>
            <button
              onClick={() => handleFilterClick('prefix')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                selectedFilter === 'prefix'
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              Префікси
            </button>
            <button
              onClick={() => handleFilterClick('traps')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                selectedFilter === 'traps'
                  ? 'bg-rose-600 text-white shadow-md shadow-rose-600/30'
                  : 'bg-slate-800 text-amber-300 hover:bg-slate-700'
              }`}
            >
              ⚠️ Пастки
            </button>
          </div>
        </div>

        {/* Hacks Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredHacks.map((hack) => (
            <div
              key={hack.id}
              className="bg-slate-900 rounded-3xl border border-slate-800 p-6 flex flex-col justify-between hover:border-slate-700 transition group hover:shadow-xl space-y-4"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="px-2.5 py-0.5 rounded-xl text-[10px] font-black uppercase tracking-wider bg-blue-500/10 text-blue-400 border border-blue-500/20">
                    {hack.tag}
                  </span>
                  <span className="text-xs font-semibold text-slate-500">{hack.examplesCount}</span>
                </div>
                <h3 className="text-lg font-black text-white group-hover:text-blue-400 transition">
                  {hack.title}
                </h3>
                <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">{hack.description}</p>
              </div>

              <div className="pt-4 border-t border-slate-800/80 flex items-center justify-between">
                <span className="text-xs font-mono text-amber-300 font-semibold truncate max-w-[180px]">
                  {hack.formula}
                </span>
                <button
                  onClick={() => handlePracticeClick(hack.id)}
                  className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-blue-600 text-xs font-bold text-slate-200 hover:text-white transition flex items-center gap-1.5 cursor-pointer"
                >
                  <span>Практика</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ================= FINAL HIGH-CONVERTING BOTTOM CTA ================= */}
      <section className="bg-gradient-to-r from-blue-900/60 via-indigo-900/70 to-purple-900/60 border border-blue-500/30 rounded-3xl p-8 sm:p-12 text-center relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 max-w-2xl mx-auto space-y-5">
          <h2 className="text-2xl sm:text-4xl font-black text-white tracking-tight">
            Готові перевірити свій рівень або почати з теми слів?
          </h2>
          <p className="text-xs sm:text-sm text-slate-200 leading-relaxed">
            Пройдіть 5-хвилинний тест CEFR з детальним аналізом прогалин або відкрийте тематичні слова (тварини, дім, робота) з мнемонічними гачками.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <button
              onClick={() => onSelectTab('level-test')}
              className="px-6 py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-sm shadow-xl shadow-orange-500/25 flex items-center gap-2 transition cursor-pointer"
            >
              <Award className="w-4 h-4" />
              <span>Почати тест CEFR (A1–C1)</span>
            </button>
            <button
              onClick={() => onSelectTab('topics')}
              className="px-6 py-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-sm shadow-xl shadow-emerald-600/25 flex items-center gap-2 transition cursor-pointer"
            >
              <span>🐾 Вивчати слова за категоріями</span>
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
