import React, { useState } from 'react';
import {
  BookMarked,
  Search,
  Volume2,
  BookmarkPlus,
  BookmarkCheck,
} from 'lucide-react';
import { ALL_VOCABULARY } from '../data/hacks';
import { ALL_THEMATIC_VOCAB_ITEMS, THEMATIC_CATEGORIES } from '../data/thematicWords';
import { VocabItem } from '../types';
import { playSound, speakEnglish } from '../utils/audio';

interface DictionaryProps {
  learnedWords: VocabItem[];
  onToggleLearned: (item: VocabItem) => void;
  onToast: (msg: string, type: 'info' | 'success' | 'error') => void;
}

export const Dictionary: React.FC<DictionaryProps> = ({
  learnedWords,
  onToggleLearned,
  onToast,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const allWords = [...ALL_VOCABULARY, ...ALL_THEMATIC_VOCAB_ITEMS];

  const filteredWords = allWords.filter((item) => {
    const matchesCategory = selectedCategory === 'all' || item.category === selectedCategory;
    const term = searchTerm.trim().toLowerCase();
    const matchesSearch =
      !term ||
      item.ukr.toLowerCase().includes(term) ||
      item.eng.toLowerCase().includes(term);
    return matchesCategory && matchesSearch;
  });

  const handleSpeak = (text: string) => {
    speakEnglish(text);
  };

  const handleToggle = (item: VocabItem) => {
    playSound('correct');
    onToggleLearned(item);
    const isAlreadyLearned = learnedWords.some((w) => w.eng === item.eng);
    if (!isAlreadyLearned) {
      onToast(`«${item.eng}» додано до Скарбнички! (+10 XP)`, 'success');
    } else {
      onToast(`«${item.eng}» видалено зі Скарбнички`, 'info');
    }
  };

  return (
    <section className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-white flex items-center gap-2">
            <BookMarked className="w-6 h-6 text-sky-400" />
            <span>База Мовних Шаблонів</span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-400">Пошук серед сотень слів за правилами</p>
        </div>
        <div className="flex items-center gap-2 text-xs font-bold text-slate-400">
          <span>
            Усього слів: <strong className="text-blue-400">{filteredWords.length}</strong>
          </span>
        </div>
      </div>

      {/* Search & Filters */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="sm:col-span-2 relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Шукати за українським чи англійським словом..."
            className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-slate-900 border border-slate-800 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-blue-500"
          />
        </div>
        <div>
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="w-full px-3.5 py-2.5 rounded-2xl bg-slate-900 border border-slate-800 text-sm font-semibold text-slate-200 focus:outline-none focus:border-blue-500"
          >
            <option value="all">Усі категорії ({allWords.length} слів)</option>
            <optgroup label="🐾 Тематичні сфери слів">
              {THEMATIC_CATEGORIES.map((cat) => (
                <option key={cat.id} value={cat.id}>
                  {cat.icon} {cat.title} ({cat.engTitle})
                </option>
              ))}
            </optgroup>
            <optgroup label="⚡ Лайфхаки суфіксів та префіксів">
              <option value="tion">Суфікс -tion / -sion</option>
              <option value="less">Суфікс -less / ir-</option>
              <option value="ic">Суфікс -ic / -ical</option>
              <option value="ity">Суфікс -ity / -ness</option>
              <option value="al">Суфікс -al</option>
              <option value="ive">Суфікс -ive</option>
              <option value="ist">Діячі -ist / -or / -er</option>
              <option value="able">-абельний -able / -ible</option>
              <option value="ment">Іменники дій -ment</option>
              <option value="re">Префікс re-</option>
              <option value="over">Префікс over-</option>
              <option value="false_friends">⚠️ Фальшиві друзі</option>
            </optgroup>
          </select>
        </div>
      </div>

      {/* Dictionary Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
        {filteredWords.map((item) => {
          const isLearned = learnedWords.some((w) => w.eng === item.eng);
          return (
            <div
              key={`${item.ukr}-${item.eng}`}
              className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between hover:border-slate-700 transition group"
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  {item.emoji && <span className="text-base">{item.emoji}</span>}
                  <span className="text-sm font-black text-white">{item.ukr}</span>
                  <span className="text-xs text-slate-500">➔</span>
                  <span className="text-sm font-black text-blue-400">{item.eng}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-mono text-slate-400">{item.ipa}</span>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-400 font-semibold">
                    {item.rule}
                  </span>
                </div>
                {item.exampleEn && (
                  <p className="text-[11px] text-slate-400 italic line-clamp-1">
                    «{item.exampleEn}»
                  </p>
                )}
              </div>
              <div className="flex items-center gap-1.5 shrink-0 ml-2">
                <button
                  onClick={() => handleSpeak(item.eng)}
                  className="p-2 rounded-xl bg-slate-800 hover:bg-blue-600 text-slate-300 hover:text-white transition"
                  title="Вимова"
                >
                  <Volume2 className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleToggle(item)}
                  className={`p-2 rounded-xl transition ${
                    isLearned
                      ? 'bg-emerald-600/20 text-emerald-400 border border-emerald-500/30'
                      : 'bg-slate-800 hover:bg-emerald-600 text-slate-300 hover:text-white'
                  }`}
                  title={isLearned ? 'Видалити зі скарбнички' : 'Зберегти у скарбничку'}
                >
                  {isLearned ? <BookmarkCheck className="w-4 h-4" /> : <BookmarkPlus className="w-4 h-4" />}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
};
