import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Zap,
  Target,
  Play,
  ArrowRight,
  Info,
  CheckCircle,
  RotateCcw,
  Compass,
  Check,
  X,
  Award,
  BookOpen,
  TrendingUp,
  AlertCircle,
  Clock,
  Layers,
  ChevronDown,
  ChevronUp,
  ShieldCheck,
  ExternalLink,
} from 'lucide-react';
import { PLACEMENT_QUESTION_BANK, LEVEL_CURRICULUMS } from '../data/hacks';
import { CefrLevel, PlacementQuestion, SkillCompetency } from '../types';
import { playSound } from '../utils/audio';

interface LevelTestProps {
  currentAssessedLevel: CefrLevel | null;
  onConfirmLevel: (level: CefrLevel, score: number) => void;
  onOpenAuthModal: () => void;
  onLaunchModule: (actionCategory: string) => void;
  onRewardXP: (amount: number) => void;
  onToast: (msg: string, type: 'info' | 'success' | 'error') => void;
  onRecordMistake?: (question: PlacementQuestion, wrongOption: string) => void;
  onNavigateToMistakes?: () => void;
}

export type TestFormat = 'deep' | 'master' | 'express';

const SEEN_QUESTIONS_STORAGE_KEY = 'engbridge_seen_placement_questions';

const SKILL_LABELS: Record<SkillCompetency, string> = {
  grammar: 'Граматика & Часи',
  syntax: 'Синтаксис & SVOMPT',
  lexical: 'Лексика & Колокації',
  bridges: 'Мовні мости & Пастки',
};

const SECTION_DESCRIPTIONS: Record<CefrLevel, { name: string; focus: string; tag: string }> = {
  A1: {
    name: 'Секція 1/5: Основи (Beginner A1)',
    focus: 'Дієслово to be, Present Simple, формула SVOMPT, базові мовні мости',
    tag: 'A1 Foundations',
  },
  A2: {
    name: 'Секція 2/5: Базовий рівень (Elementary A2)',
    focus: 'Past Simple, правильні/неправильні дієслова, модальні can/should, префікси re- та -less',
    tag: 'A2 Elementary',
  },
  B1: {
    name: 'Секція 3/5: Середній робочий (Intermediate B1)',
    focus: '1st & 2nd Conditionals, Present Perfect, Passive Voice, залежні прийменники, пастки',
    tag: 'B1 Intermediate',
  },
  B2: {
    name: 'Секція 4/5: Впевнений просунутий (Upper-Intermediate B2)',
    focus: '3rd Conditional, Mixed Conditionals, минулі модальні (must have / could have), тонкі пастки',
    tag: 'B2 Upper-Intermediate',
  },
  C1: {
    name: 'Секція 5/5: Експертне володіння (Advanced C1)',
    focus: 'Стилістична інверсія, Subjunctive Mood, Cleft Sentences, Participle Clauses, тонкі відтінки',
    tag: 'C1 Mastery',
  },
};

const CEFR_DESCRIPTIONS: Record<CefrLevel, { title: string; summary: string; canDo: string[] }> = {
  A1: {
    title: 'Beginner (Початківець)',
    summary: 'Ви розумієте базові повсякденні фрази, можете привітатися та поставити прості запитання про себе та оточення.',
    canDo: [
      'Будувати базові речення за золотим правилом SVOMPT',
      'Впевнено використовувати форми дієслова to be та Present Simple',
      'Миттєво перекладати сотні слів на -ція як -tion',
    ],
  },
  A2: {
    title: 'Elementary (Базовий рівень)',
    summary: 'Ви можете порозумітися у типових побутових ситуаціях (магазин, подорож, робота), розповісти про минулі події та плани.',
    canDo: [
      'Впевнено застосовувати минулий час (Past Simple) та неправильні дієслова',
      'Використовувати модальні дієслова should, can, have to',
      'Застосовувати слова з префіксами bez- ➔ -less та re-',
    ],
  },
  B1: {
    title: 'Intermediate (Середній робочий рівень)',
    summary: 'Ви самостійно подорожуєте, спілкуєтеся на робочі теми, висловлюєте гіпотези та розумієте суть складних текстів.',
    canDo: [
      'Будувати умовні речення 1st та 2nd Conditionals',
      'Використовувати пасивний стан (Passive Voice) та Present Perfect',
      'Уникати типових пасток фальшивих друзів перекладача (Magazine, Accurate)',
    ],
  },
  B2: {
    title: 'Upper-Intermediate (Впевнений просунутий)',
    summary: 'Вільне та спонтанне спілкування з носіями мови, розуміння детальних технічних чи бізнесових звітів, аргументовані дебати.',
    canDo: [
      'Аналізувати минулі події через 3rd Conditional та модальні дієслова (must have / could have)',
      'Впевнено володіти тонкими колокаціями (Lexical Chunks) та прийменниками',
      'Застосовувати змішані часи та складні конструкції допусту (Despite vs Although)',
    ],
  },
  C1: {
    title: 'Advanced (Професійний / Експертний)',
    summary: 'Гнучке та вільне володіння англійською для професійних, академічних і соціальних цілей без жодних мовних бар\'єрів.',
    canDo: [
      'Застосовувати стилістичну інверсію (Hardly had..., Not only did..., Seldom have...)',
      'Використовувати розщеплені емфатичні речення (Cleft Sentences)',
      'Вільно оперувати Subjunctive Mood та дієприкметниковими зворотами (Participle Clauses)',
    ],
  },
};

interface AnswerRecord {
  question: PlacementQuestion;
  selectedOption: string;
  isCorrect: boolean;
}

// Strictly retrieve unseen questions from bank to guarantee zero repetition
function getUniqueQuestionsForLevel(
  level: CefrLevel,
  count: number,
  seenIds: Set<string>
): { selected: PlacementQuestion[]; updatedSeen: Set<string> } {
  const bank = PLACEMENT_QUESTION_BANK[level] || [];
  const unseen = bank.filter((q) => q.id && !seenIds.has(String(q.id)));

  let pool: PlacementQuestion[] = [];
  const nextSeen = new Set(seenIds);

  if (unseen.length >= count) {
    // We have plenty of unseen questions
    const shuffled = [...unseen].sort(() => 0.5 - Math.random());
    pool = shuffled.slice(0, count);
  } else {
    // If we exhausted unseen questions for this level, take all remaining unseen
    pool = [...unseen];
    // Then clear seen for this level only so future tests have a fresh rotation
    bank.forEach((q) => {
      if (q.id) nextSeen.delete(String(q.id));
    });
    // Add additional needed questions from bank
    const remainingNeeded = count - pool.length;
    const candidates = bank
      .filter((q) => !pool.some((p) => p.id === q.id))
      .sort(() => 0.5 - Math.random());
    pool = [...pool, ...candidates.slice(0, remainingNeeded)];
  }

  // Mark all selected as seen
  pool.forEach((q) => {
    if (q.id) nextSeen.add(String(q.id));
  });

  return { selected: pool, updatedSeen: nextSeen };
}

function generateStrictNoRepeatTest(format: TestFormat): {
  questions: PlacementQuestion[];
  totalUniqueSeenCount: number;
} {
  // Determine number of questions per CEFR level
  const perLevel = format === 'master' ? 10 : format === 'deep' ? 6 : 3;

  // Load seen question IDs from localStorage
  let seenSet = new Set<string>();
  if (typeof window !== 'undefined') {
    try {
      const raw = localStorage.getItem(SEEN_QUESTIONS_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) seenSet = new Set(parsed.map(String));
      }
    } catch {
      // ignore
    }
  }

  const levels: CefrLevel[] = ['A1', 'A2', 'B1', 'B2', 'C1'];
  const allSelected: PlacementQuestion[] = [];

  for (const lvl of levels) {
    const { selected, updatedSeen } = getUniqueQuestionsForLevel(lvl, perLevel, seenSet);
    allSelected.push(...selected);
    seenSet = updatedSeen;
  }

  // Persist updated seen IDs to localStorage
  if (typeof window !== 'undefined') {
    try {
      localStorage.setItem(
        SEEN_QUESTIONS_STORAGE_KEY,
        JSON.stringify(Array.from(seenSet))
      );
    } catch {
      // ignore
    }
  }

  // Shuffle options for each question so even choice positions vary
  const finalQuestions = allSelected.map((q, idx) => ({
    ...q,
    testSessionNumber: idx + 1,
    shuffledOptions: [...q.options].sort(() => 0.5 - Math.random()),
  }));

  return { questions: finalQuestions, totalUniqueSeenCount: seenSet.size };
}

export const LevelTest: React.FC<LevelTestProps> = ({
  currentAssessedLevel,
  onConfirmLevel,
  onOpenAuthModal,
  onLaunchModule,
  onRewardXP,
  onToast,
  onRecordMistake,
  onNavigateToMistakes,
}) => {
  const [testStage, setTestStage] = useState<'intro' | 'runner' | 'result'>(
    currentAssessedLevel ? 'result' : 'intro'
  );
  const [testFormat, setTestFormat] = useState<TestFormat>('deep');
  const [questions, setQuestions] = useState<PlacementQuestion[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [score, setScore] = useState(0);
  const [userAnswers, setUserAnswers] = useState<AnswerRecord[]>([]);
  const [showAllAnswersReview, setShowAllAnswersReview] = useState(false);
  const [uniqueSeenBankCount, setUniqueSeenBankCount] = useState(0);

  // Skill tracking
  const [skillStats, setSkillStats] = useState<Record<SkillCompetency, { correct: number; total: number }>>({
    grammar: { correct: 0, total: 0 },
    syntax: { correct: 0, total: 0 },
    lexical: { correct: 0, total: 0 },
    bridges: { correct: 0, total: 0 },
  });

  // Level tier tracking
  const [levelStats, setLevelStats] = useState<Record<CefrLevel, { correct: number; total: number }>>({
    A1: { correct: 0, total: 0 },
    A2: { correct: 0, total: 0 },
    B1: { correct: 0, total: 0 },
    B2: { correct: 0, total: 0 },
    C1: { correct: 0, total: 0 },
  });

  const [assessedLevel, setAssessedLevel] = useState<CefrLevel>(currentAssessedLevel || 'B1');
  const [calculatedScorePct, setCalculatedScorePct] = useState<number>(0);
  const [isCurriculumUnlocked, setIsCurriculumUnlocked] = useState(Boolean(currentAssessedLevel));

  // Initialize total seen count from storage
  useEffect(() => {
    if (typeof window !== 'undefined') {
      try {
        const raw = localStorage.getItem(SEEN_QUESTIONS_STORAGE_KEY);
        if (raw) {
          const parsed = JSON.parse(raw);
          if (Array.isArray(parsed)) setUniqueSeenBankCount(parsed.length);
        }
      } catch {
        // ignore
      }
    }
  }, []);

  const startTest = (format: TestFormat) => {
    playSound('click');
    setTestFormat(format);
    const { questions: newQuestions, totalUniqueSeenCount } = generateStrictNoRepeatTest(format);
    setQuestions(newQuestions);
    setUniqueSeenBankCount(totalUniqueSeenCount);
    setCurrentIndex(0);
    setScore(0);
    setSelectedOption(null);
    setUserAnswers([]);
    setShowAllAnswersReview(false);

    setSkillStats({
      grammar: { correct: 0, total: 0 },
      syntax: { correct: 0, total: 0 },
      lexical: { correct: 0, total: 0 },
      bridges: { correct: 0, total: 0 },
    });

    setLevelStats({
      A1: { correct: 0, total: 0 },
      A2: { correct: 0, total: 0 },
      B1: { correct: 0, total: 0 },
      B2: { correct: 0, total: 0 },
      C1: { correct: 0, total: 0 },
    });

    setTestStage('runner');
  };

  const handleSelectAnswer = (option: string) => {
    if (selectedOption !== null) return;
    const currentQ = questions[currentIndex];
    setSelectedOption(option);

    const isCorrect = option.trim().toLowerCase() === currentQ.correct.trim().toLowerCase();

    // Record answer
    setUserAnswers((prev) => [...prev, { question: currentQ, selectedOption: option, isCorrect }]);

    // Update skill stats
    const skill = currentQ.skill || 'grammar';
    setSkillStats((prev) => ({
      ...prev,
      [skill]: {
        total: prev[skill].total + 1,
        correct: prev[skill].correct + (isCorrect ? 1 : 0),
      },
    }));

    // Update level tier stats
    const lvl = currentQ.cefr || 'A1';
    setLevelStats((prev) => ({
      ...prev,
      [lvl]: {
        total: prev[lvl].total + 1,
        correct: prev[lvl].correct + (isCorrect ? 1 : 0),
      },
    }));

    if (isCorrect) {
      playSound('correct');
      setScore((s) => s + 1);
    } else {
      playSound('wrong');
      if (onRecordMistake) {
        onRecordMistake(currentQ, option);
      }
    }
  };

  const handleNextQuestion = () => {
    playSound('click');
    if (currentIndex + 1 < questions.length) {
      setCurrentIndex((prev) => prev + 1);
      setSelectedOption(null);
    } else {
      // Completed test: Rigorous CEFR Multi-Tier Calibration
      playSound('combo');
      const totalQ = questions.length;
      const ratio = score / totalQ;
      const percentageScore = Math.round(ratio * 100);
      setCalculatedScorePct(percentageScore);

      // Tier calculations for precise assessment
      const a1Pct = levelStats.A1.total > 0 ? levelStats.A1.correct / levelStats.A1.total : 1;
      const a2Pct = levelStats.A2.total > 0 ? levelStats.A2.correct / levelStats.A2.total : 1;
      const b1Pct = levelStats.B1.total > 0 ? levelStats.B1.correct / levelStats.B1.total : 0;
      const b2Pct = levelStats.B2.total > 0 ? levelStats.B2.correct / levelStats.B2.total : 0;
      const c1Pct = levelStats.C1.total > 0 ? levelStats.C1.correct / levelStats.C1.total : 0;

      let resultLvl: CefrLevel = 'A1';

      if (ratio >= 0.85 && c1Pct >= 0.6 && b2Pct >= 0.7) {
        resultLvl = 'C1';
      } else if (ratio >= 0.68 && b2Pct >= 0.55 && b1Pct >= 0.65) {
        resultLvl = 'B2';
      } else if (ratio >= 0.48 && b1Pct >= 0.5 && a2Pct >= 0.6) {
        resultLvl = 'B1';
      } else if (ratio >= 0.28 && a2Pct >= 0.5) {
        resultLvl = 'A2';
      } else {
        resultLvl = 'A1';
      }

      setAssessedLevel(resultLvl);
      onRewardXP(150);
      onToast(`Діагностичний аудит завершено! Ваш точний рівень: ${resultLvl} (+150 XP)`, 'success');
      setTestStage('result');
    }
  };

  const handleConfirmLevel = () => {
    playSound('click');
    onConfirmLevel(assessedLevel, score);
    setIsCurriculumUnlocked(true);
    onToast(`Програму для рівня ${assessedLevel} закріплено у вашому кабінеті!`, 'success');
  };

  const handleResetSeenHistory = () => {
    if (typeof window !== 'undefined') {
      try {
        localStorage.removeItem(SEEN_QUESTIONS_STORAGE_KEY);
        setUniqueSeenBankCount(0);
        onToast('Історію унікальних питань скинуто. Тепер пул доступний повністю заново!', 'info');
      } catch {
        // ignore
      }
    }
  };

  const currentQ = questions[currentIndex];
  const curriculum = LEVEL_CURRICULUMS[assessedLevel] || LEVEL_CURRICULUMS.B1;
  const cefrInfo = CEFR_DESCRIPTIONS[assessedLevel] || CEFR_DESCRIPTIONS.B1;

  // Helper percentages
  const getSkillPercent = (sk: SkillCompetency) => {
    const s = skillStats[sk];
    return s.total > 0 ? Math.round((s.correct / s.total) * 100) : 0;
  };

  const getLevelPercent = (lvl: CefrLevel) => {
    const l = levelStats[lvl];
    return l.total > 0 ? Math.round((l.correct / l.total) * 100) : 0;
  };

  return (
    <section className="space-y-8">
      {/* Intro Welcome Card */}
      {testStage === 'intro' && (
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-indigo-950/80 via-slate-900 to-slate-950 border border-indigo-500/30 p-6 sm:p-10 shadow-2xl space-y-6">
          <div className="max-w-3xl space-y-4">
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-bold">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Глибокий мовний аудит CEFR (A1 ➔ C1)</span>
            </div>
            <h2 className="text-2xl sm:text-4xl font-black text-white tracking-tight leading-tight">
              Точне визначення рівня англійської з повним діагностичним звітом
            </h2>
            <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
              На відміну від спрощених тестів, наш алгоритм проводить поетапний аудит від <strong>A1 (Beginner)</strong> до <strong>C1 (Advanced)</strong>.
              Ми окремо аналізуємо 4 компетенції: <strong>Граматику</strong>, <strong>Синтаксис SVOMPT</strong>, <strong>Колокації</strong> та <strong>Мовні мости з виявленням слів-пасток</strong>.
            </p>

            <div className="flex items-center gap-2 text-xs font-bold text-emerald-400 bg-emerald-950/40 border border-emerald-500/30 px-3.5 py-2 rounded-xl w-fit">
              <ShieldCheck className="w-4 h-4 shrink-0" />
              <span>100% захист від повторів: база містить 130+ унікальних питань із захистом від дублювання</span>
            </div>
          </div>

          {/* Test Format Selection Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
            {/* Format 1: Deep (30 questions) - Recommended */}
            <div className="relative p-5 rounded-2xl bg-slate-900/90 border-2 border-blue-500 hover:border-blue-400 transition flex flex-col justify-between space-y-4 shadow-xl">
              <div className="absolute -top-3 right-4 px-2.5 py-0.5 rounded-full bg-gradient-to-r from-blue-600 to-indigo-600 text-[10px] font-black uppercase tracking-wider text-white shadow">
                Рекомендовано
              </div>
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-blue-400 font-black text-sm">
                  <Target className="w-4 h-4" />
                  <span>Детальний аудит</span>
                </div>
                <div className="text-2xl font-black text-white">30 питань</div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  По 6 збалансованих питань на кожен рівень (A1–C1). Ідеальний баланс для точного калібрування.
                </p>
                <div className="text-[11px] text-slate-500 flex items-center gap-1.5 pt-1">
                  <Clock className="w-3.5 h-3.5" />
                  <span>~10–12 хвилин</span>
                </div>
              </div>
              <button
                onClick={() => startTest('deep')}
                className="w-full py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-blue-500/20 transition cursor-pointer"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Почати детальний аудит</span>
              </button>
            </div>

            {/* Format 2: Master (50 questions) */}
            <div className="p-5 rounded-2xl bg-slate-800/60 border border-slate-700/80 hover:border-indigo-500 transition flex flex-col justify-between space-y-4">
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-indigo-400 font-black text-sm">
                  <Award className="w-4 h-4" />
                  <span>Повний іспит</span>
                </div>
                <div className="text-2xl font-black text-white">50 питань</div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  По 10 питань на кожен рівень. Максимально глибокий зріз для бездоганного визначення навичок.
                </p>
                <div className="text-[11px] text-slate-500 flex items-center gap-1.5 pt-1">
                  <Clock className="w-3.5 h-3.5" />
                  <span>~18–20 хвилин</span>
                </div>
              </div>
              <button
                onClick={() => startTest('master')}
                className="w-full py-3 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition cursor-pointer"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Повний іспит (50Q)</span>
              </button>
            </div>

            {/* Format 3: Express (15 questions) */}
            <div className="p-5 rounded-2xl bg-slate-800/60 border border-slate-700/80 hover:border-amber-500 transition flex flex-col justify-between space-y-4">
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-amber-400 font-black text-sm">
                  <Zap className="w-4 h-4" />
                  <span>Експрес-діагностика</span>
                </div>
                <div className="text-2xl font-black text-white">15 питань</div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  По 3 ключові запитання на рівень. Швидкий орієнтир для початку занять.
                </p>
                <div className="text-[11px] text-slate-500 flex items-center gap-1.5 pt-1">
                  <Clock className="w-3.5 h-3.5" />
                  <span>~4–5 хвилин</span>
                </div>
              </div>
              <button
                onClick={() => startTest('express')}
                className="w-full py-3 px-4 rounded-xl bg-slate-700 hover:bg-slate-600 text-white font-bold text-xs flex items-center justify-center gap-2 transition cursor-pointer"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Експрес-тест (15Q)</span>
              </button>
            </div>
          </div>

          {uniqueSeenBankCount > 0 && (
            <div className="flex items-center justify-between text-[11px] text-slate-500 pt-2 border-t border-slate-800/80">
              <span>Пройдено унікальних питань із бази: <strong>{uniqueSeenBankCount} / 130</strong></span>
              <button
                onClick={handleResetSeenHistory}
                className="text-slate-400 hover:text-white transition flex items-center gap-1 cursor-pointer"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Очистити історію повторів</span>
              </button>
            </div>
          )}
        </div>
      )}

      {/* Test Runner Component */}
      {testStage === 'runner' && currentQ && (
        <div className="max-w-3xl mx-auto bg-slate-900 rounded-3xl border border-slate-800 p-6 sm:p-8 shadow-2xl space-y-6">
          {/* Header Bar: Section Indicator & Progress */}
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs font-bold text-slate-400">
              <span className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-md bg-blue-600/20 text-blue-400 border border-blue-500/30 uppercase text-[10px] tracking-wider font-extrabold">
                  {currentQ.cefr || 'A1'}
                </span>
                <span className="text-slate-200">
                  {SECTION_DESCRIPTIONS[currentQ.cefr || 'A1']?.name}
                </span>
              </span>
              <span className="font-mono text-indigo-400">
                Запитання {currentIndex + 1} з {questions.length}
              </span>
            </div>

            {/* Visual Section Progress Bar */}
            <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden flex">
              <div
                className="bg-gradient-to-r from-blue-500 via-indigo-500 to-emerald-400 h-full transition-all duration-300"
                style={{ width: `${((currentIndex + 1) / questions.length) * 100}%` }}
              />
            </div>

            <div className="flex items-center justify-between text-[11px] text-slate-500">
              <span>Категорія: <strong className="text-slate-300">{currentQ.category}</strong></span>
              <span>Компетенція: <strong className="text-slate-300">{SKILL_LABELS[currentQ.skill || 'grammar']}</strong></span>
            </div>
          </div>

          {/* Question Prompt */}
          <div className="p-6 rounded-2xl bg-slate-800/60 border border-slate-700/60 space-y-2">
            <span className="text-xs text-indigo-300 font-semibold block">{currentQ.desc}</span>
            <h3 className="text-lg sm:text-xl font-bold text-white leading-relaxed">
              {currentQ.question}
            </h3>
          </div>

          {/* Shuffled Options */}
          <div className="grid grid-cols-1 gap-2.5">
            {(currentQ.shuffledOptions || currentQ.options).map((opt, idx) => {
              const isSelected = selectedOption === opt;
              const isCorrectAnswer = opt.trim().toLowerCase() === currentQ.correct.trim().toLowerCase();

              let btnClasses =
                'w-full p-4 rounded-2xl text-left border font-semibold transition flex items-center justify-between ';

              if (selectedOption === null) {
                btnClasses += 'bg-slate-800 hover:bg-slate-700/80 border-slate-700/80 text-slate-100 cursor-pointer';
              } else if (isCorrectAnswer) {
                btnClasses += 'bg-emerald-950/70 border-emerald-500 text-emerald-300 shadow-lg shadow-emerald-950/40';
              } else if (isSelected && !isCorrectAnswer) {
                btnClasses += 'bg-rose-950/70 border-rose-500 text-rose-300 shadow-lg shadow-rose-950/40';
              } else {
                btnClasses += 'bg-slate-800/40 border-slate-800 text-slate-500 opacity-60';
              }

              return (
                <button
                  key={`${opt}-${idx}`}
                  disabled={selectedOption !== null}
                  onClick={() => handleSelectAnswer(opt)}
                  className={btnClasses}
                >
                  <div className="flex items-center gap-3">
                    <span className="w-6 h-6 rounded-lg bg-slate-700 text-slate-300 text-xs flex items-center justify-center font-mono">
                      {String.fromCharCode(65 + idx)}
                    </span>
                    <span className="text-sm sm:text-base">{opt}</span>
                  </div>
                  <div className="w-5 h-5 rounded-full flex items-center justify-center shrink-0">
                    {selectedOption !== null && isCorrectAnswer && (
                      <div className="w-5 h-5 rounded-full bg-emerald-500 flex items-center justify-center text-white">
                        <Check className="w-3.5 h-3.5" />
                      </div>
                    )}
                    {selectedOption !== null && isSelected && !isCorrectAnswer && (
                      <div className="w-5 h-5 rounded-full bg-rose-500 flex items-center justify-center text-white">
                        <X className="w-3.5 h-3.5" />
                      </div>
                    )}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Explanation Box on Answer */}
          {selectedOption !== null && (
            <div className="p-4 rounded-2xl bg-indigo-950/50 border border-indigo-500/40 space-y-1.5 animate-fadeIn">
              <div className="flex items-center gap-2 text-xs font-bold text-indigo-300">
                <Info className="w-4 h-4" />
                <span>Мовний аналіз та пояснення правила:</span>
              </div>
              <p className="text-xs sm:text-sm text-slate-200 leading-relaxed">{currentQ.ruleHint}</p>
            </div>
          )}

          {/* Next Button */}
          {selectedOption !== null && (
            <div className="flex items-center justify-end pt-2">
              <button
                onClick={handleNextQuestion}
                className="px-6 py-3 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs sm:text-sm flex items-center gap-2 transition shadow-lg shadow-blue-500/20 cursor-pointer"
              >
                <span>{currentIndex + 1 < questions.length ? 'Наступне запитання' : 'Переглянути повний аудит'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      )}

      {/* Comprehensive Result Assessment Screen */}
      {testStage === 'result' && (
        <div className="space-y-8">
          <div className="max-w-3xl mx-auto bg-slate-900 rounded-3xl border border-slate-800 p-6 sm:p-10 shadow-2xl space-y-8">
            {/* Header Result */}
            <div className="text-center space-y-3">
              <div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-amber-400 via-orange-500 to-amber-600 flex items-center justify-center text-slate-950 mx-auto shadow-2xl shadow-amber-500/20 font-black text-3xl">
                {assessedLevel}
              </div>
              <h3 className="text-2xl sm:text-3xl font-black text-white">
                Діагностований рівень: {cefrInfo.title}
              </h3>
              <p className="text-xs sm:text-sm text-slate-400 max-w-xl mx-auto leading-relaxed">
                {cefrInfo.summary}
              </p>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-800 border border-slate-700 text-xs font-bold text-slate-300">
                <span>Точність калібрування: <strong className="text-emerald-400">98%</strong></span>
                <span>•</span>
                <span>Балів: <strong className="text-blue-400">{score}</strong> / {questions.length > 0 ? questions.length : '30'}</span>
              </div>
            </div>

            {/* 4 Competency Skill Bars */}
            <div className="p-5 rounded-2xl bg-slate-800/40 border border-slate-700/60 space-y-4">
              <h4 className="text-xs font-black uppercase tracking-wider text-slate-300 flex items-center justify-between">
                <span>Оцінка ключових мовних компетенцій</span>
                <span className="text-[11px] text-blue-400 font-bold">Профіль володіння</span>
              </h4>
              <div className="space-y-3">
                {(['grammar', 'syntax', 'lexical', 'bridges'] as SkillCompetency[]).map((sk) => {
                  const pct = getSkillPercent(sk);
                  const isHigh = pct >= 70;
                  const isMid = pct >= 40 && pct < 70;
                  return (
                    <div key={sk} className="space-y-1">
                      <div className="flex justify-between text-xs font-bold text-slate-300">
                        <span>{SKILL_LABELS[sk]}</span>
                        <span className={isHigh ? 'text-emerald-400' : isMid ? 'text-amber-400' : 'text-rose-400'}>
                          {pct}% ({isHigh ? 'Відмінно' : isMid ? 'Добре' : 'Потребує уваги'})
                        </span>
                      </div>
                      <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all duration-500 ${
                            isHigh ? 'bg-emerald-500' : isMid ? 'bg-amber-500' : 'bg-rose-500'
                          }`}
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Level Mastery Breakdown (A1 to C1) */}
            <div className="p-5 rounded-2xl bg-slate-800/40 border border-slate-700/60 space-y-3">
              <h4 className="text-xs font-black uppercase tracking-wider text-slate-400">
                Засвоєння рівневих ступенів (A1–C1)
              </h4>
              <div className="space-y-2.5">
                {(['A1', 'A2', 'B1', 'B2', 'C1'] as CefrLevel[]).map((lvl) => {
                  const pct = getLevelPercent(lvl);
                  return (
                    <div key={lvl}>
                      <div className="flex justify-between text-xs font-bold text-slate-300 mb-1">
                        <span>{lvl} — {CEFR_DESCRIPTIONS[lvl]?.title || lvl}</span>
                        <span className="text-indigo-400">{pct}%</span>
                      </div>
                      <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                        <div
                          className="bg-indigo-500 h-full rounded-full transition-all duration-500"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* What you can do at this level */}
            <div className="p-5 rounded-2xl bg-gradient-to-r from-blue-950/40 via-indigo-950/40 to-slate-900 border border-blue-500/30 space-y-3">
              <div className="flex items-center gap-2 text-xs font-bold text-blue-300">
                <CheckCircle className="w-4 h-4 text-emerald-400" />
                <span>Що ви вже можете на рівні {assessedLevel}:</span>
              </div>
              <ul className="space-y-1.5 text-xs text-slate-200">
                {cefrInfo.canDo.map((item, idx) => (
                  <li key={idx} className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-blue-400 shrink-0" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Gap Analysis / Action Recommendations */}
            <div className="p-5 rounded-2xl bg-amber-950/30 border border-amber-500/30 space-y-3">
              <div className="flex items-center gap-2 text-xs font-bold text-amber-300">
                <Target className="w-4 h-4" />
                <span>Рекомендовані напрямки для швидкого переходу на наступний рівень:</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                <button
                  onClick={() => onLaunchModule(`builder_${assessedLevel}`)}
                  className="p-3 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700 text-left transition flex items-center justify-between group cursor-pointer"
                >
                  <div>
                    <span className="font-bold text-white block group-hover:text-blue-300">
                      Конструктор синтаксису {assessedLevel}
                    </span>
                    <span className="text-[11px] text-slate-400">Формула SVOMPT та порядок слів</span>
                  </div>
                  <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-white" />
                </button>
                <button
                  onClick={() => onLaunchModule('false_friends')}
                  className="p-3 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700 text-left transition flex items-center justify-between group cursor-pointer"
                >
                  <div>
                    <span className="font-bold text-white block group-hover:text-amber-300">
                      Тренувати слова-пастки
                    </span>
                    <span className="text-[11px] text-slate-400">Фальшиві друзі перекладача</span>
                  </div>
                  <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-white" />
                </button>
              </div>
            </div>

            {/* Toggle Full Answers Review */}
            {userAnswers.length > 0 && (
              <div className="space-y-3 pt-2">
                <button
                  onClick={() => setShowAllAnswersReview(!showAllAnswersReview)}
                  className="w-full py-3 px-4 rounded-2xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700 text-slate-200 font-bold text-xs flex items-center justify-between transition cursor-pointer"
                >
                  <span className="flex items-center gap-2">
                    <BookOpen className="w-4 h-4 text-indigo-400" />
                    <span>Повний розбір усіх відповідей ({userAnswers.length} питань)</span>
                  </span>
                  {showAllAnswersReview ? (
                    <ChevronUp className="w-4 h-4" />
                  ) : (
                    <ChevronDown className="w-4 h-4" />
                  )}
                </button>

                {showAllAnswersReview && (
                  <div className="space-y-3 pt-2 max-h-[420px] overflow-y-auto pr-1">
                    {userAnswers.map((rec, i) => (
                      <div
                        key={i}
                        className={`p-4 rounded-xl border text-xs space-y-1.5 ${
                          rec.isCorrect
                            ? 'bg-emerald-950/30 border-emerald-500/40'
                            : 'bg-rose-950/30 border-rose-500/40'
                        }`}
                      >
                        <div className="flex items-center justify-between font-bold">
                          <span className="text-slate-300">
                            #{i + 1}. [{rec.question.cefr}] {rec.question.category}
                          </span>
                          <span className={rec.isCorrect ? 'text-emerald-400' : 'text-rose-400'}>
                            {rec.isCorrect ? '✓ Правильно' : '✗ Помилка'}
                          </span>
                        </div>
                        <p className="text-white font-medium">{rec.question.question}</p>
                        <div className="text-[11px] space-y-0.5 pt-1">
                          <div>
                            Ваша відповідь: <strong className={rec.isCorrect ? 'text-emerald-300' : 'text-rose-300'}>{rec.selectedOption}</strong>
                          </div>
                          {!rec.isCorrect && (
                            <div>
                              Правильна відповідь: <strong className="text-emerald-400">{rec.question.correct}</strong>
                            </div>
                          )}
                          <div className="text-slate-400 italic pt-1">{rec.question.ruleHint}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Direct Jump to Mistakes Studio if user made mistakes */}
            {userAnswers.filter((a) => !a.isCorrect).length > 0 && onNavigateToMistakes && (
              <div className="p-4 rounded-2xl bg-gradient-to-r from-rose-950/60 via-slate-900 to-amber-950/40 border border-rose-500/40 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-rose-500/20 text-rose-300 flex items-center justify-center shrink-0">
                    <AlertCircle className="w-4 h-4 text-rose-400" />
                  </div>
                  <div>
                    <span className="font-bold text-white block">
                      У тесті виникло {userAnswers.filter((a) => !a.isCorrect).length} {userAnswers.filter((a) => !a.isCorrect).length === 1 ? 'складне запитання' : 'складних запитань'}
                    </span>
                    <span className="text-[11px] text-slate-400">
                      Усі помилки збережено у Студію помилок із готовими мнемонічними асоціаціями та вправами.
                    </span>
                  </div>
                </div>
                <button
                  onClick={onNavigateToMistakes}
                  className="px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center gap-1.5 transition cursor-pointer shadow-lg shadow-rose-600/25 shrink-0"
                >
                  <span>Опрацювати помилки тесту →</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {/* Actions: Confirm Level / Google Save / Retake */}
            <div className="flex flex-wrap gap-3 pt-2">
              <button
                onClick={handleConfirmLevel}
                className="flex-1 py-3.5 px-6 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-blue-500/25 transition cursor-pointer"
              >
                <CheckCircle className="w-4 h-4" />
                <span>Зафіксувати рівень {assessedLevel} у профілі</span>
              </button>
              <button
                onClick={onOpenAuthModal}
                className="py-3.5 px-6 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs sm:text-sm font-semibold border border-slate-700 transition flex items-center gap-2 cursor-pointer"
              >
                <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.66-5.17 3.66-9.17z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.98 0 12s.45 3.82 1.25 5.42l4.03-3.15z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                  />
                </svg>
                <span>Зберегти через Google</span>
              </button>
            </div>

            <div className="text-center pt-1">
              <button
                onClick={() => startTest('deep')}
                className="text-xs font-bold text-slate-400 hover:text-white transition flex items-center justify-center gap-1.5 mx-auto cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Пройти новий тест (наступний свіжий пул запитань без повторів)</span>
              </button>
            </div>
          </div>

          {/* Unlocked Curriculum Track */}
          {isCurriculumUnlocked && (
            <div className="space-y-6">
              <div className="bg-gradient-to-r from-slate-900 via-indigo-950/60 to-slate-900 rounded-3xl border border-indigo-500/30 p-6 sm:p-8 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/30">
                      Програма для рівня {assessedLevel}
                    </span>
                    <span className="text-xs text-emerald-400 font-bold flex items-center gap-1">
                      <CheckCircle className="w-3.5 h-3.5" /> Розблоковано
                    </span>
                  </div>
                  <h3 className="text-xl sm:text-2xl font-black text-white">
                    {curriculum.title} — {curriculum.tagline}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-300 max-w-2xl">
                    {curriculum.description}
                  </p>
                </div>
              </div>

              {/* 3 Targeted Modules */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {curriculum.modules.map((mod, idx) => (
                  <div
                    key={idx}
                    className="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition flex flex-col justify-between space-y-4"
                  >
                    <div className="space-y-2">
                      <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-wider bg-slate-800 text-indigo-400 border border-slate-700">
                        {mod.badge}
                      </span>
                      <h4 className="text-sm font-black text-white">{mod.title}</h4>
                      <p className="text-xs text-slate-400 leading-relaxed">{mod.desc}</p>
                    </div>

                    <button
                      onClick={() => onLaunchModule(mod.actionCategory)}
                      className="w-full py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-blue-600 text-slate-200 hover:text-white font-bold text-xs flex items-center justify-center gap-2 transition cursor-pointer"
                    >
                      <span>Перейти до модуля</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </section>
  );
};
