import React from 'react';
import {
  Award,
  LogIn,
  LogOut,
  Route,
  ArrowRight,
  BookmarkCheck,
  Volume2,
  Trash2,
  Sparkles,
  BellRing,
  Clock,
  Repeat,
  Brain,
} from 'lucide-react';
import { UserProfile, VocabItem } from '../types';
import { LEVEL_CURRICULUMS } from '../data/hacks';
import { speakEnglish, playSound } from '../utils/audio';

interface ProfileViewProps {
  user: UserProfile;
  onOpenAuth: () => void;
  onLogout: () => void;
  onNavigateToLevelTest: () => void;
  onRemoveWord: (eng: string) => void;
  onClearVault: () => void;
  onToast: (msg: string, type: 'info' | 'success' | 'error') => void;
  onOpenReminders?: () => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  user,
  onOpenAuth,
  onLogout,
  onNavigateToLevelTest,
  onRemoveWord,
  onClearVault,
  onToast,
  onOpenReminders,
}) => {
  const nextLevelXp = user.level * 100;
  const xpPercent = Math.min(100, Math.round((user.xp / nextLevelXp) * 100));
  const accuracy =
    user.totalAnswered > 0 ? Math.round((user.correctCount / user.totalAnswered) * 100) : 100;

  const curriculum = user.cefrLevel ? LEVEL_CURRICULUMS[user.cefrLevel] : null;

  const handleSpeak = (text: string) => {
    speakEnglish(text);
  };

  const handleRemove = (item: VocabItem) => {
    playSound('click');
    onRemoveWord(item.eng);
    onToast(`«${item.eng}» видалено`, 'info');
  };

  const handleClear = () => {
    if (user.learnedWords.length === 0) return;
    playSound('click');
    onClearVault();
    onToast('Скарбничку очищено', 'info');
  };

  return (
    <section className="space-y-6">
      {/* User Profile Header Card */}
      <div className="bg-slate-900 rounded-3xl border border-slate-800 p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col sm:flex-row items-center sm:items-start justify-between gap-6">
          <div className="flex flex-col sm:flex-row items-center gap-5 text-center sm:text-left">
            <div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white font-black text-2xl flex items-center justify-center shadow-xl shadow-blue-500/20 shrink-0">
              {user.displayName.slice(0, 2).toUpperCase()}
            </div>
            <div className="space-y-1">
              <div className="flex items-center justify-center sm:justify-start gap-2">
                <h3 className="text-2xl font-black text-white">{user.displayName}</h3>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-slate-800 text-slate-300 border border-slate-700">
                  {user.isLoggedIn ? 'Google Verified 🇬' : 'Гість'}
                </span>
              </div>
              <p className="text-xs text-slate-400">
                {user.email || 'Локальний профіль (дані зберігаються у браузері)'}
              </p>
              <div className="pt-1 flex items-center justify-center sm:justify-start gap-2 text-xs font-bold text-amber-400">
                <Award className="w-4 h-4" />
                <span>
                  Рівень знань:{' '}
                  {user.cefrLevel ? (
                    <strong className="text-amber-300 bg-amber-500/20 px-2 py-0.5 rounded-md border border-amber-500/30">
                      {user.cefrLevel}
                    </strong>
                  ) : (
                    <strong className="text-slate-400 bg-slate-800 px-2 py-0.5 rounded-md border border-slate-700">
                      Не визначено (Пройти тест)
                    </strong>
                  )}
                </span>
              </div>
            </div>
          </div>

          {/* Auth Actions Button */}
          <div className="flex items-center gap-2">
            {!user.isLoggedIn ? (
              <button
                onClick={onOpenAuth}
                className="px-5 py-2.5 rounded-2xl bg-white hover:bg-slate-100 text-slate-800 text-xs font-bold flex items-center gap-2.5 shadow-lg shadow-black/20 transition cursor-pointer"
              >
                <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.66-5.17 3.66-9.17z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.98 0 12s.45 3.82 1.25 5.42l4.03-3.15z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                  />
                </svg>
                <span>Увійти через Google</span>
              </button>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  onClick={onOpenAuth}
                  className="px-3.5 py-2 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition cursor-pointer"
                >
                  Змінити акаунт
                </button>
                <button
                  onClick={onLogout}
                  className="px-3.5 py-2 rounded-2xl bg-slate-800 hover:bg-red-500/20 text-slate-300 hover:text-red-400 border border-slate-700 text-xs font-bold flex items-center gap-1.5 transition cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Вийти</span>
                </button>
              </div>
            )}
          </div>
        </div>

        {/* XP & Level Progress */}
        <div className="mt-8 pt-6 border-t border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-xs font-bold">
            <span className="text-slate-400">
              Рівень <span className="text-white">{user.level}</span>
            </span>
            <span className="text-blue-400">
              {user.xp} / {nextLevelXp} XP
            </span>
          </div>
          <div className="w-full bg-slate-800 h-3 rounded-full overflow-hidden">
            <div
              className="bg-gradient-to-r from-blue-500 via-indigo-500 to-amber-400 h-full rounded-full transition-all duration-300"
              style={{ width: `${xpPercent}%` }}
            />
          </div>
        </div>

        {/* 4 Stats Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-6">
          <div className="p-4 rounded-2xl bg-slate-800/60 border border-slate-700/60 text-center">
            <span className="text-slate-400 text-xs block mb-1">Вивчено слів</span>
            <span className="text-2xl font-black text-emerald-400">{user.learnedWords.length}</span>
          </div>
          <div className="p-4 rounded-2xl bg-slate-800/60 border border-slate-700/60 text-center">
            <span className="text-slate-400 text-xs block mb-1">Бали тренажера</span>
            <span className="text-2xl font-black text-blue-400">{user.quizScore}</span>
          </div>
          <div className="p-4 rounded-2xl bg-slate-800/60 border border-slate-700/60 text-center">
            <span className="text-slate-400 text-xs block mb-1">Серія звичок</span>
            <span className="text-2xl font-black text-amber-400">🔥 {user.dailyStreak || 1} дн.</span>
          </div>
          <div className="p-4 rounded-2xl bg-slate-800/60 border border-slate-700/60 text-center">
            <span className="text-slate-400 text-xs block mb-1">В системі SRS</span>
            <span className="text-2xl font-black text-sky-400">{user.srsCards?.length || 0} слів</span>
          </div>
        </div>
      </div>

      {/* Profile Active Track Card */}
      <div className="bg-slate-900 rounded-3xl border border-slate-800 p-6 sm:p-8 shadow-2xl space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Route className="w-5 h-5 text-indigo-400" />
            <h3 className="text-lg font-black text-white">Мій трек навчання</h3>
          </div>
          <button
            onClick={onNavigateToLevelTest}
            className="text-xs font-bold text-blue-400 hover:text-blue-300 flex items-center gap-1 transition"
          >
            <span>{curriculum ? 'Відкрити програму' : 'Пройти діагностику'}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
        <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
          {curriculum ? (
            <span>
              <strong className="text-white">{curriculum.title}:</strong> {curriculum.tagline}
            </span>
          ) : (
            'Пройдіть діагностичний тест, щоб отримати індивідуальну програму на основі вашого рівня володіння англійською.'
          )}
        </p>
      </div>

      {/* Spaced Repetition & Reminders Center Card */}
      <div className="bg-slate-900 rounded-3xl border border-slate-800 p-6 sm:p-8 shadow-2xl relative overflow-hidden space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500 to-rose-600 flex items-center justify-center text-white shadow-lg shadow-rose-500/20 shrink-0">
              <BellRing className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg sm:text-xl font-black text-white">
                  Нагадування та Інтервальне Повторення
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-rose-500/20 text-rose-400 border border-rose-500/30">
                  SRS • Еббінгауз
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Захист від кривої забування: розклад нагадувань, черга слів Leitner Box та збереження вивченого
              </p>
            </div>
          </div>

          {onOpenReminders && (
            <button
              onClick={onOpenReminders}
              className="px-5 py-2.5 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-xs shadow-lg shadow-blue-500/25 flex items-center gap-2 transition cursor-pointer self-start sm:self-auto shrink-0"
            >
              <Clock className="w-4 h-4 text-amber-300" />
              <span>Налаштувати нагадування та чергу</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
          <div className="p-3.5 rounded-2xl bg-slate-800/60 border border-slate-700/60 flex items-center gap-3">
            <Brain className="w-5 h-5 text-amber-400 shrink-0" />
            <div>
              <span className="text-[11px] text-slate-400 block font-medium">Алгоритм пам'яті</span>
              <span className="text-xs font-bold text-white">Крива Еббінгауза (1, 3, 7, 14, 30 дн.)</span>
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-800/60 border border-slate-700/60 flex items-center gap-3">
            <Repeat className="w-5 h-5 text-sky-400 shrink-0" />
            <div>
              <span className="text-[11px] text-slate-400 block font-medium">Картки Leitner Box</span>
              <span className="text-xs font-bold text-white">{user.srsCards?.length || 0} слів у циклах</span>
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-800/60 border border-slate-700/60 flex items-center gap-3">
            <BellRing className="w-5 h-5 text-rose-400 shrink-0" />
            <div>
              <span className="text-[11px] text-slate-400 block font-medium">Щоденні сповіщення</span>
              <span className="text-xs font-bold text-emerald-400">19:00 (Вечірнє закріплення)</span>
            </div>
          </div>
        </div>
      </div>

      {/* Words Vault (Скарбничка слів) */}
      <div className="bg-slate-900 rounded-3xl border border-slate-800 p-6 sm:p-8 shadow-2xl space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg sm:text-xl font-black text-white flex items-center gap-2">
              <BookmarkCheck className="w-5 h-5 text-emerald-400" />
              <span>Моя Скарбничка Слів</span>
            </h3>
            <p className="text-xs text-slate-400">Слова, які ви закріпили під час практики</p>
          </div>
          {user.learnedWords.length > 0 && (
            <button
              onClick={handleClear}
              className="text-xs text-slate-500 hover:text-red-400 font-semibold transition"
            >
              Очистити список
            </button>
          )}
        </div>

        {user.learnedWords.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {user.learnedWords.map((w) => (
              <div
                key={w.eng}
                className="p-3.5 rounded-2xl bg-slate-800/80 border border-slate-700/80 flex items-center justify-between"
              >
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold text-slate-200">{w.ukr}</span>
                    <span className="text-[10px] text-slate-500">➔</span>
                    <span className="text-xs font-black text-emerald-400">{w.eng}</span>
                  </div>
                  <span className="text-[10px] text-slate-400 font-mono">
                    {w.ipa || ''} • {w.rule || ''}
                  </span>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => handleSpeak(w.eng)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-white transition"
                  >
                    <Volume2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleRemove(w)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 transition"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8 text-slate-500 space-y-2">
            <Sparkles className="w-8 h-8 mx-auto text-slate-600" />
            <p className="text-xs sm:text-sm">
              Поки немає вивчених слів. Проходьте тренажер чи картки, щоб поповнювати скарбничку!
            </p>
          </div>
        )}
      </div>
    </section>
  );
};
