import React, { useState, useEffect } from 'react';
import {
  Bell,
  BellRing,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Flame,
  Volume2,
  Sparkles,
  RotateCcw,
  X,
  Play,
  ArrowRight,
  Settings2,
  BookOpen,
  Brain,
  ShieldCheck,
  Calendar,
  Layers,
  ChevronRight,
  TrendingDown,
  Info,
} from 'lucide-react';
import {
  ReminderSettings,
  TopicRetentionStatus,
  TopicReviewRecord,
  SrsCard,
  MistakeRecord,
  VocabItem,
  ThematicCategoryInfo,
  ThematicWord,
  CefrLevel,
} from '../types';
import {
  loadReminderSettings,
  saveReminderSettings,
  loadTopicReviews,
  saveTopicReviews,
  recordTopicReview,
  computeTopicRetentionStatuses,
  getDueReviewWords,
  DueWordItem,
  requestNotificationPermission,
  sendBrowserNotification,
  DEFAULT_REMINDER_SETTINGS,
} from '../utils/reminderEngine';
import { THEMATIC_CATEGORIES, THEMATIC_WORDS, getWordsByCategory } from '../data/thematicWords';
import { speakEnglish, playSound } from '../utils/audio';

interface ReviewRemindersModalProps {
  isOpen: boolean;
  onClose: () => void;
  learnedWords: VocabItem[];
  srsCards: SrsCard[];
  mistakes: MistakeRecord[];
  onUpdateSrsCards?: (cards: SrsCard[]) => void;
  onRewardXP: (amount: number) => void;
  onToast: (msg: string, type: 'info' | 'success' | 'error') => void;
  onNavigateToTopic?: (categoryId: string, packNumber?: number) => void;
}

type ModalTab = 'topics' | 'words' | 'settings' | 'science';

interface ExpressQuestion {
  word: VocabItem;
  prompt: string;
  correctAnswer: string;
  options: string[];
  contextExample?: string;
  categoryTitle?: string;
}

export const ReviewRemindersModal: React.FC<ReviewRemindersModalProps> = ({
  isOpen,
  onClose,
  learnedWords,
  srsCards,
  mistakes,
  onUpdateSrsCards,
  onRewardXP,
  onToast,
  onNavigateToTopic,
}) => {
  const [activeTab, setActiveTab] = useState<ModalTab>('topics');
  const [settings, setSettings] = useState<ReminderSettings>(loadReminderSettings);
  const [topicRecords, setTopicRecords] = useState<Record<string, TopicReviewRecord>>(loadTopicReviews);

  // Unlocked packs from storage
  const [unlockedPacks, setUnlockedPacks] = useState<Record<string, number>>(() => {
    try {
      const saved = localStorage.getItem('unlocked_thematic_packs_v1');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  // Express Review session state
  const [isReviewing, setIsReviewing] = useState(false);
  const [reviewQuestions, setReviewQuestions] = useState<ExpressQuestion[]>([]);
  const [currentQIndex, setCurrentQIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [isAnswerChecked, setIsAnswerChecked] = useState(false);
  const [reviewScore, setReviewScore] = useState(0);
  const [reviewCompleted, setReviewCompleted] = useState(false);
  const [activeReviewCategory, setActiveReviewCategory] = useState<string | null>(null);

  // Compute live statuses
  const topicStatuses = computeTopicRetentionStatuses(
    THEMATIC_CATEGORIES,
    learnedWords,
    topicRecords,
    unlockedPacks
  );

  const dueWords = getDueReviewWords(srsCards, mistakes, learnedWords);

  // Critical / decaying topics count
  const criticalTopicsCount = topicStatuses.filter(
    (t) => t.urgency === 'critical' || t.urgency === 'high'
  ).length;

  const averageRetention =
    topicStatuses.length > 0
      ? Math.round(
          topicStatuses.reduce((acc, t) => acc + t.retentionPercent, 0) / topicStatuses.length
        )
      : 100;

  // Save settings helper
  const updateSettings = (partial: Partial<ReminderSettings>) => {
    const updated = { ...settings, ...partial };
    setSettings(updated);
    saveReminderSettings(updated);
  };

  // Toggle browser push notification permission
  const handleToggleBrowserNotifications = async () => {
    if (!settings.browserNotificationsEnabled) {
      const permission = await requestNotificationPermission();
      if (permission === 'granted') {
        updateSettings({ browserNotificationsEnabled: true });
        playSound('correct');
        onToast('Сповіщення у браузері успішно активовано!', 'success');
        sendBrowserNotification(
          'EngBridge UA 🇺🇦',
          'Сповіщення налаштовано! Ми нагадуватимемо про теми та слова для повторення.'
        );
      } else {
        updateSettings({ browserNotificationsEnabled: false });
        onToast('Браузер відхилив доступ до сповіщень. Перевірте налаштування сайту.', 'error');
      }
    } else {
      updateSettings({ browserNotificationsEnabled: false });
      onToast('Сповіщення у браузері вимкнено', 'info');
    }
  };

  // Send a test notification
  const handleSendTestNotification = () => {
    playSound('combo');
    if ('Notification' in window && Notification.permission === 'granted') {
      sendBrowserNotification(
        '🔔 Час повторити англійські слова!',
        `У вас є ${criticalTopicsCount} тем та ${dueWords.length} слів, які втрачають міцність у пам'яті.`
      );
      onToast('Тестове сповіщення надіслано на екран вашого пристрою!', 'success');
    } else {
      onToast(
        `Тестове нагадування: У вас ${criticalTopicsCount} тем і ${dueWords.length} слів у черзі повторення!`,
        'info'
      );
    }
  };

  // Start Express Review Session for a specific category or all due words
  const handleStartExpressReview = (categoryId?: string) => {
    playSound('click');
    let targetWords: VocabItem[] = [];
    let catTitle = 'Змішане повторення';

    if (categoryId) {
      const cat = THEMATIC_CATEGORIES.find((c) => c.id === categoryId);
      catTitle = cat ? cat.title : categoryId;
      const allCat = getWordsByCategory(categoryId);
      // prioritize words user has learned or first 10
      const learnedInCat = allCat.filter((w) =>
        learnedWords.some((lw) => lw.eng.toLowerCase() === w.eng.toLowerCase())
      );
      targetWords = learnedInCat.length >= 4 ? learnedInCat.slice(0, 10) : allCat.slice(0, 10);
      setActiveReviewCategory(categoryId);
    } else {
      targetWords = dueWords.slice(0, 10).map((d) => d.word);
      setActiveReviewCategory(null);
    }

    if (targetWords.length === 0) {
      targetWords = THEMATIC_WORDS.slice(0, 8);
    }

    // Build question list
    const questions: ExpressQuestion[] = targetWords.map((word) => {
      // Find 3 distractors
      const distractors = THEMATIC_WORDS.filter(
        (w) => w.eng.toLowerCase() !== word.eng.toLowerCase()
      )
        .sort(() => Math.random() - 0.5)
        .slice(0, 3)
        .map((w) => w.eng);

      const options = [word.eng, ...distractors].sort(() => Math.random() - 0.5);

      return {
        word,
        prompt: `Як перекладається: «${word.ukr}»?`,
        correctAnswer: word.eng,
        options,
        contextExample: word.exampleEn,
        categoryTitle: catTitle,
      };
    });

    setReviewQuestions(questions);
    setCurrentQIndex(0);
    setSelectedOption(null);
    setIsAnswerChecked(false);
    setReviewScore(0);
    setReviewCompleted(false);
    setIsReviewing(true);
  };

  // Handle answering in Express Review
  const handleSelectAnswer = (option: string) => {
    if (isAnswerChecked) return;
    setSelectedOption(option);
    setIsAnswerChecked(true);

    const currentQ = reviewQuestions[currentQIndex];
    const isCorrect = option.toLowerCase().trim() === currentQ.correctAnswer.toLowerCase().trim();

    if (isCorrect) {
      playSound('correct');
      setReviewScore((s) => s + 1);
    } else {
      playSound('wrong');
    }
  };

  // Advance question in Express Review
  const handleNextReviewQuestion = () => {
    if (currentQIndex + 1 < reviewQuestions.length) {
      setCurrentQIndex((i) => i + 1);
      setSelectedOption(null);
      setIsAnswerChecked(false);
    } else {
      // Finished review!
      playSound('combo');
      setReviewCompleted(true);
      onRewardXP(25);

      // Record review timestamp
      if (activeReviewCategory) {
        const updatedRecords = recordTopicReview(activeReviewCategory);
        setTopicRecords(updatedRecords);
      } else {
        // Record all touched categories
        const touchedCats = new Set(
          reviewQuestions.map((q) => q.word.category).filter(Boolean) as string[]
        );
        let updated = { ...topicRecords };
        touchedCats.forEach((catId) => {
          updated = recordTopicReview(catId);
        });
        setTopicRecords(updated);
      }

      onToast('🎉 Сесію повторення завершено! Пам’ять закріплено на 100%! (+25 XP)', 'success');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700/80 rounded-3xl max-w-4xl w-full max-h-[92vh] flex flex-col shadow-2xl shadow-black/80 overflow-hidden">
        {/* Modal Header */}
        <div className="px-5 sm:px-8 py-5 border-b border-slate-800 bg-slate-900/90 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-amber-500 via-rose-500 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-rose-500/25">
              <BellRing className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg sm:text-xl font-black text-white">
                  Центр нагадувань та повторення
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-rose-500/20 text-rose-400 border border-rose-500/30">
                  SRS • Еббінгауз
                </span>
              </div>
              <p className="text-xs text-slate-400 font-medium">
                Регулярні повторення закріплюють 80%+ знань у довготривалу пам’ять
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-9 h-9 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition cursor-pointer"
            title="Закрити"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-8 space-y-6">
          {isReviewing ? (
            /* ================= EXPRESS REVIEW RUNNER ================= */
            <div className="max-w-2xl mx-auto space-y-6 py-4">
              {!reviewCompleted ? (
                <>
                  <div className="flex items-center justify-between">
                    <span className="px-3 py-1 rounded-xl bg-blue-500/20 text-blue-400 border border-blue-500/30 text-xs font-bold">
                      {reviewQuestions[currentQIndex]?.categoryTitle || 'Експрес-повторення'}
                    </span>
                    <span className="text-xs font-bold text-slate-400">
                      Питання {currentQIndex + 1} з {reviewQuestions.length}
                    </span>
                  </div>

                  {/* Progress Bar */}
                  <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-blue-500 to-emerald-400 transition-all duration-300"
                      style={{
                        width: `${((currentQIndex + 1) / reviewQuestions.length) * 100}%`,
                      }}
                    />
                  </div>

                  {/* Question Card */}
                  <div className="p-6 bg-slate-800/80 rounded-3xl border border-slate-700 space-y-4 text-center">
                    <p className="text-xs font-bold uppercase tracking-wider text-slate-400">
                      Переклад на англійську:
                    </p>
                    <h4 className="text-2xl sm:text-3xl font-black text-white">
                      {reviewQuestions[currentQIndex]?.word.ukr}
                    </h4>

                    {reviewQuestions[currentQIndex]?.contextExample && (
                      <p className="text-xs text-slate-400 italic bg-slate-900/60 p-3 rounded-xl border border-slate-700/50">
                        «{reviewQuestions[currentQIndex]?.contextExample}»
                      </p>
                    )}

                    <button
                      onClick={() => speakEnglish(reviewQuestions[currentQIndex]?.word.eng)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-700 hover:bg-slate-600 text-slate-200 text-xs font-semibold transition cursor-pointer"
                    >
                      <Volume2 className="w-3.5 h-3.5 text-blue-400" />
                      <span>Озвучити англійською</span>
                    </button>
                  </div>

                  {/* Options */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {reviewQuestions[currentQIndex]?.options.map((opt) => {
                      const isSelected = selectedOption === opt;
                      const isCorrect =
                        opt.toLowerCase().trim() ===
                        reviewQuestions[currentQIndex]?.correctAnswer.toLowerCase().trim();

                      let btnStyle =
                        'bg-slate-800/90 border-slate-700 text-slate-200 hover:border-blue-500 hover:bg-slate-750';
                      if (isAnswerChecked) {
                        if (isCorrect) {
                          btnStyle =
                            'bg-emerald-500/20 border-emerald-500 text-emerald-300 shadow-md shadow-emerald-500/20';
                        } else if (isSelected) {
                          btnStyle = 'bg-rose-500/20 border-rose-500 text-rose-300';
                        } else {
                          btnStyle = 'bg-slate-800/40 border-slate-800 text-slate-500';
                        }
                      }

                      return (
                        <button
                          key={opt}
                          disabled={isAnswerChecked}
                          onClick={() => handleSelectAnswer(opt)}
                          className={`p-4 rounded-2xl border text-left font-bold text-sm transition-all duration-200 flex items-center justify-between cursor-pointer ${btnStyle}`}
                        >
                          <span>{opt}</span>
                          {isAnswerChecked && isCorrect && (
                            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                          )}
                        </button>
                      );
                    })}
                  </div>

                  {/* Next Button */}
                  {isAnswerChecked && (
                    <div className="flex justify-end pt-2">
                      <button
                        onClick={handleNextReviewQuestion}
                        className="px-6 py-3 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm shadow-lg shadow-blue-500/30 flex items-center gap-2 transition cursor-pointer"
                      >
                        <span>
                          {currentQIndex + 1 === reviewQuestions.length
                            ? 'Завершити повторення'
                            : 'Наступне слово'}
                        </span>
                        <ArrowRight className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                </>
              ) : (
                /* Celebration Completion */
                <div className="text-center py-8 space-y-5 bg-slate-800/40 border border-slate-700/60 p-8 rounded-3xl">
                  <div className="w-16 h-16 mx-auto rounded-3xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
                    <Sparkles className="w-8 h-8" />
                  </div>

                  <h3 className="text-2xl font-black text-white">
                    Чудово повторено! Пам’ять оновлена!
                  </h3>
                  <p className="text-sm text-slate-300 max-w-md mx-auto">
                    Ви успішно відповіли на {reviewScore} з {reviewQuestions.length} слів. Згідно з
                    кривою Еббінгауза, наступне повторення знадобиться лише через кілька днів.
                  </p>

                  <div className="flex items-center justify-center gap-4 py-2">
                    <div className="bg-slate-800 px-4 py-2.5 rounded-2xl border border-slate-700 text-center">
                      <span className="text-xs text-slate-400 block font-medium">Результат</span>
                      <span className="text-xl font-black text-emerald-400">
                        {Math.round((reviewScore / reviewQuestions.length) * 100)}%
                      </span>
                    </div>
                    <div className="bg-slate-800 px-4 py-2.5 rounded-2xl border border-slate-700 text-center">
                      <span className="text-xs text-slate-400 block font-medium">Нагорода</span>
                      <span className="text-xl font-black text-amber-400">+25 XP</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-center gap-3 pt-3">
                    <button
                      onClick={() => setIsReviewing(false)}
                      className="px-6 py-2.5 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm shadow-md transition cursor-pointer"
                    >
                      Повернутися до списку тем
                    </button>
                    <button
                      onClick={() => handleStartExpressReview(activeReviewCategory || undefined)}
                      className="px-5 py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-sm border border-slate-700 transition cursor-pointer flex items-center gap-2"
                    >
                      <RotateCcw className="w-4 h-4" />
                      <span>Повторити ще раз</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <>
              {/* Top Metrics Cards */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
                <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 space-y-1">
                  <div className="flex items-center justify-between text-rose-400">
                    <span className="text-xs font-bold">Потребують уваги</span>
                    <AlertTriangle className="w-4 h-4" />
                  </div>
                  <div className="text-2xl font-black text-white">
                    {criticalTopicsCount}{' '}
                    <span className="text-xs font-semibold text-rose-400">тем</span>
                  </div>
                  <p className="text-[11px] text-slate-400">Критично освіжити знання</p>
                </div>

                <div className="p-4 rounded-2xl bg-blue-500/10 border border-blue-500/20 space-y-1">
                  <div className="flex items-center justify-between text-blue-400">
                    <span className="text-xs font-bold">Слова в черзі SRS</span>
                    <Layers className="w-4 h-4" />
                  </div>
                  <div className="text-2xl font-black text-white">
                    {dueWords.length}{' '}
                    <span className="text-xs font-semibold text-blue-400">слів</span>
                  </div>
                  <p className="text-[11px] text-slate-400">Термін інтервалу настав</p>
                </div>

                <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/20 space-y-1">
                  <div className="flex items-center justify-between text-amber-400">
                    <span className="text-xs font-bold">Середня пам’ять</span>
                    <Brain className="w-4 h-4" />
                  </div>
                  <div className="text-2xl font-black text-white">{averageRetention}%</div>
                  <p className="text-[11px] text-slate-400">За кривою Еббінгауза</p>
                </div>

                <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 space-y-1">
                  <div className="flex items-center justify-between text-emerald-400">
                    <span className="text-xs font-bold">Нагадування</span>
                    <Clock className="w-4 h-4" />
                  </div>
                  <div className="text-xl font-black text-white">
                    {settings.enabled ? settings.reminderTime : 'Вимкнено'}
                  </div>
                  <p className="text-[11px] text-slate-400">
                    {settings.frequency === 'daily'
                      ? 'Щоденний розклад'
                      : settings.frequency === 'weekdays'
                      ? 'По буднях'
                      : 'Через день'}
                  </p>
                </div>
              </div>

              {/* Navigation Tabs */}
              <div className="flex items-center gap-2 border-b border-slate-800 pb-2 overflow-x-auto text-xs font-bold">
                <button
                  onClick={() => setActiveTab('topics')}
                  className={`px-4 py-2 rounded-xl transition flex items-center gap-2 whitespace-nowrap cursor-pointer ${
                    activeTab === 'topics'
                      ? 'bg-blue-600 text-white shadow'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800'
                  }`}
                >
                  <BookOpen className="w-4 h-4" />
                  <span>Теми для повторення ({topicStatuses.length})</span>
                  {criticalTopicsCount > 0 && (
                    <span className="px-1.5 py-0.2 rounded-full bg-rose-500 text-white text-[10px]">
                      {criticalTopicsCount}
                    </span>
                  )}
                </button>

                <button
                  onClick={() => setActiveTab('words')}
                  className={`px-4 py-2 rounded-xl transition flex items-center gap-2 whitespace-nowrap cursor-pointer ${
                    activeTab === 'words'
                      ? 'bg-blue-600 text-white shadow'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800'
                  }`}
                >
                  <Layers className="w-4 h-4" />
                  <span>Слова у черзі ({dueWords.length})</span>
                </button>

                <button
                  onClick={() => setActiveTab('settings')}
                  className={`px-4 py-2 rounded-xl transition flex items-center gap-2 whitespace-nowrap cursor-pointer ${
                    activeTab === 'settings'
                      ? 'bg-blue-600 text-white shadow'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800'
                  }`}
                >
                  <Settings2 className="w-4 h-4" />
                  <span>Налаштування нагадувань</span>
                </button>

                <button
                  onClick={() => setActiveTab('science')}
                  className={`px-4 py-2 rounded-xl transition flex items-center gap-2 whitespace-nowrap cursor-pointer ${
                    activeTab === 'science'
                      ? 'bg-blue-600 text-white shadow'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800'
                  }`}
                >
                  <Brain className="w-4 h-4 text-amber-400" />
                  <span>Наука повторення</span>
                </button>
              </div>

              {/* TAB 1: TOPICS RETENTION */}
              {activeTab === 'topics' && (
                <div className="space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-800/40 p-4 rounded-2xl border border-slate-800">
                    <div>
                      <h4 className="text-sm font-bold text-white">
                        Стан збереження тем у пам’яті
                      </h4>
                      <p className="text-xs text-slate-400">
                        Теми сортуються від найбільш критичних до свіжо закріплених.
                      </p>
                    </div>

                    <button
                      onClick={() => handleStartExpressReview()}
                      className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-xs shadow-md shadow-blue-500/20 flex items-center gap-2 shrink-0 cursor-pointer"
                    >
                      <Sparkles className="w-4 h-4 text-amber-300" />
                      <span>Експрес-повторення всіх тем (10 слів)</span>
                    </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {topicStatuses.map((topic) => {
                      const isCritical = topic.urgency === 'critical';
                      const isHigh = topic.urgency === 'high';
                      const isMedium = topic.urgency === 'medium';

                      let badgeColor = 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30';
                      let barColor = 'bg-emerald-500';

                      if (isCritical) {
                        badgeColor = 'bg-rose-500/20 text-rose-300 border-rose-500/30 animate-pulse';
                        barColor = 'bg-rose-500';
                      } else if (isHigh) {
                        badgeColor = 'bg-amber-500/20 text-amber-300 border-amber-500/30';
                        barColor = 'bg-amber-500';
                      } else if (isMedium) {
                        badgeColor = 'bg-sky-500/20 text-sky-300 border-sky-500/30';
                        barColor = 'bg-sky-500';
                      }

                      return (
                        <div
                          key={topic.categoryId}
                          className="p-4 rounded-2xl bg-slate-800/70 border border-slate-700/80 hover:border-slate-600 transition flex flex-col justify-between gap-3 group"
                        >
                          <div className="space-y-2">
                            <div className="flex items-center justify-between gap-2">
                              <div className="flex items-center gap-2.5">
                                <span className="text-2xl">{topic.icon}</span>
                                <div>
                                  <h5 className="text-sm font-black text-white group-hover:text-blue-400 transition">
                                    {topic.title}
                                  </h5>
                                  <span className="text-[11px] text-slate-400 font-medium">
                                    {topic.engTitle} • {topic.totalWordsLearned} вивчено
                                  </span>
                                </div>
                              </div>

                              <span
                                className={`px-2 py-0.5 rounded-lg text-[10px] font-black uppercase tracking-wider border ${badgeColor}`}
                              >
                                {topic.statusLabel}
                              </span>
                            </div>

                            {/* Retention Gauge */}
                            <div className="space-y-1">
                              <div className="flex items-center justify-between text-[11px] font-bold">
                                <span className="text-slate-400">Міцність у пам’яті:</span>
                                <span
                                  className={
                                    isCritical
                                      ? 'text-rose-400'
                                      : isHigh
                                      ? 'text-amber-400'
                                      : 'text-emerald-400'
                                  }
                                >
                                  {topic.retentionPercent}%
                                </span>
                              </div>
                              <div className="w-full h-2 bg-slate-900 rounded-full overflow-hidden">
                                <div
                                  className={`h-full ${barColor} transition-all duration-300`}
                                  style={{ width: `${topic.retentionPercent}%` }}
                                />
                              </div>
                            </div>
                          </div>

                          {/* Action Buttons */}
                          <div className="flex items-center gap-2 pt-1">
                            <button
                              onClick={() => handleStartExpressReview(topic.categoryId)}
                              className="flex-1 py-2 px-3 rounded-xl bg-blue-600/20 hover:bg-blue-600 text-blue-300 hover:text-white border border-blue-500/30 text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer"
                            >
                              <Play className="w-3.5 h-3.5" />
                              <span>Повторити зараз</span>
                            </button>

                            {onNavigateToTopic && (
                              <button
                                onClick={() => {
                                  onClose();
                                  onNavigateToTopic(topic.categoryId, topic.recommendedPack);
                                }}
                                className="py-2 px-3 rounded-xl bg-slate-700/60 hover:bg-slate-700 text-slate-300 text-xs font-semibold border border-slate-600 transition flex items-center gap-1 cursor-pointer"
                                title="Перейти до повного каталогу теми"
                              >
                                <span>Блок {topic.recommendedPack}</span>
                                <ChevronRight className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* TAB 2: DUE WORDS (SRS) */}
              {activeTab === 'words' && (
                <div className="space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-800/40 p-4 rounded-2xl border border-slate-800">
                    <div>
                      <h4 className="text-sm font-bold text-white">
                        Слова для інтервального повторення
                      </h4>
                      <p className="text-xs text-slate-400">
                        Складено на основі карток Leitner Box та невідпрацьованих помилок.
                      </p>
                    </div>

                    <button
                      onClick={() => handleStartExpressReview()}
                      disabled={dueWords.length === 0}
                      className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-bold text-xs shadow-md flex items-center gap-2 cursor-pointer"
                    >
                      <Play className="w-4 h-4" />
                      <span>Почати експрес-тест ({Math.min(10, dueWords.length)} слів)</span>
                    </button>
                  </div>

                  {dueWords.length === 0 ? (
                    <div className="text-center py-12 space-y-3 bg-slate-800/20 rounded-2xl border border-slate-800">
                      <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto" />
                      <h5 className="text-base font-bold text-white">Черга повторення порожня!</h5>
                      <p className="text-xs text-slate-400 max-w-sm mx-auto">
                        Ви засвоїли всі активні слова. Нові слова додадуться автоматично після тестів
                        або спливання інтервалу.
                      </p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[420px] overflow-y-auto pr-1">
                      {dueWords.map((item, idx) => (
                        <div
                          key={`${item.word.eng}_${idx}`}
                          className="p-3.5 rounded-2xl bg-slate-800/70 border border-slate-700/80 flex items-center justify-between gap-3 hover:border-slate-600 transition"
                        >
                          <div className="space-y-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-black text-white truncate">
                                {item.word.eng}
                              </span>
                              <button
                                onClick={() => speakEnglish(item.word.eng)}
                                className="text-slate-400 hover:text-blue-400 transition"
                                title="Озвучити"
                              >
                                <Volume2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                            <p className="text-xs text-slate-300 font-medium truncate">
                              {item.word.ukr}
                            </p>
                            <span className="text-[10px] text-slate-400 block font-medium">
                              {item.reason}
                            </span>
                          </div>

                          <span
                            className={`px-2 py-0.5 rounded-md text-[9px] font-black uppercase shrink-0 ${
                              item.source === 'mistake'
                                ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                                : 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                            }`}
                          >
                            {item.source === 'mistake' ? 'Помилка' : 'SRS Card'}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* TAB 3: REMINDER SETTINGS */}
              {activeTab === 'settings' && (
                <div className="space-y-6 max-w-2xl mx-auto py-2">
                  {/* Master Switch */}
                  <div className="flex items-center justify-between p-4 rounded-2xl bg-slate-800/80 border border-slate-700">
                    <div className="space-y-0.5">
                      <h4 className="text-sm font-bold text-white">Увімкнути систему нагадувань</h4>
                      <p className="text-xs text-slate-400">
                        Отримувати регулярні сповіщення про теми й слова для закріплення
                      </p>
                    </div>

                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={settings.enabled}
                        onChange={(e) => updateSettings({ enabled: e.target.checked })}
                        className="sr-only peer"
                      />
                      <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                    </label>
                  </div>

                  {/* Browser Push Notifications */}
                  <div className="flex items-center justify-between p-4 rounded-2xl bg-slate-800/80 border border-slate-700">
                    <div className="space-y-0.5">
                      <h4 className="text-sm font-bold text-white flex items-center gap-2">
                        <span>Сповіщення браузера (Push)</span>
                        {settings.browserNotificationsEnabled ? (
                          <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-md border border-emerald-500/20">
                            Активовано
                          </span>
                        ) : (
                          <span className="text-[10px] text-slate-400 bg-slate-700 px-2 py-0.5 rounded-md">
                            Вимкнено
                          </span>
                        )}
                      </h4>
                      <p className="text-xs text-slate-400">
                        Показувати сповіщення на екрані пристрою навіть якщо вкладка у фоні
                      </p>
                    </div>

                    <button
                      onClick={handleToggleBrowserNotifications}
                      className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
                        settings.browserNotificationsEnabled
                          ? 'bg-rose-500/20 text-rose-300 hover:bg-rose-500/30 border border-rose-500/40'
                          : 'bg-blue-600 hover:bg-blue-500 text-white shadow-md'
                      }`}
                    >
                      {settings.browserNotificationsEnabled ? 'Вимкнути' : 'Увімкнути сповіщення'}
                    </button>
                  </div>

                  {/* Time Picker & Presets */}
                  <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700 space-y-3">
                    <h4 className="text-sm font-bold text-white">Час щоденного нагадування</h4>
                    <p className="text-xs text-slate-400">
                      Оберіть найзручніший час, коли вам комфортно приділити 5 хвилин повторенню:
                    </p>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {[
                        { time: '09:00', label: 'Ранок ☀️' },
                        { time: '14:00', label: 'Обід ☕' },
                        { time: '19:00', label: 'Вечір 🌆' },
                        { time: '21:30', label: 'Перед сном 🌙' },
                      ].map((preset) => (
                        <button
                          key={preset.time}
                          onClick={() => updateSettings({ reminderTime: preset.time })}
                          className={`p-2.5 rounded-xl border text-xs font-bold transition text-center cursor-pointer ${
                            settings.reminderTime === preset.time
                              ? 'bg-blue-600 border-blue-500 text-white shadow'
                              : 'bg-slate-900/60 border-slate-750 text-slate-300 hover:border-slate-600'
                          }`}
                        >
                          <span className="block text-sm font-black">{preset.time}</span>
                          <span className="text-[10px] opacity-80">{preset.label}</span>
                        </button>
                      ))}
                    </div>

                    <div className="pt-2 flex items-center gap-3">
                      <span className="text-xs font-bold text-slate-300">Власний час:</span>
                      <input
                        type="time"
                        value={settings.reminderTime}
                        onChange={(e) => updateSettings({ reminderTime: e.target.value })}
                        className="bg-slate-900 border border-slate-700 text-white text-xs font-bold rounded-xl px-3 py-1.5 focus:border-blue-500 focus:outline-none"
                      />
                    </div>
                  </div>

                  {/* Frequency */}
                  <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700 space-y-3">
                    <h4 className="text-sm font-bold text-white">Періодичність нагадувань</h4>
                    <div className="grid grid-cols-3 gap-2">
                      {[
                        { id: 'daily', label: 'Щодня' },
                        { id: 'every_other_day', label: 'Через день' },
                        { id: 'weekdays', label: 'По буднях (Пн-Пт)' },
                      ].map((freq) => (
                        <button
                          key={freq.id}
                          onClick={() => updateSettings({ frequency: freq.id as any })}
                          className={`p-2.5 rounded-xl border text-xs font-bold transition text-center cursor-pointer ${
                            settings.frequency === freq.id
                              ? 'bg-blue-600 border-blue-500 text-white shadow'
                              : 'bg-slate-900/60 border-slate-750 text-slate-300 hover:border-slate-600'
                          }`}
                        >
                          {freq.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Triggers Checklist */}
                  <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700 space-y-3">
                    <h4 className="text-sm font-bold text-white">Про що нагадувати</h4>
                    <div className="space-y-2 text-xs">
                      <label className="flex items-center gap-3 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={settings.remindTopicsDecaying}
                          onChange={(e) =>
                            updateSettings({ remindTopicsDecaying: e.target.checked })
                          }
                          className="w-4 h-4 rounded text-blue-600 bg-slate-900 border-slate-700"
                        />
                        <span className="text-slate-300">
                          Теми слів, що підзабуваються за кривою Еббінгауза (&gt;3 днів без практики)
                        </span>
                      </label>

                      <label className="flex items-center gap-3 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={settings.remindSrsWords}
                          onChange={(e) => updateSettings({ remindSrsWords: e.target.checked })}
                          className="w-4 h-4 rounded text-blue-600 bg-slate-900 border-slate-700"
                        />
                        <span className="text-slate-300">
                          Слова з інтервального повторення (Leitner Box), термін яких настав
                        </span>
                      </label>

                      <label className="flex items-center gap-3 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={settings.remindMistakes}
                          onChange={(e) => updateSettings({ remindMistakes: e.target.checked })}
                          className="w-4 h-4 rounded text-blue-600 bg-slate-900 border-slate-700"
                        />
                        <span className="text-slate-300">
                          Невідпрацьовані помилки з тестів та спринтів
                        </span>
                      </label>
                    </div>
                  </div>

                  {/* Test Notification Button */}
                  <div className="flex items-center justify-between pt-2">
                    <button
                      onClick={handleSendTestNotification}
                      className="px-5 py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 flex items-center gap-2 transition cursor-pointer"
                    >
                      <BellRing className="w-4 h-4 text-amber-400" />
                      <span>Надіслати тестове сповіщення зараз</span>
                    </button>

                    <button
                      onClick={() => {
                        saveReminderSettings(settings);
                        playSound('correct');
                        onToast('Налаштування нагадувань збережено!', 'success');
                      }}
                      className="px-6 py-2.5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-md transition cursor-pointer"
                    >
                      Зберегти налаштування
                    </button>
                  </div>
                </div>
              )}

              {/* TAB 4: EBBINGHAUS SCIENCE */}
              {activeTab === 'science' && (
                <div className="space-y-6 max-w-2xl mx-auto py-2">
                  <div className="p-6 rounded-3xl bg-slate-800/80 border border-slate-700 space-y-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-black">
                        🧠
                      </div>
                      <div>
                        <h4 className="text-base font-black text-white">
                          Крива забування Германа Еббінгауза
                        </h4>
                        <p className="text-xs text-slate-400">
                          Науковий фундамент інтервальних нагадувань у EngBridge
                        </p>
                      </div>
                    </div>

                    <p className="text-xs text-slate-300 leading-relaxed">
                      У 1885 році психолог Герман Еббінгауз довів, що людський мозок втрачає{' '}
                      <strong className="text-rose-400 font-bold">понад 50%</strong> нової
                      інформації вже протягом перших 24 годин, якщо її не освіжити.
                    </p>

                    {/* Timeline Infographic */}
                    <div className="space-y-3 pt-2">
                      {[
                        {
                          day: 'Одразу після уроку',
                          retention: '100%',
                          bar: 'w-full bg-emerald-500',
                          desc: 'Інформація у свіжій оперативній пам’яті',
                        },
                        {
                          day: 'День 1 (без повторення)',
                          retention: '~58%',
                          bar: 'w-[58%] bg-amber-500',
                          desc: 'Початок стрімкого забування',
                        },
                        {
                          day: 'День 1 (після 1-го нагадування)',
                          retention: '100% ↗',
                          bar: 'w-full bg-emerald-500',
                          desc: 'Пам’ять відновлена, крива стає більш пологою',
                        },
                        {
                          day: 'День 3 (після 2-го нагадування)',
                          retention: '90%',
                          bar: 'w-[90%] bg-blue-500',
                          desc: 'Формуються стійкі нейронні зв’язки',
                        },
                        {
                          day: 'День 7 (після 3-го нагадування)',
                          retention: '85%',
                          bar: 'w-[85%] bg-indigo-500',
                          desc: 'Перехід слова у довготривалий активний словник',
                        },
                      ].map((item, i) => (
                        <div key={i} className="p-3 bg-slate-900/60 rounded-xl space-y-1">
                          <div className="flex items-center justify-between text-xs font-bold">
                            <span className="text-slate-200">{item.day}</span>
                            <span className="text-blue-400">{item.retention}</span>
                          </div>
                          <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                            <div className={`h-full ${item.bar}`} />
                          </div>
                          <p className="text-[11px] text-slate-400">{item.desc}</p>
                        </div>
                      ))}
                    </div>

                    <div className="p-4 rounded-2xl bg-blue-500/10 border border-blue-500/20 text-xs text-blue-300">
                      💡 <strong>Висновок:</strong> Коротке 3-хвилинне повторення за нагадуванням
                      заощаджує години повторного перечитування та гарантує легке вживання слів у
                      розмові.
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-5 sm:px-8 py-4 border-t border-slate-800 bg-slate-900/90 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>Інтервальні алгоритми Leitner Box & Ebbinghaus Curve</span>
          </div>

          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition cursor-pointer"
          >
            Закрити
          </button>
        </div>
      </div>
    </div>
  );
};
