import React, { useState } from 'react';
import { X, UserCheck, LogIn, ArrowLeft, Check, CheckCircle2, Loader2, Sparkles, LogOut } from 'lucide-react';
import { playSound } from '../utils/audio';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLogin: (data: { displayName: string; email: string }) => void;
  onToast: (msg: string, type: 'info' | 'success' | 'error') => void;
  currentUserEmail?: string;
  isLoggedIn?: boolean;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onLogin,
  onToast,
  currentUserEmail,
  isLoggedIn = false,
}) => {
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [isGoogleLoading, setIsGoogleLoading] = useState(false);
  const [showCustomGoogleInput, setShowCustomGoogleInput] = useState(false);
  const [customGoogleEmail, setCustomGoogleEmail] = useState('');

  if (!isOpen) return null;

  // Primary active Google account from environment
  const primaryGoogleAccount = {
    email: 'srgbltmnit@gmail.com',
    name: 'Сергій',
    fullName: 'Сергій (srgbltmnit@gmail.com)',
    initials: 'СГ',
  };

  const handleCustomLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !email.includes('@')) {
      onToast('Будь ласка, введіть коректну електронну пошту', 'error');
      return;
    }
    playSound('correct');
    const finalName = name.trim() || email.split('@')[0];
    onLogin({ displayName: finalName, email: email.trim() });
    onClose();
  };

  const executeGoogleLogin = (accEmail: string, accName: string) => {
    setIsGoogleLoading(true);
    playSound('click');

    setTimeout(() => {
      playSound('combo');
      setIsGoogleLoading(false);
      onLogin({ displayName: accName, email: accEmail });
      onToast(`Вхід через Google успішний! Вітаємо, ${accName}! (+50 XP)`, 'success');
      onClose();
    }, 350);
  };

  const handleCustomGoogleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customGoogleEmail.trim() || !customGoogleEmail.includes('@')) {
      onToast('Введіть коректну адресу пошти Google (наприклад, user@gmail.com)', 'error');
      return;
    }
    const cleanEmail = customGoogleEmail.trim();
    const inferred = cleanEmail.split('@')[0];
    const capitalized = inferred.charAt(0).toUpperCase() + inferred.slice(1);
    executeGoogleLogin(cleanEmail, capitalized);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-900 rounded-3xl border border-slate-800 max-w-md w-full p-6 sm:p-8 shadow-2xl relative animate-fadeIn">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:bg-slate-800 hover:text-white transition cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="text-center mb-6">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-white mx-auto mb-3 shadow-lg shadow-blue-500/20">
            <UserCheck className="w-7 h-7 text-amber-300" />
          </div>
          <h3 className="text-xl font-black text-white">Вхід до EngBridge UA</h3>
          <p className="text-xs text-slate-400 mt-1">
            Збережіть свій рівень знань, вивчені слова та XP прогрес
          </p>
        </div>

        {/* Current status if already logged in */}
        {isLoggedIn && currentUserEmail && (
          <div className="mb-4 p-3.5 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2.5">
              <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
              <div>
                <span className="text-slate-300 block font-semibold">Поточний акаунт:</span>
                <span className="text-emerald-300 font-bold">{currentUserEmail}</span>
              </div>
            </div>
            <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-[10px] font-bold">
              Google Verified
            </span>
          </div>
        )}

        <div className="space-y-4">
          {/* Official Google Sign-In Card */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-blue-950/40 via-indigo-950/30 to-slate-800 border border-blue-500/40 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-black uppercase tracking-wider text-blue-300 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>Вхід через Google</span>
              </span>
              <span className="text-[10px] text-emerald-400 font-bold flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" /> 1-клік збереження
              </span>
            </div>

            {/* Main 1-Click Google Sign In Button */}
            <button
              type="button"
              disabled={isGoogleLoading}
              onClick={() => executeGoogleLogin(primaryGoogleAccount.email, primaryGoogleAccount.name)}
              className="w-full p-3.5 rounded-2xl bg-white hover:bg-slate-100 text-slate-800 border border-slate-200 flex items-center justify-between transition shadow-lg shadow-black/25 group cursor-pointer"
            >
              <div className="flex items-center gap-3 text-left">
                <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.66-5.17 3.66-9.17z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.98 0 12s.45 3.82 1.25 5.42l4.03-3.15z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                  />
                </svg>
                <div>
                  <span className="text-xs font-bold text-slate-900 block group-hover:text-blue-600 transition">
                    Продовжити як {primaryGoogleAccount.name}
                  </span>
                  <span className="text-[11px] text-slate-500 block font-mono">
                    {primaryGoogleAccount.email}
                  </span>
                </div>
              </div>

              {isGoogleLoading ? (
                <Loader2 className="w-5 h-5 text-blue-600 animate-spin shrink-0" />
              ) : (
                <div className="w-6 h-6 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center font-bold text-xs shrink-0 group-hover:bg-blue-600 group-hover:text-white transition">
                  →
                </div>
              )}
            </button>

            {/* Option to enter any other Google account */}
            {!showCustomGoogleInput ? (
              <button
                type="button"
                onClick={() => setShowCustomGoogleInput(true)}
                className="text-[11px] text-blue-400 hover:text-blue-300 font-semibold text-center block w-full transition pt-1 cursor-pointer"
              >
                Вибрати інший обліковий запис Google...
              </button>
            ) : (
              <form onSubmit={handleCustomGoogleSubmit} className="pt-2 space-y-2">
                <label className="text-[11px] font-bold text-slate-300 block">
                  Введіть іншу адресу Google (Gmail):
                </label>
                <div className="flex gap-2">
                  <input
                    type="email"
                    value={customGoogleEmail}
                    onChange={(e) => setCustomGoogleEmail(e.target.value)}
                    placeholder="my.account@gmail.com"
                    className="flex-grow px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-blue-500"
                  />
                  <button
                    type="submit"
                    className="px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition shrink-0 cursor-pointer"
                  >
                    Увійти
                  </button>
                </div>
              </form>
            )}
          </div>

          <div className="relative flex py-1 items-center">
            <div className="flex-grow border-t border-slate-800" />
            <span className="flex-shrink mx-3 text-[11px] font-bold text-slate-500">
              або вхід за іншим Email
            </span>
            <div className="flex-grow border-t border-slate-800" />
          </div>

          {/* Fallback Entry Form */}
          <form
            onSubmit={handleCustomLogin}
            className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700/80 space-y-3"
          >
            <div>
              <label className="text-[11px] font-medium text-slate-400 block mb-1">
                Електронна пошта
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@example.com"
                className="w-full px-3.5 py-2 rounded-xl border border-slate-700 bg-slate-900 text-xs text-white focus:border-blue-500 focus:outline-none"
              />
            </div>
            <div>
              <label className="text-[11px] font-medium text-slate-400 block mb-1">
                Ім'я або нікнейм (необов'язково)
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Сергій"
                className="w-full px-3.5 py-2 rounded-xl border border-slate-700 bg-slate-900 text-xs text-white focus:border-blue-500 focus:outline-none"
              />
            </div>
            <button
              type="submit"
              className="w-full py-2.5 px-4 rounded-xl bg-slate-700 hover:bg-slate-600 text-white font-bold text-xs flex items-center justify-center gap-2 transition cursor-pointer"
            >
              <LogIn className="w-4 h-4" />
              <span>Увійти з Email</span>
            </button>
          </form>
        </div>

        <div className="mt-4 pt-3 border-t border-slate-800 text-[11px] text-slate-500 text-center">
          Дані надійно зберігаються у вашому персональному профілі.
        </div>
      </div>
    </div>
  );
};
