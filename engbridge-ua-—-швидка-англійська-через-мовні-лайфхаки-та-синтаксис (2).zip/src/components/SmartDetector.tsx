import React, { useState } from 'react';
import {
  Cpu,
  Search,
  X,
  ArrowRight,
  Volume2,
  Lightbulb,
  BookmarkPlus,
  AlertTriangle,
} from 'lucide-react';
import { analyzeWord, DetectionResult } from '../utils/detectorEngine';
import { VocabItem } from '../types';
import { playSound, speakEnglish } from '../utils/audio';

interface SmartDetectorProps {
  onSaveWord: (word: VocabItem) => void;
  onToast: (msg: string, type: 'info' | 'success' | 'error') => void;
}

export const SmartDetector: React.FC<SmartDetectorProps> = ({ onSaveWord, onToast }) => {
  const [inputValue, setInputValue] = useState('');
  const [analysis, setAnalysis] = useState<DetectionResult | null>(null);

  const sampleWords = [
    { label: 'безвідповідальний 🔥', value: 'безвідповідальний' },
    { label: 'інформація', value: 'інформація' },
    { label: 'бездротовий', value: 'бездротовий' },
    { label: 'романтичний', value: 'романтичний' },
    { label: 'магазин ⚠️', value: 'магазин' },
  ];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setInputValue(val);
    if (val.trim()) {
      setAnalysis(analyzeWord(val));
    } else {
      setAnalysis(null);
    }
  };

  const handleClear = () => {
    playSound('click');
    setInputValue('');
    setAnalysis(null);
  };

  const handleSampleClick = (word: string) => {
    playSound('click');
    setInputValue(word);
    setAnalysis(analyzeWord(word));
  };

  const handleSpeak = () => {
    if (analysis && analysis.engWord && !analysis.engWord.includes('[')) {
      speakEnglish(analysis.engWord);
    }
  };

  const handleSaveToVault = () => {
    if (!analysis) return;
    playSound('correct');
    onSaveWord({
      ukr: analysis.ukrWord,
      eng: analysis.engWord,
      ipa: analysis.ipa,
      rule: analysis.ruleTitle,
    });
    onToast(`«${analysis.engWord}» збережено у Скарбничку! (+10 XP)`, 'success');
  };

  return (
    <section className="space-y-6">
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <div className="inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-blue-600/20 text-blue-400 border border-blue-500/30 mb-1">
          <Cpu className="w-6 h-6" />
        </div>
        <h2 className="text-2xl sm:text-3xl font-black text-white">Розумний Детектор & Конвертер</h2>
        <p className="text-xs sm:text-sm text-slate-400">
          Введіть будь-яке українське слово (наприклад:{' '}
          <span className="text-blue-300 font-semibold">
            інформація, бездротовий, безвідповідальний, романтичний, перезавантажити
          </span>
          ). Алгоритм миттєво визначить мовний міст і дасть чистий результат без гібридних спотворень!
        </p>
      </div>

      {/* Input Box */}
      <div className="max-w-2xl mx-auto">
        <div className="relative bg-slate-900 border-2 border-slate-700 focus-within:border-blue-500 rounded-3xl p-2 sm:p-3 shadow-xl transition">
          <div className="flex items-center gap-3 px-3">
            <Search className="w-5 h-5 text-slate-400 shrink-0" />
            <input
              type="text"
              value={inputValue}
              onChange={handleInputChange}
              placeholder="Введіть українське слово (напр: безвідповідальний)..."
              className="w-full bg-transparent border-none text-slate-100 placeholder-slate-500 text-base sm:text-lg font-semibold focus:outline-none py-2"
              autoComplete="off"
            />
            {inputValue && (
              <button
                onClick={handleClear}
                className="p-1.5 rounded-xl hover:bg-slate-800 text-slate-400 hover:text-white transition"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Quick Sample Pills */}
        <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Приклади:</span>
          {sampleWords.map((sample) => (
            <button
              key={sample.value}
              onClick={() => handleSampleClick(sample.value)}
              className="px-3 py-1 rounded-xl bg-slate-800/80 hover:bg-blue-600 text-xs font-semibold text-slate-300 hover:text-white border border-slate-700 transition"
            >
              {sample.label}
            </button>
          ))}
        </div>
      </div>

      {/* Result Card */}
      <div className="max-w-2xl mx-auto bg-slate-900/90 rounded-3xl border border-slate-800 p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <span className="px-3 py-1 rounded-xl text-xs font-bold bg-blue-500/20 text-blue-400 border border-blue-500/30">
            {analysis ? analysis.ruleTitle : 'Очікування введення...'}
          </span>
          <span className="text-xs text-slate-400 font-medium">
            {analysis ? (analysis.isExactMatch ? 'Знайдено в базі шаблонів ✓' : 'Аналіз за шаблоном') : 'Введіть слово вище'}
          </span>
        </div>

        <div className="py-6 sm:py-8 flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="text-center sm:text-left space-y-1">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
              Українське слово
            </span>
            <h3 className="text-2xl sm:text-3xl font-black text-white">
              {analysis ? analysis.ukrWord : 'Введіть слово'}
            </h3>
          </div>

          <div className="w-10 h-10 rounded-2xl bg-blue-600/20 flex items-center justify-center text-blue-400 shrink-0">
            <ArrowRight className="w-5 h-5" />
          </div>

          <div className="text-center sm:text-right space-y-1">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
              Англійський відповідник
            </span>
            <div className="flex items-center justify-center sm:justify-end gap-3">
              <h3 className="text-2xl sm:text-3xl font-black text-blue-400">
                {analysis ? analysis.engWord : '...'}
              </h3>
              <button
                disabled={!analysis || analysis.engWord.includes('[')}
                onClick={handleSpeak}
                className="w-10 h-10 rounded-xl bg-blue-600 hover:bg-blue-500 text-white flex items-center justify-center shadow-md transition disabled:opacity-40"
              >
                <Volume2 className="w-5 h-5" />
              </button>
            </div>
            <p className="text-xs text-slate-400 font-mono">{analysis ? analysis.ipa : '/—/'}</p>
          </div>
        </div>

        {/* Formula Explanation */}
        <div className="p-4 rounded-2xl bg-slate-800/60 border border-slate-700/80 space-y-2">
          <div className="flex items-center gap-2 text-xs font-bold text-amber-300">
            {analysis?.isTrap ? <AlertTriangle className="w-4 h-4 text-rose-400" /> : <Lightbulb className="w-4 h-4" />}
            <span>{analysis?.isTrap ? 'Увага! Пастка для українців' : 'Формула правила'}</span>
          </div>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            {analysis
              ? analysis.ruleExplanation
              : 'Введіть або оберіть слово для миттєвого морфемного аналізу.'}
          </p>
        </div>

        {/* Save button */}
        {analysis && !analysis.engWord.includes('[') && (
          <div className="mt-4 flex items-center justify-end">
            <button
              onClick={handleSaveToVault}
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-2 transition shadow-md"
            >
              <BookmarkPlus className="w-4 h-4" />
              <span>Зберегти в мої слова (+10 XP)</span>
            </button>
          </div>
        )}
      </div>
    </section>
  );
};
