import React, { useState, useRef, useEffect } from 'react';
import {
  MessageSquareCode,
  Mic,
  MicOff,
  Send,
  Volume2,
  VolumeX,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Award,
  ArrowRight,
  RotateCcw,
  BookOpen,
  Brain,
  Compass,
  Check,
  ChevronDown,
  ChevronUp,
  Plus,
  X,
  Play,
  BookmarkPlus,
  Loader2,
  Filter,
  Languages,
  ExternalLink,
  Wrench,
  Paperclip,
  Upload,
} from 'lucide-react';
import {
  RoleplayScenario,
  RoleplayMessage,
  RoleplayReport,
  RoleplayMission,
  CefrLevel,
  VocabItem,
} from '../types';
import { ROLEPLAY_SCENARIOS } from '../data/roleplayScenarios';
import { speakEnglish, playSound } from '../utils/audio';
import {
  createSpeechRecognizer,
  isSpeechRecognitionSupported,
  requestMicrophonePermission,
  createAudioLevelMonitor,
  transcribeAudioBlob,
  transcribeAudioFile,
  isRunningInIframe,
} from '../utils/shadowingEvaluator';
import { MicrophoneDiagnosticModal } from './MicrophoneDiagnosticModal';

interface RoleplaySimulatorProps {
  onRewardXP: (amount: number) => void;
  onToast: (msg: string, type: 'info' | 'success' | 'error') => void;
  onSaveWord?: (word: VocabItem) => void;
  userLevel?: CefrLevel | null;
}

export const RoleplaySimulator: React.FC<RoleplaySimulatorProps> = ({
  onRewardXP,
  onToast,
  onSaveWord,
  userLevel,
}) => {
  // Scenario states
  const [selectedScenario, setSelectedScenario] = useState<RoleplayScenario | null>(null);
  const [levelFilter, setLevelFilter] = useState<'all' | CefrLevel>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');

  // Active chat session states
  const [messages, setMessages] = useState<RoleplayMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [isLoadingReply, setIsLoadingReply] = useState(false);
  const [isAutoPlayAudio, setIsAutoPlayAudio] = useState(true);
  const [showTranslations, setShowTranslations] = useState<Record<string, boolean>>({});
  const [missions, setMissions] = useState<RoleplayMission[]>([]);
  const [isMissionsOpen, setIsMissionsOpen] = useState(false);
  const [isVocabDrawerOpen, setIsVocabDrawerOpen] = useState(false);

  // Voice recording / Speech-to-text
  const [isRecording, setIsRecording] = useState(false);
  const [audioLevel, setAudioLevel] = useState<number>(0);
  const [isTranscribingAudio, setIsTranscribingAudio] = useState(false);
  const [micPermissionDenied, setMicPermissionDenied] = useState(false);
  const [micErrorMessage, setMicErrorMessage] = useState<string | null>(null);
  const [isMicDiagnosticOpen, setIsMicDiagnosticOpen] = useState(false);
  const [selectedDeviceId, setSelectedDeviceId] = useState<string>('');
  const [recordingSeconds, setRecordingSeconds] = useState(0);

  const speechRecognizerRef = useRef<{ stop: () => void; recognition: any } | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const audioLevelMonitorRef = useRef<{ stop: () => void } | null>(null);
  const recordingTimerRef = useRef<any>(null);
  const liveTranscriptRef = useRef<string>('');
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handleAudioFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsTranscribingAudio(true);
    onToast(`Обробка аудіофайлу "${file.name}" через ШІ Gemini...`, 'info');
    const { transcript, error } = await transcribeAudioFile(file);
    setIsTranscribingAudio(false);

    if (transcript && transcript.trim().length > 0) {
      setInputText(transcript);
      onToast('Аудіо успішно розпізнано! Перевірте текст і натисніть Надіслати.', 'success');
    } else {
      onToast(error || 'Не вдалося розпізнати слова в аудіофайлі.', 'error');
    }
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  // Custom Scenario Creator Modal
  const [isCustomModalOpen, setIsCustomModalOpen] = useState(false);
  const [customTitle, setCustomTitle] = useState('');
  const [customRole, setCustomRole] = useState('');
  const [customLocation, setCustomLocation] = useState('');
  const [customDescription, setCustomDescription] = useState('');

  // Final Report states
  const [report, setReport] = useState<RoleplayReport | null>(null);
  const [isEvaluatingReport, setIsEvaluatingReport] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  // Auto-scroll chat to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoadingReply]);

  // Clean up speech recognition on unmount
  useEffect(() => {
    return () => {
      if (speechRecognizerRef.current) {
        speechRecognizerRef.current.stop();
      }
      if (audioLevelMonitorRef.current) {
        audioLevelMonitorRef.current.stop();
      }
      if (recordingTimerRef.current) {
        clearInterval(recordingTimerRef.current);
      }
    };
  }, []);

  // Filtered scenarios
  const filteredScenarios = ROLEPLAY_SCENARIOS.filter((sc) => {
    const matchLevel = levelFilter === 'all' || sc.level === levelFilter;
    const matchCat = categoryFilter === 'all' || sc.category === categoryFilter;
    return matchLevel && matchCat;
  });

  // Start a scenario session
  const handleStartScenario = (scenario: RoleplayScenario) => {
    playSound('click');
    setSelectedScenario(scenario);
    setMissions(scenario.missions.map((m) => ({ ...m, completed: false })));
    setReport(null);

    const initialMsg: RoleplayMessage = {
      id: 'msg-' + Date.now(),
      sender: 'ai',
      textEn: scenario.initialMessageEn,
      textUa: scenario.initialMessageUa,
      timestamp: Date.now(),
      suggestedResponses: [
        { en: scenario.keyVocabulary[0]?.en || 'Hello!', ua: scenario.keyVocabulary[0]?.ua || 'Привіт!' },
        { en: scenario.keyVocabulary[1]?.en || 'Nice to meet you.', ua: scenario.keyVocabulary[1]?.ua || 'Приємно познайомитись.' },
      ],
    };

    setMessages([initialMsg]);

    if (isAutoPlayAudio) {
      setTimeout(() => speakEnglish(scenario.initialMessageEn), 500);
    }
  };

  // Toggle speech-to-text recording
  const handleStopVoiceRecording = () => {
    setIsRecording(false);
    if (recordingTimerRef.current) {
      clearInterval(recordingTimerRef.current);
      recordingTimerRef.current = null;
    }
    if (audioLevelMonitorRef.current) {
      audioLevelMonitorRef.current.stop();
      audioLevelMonitorRef.current = null;
    }
    setAudioLevel(0);

    if (speechRecognizerRef.current) {
      speechRecognizerRef.current.stop();
      speechRecognizerRef.current = null;
    }

    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
    playSound('click');
  };

  const handleStartVoiceRecording = async () => {
    setMicPermissionDenied(false);
    setMicErrorMessage(null);
    const { stream, error, errorType } = await requestMicrophonePermission(selectedDeviceId || undefined);
    if (!stream) {
      if (
        errorType === 'iframe-blocked' ||
        errorType === 'not-allowed' ||
        error?.includes('заблоковано') ||
        error?.includes('відхилено')
      ) {
        setMicPermissionDenied(true);
        setMicErrorMessage(error);
      }
      onToast(error || 'Не вдалося підключити мікрофон', 'error');
      return;
    }

    playSound('click');
    setIsRecording(true);
    setRecordingSeconds(0);
    audioChunksRef.current = [];
    liveTranscriptRef.current = '';

    // Recording duration timer
    recordingTimerRef.current = setInterval(() => {
      setRecordingSeconds((s) => s + 1);
    }, 1000);

    // Audio level meter
    const monitor = createAudioLevelMonitor(stream, (lvl) => {
      setAudioLevel(lvl);
    });
    audioLevelMonitorRef.current = monitor;

    // MediaRecorder
    let mediaRecorder: MediaRecorder;
    try {
      const mime = MediaRecorder.isTypeSupported('audio/webm;codecs=opus')
        ? 'audio/webm;codecs=opus'
        : MediaRecorder.isTypeSupported('audio/webm')
        ? 'audio/webm'
        : '';
      mediaRecorder = mime ? new MediaRecorder(stream, { mimeType: mime }) : new MediaRecorder(stream);
    } catch {
      mediaRecorder = new MediaRecorder(stream);
    }
    mediaRecorderRef.current = mediaRecorder;

    mediaRecorder.ondataavailable = (event) => {
      if (event.data.size > 0) {
        audioChunksRef.current.push(event.data);
      }
    };

    mediaRecorder.onstop = async () => {
      stream.getTracks().forEach((track) => track.stop());

      // If live Web Speech API didn't pick up text, transcribe via Gemini server endpoint
      if (!liveTranscriptRef.current || liveTranscriptRef.current.trim().length === 0) {
        const audioBlob = new Blob(audioChunksRef.current, {
          type: mediaRecorder.mimeType || 'audio/webm',
        });
        if (audioBlob.size > 100) {
          setIsTranscribingAudio(true);
          onToast('Розпізнавання аудіо через ШІ Gemini...', 'info');
          const { transcript, error: trErr } = await transcribeAudioBlob(audioBlob);
          setIsTranscribingAudio(false);

          if (transcript && transcript.trim().length > 0) {
            setInputText(transcript);
            onToast('Голос розпізнано! Перевірте текст і натисніть Надіслати.', 'success');
          } else if (trErr) {
            onToast(trErr, 'info');
          }
        }
      }
    };

    // Live Web Speech recognition if supported
    if (isSpeechRecognitionSupported()) {
      const recognizer = createSpeechRecognizer(
        (transcript) => {
          setInputText(transcript);
          liveTranscriptRef.current = transcript;
        },
        (err) => {
          console.warn('Speech recognition notice:', err);
        }
      );
      speechRecognizerRef.current = recognizer;
    }

    mediaRecorder.start(250);
    onToast('Говоріть англійською... Ми записуємо ваш голос', 'info');
  };

  const handleToggleVoiceInput = () => {
    if (isRecording) {
      handleStopVoiceRecording();
    } else {
      handleStartVoiceRecording();
    }
  };

  // Send message to AI
  const handleSendMessage = async (textToSend?: string) => {
    const text = (textToSend || inputText).trim();
    if (!text || !selectedScenario || isLoadingReply) return;

    if (isRecording && speechRecognizerRef.current) {
      speechRecognizerRef.current.stop();
      speechRecognizerRef.current = null;
      setIsRecording(false);
    }

    playSound('click');
    setInputText('');

    const userMsg: RoleplayMessage = {
      id: 'msg-user-' + Date.now(),
      sender: 'user',
      textEn: text,
      timestamp: Date.now(),
    };

    const updatedMessages = [...messages, userMsg];
    setMessages(updatedMessages);
    setIsLoadingReply(true);

    try {
      const res = await fetch('/api/roleplay/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          scenarioTitle: selectedScenario.title,
          characterName: selectedScenario.characterName,
          characterRole: selectedScenario.characterRole,
          location: selectedScenario.location,
          systemPrompt: selectedScenario.systemPrompt,
          level: selectedScenario.level,
          history: updatedMessages.map((m) => ({ sender: m.sender, textEn: m.textEn })),
          userMessage: text,
          missions,
        }),
      });

      if (res.ok) {
        const data = await res.json();

        // Check off completed missions
        if (data.completedMissionIds && Array.isArray(data.completedMissionIds)) {
          setMissions((prev) =>
            prev.map((m) =>
              data.completedMissionIds.includes(m.id) ? { ...m, completed: true } : m
            )
          );
        }

        const aiMsg: RoleplayMessage = {
          id: 'msg-ai-' + Date.now(),
          sender: 'ai',
          textEn: data.reply || "I understand. Let's continue!",
          textUa: data.translationUa || '',
          timestamp: Date.now(),
          suggestedResponses: data.suggestedResponses || [],
          feedbackOnUser: data.feedbackOnUser,
        };

        setMessages((prev) => [...prev, aiMsg]);
        onRewardXP(15);

        if (isAutoPlayAudio && data.reply) {
          setTimeout(() => speakEnglish(data.reply), 300);
        }
      } else {
        throw new Error('Server error');
      }
    } catch {
      // Fallback response
      const fallbackAi: RoleplayMessage = {
        id: 'msg-fallback-' + Date.now(),
        sender: 'ai',
        textEn: "That's very interesting! Could you tell me a little bit more about that?",
        textUa: "Це дуже цікаво! Чи не могли б ви розповісти про це трохи більше?",
        timestamp: Date.now(),
        suggestedResponses: [
          { en: "Sure, let me elaborate.", ua: "Звісно, дозвольте уточнити." },
          { en: "Actually, I wanted to ask another question.", ua: "Власне, я хотів поставити інше запитання." },
        ],
      };
      setMessages((prev) => [...prev, fallbackAi]);
    } finally {
      setIsLoadingReply(false);
    }
  };

  // Conclude dialogue and generate final comprehensive report
  const handleConcludeRoleplay = async () => {
    if (!selectedScenario || messages.length < 2) {
      onToast('Проведіть хоча б 1-2 репліки діалогу перед оцінкою!', 'info');
      return;
    }

    setIsEvaluatingReport(true);
    playSound('click');

    try {
      const res = await fetch('/api/roleplay/evaluate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          scenarioTitle: selectedScenario.title,
          characterName: selectedScenario.characterName,
          level: selectedScenario.level,
          messages,
          missions,
        }),
      });

      if (res.ok) {
        const reportData: RoleplayReport = await res.json();
        setReport(reportData);
        playSound('combo');
        onRewardXP(reportData.xpEarned || 50);
        onToast(`Сесію завершено! Ваш результат: ${reportData.score}/100 (+${reportData.xpEarned} XP)`, 'success');
      } else {
        throw new Error('Evaluation error');
      }
    } catch {
      // Fallback report
      const completedCount = missions.filter((m) => m.completed).length;
      const pct = Math.round((completedCount / Math.max(1, missions.length)) * 100);
      setReport({
        score: Math.max(75, pct),
        assessedLevel: selectedScenario.level,
        taskCompletionPercent: Math.max(70, pct),
        fluencyScore: 82,
        grammarScore: 85,
        vocabularyScore: 80,
        strengthsUa: [
          "Впевнене мовлення та підтримання контакту зі співрозмовником",
          "Грамотне вживання привітань та ввічливих конструкцій",
        ],
        mistakesAnalyzed: [],
        recommendedVocabulary: selectedScenario.keyVocabulary.slice(0, 3),
        overallSummaryUa:
          "Чудова розмовна практика! Ви успішно провели діалог у реалістичній ситуації та досягли більшості комунікативних цілей.",
        xpEarned: 50,
      });
      onRewardXP(50);
    } finally {
      setIsEvaluatingReport(false);
    }
  };

  // Create custom scenario
  const handleCreateCustomScenario = () => {
    if (!customTitle || !customRole) {
      onToast('Вкажіть назву та роль співрозмовника!', 'error');
      return;
    }

    const newScenario: RoleplayScenario = {
      id: 'custom-' + Date.now(),
      title: customTitle,
      engTitle: customTitle,
      category: 'custom',
      level: 'B1',
      avatarEmoji: '🎭',
      avatarBg: 'from-violet-600 to-indigo-800',
      characterName: customRole.split(' ')[0] || 'Partner',
      characterRole: customRole,
      location: customLocation || 'Custom Location',
      descriptionUa: customDescription || 'Індивідуальний сценарій користувача',
      initialMessageEn: `Hello! I understand we are here for: "${customTitle}". How can I help you today?`,
      initialMessageUa: `Вітаю! Як я розумію, ми тут щодо: "${customTitle}". Чим можу допомогти?`,
      systemPrompt: `You are roleplaying as ${customRole} in ${customLocation || 'a realistic context'}. The scenario is: "${customTitle}". Speak naturally and help the user practice.`,
      missions: [
        { id: 'm1', textUa: "Почати діалог та пояснити суть звернення", textEn: "Introduce the topic and reason for speaking", completed: false },
        { id: 'm2', textUa: "Запитати важливу деталь або вирішити питання", textEn: "Ask a key question and negotiate", completed: false },
        { id: 'm3', textUa: "Узгодити наступний крок та подякувати", textEn: "Agree on next steps and thank them", completed: false },
      ],
      keyVocabulary: [
        { en: "Could you please explain how this works?", ua: "Чи не могли б ви пояснити, як це працює?" },
        { en: "I would really appreciate your guidance", ua: "Я був би дуже вдячний за вашу пораду" },
      ],
    };

    setIsCustomModalOpen(false);
    handleStartScenario(newScenario);
    onToast('Власний сценарій створено! Почнімо спілкування.', 'success');
  };

  return (
    <div className="space-y-6">
      {/* ================= VIEW 1: SCENARIO SELECTION ================= */}
      {!selectedScenario ? (
        <div className="space-y-6">
          {/* Header Banner */}
          <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-violet-950/80 via-slate-900 to-indigo-950/80 border border-violet-500/30 shadow-2xl relative overflow-hidden flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="space-y-2 max-w-2xl">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-violet-500/20 text-violet-300 border border-violet-500/30">
                  AI Roleplay Studio • Gemini 3.8 Flash
                </span>
                <span className="text-xs text-amber-400 font-bold flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Живий голосовий діалог</span>
                </span>
              </div>

              <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                AI Roleplay Симулятор
              </h2>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                Долайте мовний бар'єр у безпечному середовищі: говоріть голосом або пишіть баристі в Лондоні,
                HR на технічній співбесіді, офіцеру на паспортному контролі чи колезі на IT-стендапі.
                Отримуйте миттєві переклади, підказки реплік та аналіз вимови.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 shrink-0">
              <button
                onClick={() => setIsCustomModalOpen(true)}
                className="px-5 py-3 rounded-2xl bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white font-bold text-xs sm:text-sm shadow-xl shadow-violet-500/25 flex items-center justify-center gap-2 transition cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Створити свій сценарій</span>
              </button>
            </div>
          </div>

          {/* Filters Bar */}
          <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900/80 p-4 rounded-2xl border border-slate-800">
            <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
              <span className="text-xs font-bold text-slate-400 flex items-center gap-1.5 shrink-0">
                <Filter className="w-3.5 h-3.5 text-slate-400" />
                <span>Рівень:</span>
              </span>
              {(['all', 'A1', 'A2', 'B1', 'B2', 'C1'] as const).map((lvl) => (
                <button
                  key={lvl}
                  onClick={() => setLevelFilter(lvl)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                    levelFilter === lvl
                      ? 'bg-violet-600 text-white shadow'
                      : 'bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700'
                  }`}
                >
                  {lvl === 'all' ? 'Усі рівні' : lvl}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
              <span className="text-xs font-bold text-slate-400 shrink-0">Категорія:</span>
              {[
                { id: 'all', label: 'Усі' },
                { id: 'daily', label: 'Побут ☕' },
                { id: 'work', label: 'IT & Робота 💻' },
                { id: 'interview', label: 'Співбесіда 💼' },
                { id: 'travel', label: 'Подорожі ✈️' },
              ].map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setCategoryFilter(cat.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                    categoryFilter === cat.id
                      ? 'bg-blue-600 text-white shadow'
                      : 'bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>

          {/* Scenario Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredScenarios.map((sc) => (
              <div
                key={sc.id}
                className="p-6 rounded-3xl bg-slate-900 border border-slate-800 hover:border-violet-500/50 hover:bg-slate-850 transition flex flex-col justify-between gap-5 group shadow-lg shadow-black/40 relative overflow-hidden"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div
                      className={`w-13 h-13 rounded-2xl bg-gradient-to-tr ${sc.avatarBg} flex items-center justify-center text-3xl shadow-md`}
                    >
                      {sc.avatarEmoji}
                    </div>

                    <div className="flex items-center gap-1.5">
                      <span className="px-2.5 py-0.5 rounded-xl text-[10px] font-black uppercase bg-violet-500/20 text-violet-300 border border-violet-500/30">
                        {sc.level}
                      </span>
                      <span className="px-2 py-0.5 rounded-xl text-[10px] font-bold bg-slate-800 text-slate-400 border border-slate-700">
                        {sc.category}
                      </span>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-black text-white group-hover:text-violet-300 transition">
                      {sc.title}
                    </h3>
                    <p className="text-xs font-bold text-slate-400">
                      {sc.characterName} • {sc.characterRole}
                    </p>
                    <span className="text-[11px] text-slate-400 block font-medium mt-0.5">
                      📍 {sc.location}
                    </span>
                  </div>

                  <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
                    {sc.descriptionUa}
                  </p>

                  {/* Missions Preview */}
                  <div className="pt-2 border-t border-slate-800 space-y-1.5">
                    <span className="text-[10px] uppercase font-black tracking-wider text-slate-400 block">
                      Місії діалогу ({sc.missions.length}):
                    </span>
                    <ul className="space-y-1">
                      {sc.missions.slice(0, 2).map((m) => (
                        <li key={m.id} className="text-[11px] text-slate-400 flex items-center gap-1.5 truncate">
                          <CheckCircle2 className="w-3 h-3 text-emerald-400 shrink-0" />
                          <span className="truncate">{m.textUa}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <button
                  onClick={() => handleStartScenario(sc)}
                  className="w-full py-3 rounded-2xl bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white font-black text-xs flex items-center justify-center gap-2 shadow-lg shadow-violet-500/20 transition cursor-pointer"
                >
                  <Play className="w-4 h-4 fill-white" />
                  <span>Почати рольову гру</span>
                </button>
              </div>
            ))}
          </div>
        </div>
      ) : (
        /* ================= VIEW 2: ACTIVE CHAT SESSION ================= */
        <div className="max-w-4xl mx-auto space-y-4">
          {/* Top Session Bar */}
          <div className="p-4 sm:p-5 rounded-3xl bg-slate-900 border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-xl">
            <div className="flex items-center gap-3.5">
              <div
                className={`w-12 h-12 rounded-2xl bg-gradient-to-tr ${selectedScenario.avatarBg} flex items-center justify-center text-2xl shadow-md shrink-0`}
              >
                {selectedScenario.avatarEmoji}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-base sm:text-lg font-black text-white">
                    {selectedScenario.title}
                  </h3>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase bg-violet-500/20 text-violet-300 border border-violet-500/30">
                    {selectedScenario.level}
                  </span>
                </div>
                <p className="text-xs text-slate-400">
                  Співрозмовник: <strong className="text-slate-200">{selectedScenario.characterName}</strong> ({selectedScenario.characterRole}) • 📍 {selectedScenario.location}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto justify-end flex-wrap">
              {/* Audio Autoplay Switcher */}
              <button
                onClick={() => {
                  const nextState = !isAutoPlayAudio;
                  setIsAutoPlayAudio(nextState);
                  onToast(nextState ? 'Автоозвучка AI увімкнена' : 'Автоозвучка вимкнена', 'info');
                }}
                title={isAutoPlayAudio ? 'Вимкнути автоозвучку' : 'Увімкнути автоозвучку'}
                className={`p-2.5 rounded-xl border text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                  isAutoPlayAudio
                    ? 'bg-blue-600/20 border-blue-500/40 text-blue-300'
                    : 'bg-slate-800 border-slate-700 text-slate-400'
                }`}
              >
                {isAutoPlayAudio ? <Volume2 className="w-4 h-4 text-blue-400" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
                <span className="hidden sm:inline">Автоозвучка</span>
              </button>

              {/* Vocab Helper Drawer Button */}
              <button
                onClick={() => setIsVocabDrawerOpen(!isVocabDrawerOpen)}
                className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 text-xs font-bold flex items-center gap-1.5 transition cursor-pointer"
                title="Підказки лексики для цієї сцени"
              >
                <BookOpen className="w-4 h-4 text-amber-400" />
                <span className="hidden sm:inline">Словничок</span>
              </button>

              {/* Conclude Dialog Button */}
              <button
                onClick={handleConcludeRoleplay}
                disabled={isEvaluatingReport}
                className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-md transition cursor-pointer"
              >
                {isEvaluatingReport ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Аналізуємо...</span>
                  </>
                ) : (
                  <>
                    <Award className="w-4 h-4" />
                    <span>Завершити та оцінити</span>
                  </>
                )}
              </button>

              {/* Exit Scenario */}
              <button
                onClick={() => {
                  if (confirm('Вийти з поточної рольової гри та повернутися до списку?')) {
                    setSelectedScenario(null);
                  }
                }}
                className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition cursor-pointer"
                title="Вийти до списку"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Missions Collapsible Bar */}
          <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-3.5 space-y-2">
            <div
              onClick={() => setIsMissionsOpen(!isMissionsOpen)}
              className="flex items-center justify-between cursor-pointer select-none"
            >
              <div className="flex items-center gap-2">
                <Compass className="w-4 h-4 text-emerald-400" />
                <span className="text-xs font-bold text-white">
                  Прогрес цілей діалогу: {missions.filter((m) => m.completed).length} з {missions.length} виконано
                </span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-24 bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-emerald-500 h-full rounded-full transition-all duration-300"
                    style={{
                      width: `${(missions.filter((m) => m.completed).length / Math.max(1, missions.length)) * 100}%`,
                    }}
                  />
                </div>
                {isMissionsOpen ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
              </div>
            </div>

            {isMissionsOpen && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2 border-t border-slate-800 animate-fadeIn">
                {missions.map((m) => (
                  <div
                    key={m.id}
                    className={`p-2.5 rounded-xl border text-xs flex items-center gap-2.5 transition ${
                      m.completed
                        ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                        : 'bg-slate-850 border-slate-800 text-slate-400'
                    }`}
                  >
                    <CheckCircle2
                      className={`w-4 h-4 shrink-0 ${m.completed ? 'text-emerald-400' : 'text-slate-600'}`}
                    />
                    <div className="min-w-0">
                      <span className="block font-bold truncate">{m.textUa}</span>
                      <span className="text-[10px] opacity-75 truncate block">{m.textEn}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Vocabulary Drawer (When Open) */}
          {isVocabDrawerOpen && (
            <div className="bg-slate-900 border border-amber-500/30 p-4 rounded-2xl space-y-3 animate-fadeIn">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-amber-400" />
                  <h4 className="text-xs font-black uppercase tracking-wider text-amber-300">
                    Корисні фрази для цієї сцени:
                  </h4>
                </div>
                <button
                  onClick={() => setIsVocabDrawerOpen(false)}
                  className="text-slate-400 hover:text-white transition"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {selectedScenario.keyVocabulary.map((item, idx) => (
                  <div
                    key={idx}
                    className="p-3 rounded-xl bg-slate-800/80 border border-slate-700/80 flex items-center justify-between gap-2"
                  >
                    <div className="space-y-0.5 min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-black text-white truncate">{item.en}</span>
                        <button
                          onClick={() => speakEnglish(item.en)}
                          className="text-slate-400 hover:text-blue-400 transition"
                          title="Озвучити"
                        >
                          <Volume2 className="w-3 h-3" />
                        </button>
                      </div>
                      <p className="text-[11px] text-slate-400 truncate">{item.ua}</p>
                      {item.tip && <span className="text-[10px] text-amber-300 block italic">💡 {item.tip}</span>}
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        onClick={() => {
                          setInputText(item.en);
                          setIsVocabDrawerOpen(false);
                        }}
                        className="p-1.5 rounded-lg bg-blue-600/20 text-blue-300 hover:bg-blue-600 hover:text-white transition text-[10px] font-bold"
                        title="Вставити в поле введення"
                      >
                        Вставити
                      </button>
                      {onSaveWord && (
                        <button
                          onClick={() => {
                            onSaveWord({
                              eng: item.en,
                              ukr: item.ua,
                              ipa: '',
                              rule: item.tip || selectedScenario.title,
                              level: selectedScenario.level,
                            });
                            playSound('click');
                            onToast(`«${item.en}» збережено до скарбнички!`, 'success');
                          }}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-emerald-400 transition"
                          title="Зберегти в словник"
                        >
                          <BookmarkPlus className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Dialogue Message Stream */}
          <div className="bg-slate-950/70 border border-slate-800 rounded-3xl p-4 sm:p-6 min-h-[420px] max-h-[560px] overflow-y-auto space-y-4 shadow-inner">
            {messages.map((msg) => {
              const isAi = msg.sender === 'ai';
              const showTrans = showTranslations[msg.id];

              return (
                <div
                  key={msg.id}
                  className={`flex gap-3 max-w-[85%] ${isAi ? 'self-start mr-auto' : 'self-end ml-auto flex-row-reverse'}`}
                >
                  {/* Avatar */}
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 shadow text-sm ${
                      isAi
                        ? `bg-gradient-to-tr ${selectedScenario.avatarBg} text-white`
                        : 'bg-gradient-to-tr from-blue-600 to-indigo-600 text-white font-bold'
                    }`}
                  >
                    {isAi ? selectedScenario.avatarEmoji : 'Ви'}
                  </div>

                  {/* Bubble Content */}
                  <div className="space-y-2">
                    <div
                      className={`p-4 rounded-3xl space-y-2 ${
                        isAi
                          ? 'bg-slate-900 border border-slate-800 text-slate-100 rounded-tl-sm'
                          : 'bg-blue-600 text-white rounded-tr-sm shadow-md shadow-blue-600/20'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-4">
                        <span className={`text-[10px] font-black uppercase tracking-wider ${isAi ? 'text-violet-400' : 'text-blue-200'}`}>
                          {isAi ? selectedScenario.characterName : 'Ви'}
                        </span>

                        {isAi && (
                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => speakEnglish(msg.textEn)}
                              className="p-1 rounded-lg text-slate-400 hover:text-white transition"
                              title="Озвучити англійською"
                            >
                              <Volume2 className="w-3.5 h-3.5" />
                            </button>
                            {msg.textUa && (
                              <button
                                onClick={() =>
                                  setShowTranslations((prev) => ({
                                    ...prev,
                                    [msg.id]: !prev[msg.id],
                                  }))
                                }
                                className={`px-1.5 py-0.5 rounded text-[10px] font-bold border transition ${
                                  showTrans
                                    ? 'bg-blue-500/20 text-blue-300 border-blue-500/30'
                                    : 'text-slate-400 hover:text-slate-200 border-slate-700'
                                }`}
                              >
                                {showTrans ? 'Eng' : 'UA 🇺🇦'}
                              </button>
                            )}
                          </div>
                        )}
                      </div>

                      {/* Main Message Text */}
                      <p className="text-sm font-medium leading-relaxed">
                        {msg.textEn}
                      </p>

                      {/* Ukrainian Translation (Toggled) */}
                      {isAi && showTrans && msg.textUa && (
                        <p className="text-xs text-slate-400 italic pt-1 border-t border-slate-800">
                          {msg.textUa}
                        </p>
                      )}
                    </div>

                    {/* Feedback on User's previous response */}
                    {isAi && msg.feedbackOnUser && (
                      <div className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800 text-xs space-y-1 animate-fadeIn">
                        <div className="flex items-center gap-1.5 font-bold text-amber-300">
                          <Sparkles className="w-3.5 h-3.5" />
                          <span>Мовний коментар тренера:</span>
                        </div>
                        {msg.feedbackOnUser.betterAlternative && (
                          <p className="text-slate-300">
                            💡 <strong>Як сказати природніше:</strong>{' '}
                            <span className="text-emerald-400 font-semibold">«{msg.feedbackOnUser.betterAlternative}»</span>
                          </p>
                        )}
                        {msg.feedbackOnUser.linguisticTipUa && (
                          <p className="text-slate-400 text-[11px] leading-relaxed">
                            {msg.feedbackOnUser.linguisticTipUa}
                          </p>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}

            {/* AI Typing Indicator */}
            {isLoadingReply && (
              <div className="flex items-center gap-3">
                <div
                  className={`w-8 h-8 rounded-xl bg-gradient-to-tr ${selectedScenario.avatarBg} flex items-center justify-center text-sm shadow`}
                >
                  {selectedScenario.avatarEmoji}
                </div>
                <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 flex items-center gap-2 text-xs text-slate-400">
                  <Loader2 className="w-3.5 h-3.5 animate-spin text-violet-400" />
                  <span>{selectedScenario.characterName} друкує відповідь...</span>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Suggested Responses Pills */}
          {messages.length > 0 &&
            messages[messages.length - 1]?.sender === 'ai' &&
            messages[messages.length - 1]?.suggestedResponses &&
            messages[messages.length - 1]!.suggestedResponses!.length > 0 && (
              <div className="space-y-1.5 animate-fadeIn">
                <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 block px-1">
                  Підказки відповідей (клікніть для відправки):
                </span>
                <div className="flex flex-wrap gap-2">
                  {messages[messages.length - 1]!.suggestedResponses!.map((resp, idx) => (
                    <button
                      key={idx}
                      onClick={() => handleSendMessage(resp.en)}
                      className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700/80 hover:border-violet-500/50 text-left transition flex items-center gap-2 group cursor-pointer"
                    >
                      <Sparkles className="w-3 h-3 text-amber-400 shrink-0 group-hover:scale-110 transition" />
                      <div className="text-xs">
                        <span className="font-bold text-white block group-hover:text-violet-300">
                          {resp.en}
                        </span>
                        <span className="text-[10px] text-slate-400">{resp.ua}</span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}

          {/* Permission Denied Guide */}
          {micPermissionDenied && (
            <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-xs space-y-3 animate-fadeIn relative">
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2 text-amber-300 font-bold">
                  <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>Доступ до мікрофона заблоковано в браузері</span>
                </div>
                <button
                  onClick={() => setMicPermissionDenied(false)}
                  className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition cursor-pointer"
                  title="Закрити сповіщення"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <p className="text-slate-300 text-xs leading-relaxed">
                {micErrorMessage ||
                  'Якщо ви вже дозволили мікрофон біля адреси сайту, це найчастіше трапляється через запуск у вікні передперегляду AI Studio (iFrame) або налаштування конфіденційності macOS/Windows.'}
              </p>

              <div className="flex flex-wrap items-center gap-2 pt-1">
                {isRunningInIframe() && (
                  <button
                    onClick={() => window.open(window.location.href, '_blank', 'noopener,noreferrer')}
                    className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-xs flex items-center gap-1.5 transition cursor-pointer shadow-md shadow-amber-500/20"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    Відкрити в новій вкладці (Без обмежень iFrame)
                  </button>
                )}

                <button
                  onClick={() => setIsMicDiagnosticOpen(true)}
                  className="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-1.5 transition cursor-pointer shadow-md shadow-indigo-600/20"
                >
                  <Wrench className="w-3.5 h-3.5" />
                  Діагностика та тест звуку
                </button>

                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5 transition cursor-pointer border border-slate-700"
                >
                  <Upload className="w-3.5 h-3.5" />
                  Завантажити аудіофайл
                </button>

                <button
                  onClick={handleToggleVoiceInput}
                  className="px-3 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 text-xs font-bold transition cursor-pointer border border-amber-500/40"
                >
                  Спробувати знову
                </button>
              </div>
            </div>
          )}

          {/* Live Voice Recording Status & VU Meter */}
          {isRecording && (
            <div className="p-3 rounded-2xl bg-rose-500/10 border border-rose-500/30 flex flex-col sm:flex-row items-center justify-between gap-3 animate-fadeIn">
              <div className="flex items-center gap-2.5">
                <span className="w-3 h-3 rounded-full bg-rose-500 animate-ping" />
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-black text-rose-400 uppercase tracking-wider">
                      Запис голосу ({String(Math.floor(recordingSeconds / 60)).padStart(2, '0')}:{String(recordingSeconds % 60).padStart(2, '0')})
                    </span>
                    <span className="text-[10px] text-slate-400">
                      • Говоріть англійською
                    </span>
                  </div>
                  <div className="text-[10px] text-slate-300">
                    Рівень сигналу мікрофона: <strong className={audioLevel > 5 ? 'text-emerald-400' : 'text-amber-400'}>{audioLevel > 5 ? `${audioLevel}% (Звук є ✓)` : '0% (Тиша або мут)'}</strong>
                  </div>
                </div>
              </div>

              {/* Soundwave bars */}
              <div className="flex items-center gap-1 h-6">
                {[...Array(12)].map((_, i) => {
                  const variance = Math.sin(i * 0.8 + Date.now() / 150) * 15;
                  const height = Math.min(100, Math.max(20, audioLevel + variance));
                  return (
                    <div
                      key={i}
                      className={`w-1 rounded-full transition-all duration-75 ${
                        audioLevel > 5 ? 'bg-emerald-400' : 'bg-slate-700'
                      }`}
                      style={{ height: `${height}%` }}
                    />
                  );
                })}
              </div>

              <button
                onClick={handleStopVoiceRecording}
                className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition shadow shrink-0 cursor-pointer"
              >
                Зупинити та перевірити
              </button>
            </div>
          )}

          {/* AI Transcribing Audio Loader */}
          {isTranscribingAudio && (
            <div className="p-3 rounded-2xl bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-center gap-2 text-xs text-indigo-300 animate-pulse">
              <Loader2 className="w-4 h-4 animate-spin text-indigo-400" />
              <span>ШІ Gemini розшифровує ваш голос у текст...</span>
            </div>
          )}

          {/* User Input Bar */}
          <div className="p-2 sm:p-2.5 rounded-3xl bg-slate-900 border border-slate-700/80 shadow-2xl flex items-center gap-2">
            {/* Hidden audio file upload input */}
            <input
              type="file"
              ref={fileInputRef}
              accept="audio/*,.mp3,.wav,.m4a,.ogg,.webm"
              onChange={handleAudioFileUpload}
              className="hidden"
            />

            {/* Microphone Speech-to-Text Button */}
            <button
              onClick={handleToggleVoiceInput}
              className={`w-11 h-11 rounded-2xl flex items-center justify-center transition cursor-pointer shrink-0 ${
                isRecording
                  ? 'bg-rose-600 text-white animate-pulse shadow-lg shadow-rose-600/30'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700'
              }`}
              title={isRecording ? 'Зупинити розпізнавання' : 'Говорити на мікрофон (Speech-to-Text)'}
            >
              {isRecording ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5 text-sky-400" />}
            </button>

            {/* Audio File Upload Button */}
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="w-10 h-10 rounded-2xl bg-slate-800 hover:bg-slate-750 text-slate-400 hover:text-indigo-300 border border-slate-700/80 hidden sm:flex items-center justify-center transition cursor-pointer shrink-0"
              title="Завантажити готовий аудіофайл (.mp3, .wav, .m4a)"
            >
              <Paperclip className="w-4 h-4" />
            </button>

            {/* Mic Diagnostic / Wrench Button */}
            <button
              type="button"
              onClick={() => setIsMicDiagnosticOpen(true)}
              className="w-10 h-10 rounded-2xl bg-slate-800 hover:bg-slate-750 text-slate-400 hover:text-white border border-slate-700/80 hidden sm:flex items-center justify-center transition cursor-pointer shrink-0"
              title="Діагностика мікрофона та тест звуку"
            >
              <Wrench className="w-4 h-4" />
            </button>

            {/* Text Input */}
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleSendMessage();
              }}
              placeholder={
                isRecording
                  ? 'Слухаємо вашу англійську мову...'
                  : 'Введіть відповідь англійською або натисніть мікрофон...'
              }
              className="flex-1 bg-transparent px-3 py-2 text-sm text-white placeholder-slate-500 focus:outline-none"
            />

            {/* Send Button */}
            <button
              onClick={() => handleSendMessage()}
              disabled={!inputText.trim() || isLoadingReply}
              className="w-11 h-11 rounded-2xl bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-white flex items-center justify-center transition shadow-lg shadow-blue-500/25 shrink-0 cursor-pointer"
              title="Надіслати відповідь"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* ================= MODAL: FINAL REPORT CARD ================= */}
      {report && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
          <div className="bg-slate-900 border border-slate-700/80 rounded-3xl max-w-2xl w-full max-h-[90vh] flex flex-col shadow-2xl shadow-black/90 overflow-hidden">
            {/* Header */}
            <div className="p-6 border-b border-slate-800 bg-slate-900/90 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-600 flex items-center justify-center text-white font-black text-xl shadow-lg">
                  {report.score}%
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-lg font-black text-white">Підсумок рольової гри</h3>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      Рівень {report.assessedLevel}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400">
                    Оцінка комунікації, лексики та точності за стандартами CEFR
                  </p>
                </div>
              </div>

              <button
                onClick={() => setReport(null)}
                className="w-8 h-8 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Body */}
            <div className="flex-1 overflow-y-auto p-6 space-y-5">
              {/* Metrics Grid */}
              <div className="grid grid-cols-3 gap-2.5">
                <div className="p-3 rounded-2xl bg-slate-800/80 border border-slate-700 text-center space-y-1">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Цілі місій</span>
                  <span className="text-lg font-black text-emerald-400">{report.taskCompletionPercent}%</span>
                </div>
                <div className="p-3 rounded-2xl bg-slate-800/80 border border-slate-700 text-center space-y-1">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Плавність</span>
                  <span className="text-lg font-black text-sky-400">{report.fluencyScore}%</span>
                </div>
                <div className="p-3 rounded-2xl bg-slate-800/80 border border-slate-700 text-center space-y-1">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Граматика</span>
                  <span className="text-lg font-black text-indigo-400">{report.grammarScore}%</span>
                </div>
              </div>

              {/* Summary Text */}
              <div className="p-4 rounded-2xl bg-blue-500/10 border border-blue-500/20 space-y-1 text-xs">
                <span className="font-bold text-blue-300 block">Резюме лінгвіста:</span>
                <p className="text-slate-200 leading-relaxed">{report.overallSummaryUa}</p>
              </div>

              {/* Strengths */}
              {report.strengthsUa?.length > 0 && (
                <div className="space-y-2">
                  <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider block">
                    Ваші сильні сторони в діалозі:
                  </span>
                  <ul className="space-y-1.5 text-xs text-slate-300">
                    {report.strengthsUa.map((s, idx) => (
                      <li key={idx} className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                        <span>{s}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Mistakes analyzed */}
              {report.mistakesAnalyzed?.length > 0 && (
                <div className="space-y-2">
                  <span className="text-xs font-bold text-rose-400 uppercase tracking-wider block">
                    Помилки, над якими варто попрацювати:
                  </span>
                  <div className="space-y-2">
                    {report.mistakesAnalyzed.map((item, idx) => (
                      <div key={idx} className="p-3 rounded-xl bg-slate-800/70 border border-slate-700/80 text-xs space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="text-rose-400 line-through">«{item.userSaid}»</span>
                          <span className="text-slate-400">➔</span>
                          <span className="text-emerald-400 font-bold">«{item.correction}»</span>
                        </div>
                        <p className="text-slate-400 text-[11px]">{item.explanationUa}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Recommended Vocab */}
              {report.recommendedVocabulary?.length > 0 && (
                <div className="space-y-2">
                  <span className="text-xs font-bold text-amber-400 uppercase tracking-wider block">
                    Рекомендована лексика з цього діалогу:
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {report.recommendedVocabulary.map((item, idx) => (
                      <div key={idx} className="p-2.5 rounded-xl bg-slate-800/60 border border-slate-700 text-xs flex items-center justify-between">
                        <div>
                          <span className="font-bold text-white block">{item.en}</span>
                          <span className="text-[10px] text-slate-400">{item.ua}</span>
                        </div>
                        {onSaveWord && (
                          <button
                            onClick={() => {
                              onSaveWord({
                                eng: item.en,
                                ukr: item.ua,
                                ipa: '',
                                rule: 'Roleplay simulation vocabulary',
                              });
                              playSound('click');
                              onToast(`«${item.en}» додано до Скарбнички!`, 'success');
                            }}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-emerald-400 transition"
                            title="Зберегти в словник"
                          >
                            <BookmarkPlus className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="p-5 border-t border-slate-800 bg-slate-900 flex items-center justify-between gap-3 shrink-0">
              <button
                onClick={() => {
                  setReport(null);
                  if (selectedScenario) handleStartScenario(selectedScenario);
                }}
                className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Пройти ще раз</span>
              </button>

              <button
                onClick={() => {
                  setReport(null);
                  setSelectedScenario(null);
                }}
                className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-md transition cursor-pointer"
              >
                Обрати інший сценарій
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= MODAL: CUSTOM SCENARIO CREATOR ================= */}
      {isCustomModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
          <div className="bg-slate-900 border border-slate-700/80 rounded-3xl max-w-lg w-full p-6 sm:p-8 space-y-5 shadow-2xl">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-violet-600/20 text-violet-300 flex items-center justify-center">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-white">Власний сценарій для рольової гри</h3>
                  <p className="text-xs text-slate-400">Опишіть будь-яку життєву чи професійну ситуацію</p>
                </div>
              </div>
              <button
                onClick={() => setIsCustomModalOpen(false)}
                className="w-8 h-8 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-300 font-bold mb-1">
                  Тема або ситуація:
                </label>
                <input
                  type="text"
                  value={customTitle}
                  onChange={(e) => setCustomTitle(e.target.value)}
                  placeholder="наприклад: Оренда квартири або повернення товару в Apple Store"
                  className="w-full p-3 rounded-xl bg-slate-800 border border-slate-700 text-white focus:border-violet-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">
                  Роль співрозмовника (AI Character):
                </label>
                <input
                  type="text"
                  value={customRole}
                  onChange={(e) => setCustomRole(e.target.value)}
                  placeholder="наприклад: Рієлтор James або Консультант магазину"
                  className="w-full p-3 rounded-xl bg-slate-800 border border-slate-700 text-white focus:border-violet-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">
                  Місце дії (Location):
                </label>
                <input
                  type="text"
                  value={customLocation}
                  onChange={(e) => setCustomLocation(e.target.value)}
                  placeholder="наприклад: Лондон, Covent Garden або Zoom-дзвінок"
                  className="w-full p-3 rounded-xl bg-slate-800 border border-slate-700 text-white focus:border-violet-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">
                  Деталі та мета (опціонально):
                </label>
                <textarea
                  value={customDescription}
                  onChange={(e) => setCustomDescription(e.target.value)}
                  placeholder="Опишіть, чого ви хочете досягти в цьому діалозі..."
                  rows={2}
                  className="w-full p-3 rounded-xl bg-slate-800 border border-slate-700 text-white focus:border-violet-500 focus:outline-none"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setIsCustomModalOpen(false)}
                className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition cursor-pointer"
              >
                Скасувати
              </button>
              <button
                onClick={handleCreateCustomScenario}
                className="px-5 py-2.5 rounded-xl bg-violet-600 hover:bg-violet-500 text-white font-bold text-xs shadow-md transition cursor-pointer"
              >
                Розпочати рольову гру
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Microphone Diagnostic & Live Test Modal */}
      <MicrophoneDiagnosticModal
        isOpen={isMicDiagnosticOpen}
        onClose={() => setIsMicDiagnosticOpen(false)}
        selectedDeviceId={selectedDeviceId}
        onSelectDeviceId={setSelectedDeviceId}
      />
    </div>
  );
};
