import React, { useState } from 'react';
import {
  AlertTriangle,
  Sparkles,
  RotateCcw,
  CheckCircle2,
  Check,
  X,
  Volume2,
  ArrowRight,
  BookOpen,
  Layers,
  Brain,
  Repeat,
  Lightbulb,
  ShieldAlert,
  Play,
  Flame,
  Award,
  Trash2,
  Mic,
  VolumeX,
  Box,
  Eye,
  HelpCircle,
  Clock,
  Sparkle,
} from 'lucide-react';
import { MistakeRecord, SrsCard } from '../types';
import { playSound, speakEnglish, speakEnglishSlow } from '../utils/audio';
import { COMMON_MNEMONICS } from '../utils/mnemonics';

interface MistakesStudioProps {
  mistakes: MistakeRecord[];
  onUpdateMistakes: (updated: MistakeRecord[]) => void;
  onSendToSrs: (cards: SrsCard[]) => void;
  onRewardXP: (amount: number) => void;
  onToast: (msg: string, type: 'info' | 'success' | 'error') => void;
  onNavigateToTab: (tab: any) => void;
}

type StudioMode = 'browse' | 'shadowing' | 'leitner' | 'active_drill' | 'tile_builder';

export const MistakesStudio: React.FC<MistakesStudioProps> = ({
  mistakes,
  onUpdateMistakes,
  onSendToSrs,
  onRewardXP,
  onToast,
  onNavigateToTab,
}) => {
  const [activeMode, setActiveMode] = useState<StudioMode>('browse');
  const [filterType, setFilterType] = useState<'all' | 'unmastered' | 'mastered'>('unmastered');

  // Shadowing state: tracks vocalization step (0, 1, 2, 3) per mistake
  const [shadowingItemIndex, setShadowingItemIndex] = useState(0);
  const [oralRepetitions, setOralRepetitions] = useState<Record<string, number>>({});

  // Active Recall Drill State
  const [drillIndex, setDrillIndex] = useState(0);
  const [drillSelectedOption, setDrillSelectedOption] = useState<string | null>(null);
  const [drillOptions, setDrillOptions] = useState<string[]>([]);

  // Tile Builder State
  const [tileIndex, setTileIndex] = useState(0);
  const [availableTiles, setAvailableTiles] = useState<string[]>([]);
  const [selectedTiles, setSelectedTiles] = useState<string[]>([]);
  const [tileCheckStatus, setTileCheckStatus] = useState<'idle' | 'correct' | 'wrong'>('idle');

  // Leitner Boxes mapping: Box 1 (0 consecutive), Box 2 (1 consecutive), Box 3 (mastered >= 2)
  const unmasteredList = mistakes.filter((m) => !m.isMastered);
  const masteredList = mistakes.filter((m) => m.isMastered);

  const box1List = mistakes.filter((m) => !m.isMastered && (m.consecutiveCorrect || 0) === 0);
  const box2List = mistakes.filter((m) => !m.isMastered && (m.consecutiveCorrect || 0) === 1);
  const box3List = mistakes.filter((m) => m.isMastered);

  const displayList =
    filterType === 'all'
      ? mistakes
      : filterType === 'unmastered'
      ? unmasteredList
      : masteredList;

  // Generate 4 plausible options for active drill
  const initDrillQuestion = (index: number, list: MistakeRecord[]) => {
    if (list.length === 0 || index >= list.length) return;
    const current = list[index];
    const opts = new Set<string>();
    opts.add(current.correctAnswer);
    if (current.userWrongAnswer && current.userWrongAnswer !== current.correctAnswer) {
      opts.add(current.userWrongAnswer);
    }
    for (const m of list) {
      if (opts.size >= 4) break;
      if (m.correctAnswer !== current.correctAnswer) opts.add(m.correctAnswer);
    }
    const fallbacks = [
      'actual',
      'make a decision',
      'receipt',
      'sympathetic',
      'accurate',
      'sensible',
      'chef',
      'depend on',
    ];
    for (const fb of fallbacks) {
      if (opts.size >= 4) break;
      if (fb.toLowerCase() !== current.correctAnswer.toLowerCase()) opts.add(fb);
    }

    setDrillOptions(Array.from(opts).slice(0, 4).sort(() => 0.5 - Math.random()));
    setDrillSelectedOption(null);
  };

  const handleStartDrill = () => {
    if (unmasteredList.length === 0) {
      onToast('Всі помилки вже опановано! Чудова робота!', 'success');
      return;
    }
    playSound('click');
    setDrillIndex(0);
    initDrillQuestion(0, unmasteredList);
    setActiveMode('active_drill');
  };

  const handleSelectDrillAnswer = (opt: string) => {
    if (drillSelectedOption !== null || unmasteredList.length === 0) return;
    setDrillSelectedOption(opt);
    const current = unmasteredList[drillIndex];
    const isCorrect = opt.trim().toLowerCase() === current.correctAnswer.trim().toLowerCase();

    if (isCorrect) {
      playSound('correct');
      const nextConsecutive = (current.consecutiveCorrect || 0) + 1;
      const isNowMastered = nextConsecutive >= 2;

      const updated = mistakes.map((m) =>
        m.id === current.id
          ? {
              ...m,
              consecutiveCorrect: nextConsecutive,
              isMastered: isNowMastered,
            }
          : m
      );
      onUpdateMistakes(updated);
      onRewardXP(15);
      if (isNowMastered) {
        playSound('combo');
        onToast(`🎉 «${current.correctAnswer}» повністю засвоєно та закріплено! (+30 XP)`, 'success');
      }
    } else {
      playSound('wrong');
      const updated = mistakes.map((m) =>
        m.id === current.id
          ? {
              ...m,
              errorCount: m.errorCount + 1,
              consecutiveCorrect: 0,
            }
          : m
      );
      onUpdateMistakes(updated);
    }
  };

  const handleNextDrill = () => {
    playSound('click');
    const nextIdx = drillIndex + 1;
    if (nextIdx < unmasteredList.length) {
      setDrillIndex(nextIdx);
      initDrillQuestion(nextIdx, unmasteredList);
    } else {
      playSound('combo');
      onToast('Сесію експрес-розминки завершено!', 'success');
      setActiveMode('browse');
    }
  };

  // Tile Builder init
  const initTileBuilder = (index: number, list: MistakeRecord[]) => {
    if (list.length === 0 || index >= list.length) return;
    const current = list[index];
    const words = current.correctAnswer.split(' ');
    const distractors = ['do', 'not', 'have', 'the', 'to', 'for', 'about', 'with'];
    const extra = distractors.filter((d) => !words.includes(d)).slice(0, 2);
    const combined = [...words, ...extra].sort(() => 0.5 - Math.random());
    setAvailableTiles(combined);
    setSelectedTiles([]);
    setTileCheckStatus('idle');
  };

  const handleStartTileBuilder = () => {
    if (unmasteredList.length === 0) {
      onToast('Немає активних помилок для збирання плиток.', 'info');
      return;
    }
    playSound('click');
    setTileIndex(0);
    initTileBuilder(0, unmasteredList);
    setActiveMode('tile_builder');
  };

  const handleSelectTile = (word: string, fromIndex: number) => {
    playSound('click');
    setSelectedTiles((prev) => [...prev, word]);
    setAvailableTiles((prev) => prev.filter((_, i) => i !== fromIndex));
    setTileCheckStatus('idle');
  };

  const handleRemoveTile = (word: string, fromIndex: number) => {
    playSound('click');
    setAvailableTiles((prev) => [...prev, word]);
    setSelectedTiles((prev) => prev.filter((_, i) => i !== fromIndex));
    setTileCheckStatus('idle');
  };

  const handleCheckTileSentence = () => {
    const current = unmasteredList[tileIndex];
    const userBuilt = selectedTiles.join(' ').trim().toLowerCase();
    const target = current.correctAnswer.trim().toLowerCase();

    if (userBuilt === target) {
      playSound('correct');
      setTileCheckStatus('correct');
      onRewardXP(20);
      const nextConsecutive = (current.consecutiveCorrect || 0) + 1;
      const isNowMastered = nextConsecutive >= 2;
      const updated = mistakes.map((m) =>
        m.id === current.id
          ? {
              ...m,
              consecutiveCorrect: nextConsecutive,
              isMastered: isNowMastered,
            }
          : m
      );
      onUpdateMistakes(updated);
      onToast('Бездоганно! Структуру зібрано вірно (+20 XP)', 'success');
    } else {
      playSound('wrong');
      setTileCheckStatus('wrong');
    }
  };

  const handleNextTile = () => {
    playSound('click');
    const nextIdx = tileIndex + 1;
    if (nextIdx < unmasteredList.length) {
      setTileIndex(nextIdx);
      initTileBuilder(nextIdx, unmasteredList);
    } else {
      playSound('combo');
      onToast('Всі вправи з конструктора завершено!', 'success');
      setActiveMode('browse');
    }
  };

  // Shadowing & Vocalization mode
  const handleStartShadowing = () => {
    if (unmasteredList.length === 0) {
      onToast('Всі помилки вже засвоєно! Спробуйте переглянути всі картки.', 'info');
      return;
    }
    playSound('click');
    setShadowingItemIndex(0);
    setActiveMode('shadowing');
  };

  const handleStepShadowingRepetition = (id: string) => {
    playSound('click');
    const currentReps = oralRepetitions[id] || 0;
    const nextReps = currentReps + 1;
    setOralRepetitions((prev) => ({ ...prev, [id]: nextReps }));

    if (nextReps >= 3) {
      playSound('combo');
      onRewardXP(20);
      const current = mistakes.find((m) => m.id === id);
      if (current) {
        const nextConsecutive = (current.consecutiveCorrect || 0) + 1;
        const updated = mistakes.map((m) =>
          m.id === id
            ? {
                ...m,
                consecutiveCorrect: nextConsecutive,
                isMastered: nextConsecutive >= 2,
              }
            : m
        );
        onUpdateMistakes(updated);
      }
      onToast('🎉 3-кратне оральне відтворення завершено! Моторна пам\'ять активована (+20 XP)', 'success');
    }
  };

  // Leitner manual advancement
  const handlePromoteLeitnerBox = (item: MistakeRecord) => {
    playSound('combo');
    const nextConsecutive = (item.consecutiveCorrect || 0) + 1;
    const isNowMastered = nextConsecutive >= 2;
    const updated = mistakes.map((m) =>
      m.id === item.id
        ? {
            ...m,
            consecutiveCorrect: nextConsecutive,
            isMastered: isNowMastered,
          }
        : m
    );
    onUpdateMistakes(updated);
    onRewardXP(15);
    onToast(
      isNowMastered
        ? `⭐ «${item.correctAnswer}» переведено до Скриньки 3 (Повністю засвоєно)!`
        : `📦 «${item.correctAnswer}» переведено до Скриньки 2 (Закріплення)!`,
      'success'
    );
  };

  const handleDemoteLeitnerBox = (item: MistakeRecord) => {
    playSound('wrong');
    const updated = mistakes.map((m) =>
      m.id === item.id
        ? {
            ...m,
            consecutiveCorrect: 0,
            isMastered: false,
            errorCount: m.errorCount + 1,
          }
        : m
    );
    onUpdateMistakes(updated);
    onToast(`«${item.correctAnswer}» повернено до Скриньки 1 (Потребує повторення)`, 'info');
  };

  // Export all unmastered to SRS
  const handleExportAllToSrs = () => {
    const listToExport = unmasteredList.length > 0 ? unmasteredList : mistakes;
    const cards: SrsCard[] = listToExport.map((m) => ({
      word: {
        ukr: m.prompt,
        eng: m.correctAnswer,
        ipa: '',
        rule: m.explanation,
        trap: m.mnemonicHint,
        category: m.category || 'mistakes',
      },
      intervalDays: 1,
      repetitions: 0,
      easeFactor: 2.3,
      dueDate: Date.now(),
      lastReviewed: Date.now(),
      box: 1,
    }));
    onSendToSrs(cards);
    playSound('combo');
    onToast(`📥 ${cards.length} складних елементів додано до системи інтервального повторення (SRS)!`, 'success');
  };

  // Seed sample common false friend traps if empty
  const handleSeedSampleTraps = () => {
    const samples: MistakeRecord[] = [
      {
        id: 'trap-actual',
        type: 'vocab',
        prompt: 'Оберіть правильний переклад слова «Actual»',
        userWrongAnswer: 'Актуальний',
        correctAnswer: 'actual (фактичний, реальний)',
        explanation: '«Actual» означає реальний/дійсний. Актуальний англійською — «relevant» або «current».',
        mnemonicHint: '«Actual» — це ACT (дія), тобто ФАКТИЧНИЙ! Актуальний — це «relevant».',
        category: '⚠️ Фальшиві друзі (Пастки)',
        errorCount: 2,
        consecutiveCorrect: 0,
        isMastered: false,
        lastMistakeTimestamp: Date.now(),
      },
      {
        id: 'trap-receipt',
        type: 'vocab',
        prompt: 'Після оплати покупки в магазині касир видає вам:',
        userWrongAnswer: 'recipe',
        correctAnswer: 'receipt',
        explanation: '«Receipt» — це фіскальний чек/квитанція. «Recipe» — це кулінарний рецепт!',
        mnemonicHint: '«Receipt» має тиху букву «p» і означає ЧЕК або квитанцію! А кулінарний рецепт — «recipe»!',
        category: '⚠️ Фальшиві друзі (Пастки)',
        errorCount: 1,
        consecutiveCorrect: 0,
        isMastered: false,
        lastMistakeTimestamp: Date.now(),
      },
      {
        id: 'trap-sympathetic',
        type: 'vocab',
        prompt: 'The word «Sympathetic» in formal English means:',
        userWrongAnswer: 'Симпатичний (вродливий)',
        correctAnswer: 'sympathetic (співчутливий)',
        explanation: '«Sympathetic» означає співчутливий. Привабливий / симпатичний — «attractive» або «cute».',
        mnemonicHint: '«Sympathy» = СПІВЧУТТЯ! Sympathetic — це той, хто щиро співчуває та розуміє біль іншого.',
        category: '⚠️ Фальшиві друзі (Пастки)',
        errorCount: 1,
        consecutiveCorrect: 0,
        isMastered: false,
        lastMistakeTimestamp: Date.now(),
      },
      {
        id: 'trap-make-decision',
        type: 'vocab',
        prompt: 'We need to ___ an important business decision.',
        userWrongAnswer: 'do',
        correctAnswer: 'make a decision',
        explanation: 'Рішення створюють з нуля, тому завжди «MAKE a decision», ніколи не «do».',
        mnemonicHint: 'Формула: MAKE для створення нового результату (make a decision, make a mistake). DO — для рутини (do homework).',
        category: 'Колокації Make vs Do',
        errorCount: 2,
        consecutiveCorrect: 0,
        isMastered: false,
        lastMistakeTimestamp: Date.now(),
      },
      {
        id: 'trap-eventually',
        type: 'vocab',
        prompt: 'After hours of debugging, the app ___ started working.',
        userWrongAnswer: 'possibly',
        correctAnswer: 'eventually',
        explanation: '«Eventually» означає «зрештою, кінець кінцем». У разі можливості — «possibly».',
        mnemonicHint: 'Event = подія добігла кінця! Eventually — це щасливе «зрештою / врешті-решт»!',
        category: '⚠️ Фальшиві друзі (Пастки)',
        errorCount: 1,
        consecutiveCorrect: 0,
        isMastered: false,
        lastMistakeTimestamp: Date.now(),
      },
    ];

    onUpdateMistakes([...mistakes, ...samples]);
    playSound('combo');
    onToast('Завантажено тренувальний набір підступних слів-пасток для опрацювання!', 'success');
  };

  const handleClearAllMistakes = () => {
    playSound('click');
    onUpdateMistakes([]);
    onToast('Список помилок очищено', 'info');
  };

  return (
    <section className="space-y-6">
      {/* Hero Header */}
      <div className="bg-gradient-to-br from-slate-900 via-rose-950/40 to-slate-900 rounded-3xl border border-rose-500/30 p-6 sm:p-8 shadow-2xl space-y-5 relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-3 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30 text-xs font-bold">
              <Brain className="w-3.5 h-3.5 text-amber-400" />
              <span>Смарт-система подолання помилок (5 світових методик пам'яті)</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              Студія подолання помилок & Мнемонічні зачіпки
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              Додаток запам'ятовує ваші помилки з тестів CEFR, тренажера та конструктора SVOMPT.
              Оберіть найзручніший для вашого мозку метод легкого запам'ятовування:
              <strong> Мнемонічні образи</strong>, <strong>Оральне Shadowing 3x</strong>,
              <strong> Скриньки Лейтнера (SRS)</strong>, <strong>Експрес-розминку</strong> чи <strong>Конструктор плиток</strong>.
            </p>
          </div>

          {/* Quick Metrics */}
          <div className="flex gap-2 sm:gap-3 flex-wrap">
            <div className="p-3.5 rounded-2xl bg-slate-800/80 border border-rose-500/30 text-center min-w-[90px]">
              <span className="text-[10px] text-slate-400 block mb-1">Потребують уваги</span>
              <span className="text-2xl font-black text-rose-400">{unmasteredList.length}</span>
            </div>
            <div className="p-3.5 rounded-2xl bg-slate-800/80 border border-amber-500/30 text-center min-w-[90px]">
              <span className="text-[10px] text-slate-400 block mb-1">На закріпленні</span>
              <span className="text-2xl font-black text-amber-400">{box2List.length}</span>
            </div>
            <div className="p-3.5 rounded-2xl bg-slate-800/80 border border-emerald-500/30 text-center min-w-[90px]">
              <span className="text-[10px] text-slate-400 block mb-1">Засвоєно</span>
              <span className="text-2xl font-black text-emerald-400">{masteredList.length}</span>
            </div>
          </div>
        </div>

        {/* 5 Distinct Cognitive Methodology Launchers */}
        <div className="pt-2 flex flex-wrap items-center gap-2 border-t border-slate-800/80">
          <button
            onClick={() => setActiveMode('browse')}
            className={`px-3.5 py-2.5 rounded-xl font-bold text-xs flex items-center gap-2 transition cursor-pointer ${
              activeMode === 'browse'
                ? 'bg-rose-600 text-white shadow-lg shadow-rose-500/25 ring-2 ring-rose-400'
                : 'bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white'
            }`}
          >
            <Lightbulb className="w-4 h-4 text-amber-300" />
            <span>1. Мнемонічні зачіпки</span>
          </button>

          <button
            onClick={handleStartShadowing}
            className={`px-3.5 py-2.5 rounded-xl font-bold text-xs flex items-center gap-2 transition cursor-pointer ${
              activeMode === 'shadowing'
                ? 'bg-sky-600 text-white shadow-lg shadow-sky-500/25 ring-2 ring-sky-400'
                : 'bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white'
            }`}
          >
            <Mic className="w-4 h-4 text-sky-300" />
            <span>2. Shadowing & Вимова (3x)</span>
          </button>

          <button
            onClick={() => setActiveMode('leitner')}
            className={`px-3.5 py-2.5 rounded-xl font-bold text-xs flex items-center gap-2 transition cursor-pointer ${
              activeMode === 'leitner'
                ? 'bg-amber-600 text-white shadow-lg shadow-amber-500/25 ring-2 ring-amber-400'
                : 'bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white'
            }`}
          >
            <Box className="w-4 h-4 text-amber-300" />
            <span>3. Скриньки Лейтнера (SRS)</span>
          </button>

          <button
            onClick={handleStartDrill}
            disabled={unmasteredList.length === 0}
            className={`px-3.5 py-2.5 rounded-xl font-bold text-xs flex items-center gap-2 transition cursor-pointer ${
              activeMode === 'active_drill'
                ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/25 ring-2 ring-blue-400'
                : 'bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white disabled:opacity-40'
            }`}
          >
            <Play className="w-4 h-4 fill-current text-sky-400" />
            <span>4. Експрес-розминка ({unmasteredList.length})</span>
          </button>

          <button
            onClick={handleStartTileBuilder}
            disabled={unmasteredList.length === 0}
            className={`px-3.5 py-2.5 rounded-xl font-bold text-xs flex items-center gap-2 transition cursor-pointer ${
              activeMode === 'tile_builder'
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/25 ring-2 ring-indigo-400'
                : 'bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white disabled:opacity-40'
            }`}
          >
            <Layers className="w-4 h-4 text-indigo-400" />
            <span>5. Конструктор плиток</span>
          </button>

          {unmasteredList.length > 0 && (
            <button
              onClick={handleExportAllToSrs}
              className="ml-auto px-3.5 py-2.5 rounded-xl bg-slate-800/80 hover:bg-emerald-950/60 border border-slate-700 hover:border-emerald-500/40 text-emerald-400 font-bold text-xs flex items-center gap-2 transition cursor-pointer"
            >
              <Repeat className="w-4 h-4" />
              <span>Експорт до черги SRS</span>
            </button>
          )}
        </div>
      </div>

      {/* Mode 1: Browse Mnemonic Cards */}
      {activeMode === 'browse' && (
        <div className="space-y-4">
          {/* Filter Pills Bar */}
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div className="flex items-center gap-2">
              <button
                onClick={() => setFilterType('unmastered')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                  filterType === 'unmastered'
                    ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                    : 'bg-slate-800/60 text-slate-400 hover:text-white'
                }`}
              >
                Активні складні ({unmasteredList.length})
              </button>
              <button
                onClick={() => setFilterType('mastered')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                  filterType === 'mastered'
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    : 'bg-slate-800/60 text-slate-400 hover:text-white'
                }`}
              >
                Опановані ({masteredList.length})
              </button>
              <button
                onClick={() => setFilterType('all')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                  filterType === 'all'
                    ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                    : 'bg-slate-800/60 text-slate-400 hover:text-white'
                }`}
              >
                Всі ({mistakes.length})
              </button>
            </div>

            <div className="flex items-center gap-3">
              {mistakes.length === 0 && (
                <button
                  onClick={handleSeedSampleTraps}
                  className="text-xs text-amber-400 hover:text-amber-300 font-bold flex items-center gap-1.5 transition cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Завантажити демо-пастки</span>
                </button>
              )}
              {mistakes.length > 0 && (
                <button
                  onClick={handleClearAllMistakes}
                  className="text-xs text-slate-500 hover:text-rose-400 flex items-center gap-1 transition cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Очистити список</span>
                </button>
              )}
            </div>
          </div>

          {/* Empty State */}
          {displayList.length === 0 && (
            <div className="p-8 sm:p-12 rounded-3xl bg-slate-900 border border-slate-800 text-center space-y-4">
              <div className="w-16 h-16 rounded-2xl bg-emerald-950/60 border border-emerald-500/30 text-emerald-400 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <div className="space-y-1">
                <h3 className="text-lg font-bold text-white">
                  {filterType === 'unmastered'
                    ? 'Чудово! Немає незасвоєних помилок'
                    : 'Список помилок порожній'}
                </h3>
                <p className="text-xs text-slate-400 max-w-md mx-auto">
                  Коли ви робите помилку в тестах рівня чи тренажері, додаток
                  автоматично фіксує її тут, генерує асоціативний гачок пам'яті та тренує її повторно.
                </p>
              </div>

              <div className="pt-2 flex flex-wrap justify-center gap-3">
                <button
                  onClick={handleSeedSampleTraps}
                  className="px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center gap-2 transition cursor-pointer shadow-lg shadow-rose-500/20"
                >
                  <Sparkles className="w-4 h-4 text-amber-300" />
                  <span>Завантажити тренувальні слова-пастки (False Friends)</span>
                </button>
                <button
                  onClick={() => onNavigateToTab('quiz')}
                  className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs transition cursor-pointer"
                >
                  Перейти до тренажера слів
                </button>
              </div>
            </div>
          )}

          {/* Cards List */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {displayList.map((item) => {
              const hookData = Object.values(COMMON_MNEMONICS).find(
                (h) =>
                  item.correctAnswer.toLowerCase().includes(h.key) ||
                  item.prompt.toLowerCase().includes(h.key)
              );

              return (
                <div
                  key={item.id}
                  className={`p-5 rounded-3xl border transition flex flex-col justify-between space-y-4 ${
                    item.isMastered
                      ? 'bg-slate-900/80 border-emerald-500/40'
                      : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="space-y-3">
                    {/* Card Header Status */}
                    <div className="flex items-center justify-between text-xs">
                      <span className="px-2.5 py-0.5 rounded-md bg-slate-800 border border-slate-700 text-[10px] font-extrabold uppercase text-indigo-400">
                        {item.category || 'Помилка'}
                      </span>
                      {item.isMastered ? (
                        <span className="text-emerald-400 font-bold text-[11px] flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" /> Опановано (Скринька 3)
                        </span>
                      ) : (
                        <span className="text-rose-400 font-semibold text-[11px] flex items-center gap-1">
                          <AlertTriangle className="w-3.5 h-3.5" /> Помилок: {item.errorCount} • Прогрес: {item.consecutiveCorrect || 0}/2
                        </span>
                      )}
                    </div>

                    {/* Context / Prompt */}
                    <div className="space-y-1">
                      <span className="text-[11px] text-slate-400 font-medium">Контекст / Запитання:</span>
                      <p className="text-sm font-bold text-white">{item.prompt}</p>
                    </div>

                    {/* Side-by-side Contrast Wrong vs Correct */}
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div className="p-2.5 rounded-xl bg-rose-950/30 border border-rose-500/30">
                        <span className="text-[10px] text-rose-400 block font-bold">Ваша помилка:</span>
                        <span className="font-semibold text-rose-300 line-through">
                          {item.userWrongAnswer || 'Хибний варіант'}
                        </span>
                      </div>
                      <div className="p-2.5 rounded-xl bg-emerald-950/30 border border-emerald-500/30">
                        <span className="text-[10px] text-emerald-400 block font-bold">Правильно:</span>
                        <span className="font-bold text-emerald-300">
                          {item.correctAnswer}
                        </span>
                      </div>
                    </div>

                    {/* Explanation */}
                    {item.explanation && (
                      <div className="text-xs text-slate-300 bg-slate-800/40 p-2.5 rounded-xl border border-slate-800">
                        <span className="text-slate-400 block text-[10px] uppercase font-bold">Чому це так:</span>
                        {item.explanation}
                      </div>
                    )}

                    {/* Mnemonic Hook Anchor */}
                    <div className="p-3.5 rounded-2xl bg-amber-950/30 border border-amber-500/30 space-y-1.5">
                      <div className="flex items-center gap-1.5 text-[11px] font-bold text-amber-300">
                        <Lightbulb className="w-3.5 h-3.5" />
                        <span>Мнемонічний гачок пам'яті (Як легко запам'ятати):</span>
                      </div>
                      <p className="text-xs text-amber-100/90 leading-relaxed font-medium">
                        {item.mnemonicHint}
                      </p>
                      {hookData?.visualImage && (
                        <div className="pt-1 text-[11px] text-amber-200/80 italic flex items-start gap-1">
                          <Eye className="w-3 h-3 shrink-0 mt-0.5 text-amber-400" />
                          <span>Уявіть у голові: {hookData.visualImage}</span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Audio and Mastery Actions */}
                  <div className="pt-2 flex items-center justify-between border-t border-slate-800 gap-2">
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => speakEnglish(item.correctAnswer)}
                        className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition cursor-pointer flex items-center gap-1 text-xs"
                        title="Звичайна вимова"
                      >
                        <Volume2 className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-[10px] font-bold">1.0x</span>
                      </button>
                      <button
                        onClick={() => speakEnglishSlow(item.correctAnswer)}
                        className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition cursor-pointer flex items-center gap-1 text-xs"
                        title="Повільна вимова (для складних звуків)"
                      >
                        <Volume2 className="w-3.5 h-3.5 text-sky-400" />
                        <span className="text-[10px] font-bold">0.7x</span>
                      </button>
                    </div>

                    <div className="flex items-center gap-2">
                      {!item.isMastered ? (
                        <button
                          onClick={() => {
                            playSound('combo');
                            const updated = mistakes.map((m) =>
                              m.id === item.id ? { ...m, isMastered: true, consecutiveCorrect: 2 } : m
                            );
                            onUpdateMistakes(updated);
                            onRewardXP(25);
                            onToast(`Позначено як засвоєне! (+25 XP)`, 'success');
                          }}
                          className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-emerald-950 text-slate-300 hover:text-emerald-300 border border-slate-700 hover:border-emerald-500/40 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>Засвоєно (+25 XP)</span>
                        </button>
                      ) : (
                        <button
                          onClick={() => {
                            playSound('click');
                            const updated = mistakes.map((m) =>
                              m.id === item.id ? { ...m, isMastered: false, consecutiveCorrect: 0 } : m
                            );
                            onUpdateMistakes(updated);
                            onToast(`Повернуто на повторення`, 'info');
                          }}
                          className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-rose-950/60 text-slate-400 hover:text-rose-300 text-xs font-medium transition cursor-pointer"
                        >
                          Повторити знову
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Mode 2: Oral Shadowing & Vocalization 3x */}
      {activeMode === 'shadowing' && (
        <div className="max-w-2xl mx-auto bg-slate-900 rounded-3xl border border-sky-500/30 p-6 sm:p-8 shadow-2xl space-y-6">
          <div className="flex items-center justify-between text-xs font-bold text-slate-400 border-b border-slate-800 pb-3">
            <span className="flex items-center gap-2 text-sky-400">
              <Mic className="w-4 h-4" />
              <span>Метод Shadowing: прослухай та повтори вголос 3 рази</span>
            </span>
            <button
              onClick={() => setActiveMode('browse')}
              className="text-slate-400 hover:text-white transition"
            >
              ✕ Закрити
            </button>
          </div>

          {unmasteredList.length === 0 ? (
            <div className="text-center py-8 space-y-3">
              <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto" />
              <p className="text-white font-bold">Всі помилки закріплено!</p>
              <button
                onClick={() => setActiveMode('browse')}
                className="px-4 py-2 rounded-xl bg-blue-600 text-white font-bold text-xs"
              >
                Повернутися до карток
              </button>
            </div>
          ) : (
            (() => {
              const item = unmasteredList[shadowingItemIndex] || unmasteredList[0];
              const reps = oralRepetitions[item.id] || 0;

              return (
                <div className="space-y-6">
                  <div className="space-y-2 text-center">
                    <span className="text-[11px] font-bold uppercase text-sky-400 tracking-wider">
                      Картка {shadowingItemIndex + 1} з {unmasteredList.length} • {item.category}
                    </span>
                    <h3 className="text-lg font-bold text-slate-300">{item.prompt}</h3>
                    <div className="py-2">
                      <span className="text-3xl sm:text-4xl font-black text-white tracking-tight">
                        «{item.correctAnswer}»
                      </span>
                    </div>
                    <p className="text-xs text-amber-300 font-medium">{item.mnemonicHint}</p>
                  </div>

                  {/* Audio Speed Controls */}
                  <div className="flex justify-center gap-3">
                    <button
                      onClick={() => speakEnglish(item.correctAnswer)}
                      className="px-4 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs flex items-center gap-2 transition cursor-pointer shadow-lg shadow-sky-600/25"
                    >
                      <Volume2 className="w-4 h-4" />
                      <span>Слухати нормальний темп (1.0x)</span>
                    </button>
                    <button
                      onClick={() => speakEnglishSlow(item.correctAnswer)}
                      className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs flex items-center gap-2 border border-slate-700 transition cursor-pointer"
                    >
                      <Volume2 className="w-4 h-4 text-amber-300" />
                      <span>Повільно (0.7x)</span>
                    </button>
                  </div>

                  {/* 3x Oral repetition counter buttons */}
                  <div className="p-5 rounded-2xl bg-slate-800/80 border border-slate-700/80 space-y-3 text-center">
                    <span className="text-xs font-bold text-slate-300 block">
                      Крок: вимовте це слово/речення чітко вголос 3 рази:
                    </span>
                    <div className="flex justify-center items-center gap-3">
                      {[1, 2, 3].map((num) => {
                        const isDone = reps >= num;
                        return (
                          <button
                            key={num}
                            onClick={() => {
                              if (reps < num) handleStepShadowingRepetition(item.id);
                            }}
                            className={`w-12 h-12 rounded-2xl font-black text-sm flex items-center justify-center transition cursor-pointer ${
                              isDone
                                ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/30'
                                : reps === num - 1
                                ? 'bg-sky-600 text-white animate-pulse ring-2 ring-sky-300'
                                : 'bg-slate-700 text-slate-400'
                            }`}
                          >
                            {isDone ? <Check className="w-5 h-5" /> : `${num}x`}
                          </button>
                        );
                      })}
                    </div>
                    <span className="text-[11px] text-slate-400 block">
                      {reps === 0 && 'Натисніть «1x» після першого проголошення вголос'}
                      {reps === 1 && 'Чудово! Вимовте ще раз і натисніть «2x»'}
                      {reps === 2 && 'Ще один раз! Натисніть «3x» для закріплення в пам\'яті'}
                      {reps >= 3 && '✓ Відмінно! Моторна мовна зона мозку зафіксувала патерн!'}
                    </span>
                  </div>

                  {/* Navigation */}
                  <div className="flex justify-between items-center pt-2">
                    <button
                      disabled={shadowingItemIndex === 0}
                      onClick={() => setShadowingItemIndex((i) => Math.max(0, i - 1))}
                      className="px-3 py-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white text-xs font-bold disabled:opacity-40"
                    >
                      ← Попередня
                    </button>
                    <button
                      onClick={() => {
                        if (shadowingItemIndex + 1 < unmasteredList.length) {
                          setShadowingItemIndex((i) => i + 1);
                        } else {
                          playSound('combo');
                          onToast('Всі картки для shadowing опрацьовано!', 'success');
                          setActiveMode('browse');
                        }
                      }}
                      className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center gap-1.5"
                    >
                      <span>Наступна картка</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })()
          )}
        </div>
      )}

      {/* Mode 3: 3-Box Leitner System */}
      {activeMode === 'leitner' && (
        <div className="space-y-6">
          <div className="p-4 rounded-2xl bg-amber-950/30 border border-amber-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <div className="space-y-1">
              <h4 className="font-bold text-amber-200 flex items-center gap-1.5">
                <Box className="w-4 h-4 text-amber-400" />
                <span>Система 3 Скриньок Себастьяна Лейтнера (Spaced Interval Learning)</span>
              </h4>
              <p className="text-slate-300 text-[11px]">
                Скринька 1: свіжі помилки (повторюємо щодня). Скринька 2: закріплені (через 3 дні). Скринька 3: опановані (довготривала пам'ять).
              </p>
            </div>
            <button
              onClick={handleExportAllToSrs}
              className="px-3.5 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs whitespace-nowrap transition cursor-pointer self-start sm:self-auto"
            >
              Синхронізувати з SRS →
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
            {/* Box 1 */}
            <div className="rounded-3xl bg-slate-900 border border-rose-500/40 p-5 space-y-4 flex flex-col justify-between">
              <div className="space-y-3">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-rose-500/20 text-rose-400 flex items-center justify-center font-bold text-xs">
                      1
                    </div>
                    <span className="font-bold text-sm text-white">Скринька 1 (Щодня)</span>
                  </div>
                  <span className="px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 text-xs font-black">
                    {box1List.length}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">
                  Помилки, що потребують щоденної уваги та мнемонічних асоціацій.
                </p>

                <div className="space-y-2 max-h-[420px] overflow-y-auto pr-1">
                  {box1List.length === 0 ? (
                    <div className="text-center py-8 text-xs text-slate-500">
                      Скринька порожня! Всі помилки на вищому рівні.
                    </div>
                  ) : (
                    box1List.map((m) => (
                      <div
                        key={m.id}
                        className="p-3 rounded-2xl bg-slate-800/80 border border-slate-700/80 space-y-2 text-xs"
                      >
                        <div className="flex justify-between font-bold">
                          <span className="text-white">{m.correctAnswer}</span>
                          <span className="text-rose-400 text-[10px]">Помилок: {m.errorCount}</span>
                        </div>
                        <p className="text-[11px] text-slate-400">{m.prompt}</p>
                        <div className="flex items-center justify-between pt-1">
                          <button
                            onClick={() => speakEnglish(m.correctAnswer)}
                            className="text-slate-400 hover:text-white"
                          >
                            <Volume2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handlePromoteLeitnerBox(m)}
                            className="px-2.5 py-1 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-[10px] flex items-center gap-1 cursor-pointer"
                          >
                            <span>В Скриньку 2</span>
                            <ArrowRight className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>

            {/* Box 2 */}
            <div className="rounded-3xl bg-slate-900 border border-amber-500/40 p-5 space-y-4 flex flex-col justify-between">
              <div className="space-y-3">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-xs">
                      2
                    </div>
                    <span className="font-bold text-sm text-white">Скринька 2 (Через 3 дні)</span>
                  </div>
                  <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-xs font-black">
                    {box2List.length}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">
                  Матеріал на стадії закріплення. Правильно відтворено 1 раз поспіль.
                </p>

                <div className="space-y-2 max-h-[420px] overflow-y-auto pr-1">
                  {box2List.length === 0 ? (
                    <div className="text-center py-8 text-xs text-slate-500">
                      Немає елементів на проміжному етапі.
                    </div>
                  ) : (
                    box2List.map((m) => (
                      <div
                        key={m.id}
                        className="p-3 rounded-2xl bg-slate-800/80 border border-slate-700/80 space-y-2 text-xs"
                      >
                        <div className="flex justify-between font-bold">
                          <span className="text-white">{m.correctAnswer}</span>
                          <span className="text-amber-400 text-[10px]">Прогрес: 1/2</span>
                        </div>
                        <p className="text-[11px] text-slate-400">{m.prompt}</p>
                        <div className="flex items-center justify-between pt-1">
                          <button
                            onClick={() => handleDemoteLeitnerBox(m)}
                            className="text-rose-400 hover:text-rose-300 text-[10px]"
                          >
                            ← В Скриньку 1
                          </button>
                          <button
                            onClick={() => handlePromoteLeitnerBox(m)}
                            className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[10px] flex items-center gap-1 cursor-pointer"
                          >
                            <span>В Скриньку 3</span>
                            <ArrowRight className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>

            {/* Box 3 */}
            <div className="rounded-3xl bg-slate-900 border border-emerald-500/40 p-5 space-y-4 flex flex-col justify-between">
              <div className="space-y-3">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-xs">
                      3
                    </div>
                    <span className="font-bold text-sm text-white">Скринька 3 (Опановано)</span>
                  </div>
                  <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-black">
                    {box3List.length}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">
                  Довготривала пам'ять. Складність успішно подолано!
                </p>

                <div className="space-y-2 max-h-[420px] overflow-y-auto pr-1">
                  {box3List.length === 0 ? (
                    <div className="text-center py-8 text-xs text-slate-500">
                      Ще немає завершених карток. Продовжуйте тренування!
                    </div>
                  ) : (
                    box3List.map((m) => (
                      <div
                        key={m.id}
                        className="p-3 rounded-2xl bg-emerald-950/20 border border-emerald-500/30 space-y-1.5 text-xs"
                      >
                        <div className="flex justify-between font-bold">
                          <span className="text-emerald-300">{m.correctAnswer}</span>
                          <span className="text-emerald-400 text-[10px]">✓ Засвоєно</span>
                        </div>
                        <p className="text-[11px] text-slate-400">{m.prompt}</p>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Mode 4: Active Recall Drill */}
      {activeMode === 'active_drill' && unmasteredList.length > 0 && (
        <div className="max-w-2xl mx-auto bg-slate-900 rounded-3xl border border-slate-800 p-6 sm:p-8 shadow-2xl space-y-6">
          <div className="flex items-center justify-between text-xs font-bold text-slate-400 border-b border-slate-800 pb-3">
            <span className="flex items-center gap-2 text-blue-400">
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>Експрес-розминка помилок</span>
            </span>
            <span className="font-mono">
              Питання {drillIndex + 1} з {unmasteredList.length}
            </span>
          </div>

          {drillIndex < unmasteredList.length && (
            <div className="space-y-5">
              <div className="text-center space-y-2">
                <span className="text-xs uppercase text-slate-400 font-bold">
                  {unmasteredList[drillIndex].category || 'Помилка'}
                </span>
                <h3 className="text-xl sm:text-2xl font-black text-white">
                  {unmasteredList[drillIndex].prompt}
                </h3>
              </div>

              {/* 4 Interactive Choices */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {drillOptions.map((opt, idx) => {
                  const current = unmasteredList[drillIndex];
                  const isSelected = drillSelectedOption === opt;
                  const isCorrect = opt.trim().toLowerCase() === current.correctAnswer.trim().toLowerCase();

                  let btnCls =
                    'p-4 rounded-2xl border text-sm font-bold text-left transition flex items-center justify-between ';
                  if (drillSelectedOption === null) {
                    btnCls += 'bg-slate-800 border-slate-700 hover:border-blue-500 text-white cursor-pointer';
                  } else if (isCorrect) {
                    btnCls += 'bg-emerald-950/70 border-emerald-500 text-emerald-300';
                  } else if (isSelected && !isCorrect) {
                    btnCls += 'bg-rose-950/70 border-rose-500 text-rose-300';
                  } else {
                    btnCls += 'bg-slate-800/40 border-slate-800 text-slate-500 opacity-60';
                  }

                  return (
                    <button
                      key={idx}
                      disabled={drillSelectedOption !== null}
                      onClick={() => handleSelectDrillAnswer(opt)}
                      className={btnCls}
                    >
                      <span>{opt}</span>
                      {drillSelectedOption !== null && isCorrect && (
                        <Check className="w-4 h-4 text-emerald-400" />
                      )}
                      {drillSelectedOption !== null && isSelected && !isCorrect && (
                        <X className="w-4 h-4 text-rose-400" />
                      )}
                    </button>
                  );
                })}
              </div>

              {/* Mnemonic feedback on answer */}
              {drillSelectedOption !== null && (
                <div className="p-4 rounded-2xl bg-amber-950/40 border border-amber-500/30 space-y-1">
                  <span className="text-xs font-bold text-amber-300 block">Мнемонічне нагадування:</span>
                  <p className="text-xs text-amber-100/90 leading-relaxed">
                    {unmasteredList[drillIndex].mnemonicHint}
                  </p>
                </div>
              )}

              {drillSelectedOption !== null && (
                <div className="flex justify-end pt-2">
                  <button
                    onClick={handleNextDrill}
                    className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center gap-1.5 transition cursor-pointer"
                  >
                    <span>Наступне питання</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Mode 5: Tile Builder */}
      {activeMode === 'tile_builder' && unmasteredList.length > 0 && (
        <div className="max-w-2xl mx-auto bg-slate-900 rounded-3xl border border-slate-800 p-6 sm:p-8 shadow-2xl space-y-6">
          <div className="flex items-center justify-between text-xs font-bold text-slate-400 border-b border-slate-800 pb-3">
            <span className="flex items-center gap-2 text-indigo-400">
              <Layers className="w-3.5 h-3.5" />
              <span>Конструктор плиток (Виправлення структури)</span>
            </span>
            <span className="font-mono">
              Вправа {tileIndex + 1} з {unmasteredList.length}
            </span>
          </div>

          <div className="space-y-4">
            <div className="text-center space-y-1">
              <span className="text-xs font-bold text-slate-400">Зберіть правильну відповідь із плиток:</span>
              <h3 className="text-lg sm:text-xl font-bold text-white">
                {unmasteredList[tileIndex].prompt}
              </h3>
            </div>

            {/* Target Assembly Area */}
            <div className="min-h-[70px] p-4 rounded-2xl bg-slate-800/80 border-2 border-dashed border-slate-700 flex flex-wrap gap-2 items-center justify-center">
              {selectedTiles.length === 0 ? (
                <span className="text-xs text-slate-500">Клацніть на плитки нижче в потрібному порядку</span>
              ) : (
                selectedTiles.map((tile, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleRemoveTile(tile, idx)}
                    className="px-3.5 py-1.5 rounded-xl bg-blue-600 text-white font-bold text-xs transition hover:bg-rose-600 cursor-pointer shadow-md"
                  >
                    {tile}
                  </button>
                ))
              )}
            </div>

            {/* Available Tiles */}
            <div className="flex flex-wrap gap-2 justify-center pt-2">
              {availableTiles.map((tile, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSelectTile(tile, idx)}
                  className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-bold text-xs transition cursor-pointer"
                >
                  {tile}
                </button>
              ))}
            </div>

            {/* Check Controls */}
            <div className="flex items-center justify-between pt-4 border-t border-slate-800">
              <button
                onClick={() => initTileBuilder(tileIndex, unmasteredList)}
                className="text-xs text-slate-400 hover:text-white flex items-center gap-1"
              >
                <RotateCcw className="w-3.5 h-3.5" /> Скинути плитки
              </button>

              <div className="flex items-center gap-2">
                {tileCheckStatus !== 'correct' ? (
                  <button
                    onClick={handleCheckTileSentence}
                    disabled={selectedTiles.length === 0}
                    className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs disabled:opacity-40 cursor-pointer"
                  >
                    Перевірити структуру
                  </button>
                ) : (
                  <button
                    onClick={handleNextTile}
                    className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer"
                  >
                    <span>Наступна вправа</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>

            {tileCheckStatus === 'wrong' && (
              <div className="p-3.5 rounded-xl bg-rose-950/40 border border-rose-500/30 text-xs text-rose-300 text-center">
                Порядок слів або форма ще не точні. Спробуйте іншу комбінацію або згадайте правило SVOMPT!
              </div>
            )}
          </div>
        </div>
      )}
    </section>
  );
};
