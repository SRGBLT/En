import React from 'react';
import {
  Sparkles,
  BookOpen,
  Award,
  LayoutGrid,
  Cpu,
  Gamepad2,
  Layers,
  Search,
  User,
  Volume2,
  VolumeX,
  Repeat,
  AlertTriangle,
  Compass,
  Headphones,
  Bell,
  MessageSquareCode,
} from 'lucide-react';
import { UserProfile } from '../types';

export type TabId =
  | 'hacks'
  | 'topics'
  | 'methods'
  | 'roleplay'
  | 'level-test'
  | 'builder'
  | 'mistakes'
  | 'detector'
  | 'quiz'
  | 'cards'
  | 'dictionary'
  | 'profile';

interface HeaderProps {
  currentTab: TabId;
  onSelectTab: (tab: TabId) => void;
  user: UserProfile;
  isAudioMuted: boolean;
  onToggleAudio: () => void;
  onOpenAuth: () => void;
  onOpenAudioSettings?: () => void;
  onOpenReminders?: () => void;
  dueReviewCount?: number;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  onSelectTab,
  user,
  isAudioMuted,
  onToggleAudio,
  onOpenAuth,
  onOpenAudioSettings,
  onOpenReminders,
  dueReviewCount = 0,
}) => {
  const unmasteredMistakesCount = user.mistakes ? user.mistakes.filter((m) => !m.isMastered).length : 0;

  const navItems: { id: TabId; label: string; icon: React.ReactNode; badge?: string }[] = [
    { id: 'hacks', label: 'Лайфхаки', icon: <BookOpen className="w-4 h-4" /> },
    {
      id: 'topics',
      label: 'Теми слів',
      icon: <Compass className="w-4 h-4 text-emerald-400" />,
      badge: '300+ слів • Рівні',
    },
    {
      id: 'methods',
      label: 'Методики',
      icon: <Repeat className="w-4 h-4 text-sky-400" />,
      badge: 'SRS & Shadowing',
    },
    {
      id: 'roleplay',
      label: 'AI Рольова гра',
      icon: <MessageSquareCode className="w-4 h-4 text-purple-400" />,
      badge: 'Симулятор',
    },
    {
      id: 'level-test',
      label: 'Тест рівня',
      icon: <Award className="w-4 h-4 text-amber-400" />,
      badge: 'A1-C1',
    },
    {
      id: 'mistakes',
      label: 'Помилки',
      icon: <AlertTriangle className="w-4 h-4 text-rose-400" />,
      badge: unmasteredMistakesCount > 0 ? `${unmasteredMistakesCount}` : undefined,
    },
    {
      id: 'builder',
      label: 'Конструктор',
      icon: <LayoutGrid className="w-4 h-4 text-sky-400" />,
      badge: 'SVOMPT',
    },
    { id: 'detector', label: 'Детектор', icon: <Cpu className="w-4 h-4" /> },
    {
      id: 'quiz',
      label: 'Тренажер',
      icon: <Gamepad2 className="w-4 h-4 text-emerald-400" />,
    },
    { id: 'cards', label: 'Картки', icon: <Layers className="w-4 h-4" /> },
    { id: 'dictionary', label: 'Словник', icon: <Search className="w-4 h-4" /> },
    { id: 'profile', label: 'Кабінет', icon: <User className="w-4 h-4 text-amber-400" /> },
  ];

  return (
    <header className="sticky top-0 z-40 bg-slate-900/90 backdrop-blur-md border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20 gap-4">
          
          {/* Logo */}
          <div
            onClick={() => onSelectTab('hacks')}
            className="flex items-center gap-3 cursor-pointer shrink-0"
          >
            <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-2xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-sky-400 flex items-center justify-center text-white shadow-lg shadow-blue-500/25">
              <Sparkles className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-lg sm:text-xl font-black tracking-tight text-white">EngBridge</span>
                <span className="px-1.5 py-0.5 text-[10px] font-black uppercase tracking-wider rounded bg-blue-500/20 text-blue-400 border border-blue-500/30">
                  UA 🇺🇦
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-medium hidden sm:block">
                Мовні мости, синтаксис та швидкі алгоритми
              </p>
            </div>
          </div>

          {/* Navigation Tabs (Desktop) */}
          <nav className="hidden lg:flex items-center gap-1 bg-slate-800/60 p-1.5 rounded-2xl border border-slate-700/60 text-xs font-bold">
            {navItems.map((item) => {
              const isActive = currentTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onSelectTab(item.id)}
                  className={`px-3 py-2 rounded-xl transition flex items-center gap-1.5 whitespace-nowrap ${
                    isActive
                      ? 'bg-blue-600 text-white shadow'
                      : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
                  }`}
                >
                  {item.icon}
                  <span>{item.label}</span>
                  {item.badge && (
                    <span className="px-1.5 py-0.2 rounded-md bg-white/15 text-[9px] uppercase tracking-wider font-extrabold">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Right Action Controls */}
          <div className="flex items-center gap-2 shrink-0">
            {/* Audio Toggle & Google TTS Settings */}
            <div className="flex items-center bg-slate-800 border border-slate-700/80 rounded-xl overflow-hidden shadow-sm">
              <button
                onClick={onToggleAudio}
                title={isAudioMuted ? 'Увімкнути звук' : 'Вимкнути звук'}
                className="w-9 h-9 sm:w-10 sm:h-10 flex items-center justify-center text-slate-300 hover:text-white hover:bg-slate-700/60 transition cursor-pointer"
              >
                {isAudioMuted ? (
                  <VolumeX className="w-4 h-4 text-rose-400" />
                ) : (
                  <Volume2 className="w-4 h-4 text-emerald-400" />
                )}
              </button>

              {onOpenAudioSettings && (
                <button
                  onClick={onOpenAudioSettings}
                  title="Налаштування озвучки Google TTS"
                  className="h-9 sm:h-10 px-2.5 sm:px-3 border-l border-slate-700/70 flex items-center gap-1.5 text-blue-400 hover:text-blue-300 hover:bg-slate-700/60 transition cursor-pointer"
                >
                  <Headphones className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-blue-400" />
                  <span className="text-[10px] font-black uppercase tracking-wider text-blue-300 hidden sm:inline">
                    Google TTS
                  </span>
                </button>
              )}
            </div>

            {/* Reminders & Spaced Repetition Bell */}
            {onOpenReminders && (
              <button
                onClick={onOpenReminders}
                title={`Нагадування та повторення тем/слів${
                  dueReviewCount > 0 ? ` (${dueReviewCount} потребують уваги)` : ''
                }`}
                className="relative w-9 h-9 sm:w-10 sm:h-10 flex items-center justify-center rounded-xl bg-slate-800 border border-slate-700/80 text-amber-400 hover:text-amber-300 hover:bg-slate-700/60 transition cursor-pointer shadow-sm group"
              >
                <Bell
                  className={`w-4 h-4 transition ${
                    dueReviewCount > 0
                      ? 'text-amber-400 animate-[bounce_2s_infinite]'
                      : 'text-slate-400 group-hover:text-amber-300'
                  }`}
                />
                {dueReviewCount > 0 && (
                  <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-full bg-rose-500 text-white text-[9px] font-black flex items-center justify-center border-2 border-slate-900 shadow-md">
                    {dueReviewCount > 99 ? '99+' : dueReviewCount}
                  </span>
                )}
              </button>
            )}

            {/* Google Login Button / User Profile Status Chip */}
            {!user.isLoggedIn ? (
              <button
                onClick={onOpenAuth}
                className="flex items-center gap-2 px-3 py-2 rounded-xl bg-white hover:bg-slate-100 text-slate-800 font-bold text-xs shadow-md transition group shrink-0 cursor-pointer"
                title="Увійти через обліковий запис Google"
              >
                <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.66-5.17 3.66-9.17z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.98 0 12s.45 3.82 1.25 5.42l4.03-3.15z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                  />
                </svg>
                <span className="hidden sm:inline">Увійти з Google</span>
                <span className="sm:hidden">Google</span>
              </button>
            ) : (
              <button
                onClick={() => onSelectTab('profile')}
                className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-800/80 border border-slate-700 hover:border-slate-600 transition cursor-pointer"
                title="Перейти до профілю"
              >
                <div className="relative">
                  <div className="w-6 h-6 rounded-lg bg-gradient-to-tr from-blue-500 to-indigo-600 text-white font-black text-xs flex items-center justify-center">
                    {user.displayName.slice(0, 2).toUpperCase()}
                  </div>
                  <div className="absolute -bottom-1 -right-1 w-3 h-3 rounded-full bg-emerald-500 border border-slate-900 flex items-center justify-center text-[7px] text-white">
                    G
                  </div>
                </div>
                <div className="text-left hidden sm:block">
                  <span className="text-xs font-bold text-slate-200 block max-w-[100px] truncate">
                    {user.displayName}
                  </span>
                  <span className="text-[10px] text-blue-400 font-semibold block leading-tight">
                    Рівень {user.level} {user.cefrLevel ? `• ${user.cefrLevel}` : ''} • {user.xp} XP
                  </span>
                </div>
              </button>
            )}
          </div>

        </div>
      </div>

      {/* Mobile Nav Bar (Horizontal Scrollable) */}
      <div className="lg:hidden flex overflow-x-auto px-4 py-2 border-t border-slate-800/80 gap-1.5 bg-slate-900/80 no-scrollbar">
        {navItems.map((item) => {
          const isActive = currentTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onSelectTab(item.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap flex items-center gap-1.5 transition ${
                isActive
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              {item.icon}
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>
    </header>
  );
};
