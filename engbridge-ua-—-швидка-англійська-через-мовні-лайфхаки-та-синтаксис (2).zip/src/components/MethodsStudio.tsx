import React, { useState, useRef, useEffect } from 'react';
import {
  Sparkles,
  Repeat,
  Mic,
  MicOff,
  Volume2,
  Play,
  Square,
  CheckCircle,
  CheckCircle2,
  HelpCircle,
  Flame,
  Clock,
  BookOpen,
  ArrowRight,
  Layers,
  Award,
  AlertTriangle,
  RotateCcw,
  Edit3,
  Loader2,
  Brain,
  ChevronRight,
  Check,
  X,
  ExternalLink,
  Wrench,
  Upload,
  Paperclip,
} from 'lucide-react';
import { SHADOWING_EXERCISES, CHUNK_ITEMS, MICRO_STORIES, updateSrsCardGrade, createInitialSrsCard } from '../data/methodsData';
import { ALL_VOCABULARY } from '../data/hacks';
import {
  SrsCard,
  ShadowingExercise,
  ChunkItem,
  MicroStory,
  VocabItem,
  CefrLevel,
  ChunkCategory,
  ShadowingEvaluationResult,
} from '../types';
import { playSound, speakEnglish } from '../utils/audio';
import { ChunkTestStudio } from './ChunkTestStudio';
import {
  createSpeechRecognizer,
  evaluateShadowing,
  isSpeechRecognitionSupported,
  requestMicrophonePermission,
  createAudioLevelMonitor,
  transcribeAudioBlob,
  transcribeAudioFile,
  isRunningInIframe,
} from '../utils/shadowingEvaluator';
import { MicrophoneDiagnosticModal } from './MicrophoneDiagnosticModal';

interface MethodsStudioProps {
  srsCards: SrsCard[];
  onUpdateSrsCards: (cards: SrsCard[]) => void;
  dailyStreak: number;
  todayMinutes: number;
  onRewardXP: (amount: number) => void;
  onToast: (msg: string, type: 'info' | 'success' | 'error') => void;
  userLevel: CefrLevel | null;
  onRecordMistake?: (mistake: any) => void;
}

type StudioTab = 'srs' | 'shadowing' | 'chunks' | 'input';

export const MethodsStudio: React.FC<MethodsStudioProps> = ({
  srsCards,
  onUpdateSrsCards,
  dailyStreak,
  todayMinutes,
  onRewardXP,
  onToast,
  userLevel,
  onRecordMistake,
}) => {
  const [activeTab, setActiveTab] = useState<StudioTab>('srs');
  const [chunksSubView, setChunksSubView] = useState<'catalog' | 'test'>('catalog');

  // SRS State
  const now = Date.now();
  const dueCards = srsCards.filter((c) => c.dueDate <= now);
  const [srsReviewIndex, setSrsReviewIndex] = useState(0);
  const [isSrsFlipped, setIsSrsFlipped] = useState(false);

  // Shadowing State & AI Verification
  const [selectedShadowing, setSelectedShadowing] = useState<ShadowingExercise>(SHADOWING_EXERCISES[0]);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(0.9);
  const [isRecording, setIsRecording] = useState(false);
  const [recordedAudioUrl, setRecordedAudioUrl] = useState<string | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  // Verification & Assessment States
  const [userTranscript, setUserTranscript] = useState<string>('');
  const userTranscriptRef = useRef<string>('');
  const [isLiveRecognizing, setIsLiveRecognizing] = useState<boolean>(false);
  const [isEditingTranscript, setIsEditingTranscript] = useState<boolean>(false);
  const [editedTranscript, setEditedTranscript] = useState<string>('');
  const [isEvaluating, setIsEvaluating] = useState<boolean>(false);
  const [evaluationResult, setEvaluationResult] = useState<ShadowingEvaluationResult | null>(null);
  const [isTranscribingServer, setIsTranscribingServer] = useState<boolean>(false);
  const [audioLevel, setAudioLevel] = useState<number>(0);
  const [micPermissionDenied, setMicPermissionDenied] = useState<boolean>(false);
  const [micPermissionHelp, setMicPermissionHelp] = useState<string | null>(null);
  const [isMicDiagnosticOpen, setIsMicDiagnosticOpen] = useState(false);
  const [selectedDeviceId, setSelectedDeviceId] = useState<string>('');
  const speechRecognizerRef = useRef<{ stop: () => void; recognition: any } | null>(null);
  const audioLevelMonitorRef = useRef<{ stop: () => void } | null>(null);
  const currentStreamRef = useRef<MediaStream | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handleShadowingFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !selectedShadowing) return;

    const url = URL.createObjectURL(file);
    setRecordedAudioUrl(url);

    setIsTranscribingServer(true);
    onToast(`Обробка аудіофайлу "${file.name}" через ШІ Gemini...`, 'info');
    const { transcript, error: trErr } = await transcribeAudioFile(file, selectedShadowing.text);
    setIsTranscribingServer(false);

    if (transcript && transcript.trim().length > 0) {
      setUserTranscript(transcript);
      setEditedTranscript(transcript);
      userTranscriptRef.current = transcript;
      runEvaluation(transcript);
      onToast('Аудіозапис завантажено та розпізнано! Результати готові.', 'success');
    } else {
      onToast(trErr || 'Не вдалося розпізнати слова в аудіофайлі.', 'error');
    }
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  // Chunks State
  const [selectedChunkCategory, setSelectedChunkCategory] = useState<string>('all');
  const [chunkQuizItem, setChunkQuizItem] = useState<ChunkItem | null>(null);
  const [chunkSelectedAnswer, setChunkSelectedAnswer] = useState<string | null>(null);

  // Micro-Story State
  const [selectedStoryIndex, setSelectedStoryIndex] = useState(0);
  const [storyAnswerSelected, setStoryAnswerSelected] = useState<string | null>(null);

  // Initialize SRS with first 8 vocabulary words if empty
  useEffect(() => {
    if (srsCards.length === 0 && ALL_VOCABULARY.length > 0) {
      const initialCards = ALL_VOCABULARY.slice(0, 10).map((v) => createInitialSrsCard(v));
      onUpdateSrsCards(initialCards);
    }
  }, [srsCards.length, onUpdateSrsCards]);

  // Clean up recorded audio url
  useEffect(() => {
    return () => {
      if (recordedAudioUrl) URL.revokeObjectURL(recordedAudioUrl);
    };
  }, [recordedAudioUrl]);

  // --- SRS Handlers ---
  const currentDueCard = dueCards[srsReviewIndex];

  const handleSrsGrade = (grade: 'hard' | 'good' | 'easy') => {
    if (!currentDueCard) return;
    playSound('correct');
    const updatedCard = updateSrsCardGrade(currentDueCard, grade);
    const newCards = srsCards.map((c) =>
      c.word.eng === updatedCard.word.eng ? updatedCard : c
    );
    onUpdateSrsCards(newCards);
    onRewardXP(grade === 'easy' ? 15 : 10);
    setIsSrsFlipped(false);
    onToast(`Картку перенесено у Box ${updatedCard.box} (наступне повторення через ${updatedCard.intervalDays} дн.)`, 'success');

    if (srsReviewIndex >= dueCards.length - 1) {
      setSrsReviewIndex(0);
    }
  };

  const handleAddMoreSrsCards = () => {
    playSound('click');
    const existingEng = new Set(srsCards.map((c) => c.word.eng));
    const unadded = ALL_VOCABULARY.filter((v) => !existingEng.has(v.eng)).slice(0, 5);
    if (unadded.length === 0) {
      onToast('Усі доступні слова вже додано до системи повторення!', 'info');
      return;
    }
    const newCards = [...srsCards, ...unadded.map((v) => createInitialSrsCard(v))];
    onUpdateSrsCards(newCards);
    onToast(`Додано +${unadded.length} нових слів на інтервальне повторення!`, 'success');
  };

  // --- Shadowing Handlers ---
  const handlePlayShadowing = () => {
    if (!selectedShadowing) return;
    speakEnglish(selectedShadowing.text, playbackSpeed);
  };

  const handleStartRecording = async () => {
    setMicPermissionDenied(false);
    setMicPermissionHelp(null);

    const { stream, error, errorType } = await requestMicrophonePermission(selectedDeviceId || undefined);
    if (!stream) {
      if (
        errorType === 'iframe-blocked' ||
        errorType === 'not-allowed' ||
        error?.includes('заблоковано') ||
        error?.includes('відхилено')
      ) {
        setMicPermissionDenied(true);
        setMicPermissionHelp(error);
      }
      onToast(error || 'Не вдалося отримати доступ до мікрофона', 'error');
      return;
    }

    currentStreamRef.current = stream;
    audioChunksRef.current = [];

    // Real-time audio level visualizer
    const monitor = createAudioLevelMonitor(stream, (lvl) => {
      setAudioLevel(lvl);
    });
    audioLevelMonitorRef.current = monitor;

    // Initialize MediaRecorder safely
    let mediaRecorder: MediaRecorder;
    try {
      const mime = MediaRecorder.isTypeSupported('audio/webm;codecs=opus')
        ? 'audio/webm;codecs=opus'
        : MediaRecorder.isTypeSupported('audio/webm')
        ? 'audio/webm'
        : '';
      mediaRecorder = mime ? new MediaRecorder(stream, { mimeType: mime }) : new MediaRecorder(stream);
    } catch {
      mediaRecorder = new MediaRecorder(stream);
    }
    mediaRecorderRef.current = mediaRecorder;

    mediaRecorder.ondataavailable = (event) => {
      if (event.data.size > 0) {
        audioChunksRef.current.push(event.data);
      }
    };

    mediaRecorder.onstop = async () => {
      const audioBlob = new Blob(audioChunksRef.current, {
        type: mediaRecorder.mimeType || 'audio/webm',
      });
      const url = URL.createObjectURL(audioBlob);
      setRecordedAudioUrl(url);

      if (audioLevelMonitorRef.current) {
        audioLevelMonitorRef.current.stop();
        audioLevelMonitorRef.current = null;
      }
      setAudioLevel(0);

      stream.getTracks().forEach((track) => track.stop());

      // If live Web Speech API didn't pick up text, transcribe via Gemini backend
      if (!userTranscriptRef.current || userTranscriptRef.current.trim().length === 0) {
        setIsTranscribingServer(true);
        onToast('Розпізнавання аудіо через штучний інтелект...', 'info');
        const { transcript, error: trErr } = await transcribeAudioBlob(
          audioBlob,
          selectedShadowing.text
        );
        setIsTranscribingServer(false);

        if (transcript && transcript.trim().length > 0) {
          setUserTranscript(transcript);
          setEditedTranscript(transcript);
          userTranscriptRef.current = transcript;
          runEvaluation(transcript);
        } else {
          onToast(
            trErr || 'Голос не розпізнано. Перевірте чутливість мікрофона або введіть текст вручну.',
            'info'
          );
        }
      }
    };

    // Reset state for new attempt
    setUserTranscript('');
    setEditedTranscript('');
    userTranscriptRef.current = '';
    setEvaluationResult(null);
    setIsEditingTranscript(false);

    // Optional live SpeechRecognition preview
    if (isSpeechRecognitionSupported()) {
      const recognizer = createSpeechRecognizer(
        (text) => {
          setUserTranscript(text);
          setEditedTranscript(text);
          userTranscriptRef.current = text;
        },
        (err) => {
          console.warn('Speech recognition notice:', err);
        }
      );
      speechRecognizerRef.current = recognizer;
      setIsLiveRecognizing(true);
    }

    mediaRecorder.start(250);
    setIsRecording(true);
    playSound('click');
    onToast('Запис розпочато! Повторюйте за диктором синхронно...', 'info');
  };

  const handleStopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      setIsLiveRecognizing(false);

      if (speechRecognizerRef.current) {
        speechRecognizerRef.current.stop();
        speechRecognizerRef.current = null;
      }

      playSound('correct');
      onToast('Запис завершено! Оцінюємо вимову...', 'success');

      // If we already have live transcribed text:
      setTimeout(() => {
        if (userTranscriptRef.current && userTranscriptRef.current.trim().length > 0) {
          runEvaluation(userTranscriptRef.current);
        }
      }, 350);
    }
  };

  const runEvaluation = async (textToEvaluate?: string) => {
    const text = (
      textToEvaluate !== undefined
        ? textToEvaluate
        : isEditingTranscript
        ? editedTranscript
        : userTranscript
    ).trim();

    if (!text) {
      onToast('Будь ласка, промовте або введіть текст, який ви повторили!', 'error');
      return;
    }

    setIsEvaluating(true);
    try {
      const result = await evaluateShadowing(
        selectedShadowing.text,
        text,
        selectedShadowing.connectedSpeechTips,
        selectedShadowing.phoneticStress,
        selectedShadowing.level
      );

      setEvaluationResult(result);
      if (result.score >= 75) {
        playSound('correct');
      } else {
        playSound('combo');
      }
      onRewardXP(result.xpEarned);
      onToast(`Оцінка вимови: ${result.score}/100 балів! (+${result.xpEarned} XP)`, 'success');
    } catch {
      onToast('Помилка аналізу вимови. Спробуйте ще раз.', 'error');
    } finally {
      setIsEvaluating(false);
    }
  };

  // --- Chunks Handlers ---
  const filteredChunks = CHUNK_ITEMS.filter((ch) => {
    if (selectedChunkCategory === 'all') return true;
    return ch.category === selectedChunkCategory;
  });

  const handleStartChunkQuiz = (chunk: ChunkItem) => {
    playSound('click');
    setChunkQuizItem(chunk);
    setChunkSelectedAnswer(null);
  };

  const handleSelectChunkAnswer = (ans: string) => {
    if (chunkSelectedAnswer !== null || !chunkQuizItem) return;
    setChunkSelectedAnswer(ans);
    const isCorrect = ans === chunkQuizItem.chunk;
    if (isCorrect) {
      playSound('correct');
      onRewardXP(15);
      onToast('Правильно! Чудова колокація (+15 XP)', 'success');
    } else {
      playSound('wrong');
    }
  };

  // --- Micro-Story Handlers ---
  const currentStory = MICRO_STORIES[selectedStoryIndex % MICRO_STORIES.length];

  const handleSelectStoryAnswer = (opt: string) => {
    if (storyAnswerSelected !== null) return;
    setStoryAnswerSelected(opt);
    const isCorrect = opt === currentStory.comprehensionQuestion.correct;
    if (isCorrect) {
      playSound('correct');
      onRewardXP(25);
      onToast('Вірно! Успішне розуміння тексту (+25 XP)', 'success');
    } else {
      playSound('wrong');
    }
  };

  const handlePlayStoryParagraph = (text: string) => {
    speakEnglish(text);
  };

  return (
    <section className="space-y-8">
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-indigo-950/80 via-slate-900 to-slate-950 border border-indigo-500/30 p-6 sm:p-10 shadow-2xl">
        <div className="max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-bold">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Золоті світові стандарти: Лейтнер, Крашен, Арґуельес, Льюїс</span>
          </div>
          <h2 className="text-2xl sm:text-4xl font-black text-white tracking-tight">
            Світові Методики:{' '}
            <span className="bg-gradient-to-r from-amber-400 via-orange-300 to-yellow-200 bg-clip-text text-transparent">
              Прискорене Засвоєння
            </span>
          </h2>
          <p className="text-slate-300 text-sm leading-relaxed">
            Поєднуйте мовні мости з науково доведеними практиками поліглотів: інтервальними повтореннями SRS,
            методом Shadowing для злитого мовлення, лексичними блоками (чанками) та контекстним Comprehensible Input (i+1).
          </p>

          {/* Quick Habits & Streak Bar */}
          <div className="flex flex-wrap items-center gap-4 pt-2 text-xs font-bold">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800/80 text-amber-300 border border-amber-500/30">
              <Flame className="w-4 h-4 text-orange-400" />
              <span>Серія днів: {dailyStreak} днів поспіль</span>
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800/80 text-emerald-300 border border-emerald-500/30">
              <Clock className="w-4 h-4 text-emerald-400" />
              <span>Час практики сьогодні: {todayMinutes} хв</span>
            </div>
            {dueCards.length > 0 && (
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-500/20 text-blue-300 border border-blue-500/30">
                <Repeat className="w-4 h-4" />
                <span>На повторення: {dueCards.length} слів</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center justify-between flex-wrap gap-2 bg-slate-900 p-2.5 rounded-2xl border border-slate-800">
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar w-full sm:w-auto">
          <button
            onClick={() => {
              playSound('click');
              setActiveTab('srs');
            }}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'srs'
                ? 'bg-blue-600 text-white shadow'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <Repeat className="w-4 h-4" />
            <span>Інтервальне повторення (SRS)</span>
            {dueCards.length > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-amber-400 text-slate-950 text-[10px] font-black">
                {dueCards.length}
              </span>
            )}
          </button>

          <button
            onClick={() => {
              playSound('click');
              setActiveTab('shadowing');
            }}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'shadowing'
                ? 'bg-sky-600 text-white shadow'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <Mic className="w-4 h-4" />
            <span>Студія Shadowing (Вимова)</span>
          </button>

          <button
            onClick={() => {
              playSound('click');
              setActiveTab('chunks');
            }}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'chunks'
                ? 'bg-indigo-600 text-white shadow'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>Мовні чанки & Колокації</span>
          </button>

          <button
            onClick={() => {
              playSound('click');
              setActiveTab('input');
            }}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'input'
                ? 'bg-emerald-600 text-white shadow'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>Comprehensible Input (i+1)</span>
          </button>
        </div>
      </div>

      {/* ================= TAB 1: SPACED REPETITION (SRS) ================= */}
      {activeTab === 'srs' && (
        <div className="space-y-6">
          {/* Methodology Info Card */}
          <div className="p-4 sm:p-5 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-lg text-[10px] font-black uppercase tracking-wider bg-blue-500/20 text-blue-300 border border-blue-500/30">
                  Метод Лейтнера & Крива Еббінгауза
                </span>
                <span className="text-xs text-slate-400 font-bold">Оптимальний час для повторень</span>
              </div>
              <h4 className="text-sm sm:text-base font-black text-white">
                Повторення точно в момент, коли мозок починає забувати
              </h4>
              <p className="text-xs text-slate-300">
                Картки розподіляються за 4 скриньками: <strong>Box 1 (Щодня)</strong>, <strong>Box 2 (Раз на 3 дні)</strong>, <strong>Box 3 (Раз на тиждень)</strong>, <strong>Box 4 (Раз на місяць)</strong>.
              </p>
            </div>
            <button
              onClick={handleAddMoreSrsCards}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 transition whitespace-nowrap"
            >
              + Додати ще слів у чергу
            </button>
          </div>

          {/* Leitner Box Counters */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[1, 2, 3, 4].map((boxNum) => {
              const count = srsCards.filter((c) => c.box === boxNum).length;
              const labels = ['Box 1 (Щодня)', 'Box 2 (3 дні)', 'Box 3 (7 днів)', 'Box 4 (30 днів)'];
              return (
                <div key={boxNum} className="p-3.5 rounded-2xl bg-slate-800/60 border border-slate-700/60 text-center space-y-1">
                  <span className="text-[11px] text-slate-400 font-bold block">{labels[boxNum - 1]}</span>
                  <span className="text-xl font-black text-white">{count} слів</span>
                </div>
              );
            })}
          </div>

          {/* Active Review Card */}
          {currentDueCard ? (
            <div className="max-w-xl mx-auto bg-slate-900 rounded-3xl border border-slate-800 p-6 sm:p-8 shadow-2xl space-y-6">
              <div className="flex items-center justify-between text-xs font-bold text-slate-400">
                <span>
                  Картка {srsReviewIndex + 1} з {dueCards.length} на сьогодні
                </span>
                <span className="px-2.5 py-0.5 rounded-lg bg-blue-500/20 text-blue-300 border border-blue-500/30">
                  Box {currentDueCard.box}
                </span>
              </div>

              {/* Flippable Content */}
              <div
                onClick={() => {
                  playSound('click');
                  setIsSrsFlipped(!isSrsFlipped);
                  if (!isSrsFlipped) speakEnglish(currentDueCard.word.eng);
                }}
                className="p-8 rounded-2xl bg-slate-950/80 border-2 border-slate-700 hover:border-blue-500/50 cursor-pointer text-center space-y-3 transition transform active:scale-98"
              >
                <span className="text-xs uppercase font-extrabold text-slate-500 block">
                  {isSrsFlipped ? 'Англійський відповідник & вимова' : 'Українське слово (згадайте переклад)'}
                </span>
                <h3 className="text-3xl sm:text-4xl font-black text-white">
                  {isSrsFlipped ? currentDueCard.word.eng : currentDueCard.word.ukr}
                </h3>
                {isSrsFlipped && (
                  <div className="space-y-1 animate-fadeIn">
                    <p className="text-sm font-mono text-blue-400">{currentDueCard.word.ipa}</p>
                    <p className="text-xs text-amber-300 font-semibold">{currentDueCard.word.rule}</p>
                  </div>
                )}
                <span className="text-[11px] text-slate-500 italic block pt-2">
                  {isSrsFlipped ? 'Оцініть, наскільки легко було згадати:' : 'Клікніть, щоб перевірити себе ↻'}
                </span>
              </div>

              {/* Self-Rating Controls */}
              {isSrsFlipped && (
                <div className="space-y-2 animate-fadeIn">
                  <div className="grid grid-cols-3 gap-2">
                    <button
                      onClick={() => handleSrsGrade('hard')}
                      className="py-3 px-2 rounded-xl bg-rose-950/60 hover:bg-rose-900 border border-rose-500/40 text-rose-300 font-bold text-xs transition text-center"
                    >
                      <span className="block font-black">Важко</span>
                      <span className="text-[10px] opacity-80">Повтор за 1 день</span>
                    </button>
                    <button
                      onClick={() => handleSrsGrade('good')}
                      className="py-3 px-2 rounded-xl bg-blue-950/60 hover:bg-blue-900 border border-blue-500/40 text-blue-300 font-bold text-xs transition text-center"
                    >
                      <span className="block font-black">Добре</span>
                      <span className="text-[10px] opacity-80">Повтор за 3–7 днів</span>
                    </button>
                    <button
                      onClick={() => handleSrsGrade('easy')}
                      className="py-3 px-2 rounded-xl bg-emerald-950/60 hover:bg-emerald-900 border border-emerald-500/40 text-emerald-300 font-bold text-xs transition text-center"
                    >
                      <span className="block font-black">Легко</span>
                      <span className="text-[10px] opacity-80">Повтор за 14–30 днів</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="max-w-md mx-auto bg-slate-900 rounded-3xl border border-slate-800 p-8 text-center space-y-4">
              <CheckCircle className="w-12 h-12 text-emerald-400 mx-auto" />
              <h3 className="text-xl font-black text-white">Усі слова на сьогодні повторено!</h3>
              <p className="text-xs text-slate-400">
                Ви успішно закріпили матеріал. Система нагадає про наступні слова відповідно до кривої Еббінгауза.
              </p>
              <button
                onClick={handleAddMoreSrsCards}
                className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs transition shadow-md"
              >
                Додати нові слова зі словника
              </button>
            </div>
          )}
        </div>
      )}

      {/* ================= TAB 2: SHADOWING STUDIO ================= */}
      {activeTab === 'shadowing' && (
        <div className="space-y-6">
          {/* Methodology Info Card */}
          <div className="p-4 sm:p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-lg text-[10px] font-black uppercase tracking-wider bg-sky-500/20 text-sky-300 border border-sky-500/30">
                Shadowing Technique
              </span>
              <span className="text-xs text-slate-400 font-bold">Синхронне наслідування носія</span>
            </div>
            <h4 className="text-sm sm:text-base font-black text-white">
              Говоріть одночасно з аудіо, копіюючи інтонацію, редукції та ритм
            </h4>
            <p className="text-xs text-slate-300">
              Слухайте речення, спостерігайте за злиттям звуків (<em>connected speech</em>), потім запишіть власний голос на мікрофон та порівняйте з оригіналом.
            </p>
          </div>

          {/* Exercise Selector */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
            {SHADOWING_EXERCISES.map((ex) => (
              <button
                key={ex.id}
                onClick={() => {
                  playSound('click');
                  setSelectedShadowing(ex);
                  setRecordedAudioUrl(null);
                  setUserTranscript('');
                  setEditedTranscript('');
                  setEvaluationResult(null);
                  setIsEditingTranscript(false);
                }}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap flex items-center gap-1.5 cursor-pointer ${
                  selectedShadowing.id === ex.id
                    ? 'bg-sky-600 text-white shadow'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                <span>{ex.title}</span>
                <span className="text-[10px] opacity-75">({ex.level})</span>
              </button>
            ))}
          </div>

          {/* Main Shadowing Workspace */}
          <div className="max-w-2xl mx-auto bg-slate-900 rounded-3xl border border-slate-800 p-6 sm:p-8 shadow-2xl space-y-6">
            <div className="flex items-center justify-between text-xs font-bold text-slate-400">
              <span className="px-2.5 py-0.5 rounded-lg bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                Рівень {selectedShadowing.level} • {selectedShadowing.category}
              </span>
              <div className="flex items-center gap-2">
                <span>Швидкість:</span>
                {[0.75, 0.9, 1.0].map((speed) => (
                  <button
                    key={speed}
                    onClick={() => setPlaybackSpeed(speed)}
                    className={`px-2 py-0.5 rounded-md text-[11px] font-bold transition cursor-pointer ${
                      playbackSpeed === speed
                        ? 'bg-blue-600 text-white'
                        : 'bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    {speed}x
                  </button>
                ))}
              </div>
            </div>

            {/* Target English Phrase */}
            <div className="p-6 rounded-2xl bg-slate-950 border border-slate-800 text-center space-y-3">
              <span className="text-[11px] uppercase tracking-wider font-extrabold text-slate-500 block">
                Фраза для синхронного повторення:
              </span>
              <h3 className="text-xl sm:text-2xl font-black text-white leading-relaxed">
                "{selectedShadowing.text}"
              </h3>
              <p className="text-xs text-slate-400 italic">
                {selectedShadowing.translation}
              </p>
            </div>

            {/* Connected Speech & Stress Annotations */}
            <div className="space-y-3">
              <div className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700 text-xs space-y-1">
                <span className="text-[10px] uppercase font-black tracking-wider text-sky-400 block">
                  Злиття звуків (Connected Speech):
                </span>
                <p className="text-slate-300">{selectedShadowing.connectedSpeechTips}</p>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700 text-xs space-y-1">
                <span className="text-[10px] uppercase font-black tracking-wider text-amber-400 block">
                  Фонетичні наголоси:
                </span>
                <p className="font-mono text-slate-300 tracking-wide text-[11px]">
                  {selectedShadowing.phoneticStress}
                </p>
              </div>
            </div>

            {/* Interactive Audio Controls */}
            <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
              {/* Hidden File Input for Shadowing */}
              <input
                type="file"
                ref={fileInputRef}
                accept="audio/*,.mp3,.wav,.m4a,.ogg,.webm"
                onChange={handleShadowingFileUpload}
                className="hidden"
              />

              <button
                onClick={handlePlayShadowing}
                className="px-5 py-3 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs sm:text-sm flex items-center gap-2 shadow-lg shadow-blue-500/25 transition transform active:scale-95 cursor-pointer"
              >
                <Volume2 className="w-4 h-4" />
                <span>Прослухати диктора ({playbackSpeed}x)</span>
              </button>

              {!isRecording ? (
                <button
                  onClick={handleStartRecording}
                  className="px-5 py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm flex items-center gap-2 shadow-lg shadow-emerald-500/25 transition transform active:scale-95 cursor-pointer"
                >
                  <Mic className="w-4 h-4" />
                  <span>Записати свій голос</span>
                </button>
              ) : (
                <button
                  onClick={handleStopRecording}
                  className="px-5 py-3 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs sm:text-sm flex items-center gap-2 shadow-lg shadow-rose-500/25 transition animate-pulse cursor-pointer"
                >
                  <Square className="w-4 h-4" />
                  <span>Зупинити запис та перевірити</span>
                </button>
              )}

              {/* Upload audio file button */}
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="px-4 py-3 rounded-2xl bg-slate-800 hover:bg-slate-750 text-slate-300 font-bold text-xs flex items-center gap-2 transition border border-slate-700 cursor-pointer"
                title="Завантажити аудіозапис (.mp3, .wav, .m4a)"
              >
                <Upload className="w-4 h-4 text-indigo-400" />
                <span>Завантажити аудіо</span>
              </button>

              {/* Mic Diagnostics button */}
              <button
                type="button"
                onClick={() => setIsMicDiagnosticOpen(true)}
                className="p-3 rounded-2xl bg-slate-800 hover:bg-slate-750 text-slate-400 hover:text-white font-bold text-xs transition border border-slate-700 cursor-pointer"
                title="Діагностика та тест мікрофона"
              >
                <Wrench className="w-4 h-4" />
              </button>
            </div>

            {/* Live Recording Feedback Banner & Animated Audio Level Meter */}
            {isRecording && (
              <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-center space-y-3">
                <div className="flex items-center justify-center gap-2 text-rose-400 text-xs font-black uppercase tracking-wider">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping" />
                  <span>Йде запис голосу • Говоріть у мікрофон синхронно</span>
                </div>

                {/* Animated VU Meter / Soundwave */}
                <div className="flex items-center justify-center gap-1.5 h-8">
                  {[...Array(16)].map((_, i) => {
                    const variance = Math.sin(i * 0.8 + Date.now() / 150) * 15;
                    const height = Math.min(100, Math.max(15, audioLevel + variance));
                    return (
                      <div
                        key={i}
                        className={`w-1.5 rounded-full transition-all duration-75 ${
                          audioLevel > 5 ? 'bg-emerald-400' : 'bg-slate-700'
                        }`}
                        style={{ height: `${height}%` }}
                      />
                    );
                  })}
                </div>

                <div className="text-[11px] font-mono text-slate-400 flex items-center justify-center gap-2">
                  <span>Чутливість мікрофона:</span>
                  <span className={`font-bold ${audioLevel > 5 ? 'text-emerald-400' : 'text-amber-400'}`}>
                    {audioLevel > 5 ? `${audioLevel}% (Звук виявлено ✓)` : '0% (Тиша або мікрофон заглушено)'}
                  </span>
                </div>

                <p className="text-sm font-semibold text-white min-h-[24px]">
                  {userTranscript ? `«${userTranscript}»` : 'Слухаємо вашу вимову в реальному часі...'}
                </p>
              </div>
            )}

            {/* Server Transcription Loader */}
            {isTranscribingServer && (
              <div className="p-4 rounded-2xl bg-indigo-500/10 border border-indigo-500/30 text-center space-y-2 animate-pulse">
                <div className="flex items-center justify-center gap-2 text-indigo-400 text-xs font-bold">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>ШІ Gemini розшифровує ваш аудіозапис...</span>
                </div>
              </div>
            )}

            {/* Microphone Permission Denied Help Banner */}
            {micPermissionDenied && (
              <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 space-y-3 text-left animate-fadeIn relative">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2 text-amber-300 font-bold text-xs">
                    <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                    <span>Доступ до мікрофона заблоковано в налаштуваннях браузера</span>
                  </div>
                  <button
                    onClick={() => setMicPermissionDenied(false)}
                    className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition cursor-pointer"
                    title="Закрити сповіщення"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed">
                  {micPermissionHelp ||
                    'Якщо ви вже дозволили мікрофон біля замка адреси сайту, це найчастіше спричинено запуском у вікні передперегляду AI Studio (iFrame) або системними дозволами macOS/Windows.'}
                </p>

                <div className="flex flex-wrap items-center gap-2 pt-1">
                  {isRunningInIframe() && (
                    <button
                      onClick={() => window.open(window.location.href, '_blank', 'noopener,noreferrer')}
                      className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-xs flex items-center gap-1.5 transition cursor-pointer shadow-md shadow-amber-500/20"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      Відкрити в новій вкладці (Без фрейму)
                    </button>
                  )}

                  <button
                    onClick={() => setIsMicDiagnosticOpen(true)}
                    className="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-1.5 transition cursor-pointer shadow-md shadow-indigo-600/20"
                  >
                    <Wrench className="w-3.5 h-3.5" />
                    Діагностика та тест звуку
                  </button>

                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5 transition cursor-pointer border border-slate-700"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    Завантажити аудіофайл
                  </button>

                  <button
                    onClick={handleStartRecording}
                    className="px-3.5 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 font-bold text-xs transition cursor-pointer border border-amber-500/40"
                  >
                    Спробувати знову
                  </button>

                  <button
                    onClick={() => {
                      setUserTranscript(selectedShadowing.text);
                      setEditedTranscript(selectedShadowing.text);
                      setIsEditingTranscript(true);
                      onToast('Зразок фрази вставлено! Натисніть Оцінити вимову.', 'info');
                    }}
                    className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold border border-slate-700 transition cursor-pointer"
                  >
                    Вставити текст вручну
                  </button>
                </div>
              </div>
            )}

            {/* Recorded Audio Playback & Transcript Inspection */}
            {recordedAudioUrl && !isRecording && (
              <div className="p-5 rounded-2xl bg-slate-800/80 border border-slate-700 space-y-4 animate-fadeIn">
                <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
                  <div className="space-y-0.5 text-center sm:text-left">
                    <span className="text-xs font-bold text-emerald-400 block">Ваш аудіозапис готовий:</span>
                    <span className="text-[11px] text-slate-400">Прослухайте власний голос поруч зі зразком</span>
                  </div>
                  <audio controls src={recordedAudioUrl} className="h-9 max-w-full" />
                </div>

                {/* Recognized Text Display & Verification */}
                <div className="pt-3 border-t border-slate-700/80 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                      <Mic className="w-3.5 h-3.5 text-sky-400" />
                      <span>Розпізнаний текст користувача:</span>
                    </span>
                    <button
                      onClick={() => setIsEditingTranscript(!isEditingTranscript)}
                      className="text-[11px] font-bold text-blue-400 hover:text-blue-300 flex items-center gap-1 transition cursor-pointer"
                    >
                      <Edit3 className="w-3 h-3" />
                      <span>{isEditingTranscript ? 'Згорнути редагування' : 'Відредагувати текст'}</span>
                    </button>
                  </div>

                  {isEditingTranscript ? (
                    <div className="space-y-2">
                      <textarea
                        value={editedTranscript}
                        onChange={(e) => setEditedTranscript(e.target.value)}
                        placeholder="Введіть або скоригуйте слова, які ви промовилии..."
                        rows={2}
                        className="w-full p-3 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs font-medium focus:border-blue-500 focus:outline-none"
                      />
                      <div className="flex justify-end gap-2">
                        <button
                          onClick={() => {
                            setUserTranscript(editedTranscript);
                            setIsEditingTranscript(false);
                            runEvaluation(editedTranscript);
                          }}
                          className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>Оцінити відредагований текст</span>
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-700/60 flex items-center justify-between gap-3">
                      <p className="text-xs sm:text-sm font-semibold text-slate-200">
                        {userTranscript ? (
                          <span>«{userTranscript}»</span>
                        ) : (
                          <span className="text-slate-500 italic">
                            Текст не розпізнано автоматично. Натисніть «Відредагувати текст», щоб ввести сказане або повторіть запис.
                          </span>
                        )}
                      </p>
                      {!evaluationResult && (
                        <button
                          disabled={isEvaluating}
                          onClick={() => runEvaluation()}
                          className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-bold text-xs shrink-0 flex items-center gap-1.5 shadow transition cursor-pointer"
                        >
                          {isEvaluating ? (
                            <>
                              <Loader2 className="w-3.5 h-3.5 animate-spin" />
                              <span>Оцінюємо...</span>
                            </>
                          ) : (
                            <>
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              <span>Оцінити</span>
                            </>
                          )}
                        </button>
                      )}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* ================= DETAILED SCORE & EVALUATION CARD ================= */}
            {evaluationResult && !isRecording && (
              <div className="p-6 rounded-3xl bg-slate-800/90 border border-slate-700/80 shadow-xl space-y-5 animate-fadeIn">
                {/* Score Header */}
                <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pb-4 border-b border-slate-700/70">
                  <div className="flex items-center gap-3.5 text-center sm:text-left">
                    <div
                      className={`w-14 h-14 rounded-2xl flex items-center justify-center text-white font-black text-xl shadow-lg shrink-0 ${
                        evaluationResult.score >= 90
                          ? 'bg-gradient-to-tr from-emerald-600 to-teal-500 shadow-emerald-500/25'
                          : evaluationResult.score >= 75
                          ? 'bg-gradient-to-tr from-blue-600 to-indigo-500 shadow-blue-500/25'
                          : evaluationResult.score >= 50
                          ? 'bg-gradient-to-tr from-amber-600 to-orange-500 shadow-amber-500/25'
                          : 'bg-gradient-to-tr from-rose-600 to-red-500 shadow-rose-500/25'
                      }`}
                    >
                      {evaluationResult.score}%
                    </div>
                    <div>
                      <div className="flex items-center justify-center sm:justify-start gap-2">
                        <h4 className="text-base sm:text-lg font-black text-white">
                          {evaluationResult.score >= 90
                            ? 'Відмінна вимова! 🏆'
                            : evaluationResult.score >= 75
                            ? 'Гарне наслідування! 🌟'
                            : evaluationResult.score >= 50
                            ? 'Непогано, потренуймося ще! ⚠️'
                            : 'Спробуйте повторити повільніше 🛑'}
                        </h4>
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/30">
                          +{evaluationResult.xpEarned} XP
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 mt-0.5">
                        Оцінка точності слів, темпу та зв'язного мовлення за зразком
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => runEvaluation()}
                    disabled={isEvaluating}
                    className="px-4 py-2 rounded-xl bg-slate-700 hover:bg-slate-600 text-slate-200 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shrink-0"
                  >
                    {isEvaluating ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <RotateCcw className="w-3.5 h-3.5" />
                    )}
                    <span>Переоцінити</span>
                  </button>
                </div>

                {/* 3 Metric Breakdown Bars */}
                <div className="grid grid-cols-3 gap-2.5">
                  <div className="p-3 rounded-2xl bg-slate-900/60 border border-slate-750 text-center space-y-1">
                    <span className="text-[10px] font-bold text-slate-400 block uppercase">
                      Точність слів
                    </span>
                    <span className="text-lg font-black text-emerald-400">
                      {evaluationResult.accuracyScore}%
                    </span>
                  </div>

                  <div className="p-3 rounded-2xl bg-slate-900/60 border border-slate-750 text-center space-y-1">
                    <span className="text-[10px] font-bold text-slate-400 block uppercase">
                      Плавність / Ритм
                    </span>
                    <span className="text-lg font-black text-sky-400">
                      {evaluationResult.fluencyScore}%
                    </span>
                  </div>

                  <div className="p-3 rounded-2xl bg-slate-900/60 border border-slate-750 text-center space-y-1">
                    <span className="text-[10px] font-bold text-slate-400 block uppercase">
                      Фонетика
                    </span>
                    <span className="text-lg font-black text-indigo-400">
                      {evaluationResult.pronunciationScore}%
                    </span>
                  </div>
                </div>

                {/* Word-by-Word Diff Visualizer */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs font-bold text-slate-300">
                    <span>Слово-за-словом аналіз вимови:</span>
                    <span className="text-[10px] text-slate-400">
                      Клікніть на слово, щоб прослухати
                    </span>
                  </div>

                  <div className="p-4 rounded-2xl bg-slate-950/90 border border-slate-800 flex flex-wrap gap-1.5 items-center leading-loose">
                    {evaluationResult.wordsComparison.map((item, idx) => {
                      let tagStyle =
                        'bg-emerald-500/15 text-emerald-300 border-emerald-500/30 hover:bg-emerald-500/25';
                      let icon = '✓';

                      if (item.status === 'similar') {
                        tagStyle =
                          'bg-amber-500/15 text-amber-300 border-amber-500/30 hover:bg-amber-500/25';
                        icon = '~';
                      } else if (item.status === 'missing') {
                        tagStyle =
                          'bg-rose-500/15 text-rose-300 border-rose-500/30 hover:bg-rose-500/25';
                        icon = '✗';
                      }

                      return (
                        <button
                          key={idx}
                          onClick={() => speakEnglish(item.word)}
                          title={`${item.word}: ${
                            item.note ||
                            (item.status === 'match'
                              ? 'Вимовлено правильно'
                              : item.status === 'similar'
                              ? 'Схоже за звучанням'
                              : 'Пропущено слово')
                          } (Клікніть, щоб прослухати)`}
                          className={`px-2 py-1 rounded-lg text-xs font-bold border transition flex items-center gap-1 cursor-pointer ${tagStyle}`}
                        >
                          <span className="text-[9px] opacity-75 font-mono">{icon}</span>
                          <span>{item.word}</span>
                        </button>
                      );
                    })}
                  </div>

                  {/* Diff Legend */}
                  <div className="flex items-center gap-4 text-[10px] text-slate-400 pt-1">
                    <span className="flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-emerald-400" />
                      <span>Точно вимовлено</span>
                    </span>
                    <span className="flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-amber-400" />
                      <span>Схоже / неточний наголос</span>
                    </span>
                    <span className="flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-rose-400" />
                      <span>Пропущено слово</span>
                    </span>
                  </div>
                </div>

                {/* Connected Speech Findings */}
                {(evaluationResult.connectedSpeechFound?.length > 0 ||
                  evaluationResult.connectedSpeechMissed?.length > 0) && (
                  <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-700/80 space-y-2">
                    <span className="text-xs font-bold text-sky-400 block">
                      Оцінка злиття звуків (Connected Speech):
                    </span>
                    <div className="flex flex-wrap gap-2 text-xs">
                      {evaluationResult.connectedSpeechFound.map((item, idx) => (
                        <span
                          key={idx}
                          className="px-2.5 py-1 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1 font-semibold"
                        >
                          <span>✓ Злито правильно:</span>
                          <strong>«{item}»</strong>
                        </span>
                      ))}
                      {evaluationResult.connectedSpeechMissed.map((item, idx) => (
                        <span
                          key={idx}
                          className="px-2.5 py-1 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1 font-semibold"
                        >
                          <span>Потренувати злиття:</span>
                          <strong>«{item}»</strong>
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* AI Pronunciation Coach Advice */}
                <div className="p-4 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 space-y-1.5 text-xs text-indigo-200">
                  <div className="flex items-center gap-2 font-black text-indigo-300">
                    <Brain className="w-4 h-4 text-indigo-400" />
                    <span>Порада тренера вимови:</span>
                  </div>
                  <p className="leading-relaxed">{evaluationResult.feedbackUa}</p>
                </div>

                {/* Next Steps Buttons */}
                <div className="flex items-center justify-between pt-2">
                  <button
                    onClick={() => {
                      setUserTranscript('');
                      setEditedTranscript('');
                      setEvaluationResult(null);
                      setRecordedAudioUrl(null);
                      handleStartRecording();
                    }}
                    className="px-4 py-2.5 rounded-xl bg-slate-700 hover:bg-slate-600 text-slate-200 font-bold text-xs flex items-center gap-1.5 transition cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Записати ще раз</span>
                  </button>

                  <button
                    onClick={() => {
                      const curIdx = SHADOWING_EXERCISES.findIndex(
                        (e) => e.id === selectedShadowing.id
                      );
                      const nextEx =
                        SHADOWING_EXERCISES[(curIdx + 1) % SHADOWING_EXERCISES.length];
                      playSound('click');
                      setSelectedShadowing(nextEx);
                      setRecordedAudioUrl(null);
                      setUserTranscript('');
                      setEditedTranscript('');
                      setEvaluationResult(null);
                      setIsEditingTranscript(false);
                    }}
                    className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-md transition cursor-pointer"
                  >
                    <span>Наступна фраза</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ================= TAB 3: CHUNKS & COLLOCATIONS ================= */}
      {activeTab === 'chunks' && (
        <div className="space-y-6">
          {/* Subview Switcher: Catalog vs Dedicated Test */}
          <div className="p-3 sm:p-4 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-lg">
            <div className="flex items-center gap-2 overflow-x-auto no-scrollbar w-full sm:w-auto">
              <button
                onClick={() => {
                  playSound('click');
                  setChunksSubView('catalog');
                }}
                className={`px-4 py-2 rounded-xl text-xs font-black transition flex items-center gap-2 whitespace-nowrap ${
                  chunksSubView === 'catalog'
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/25'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                <BookOpen className="w-4 h-4" />
                <span>Каталог чанків ({CHUNK_ITEMS.length})</span>
              </button>

              <button
                onClick={() => {
                  playSound('click');
                  setChunksSubView('test');
                }}
                className={`px-4 py-2 rounded-xl text-xs font-black transition flex items-center gap-2 whitespace-nowrap ${
                  chunksSubView === 'test'
                    ? 'bg-gradient-to-r from-indigo-600 to-sky-600 text-white shadow-lg shadow-indigo-600/25'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                <Award className="w-4 h-4 text-amber-400" />
                <span>🎯 Окремий тест на колокації</span>
              </button>
            </div>

            <div className="text-[11px] text-slate-400 font-bold hidden md:block">
              {chunksSubView === 'catalog'
                ? `Досліджуйте ${CHUNK_ITEMS.length} сталих виразів або перевірте знання`
                : 'Інтерактивний тренажер пропусків, кальок та перекладів'}
            </div>
          </div>

          {/* DEDICATED TEST SUB-VIEW */}
          {chunksSubView === 'test' ? (
            <ChunkTestStudio
              onRewardXP={onRewardXP}
              onToast={onToast}
              onRecordMistake={onRecordMistake}
              onClose={() => setChunksSubView('catalog')}
              initialCategory={selectedChunkCategory as any}
            />
          ) : (
            <>
              {/* Methodology Info Card */}
              <div className="p-4 sm:p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-lg text-[10px] font-black uppercase tracking-wider bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                    The Lexical Approach (Michael Lewis)
                  </span>
                  <span className="text-xs text-slate-400 font-bold">Мислення готовими блоками</span>
                </div>
                <h4 className="text-sm sm:text-base font-black text-white">
                  Вчіть неподільні колокації замість окремих слів
                </h4>
                <p className="text-xs text-slate-300">
                  Носії мови не збирають кожне речення з нуля — вони комбінують готові мовні шаблони (*make a decision*, *take into account*, *touch base*).
                </p>
              </div>

              {/* Dedicated Test Banner */}
              <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-indigo-950/70 via-slate-900 to-sky-950/70 border border-indigo-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded-lg text-[10px] font-black uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/30">
                      Окремий тест
                    </span>
                    <span className="text-xs text-slate-400 font-bold">{CHUNK_ITEMS.length} виразів з тестами</span>
                  </div>
                  <h4 className="text-sm sm:text-base font-black text-white">
                    Бажаєте протестувати свої знання колокацій?
                  </h4>
                  <p className="text-xs text-slate-300">
                    Пройдіть інтерактивний іспит на пропуски, типові помилки (make vs do, take vs have) та швидкісний вибір природних фраз.
                  </p>
                </div>
                <button
                  onClick={() => {
                    playSound('click');
                    setChunksSubView('test');
                  }}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-sky-600 hover:from-indigo-500 hover:to-sky-500 text-white text-xs font-black shadow-lg shadow-indigo-600/20 transition flex items-center gap-2 whitespace-nowrap self-stretch sm:self-auto justify-center"
                >
                  <Award className="w-4 h-4 text-amber-300" />
                  <span>Запустити тест на чанки</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>

              {/* Category Filter */}
              <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
                {[
                  { id: 'all', label: 'Усі чанки' },
                  { id: 'make_vs_do', label: 'Make vs Do' },
                  { id: 'take_have_get', label: 'Take / Have / Get' },
                  { id: 'business_chunks', label: 'Бізнес & IT' },
                  { id: 'conversation_starters', label: 'Розмовні зв\'язки' },
                  { id: 'connectors', label: 'Конектори думок' },
                  { id: 'idiomatic_collocations', label: 'Ідіоматичні вирази' },
                ].map((cat) => {
                  const count = cat.id === 'all' ? CHUNK_ITEMS.length : CHUNK_ITEMS.filter((c) => c.category === cat.id).length;
                  const isSelected = selectedChunkCategory === cat.id;
                  return (
                    <button
                      key={cat.id}
                      onClick={() => {
                        playSound('click');
                        setSelectedChunkCategory(cat.id);
                      }}
                      className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition whitespace-nowrap flex items-center gap-1.5 ${
                        isSelected
                          ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/20'
                          : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      <span>{cat.label}</span>
                      <span className={`px-1.5 py-0.5 rounded-full text-[10px] font-black ${isSelected ? 'bg-black/30 text-white' : 'bg-slate-900 text-slate-400'}`}>
                        {count}
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* Chunks Cards Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredChunks.map((item) => (
                  <div
                    key={item.id}
                    className="p-5 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col justify-between space-y-3 hover:border-slate-700 transition"
                  >
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-slate-400">{item.ukr}</span>
                        <div className="flex items-center gap-1">
                          {item.level && (
                            <span className="px-1.5 py-0.5 rounded text-[10px] font-black bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                              {item.level}
                            </span>
                          )}
                          <button
                            onClick={() => speakEnglish(item.chunk)}
                            className="p-1 rounded-lg text-slate-400 hover:text-white transition"
                            title="Озвучити"
                          >
                            <Volume2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                      <h4 className="text-lg font-black text-indigo-400">{item.chunk}</h4>
                      <div className="p-2 rounded-xl bg-rose-950/40 border border-rose-500/30 text-[11px] text-rose-300">
                        {item.typicalMistake}
                      </div>
                      <p className="text-xs text-slate-300 italic pt-1">"{item.exampleSent}"</p>
                      {item.explanation && (
                        <p className="text-[11px] text-slate-400 pt-0.5">💡 {item.explanation}</p>
                      )}
                    </div>
                    <div className="pt-2 border-t border-slate-800 flex items-center justify-between gap-2">
                      <button
                        onClick={() => handleStartChunkQuiz(item)}
                        className="text-xs font-bold text-blue-400 hover:text-blue-300 flex items-center gap-1 transition"
                      >
                        <span>Експрес-перевірка</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={() => {
                          playSound('click');
                          setSelectedChunkCategory(item.category);
                          setChunksSubView('test');
                        }}
                        className="text-[11px] text-slate-400 hover:text-indigo-300 flex items-center gap-1 transition"
                        title="Пройти тест за цією категорією"
                      >
                        <span>Тест теми</span>
                        <Award className="w-3 h-3 text-amber-400" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {/* Interactive Express Chunk Quiz Modal / Box */}
              {chunkQuizItem && (
                <div className="max-w-md mx-auto bg-slate-900 rounded-3xl border border-indigo-500/40 p-6 shadow-2xl space-y-4">
                  <div className="flex items-center justify-between text-xs font-bold text-slate-400">
                    <span>Експрес-перевірка колокації</span>
                    <button
                      onClick={() => setChunkQuizItem(null)}
                      className="text-slate-400 hover:text-white"
                    >
                      ✕
                    </button>
                  </div>

                  <div className="text-center space-y-1">
                    <span className="text-[11px] uppercase font-bold text-slate-500">
                      Як правильно сказати:
                    </span>
                    <h4 className="text-xl font-black text-white">«{chunkQuizItem.ukr}»?</h4>
                  </div>

                  <div className="space-y-2">
                    {[
                      chunkQuizItem.chunk,
                      chunkQuizItem.typicalMistake.split('❌')[1]?.split('➔')[0]?.trim() || 'take it wrong',
                    ]
                      .sort(() => 0.5 - Math.random())
                      .map((opt) => {
                        const isSelected = chunkSelectedAnswer === opt;
                        const isCorrect = opt === chunkQuizItem.chunk;
                        let btnStyle = 'w-full p-3 rounded-xl border text-xs font-bold text-left transition ';
                        if (chunkSelectedAnswer === null) {
                          btnStyle += 'bg-slate-800 border-slate-700 text-white hover:bg-slate-700';
                        } else if (isCorrect) {
                          btnStyle += 'bg-emerald-950/60 border-emerald-500 text-emerald-300';
                        } else if (isSelected && !isCorrect) {
                          btnStyle += 'bg-rose-950/60 border-rose-500 text-rose-300';
                        } else {
                          btnStyle += 'bg-slate-800/40 border-slate-800 text-slate-500';
                        }

                        return (
                          <button
                            key={opt}
                            disabled={chunkSelectedAnswer !== null}
                            onClick={() => handleSelectChunkAnswer(opt)}
                            className={btnStyle}
                          >
                            {opt}
                          </button>
                        );
                      })}
                  </div>

                  {chunkSelectedAnswer !== null && (
                    <div className="space-y-2 pt-2">
                      <div className="text-[11px] text-slate-300 p-2.5 rounded-xl bg-slate-950/60 border border-slate-800">
                        {chunkQuizItem.explanation || chunkQuizItem.typicalMistake}
                      </div>
                      <div className="flex items-center justify-between">
                        <button
                          onClick={() => {
                            setChunkQuizItem(null);
                            setSelectedChunkCategory(chunkQuizItem.category);
                            setChunksSubView('test');
                          }}
                          className="text-xs text-indigo-400 hover:text-indigo-300 font-bold flex items-center gap-1"
                        >
                          <Award className="w-3.5 h-3.5 text-amber-400" />
                          <span>Пройти повний тест теми</span>
                        </button>
                        <button
                          onClick={() => setChunkQuizItem(null)}
                          className="px-4 py-2 rounded-xl bg-blue-600 text-white font-bold text-xs"
                        >
                          Готово
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </>
          )}
        </div>
      )}

      {/* ================= TAB 4: COMPREHENSIBLE INPUT (i+1) ================= */}
      {activeTab === 'input' && (
        <div className="space-y-6">
          {/* Methodology Info Card */}
          <div className="p-4 sm:p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-lg text-[10px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                Krashen's Input Hypothesis (i+1)
              </span>
              <span className="text-xs text-slate-400 font-bold">Природне розуміння в контексті</span>
            </div>
            <h4 className="text-sm sm:text-base font-black text-white">
              Засвоєння мови через зрозумілі тексти на 1 рівень вище вашого поточного
            </h4>
            <p className="text-xs text-slate-300">
              Читайте мікро-історії, слухайте паралельне озвучення та відповідайте на запитання для перевірки розуміння без стресу.
            </p>
          </div>

          {/* Stories Switcher */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
            {MICRO_STORIES.map((story, idx) => (
              <button
                key={story.id}
                onClick={() => {
                  playSound('click');
                  setSelectedStoryIndex(idx);
                  setStoryAnswerSelected(null);
                }}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap flex items-center gap-1.5 ${
                  selectedStoryIndex === idx
                    ? 'bg-emerald-600 text-white shadow'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                <span>{story.title}</span>
                <span className="text-[10px] opacity-75">({story.level})</span>
              </button>
            ))}
          </div>

          {/* Active Story Card */}
          <div className="max-w-2xl mx-auto bg-slate-900 rounded-3xl border border-slate-800 p-6 sm:p-8 shadow-2xl space-y-6">
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <span className="px-2.5 py-0.5 rounded-lg text-[10px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Рівень {currentStory.level}
                </span>
                <span className="text-xs text-slate-400">Клікайте 🔊 для озвучення речень</span>
              </div>
              <h3 className="text-2xl font-black text-white">{currentStory.title}</h3>
              <p className="text-xs text-slate-400">{currentStory.ukrSummary}</p>
            </div>

            {/* Paragraphs */}
            <div className="space-y-3 pt-2">
              {currentStory.content.map((p, idx) => (
                <div
                  key={idx}
                  className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 flex items-start justify-between gap-3 group hover:border-slate-700 transition"
                >
                  <div className="space-y-1">
                    <p className="text-sm sm:text-base font-bold text-slate-100">{p.en}</p>
                    <p className="text-xs text-slate-400">{p.ua}</p>
                  </div>
                  <button
                    onClick={() => handlePlayStoryParagraph(p.en)}
                    className="p-2 rounded-xl bg-slate-800 hover:bg-blue-600 text-slate-300 hover:text-white transition shrink-0"
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>

            {/* Comprehension Quiz Box */}
            <div className="p-5 rounded-2xl bg-slate-800/60 border border-slate-700/80 space-y-3">
              <div className="flex items-center gap-2 text-xs font-bold text-amber-300">
                <HelpCircle className="w-4 h-4" />
                <span>Перевірка розуміння змісту:</span>
              </div>
              <h5 className="text-sm font-black text-white">
                {currentStory.comprehensionQuestion.question}
              </h5>

              <div className="space-y-2 pt-1">
                {currentStory.comprehensionQuestion.options.map((opt) => {
                  const isSelected = storyAnswerSelected === opt;
                  const isCorrect = opt === currentStory.comprehensionQuestion.correct;
                  let style = 'w-full p-3 rounded-xl border text-xs font-bold text-left transition ';
                  if (storyAnswerSelected === null) {
                    style += 'bg-slate-900 border-slate-700 text-slate-200 hover:bg-slate-800';
                  } else if (isCorrect) {
                    style += 'bg-emerald-950/60 border-emerald-500 text-emerald-300';
                  } else if (isSelected && !isCorrect) {
                    style += 'bg-rose-950/60 border-rose-500 text-rose-300';
                  } else {
                    style += 'bg-slate-900/40 border-slate-800 text-slate-500 opacity-60';
                  }

                  return (
                    <button
                      key={opt}
                      disabled={storyAnswerSelected !== null}
                      onClick={() => handleSelectStoryAnswer(opt)}
                      className={style}
                    >
                      {opt}
                    </button>
                  );
                })}
              </div>

              {storyAnswerSelected !== null && (
                <div className="p-3 rounded-xl bg-indigo-950/40 border border-indigo-500/30 text-xs text-slate-300 animate-fadeIn">
                  <strong>Пояснення:</strong> {currentStory.comprehensionQuestion.explanation}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Microphone Diagnostic & Live Test Modal */}
      <MicrophoneDiagnosticModal
        isOpen={isMicDiagnosticOpen}
        onClose={() => setIsMicDiagnosticOpen(false)}
        selectedDeviceId={selectedDeviceId}
        onSelectDeviceId={setSelectedDeviceId}
      />
    </section>
  );
};
