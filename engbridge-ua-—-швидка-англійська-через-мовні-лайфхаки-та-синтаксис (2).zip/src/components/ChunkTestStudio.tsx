import React, { useState, useMemo, useEffect } from 'react';
import {
  Trophy,
  CheckCircle,
  XCircle,
  Volume2,
  ArrowRight,
  RotateCcw,
  Sparkles,
  Flame,
  Award,
  Layers,
  Sliders,
  BookOpen,
  Filter,
  Check,
  X,
  AlertTriangle,
  Lightbulb,
} from 'lucide-react';
import { CHUNK_ITEMS } from '../data/chunksData';
import { ChunkCategory, ChunkItem } from '../types';
import { playSound, speakEnglish } from '../utils/audio';

interface ChunkTestStudioProps {
  onRewardXP: (amount: number) => void;
  onToast: (msg: string, type: 'info' | 'success' | 'error') => void;
  onRecordMistake?: (mistake: {
    prompt: string;
    userWrongAnswer: string;
    correctAnswer: string;
    explanation: string;
    category?: string;
  }) => void;
  onClose?: () => void;
  initialCategory?: ChunkCategory;
}

type QuestionType = 'blank' | 'translation' | 'fix_mistake';

interface GeneratedQuestion {
  id: string;
  chunkItem: ChunkItem;
  type: QuestionType;
  prompt: string;
  subPrompt?: string;
  questionSentence?: string;
  options: string[];
  correctAnswer: string;
  explanation: string;
}

const CATEGORY_LABELS: Record<ChunkCategory, string> = {
  all: 'Усі категорії',
  make_vs_do: 'Make vs Do',
  take_have_get: 'Take / Have / Get',
  business_chunks: 'Бізнес & IT',
  conversation_starters: 'Розмовні зв’язки',
  connectors: 'Конектори думок',
  idiomatic_collocations: 'Ідіоматичні вирази',
};

export const ChunkTestStudio: React.FC<ChunkTestStudioProps> = ({
  onRewardXP,
  onToast,
  onRecordMistake,
  onClose,
  initialCategory = 'all',
}) => {
  const [selectedCategory, setSelectedCategory] = useState<ChunkCategory>(initialCategory);
  const [testLength, setTestLength] = useState<10 | 15 | 25>(15);
  const [isTestStarted, setIsTestStarted] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [isAnswerChecked, setIsAnswerChecked] = useState(false);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [maxStreak, setMaxStreak] = useState(0);
  const [isCompleted, setIsCompleted] = useState(false);
  const [questions, setQuestions] = useState<GeneratedQuestion[]>([]);
  const [userAnswersHistory, setUserAnswersHistory] = useState<{
    question: GeneratedQuestion;
    userAnswer: string;
    isCorrect: boolean;
  }[]>([]);

  // Generate test questions
  const generateQuestions = (cat: ChunkCategory, count: number): GeneratedQuestion[] => {
    let pool = cat === 'all' ? [...CHUNK_ITEMS] : CHUNK_ITEMS.filter((c) => c.category === cat);
    if (pool.length === 0) pool = [...CHUNK_ITEMS];

    // Shuffle pool
    const shuffledPool = [...pool].sort(() => 0.5 - Math.random());
    const selectedPool = shuffledPool.slice(0, Math.min(count, shuffledPool.length));

    return selectedPool.map((item, idx) => {
      // Determine question style
      const styles: QuestionType[] = ['blank', 'translation', 'fix_mistake'];
      const style = styles[idx % styles.length];

      if (style === 'blank' && item.blankSent && item.correctWord && item.options) {
        return {
          id: `q-${item.id}-${idx}`,
          chunkItem: item,
          type: 'blank',
          prompt: 'Вставте правильне слово в колокацію:',
          subPrompt: `Переклад: «${item.ukr}»`,
          questionSentence: item.blankSent,
          options: [...item.options].sort(() => 0.5 - Math.random()),
          correctAnswer: item.correctWord,
          explanation: item.explanation || item.typicalMistake,
        };
      } else if (style === 'fix_mistake') {
        const wrongCalque = item.typicalMistake.split('❌')[1]?.split('➔')[0]?.trim() || '';
        const optSet = new Set<string>([item.chunk]);
        if (wrongCalque && wrongCalque.toLowerCase() !== item.chunk.toLowerCase()) {
          optSet.add(wrongCalque);
        }

        const otherChunks = CHUNK_ITEMS
          .filter((c) => c.id !== item.id)
          .sort(() => 0.5 - Math.random());

        for (const c of otherChunks) {
          if (optSet.size >= 4) break;
          optSet.add(c.chunk);
        }

        const options = Array.from(optSet).sort(() => 0.5 - Math.random());

        return {
          id: `q-${item.id}-${idx}`,
          chunkItem: item,
          type: 'fix_mistake',
          prompt: 'Виправте типову кальку/помилку:',
          subPrompt: `Значення: «${item.ukr}»`,
          questionSentence: wrongCalque ? `Типова помилка: ${wrongCalque}` : `Оберіть правильний вираз для «${item.ukr}»`,
          options,
          correctAnswer: item.chunk,
          explanation: item.explanation || item.typicalMistake,
        };
      } else {
        // Translation / natural expression matcher
        const optSet = new Set<string>([item.chunk]);
        const otherChunks = CHUNK_ITEMS
          .filter((c) => c.id !== item.id)
          .sort(() => 0.5 - Math.random());

        for (const c of otherChunks) {
          if (optSet.size >= 4) break;
          optSet.add(c.chunk);
        }

        const options = Array.from(optSet).sort(() => 0.5 - Math.random());

        return {
          id: `q-${item.id}-${idx}`,
          chunkItem: item,
          type: 'translation',
          prompt: 'Оберіть природну англійську колокацію для:',
          subPrompt: 'Контекстний вираз',
          questionSentence: `«${item.ukr}»`,
          options,
          correctAnswer: item.chunk,
          explanation: `${item.typicalMistake}. Приклад: "${item.exampleSent}"`,
        };
      }
    });
  };

  const handleStartTest = (cat = selectedCategory, len = testLength) => {
    playSound('click');
    const newQuestions = generateQuestions(cat, len);
    setQuestions(newQuestions);
    setCurrentIndex(0);
    setSelectedAnswer(null);
    setIsAnswerChecked(false);
    setScore(0);
    setStreak(0);
    setMaxStreak(0);
    setUserAnswersHistory([]);
    setIsCompleted(false);
    setIsTestStarted(true);
  };

  const currentQ = questions[currentIndex];

  const handleSelectOption = (opt: string) => {
    if (isAnswerChecked) return;
    playSound('click');
    setSelectedAnswer(opt);
  };

  const handleCheckAnswer = () => {
    if (!selectedAnswer || isAnswerChecked || !currentQ) return;
    setIsAnswerChecked(true);

    const isCorrect = selectedAnswer.trim().toLowerCase() === currentQ.correctAnswer.trim().toLowerCase();

    if (isCorrect) {
      playSound('correct');
      setScore((prev) => prev + 1);
      setStreak((prev) => {
        const next = prev + 1;
        if (next > maxStreak) setMaxStreak(next);
        if (next % 3 === 0) playSound('combo');
        return next;
      });
    } else {
      playSound('wrong');
      setStreak(0);
      if (onRecordMistake) {
        onRecordMistake({
          prompt: currentQ.questionSentence || currentQ.prompt,
          userWrongAnswer: selectedAnswer,
          correctAnswer: currentQ.correctAnswer,
          explanation: currentQ.explanation,
          category: CATEGORY_LABELS[currentQ.chunkItem.category],
        });
      }
    }

    setUserAnswersHistory((prev) => [
      ...prev,
      {
        question: currentQ,
        userAnswer: selectedAnswer,
        isCorrect,
      },
    ]);
  };

  const handleNextQuestion = () => {
    playSound('click');
    if (currentIndex + 1 < questions.length) {
      setCurrentIndex((prev) => prev + 1);
      setSelectedAnswer(null);
      setIsAnswerChecked(false);
    } else {
      // Completed!
      setIsCompleted(true);
      const earnedXP = score * 5 + 25;
      onRewardXP(earnedXP);
      playSound('trophy');
      onToast(`🎉 Тест завершено! Ви заробили +${earnedXP} XP`, 'success');
    }
  };

  const handleRetakeMistakes = () => {
    const wrongQuestions = userAnswersHistory
      .filter((h) => !h.isCorrect)
      .map((h) => h.question);

    if (wrongQuestions.length === 0) {
      onToast('У вас немає помилок у цьому тесті!', 'success');
      return;
    }

    playSound('click');
    setQuestions(wrongQuestions.sort(() => 0.5 - Math.random()));
    setCurrentIndex(0);
    setSelectedAnswer(null);
    setIsAnswerChecked(false);
    setScore(0);
    setStreak(0);
    setUserAnswersHistory([]);
    setIsCompleted(false);
    setIsTestStarted(true);
  };

  // If not started yet, show welcome & settings screen
  if (!isTestStarted) {
    const availableCount =
      selectedCategory === 'all'
        ? CHUNK_ITEMS.length
        : CHUNK_ITEMS.filter((c) => c.category === selectedCategory).length;

    return (
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-lg text-[10px] font-black uppercase tracking-wider bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                Окремий тест • Lexical Collocations
              </span>
              <span className="text-xs text-slate-400 font-bold">Всього в базі: {CHUNK_ITEMS.length} чанків</span>
            </div>
            <h3 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
              <Layers className="w-6 h-6 text-indigo-400" />
              <span>Тестування мовних чанків та колокацій</span>
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl">
              Перевірте здатність мислити неподільними мовними блоками (chunks). Тест включає заповнення пропусків,
              виправлення русизмів/кальок (Make vs Do, Take/Have/Get) та пошук природних виразів.
            </p>
          </div>

          {onClose && (
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
              title="Закрити тест"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Category Picker */}
        <div className="space-y-2">
          <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
            <Filter className="w-3.5 h-3.5 text-indigo-400" />
            <span>Оберіть категорію тестування:</span>
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2">
            {(Object.keys(CATEGORY_LABELS) as ChunkCategory[]).map((cat) => {
              const count = cat === 'all' ? CHUNK_ITEMS.length : CHUNK_ITEMS.filter((c) => c.category === cat).length;
              const isSelected = selectedCategory === cat;
              return (
                <button
                  key={cat}
                  onClick={() => {
                    playSound('click');
                    setSelectedCategory(cat);
                  }}
                  className={`p-3 rounded-2xl text-left border transition flex flex-col justify-between gap-1.5 ${
                    isSelected
                      ? 'bg-indigo-600/20 border-indigo-500 text-white shadow-lg shadow-indigo-500/10'
                      : 'bg-slate-800/60 border-slate-700 text-slate-300 hover:bg-slate-800 hover:border-slate-600'
                  }`}
                >
                  <span className="text-xs font-black">{CATEGORY_LABELS[cat]}</span>
                  <span className={`text-[10px] font-bold ${isSelected ? 'text-indigo-300' : 'text-slate-400'}`}>
                    {count} виразів
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Length Picker */}
        <div className="space-y-2">
          <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
            <Sliders className="w-3.5 h-3.5 text-indigo-400" />
            <span>Кількість питань у раунді:</span>
          </label>
          <div className="flex items-center gap-3">
            {[10, 15, 25].map((len) => (
              <button
                key={len}
                onClick={() => {
                  playSound('click');
                  setTestLength(len as any);
                }}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition border ${
                  testLength === len
                    ? 'bg-indigo-600 text-white border-indigo-500'
                    : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                }`}
              >
                {len} питань
              </button>
            ))}
          </div>
        </div>

        {/* Start Button */}
        <div className="pt-4 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-xs text-slate-400">
            Готово до тесту: <strong className="text-white">{Math.min(testLength, availableCount)} питань</strong> за категорією{' '}
            <strong className="text-indigo-400">{CATEGORY_LABELS[selectedCategory]}</strong>
          </div>
          <button
            onClick={() => handleStartTest()}
            className="w-full sm:w-auto px-8 py-3.5 rounded-2xl bg-gradient-to-r from-indigo-600 to-sky-600 hover:from-indigo-500 hover:to-sky-500 text-white font-black text-sm shadow-xl shadow-indigo-600/25 transition flex items-center justify-center gap-2"
          >
            <Sparkles className="w-4 h-4 text-amber-300" />
            <span>Почати тестування</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    );
  }

  // If test completed, show detailed Results Screen
  if (isCompleted) {
    const percent = Math.round((score / questions.length) * 100);
    const mistakesCount = questions.length - score;

    return (
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 max-w-3xl mx-auto shadow-2xl">
        {/* Results Header */}
        <div className="text-center space-y-3 pb-6 border-b border-slate-800">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-indigo-600 to-sky-400 flex items-center justify-center mx-auto text-white shadow-xl shadow-indigo-500/30">
            <Trophy className="w-8 h-8 text-amber-300" />
          </div>
          <div>
            <h3 className="text-2xl font-black text-white">Тест успішно завершено!</h3>
            <p className="text-xs text-slate-400">
              Категорія: <span className="text-indigo-400 font-bold">{CATEGORY_LABELS[selectedCategory]}</span>
            </p>
          </div>

          <div className="flex items-center justify-center gap-6 pt-2">
            <div className="text-center">
              <span className="text-2xl sm:text-3xl font-black text-emerald-400">{score}/{questions.length}</span>
              <p className="text-[11px] text-slate-400 font-bold uppercase tracking-wider">Правильно</p>
            </div>
            <div className="text-center border-x border-slate-800 px-6">
              <span className="text-2xl sm:text-3xl font-black text-indigo-400">{percent}%</span>
              <p className="text-[11px] text-slate-400 font-bold uppercase tracking-wider">Успішність</p>
            </div>
            <div className="text-center">
              <span className="text-2xl sm:text-3xl font-black text-amber-400">{maxStreak}</span>
              <p className="text-[11px] text-slate-400 font-bold uppercase tracking-wider">Макс. Серія 🔥</p>
            </div>
          </div>
        </div>

        {/* Detailed Breakdown */}
        <div className="space-y-3">
          <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">Розбір відповідей раунду:</h4>
          <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
            {userAnswersHistory.map((item, idx) => (
              <div
                key={idx}
                className={`p-3 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs ${
                  item.isCorrect
                    ? 'bg-emerald-950/20 border-emerald-500/30 text-emerald-200'
                    : 'bg-rose-950/20 border-rose-500/30 text-rose-200'
                }`}
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 font-bold">
                    {item.isCorrect ? (
                      <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                    ) : (
                      <XCircle className="w-4 h-4 text-rose-400 shrink-0" />
                    )}
                    <span className="text-white">{item.question.questionSentence || item.question.prompt}</span>
                  </div>
                  <div className="text-[11px] text-slate-300">
                    Правильно: <strong className="text-emerald-400">{item.question.correctAnswer}</strong>
                    {!item.isCorrect && (
                      <span className="text-rose-400 ml-2">Ваша відповідь: <s>{item.userAnswer}</s></span>
                    )}
                  </div>
                </div>

                <button
                  onClick={() => speakEnglish(item.question.chunkItem.chunk)}
                  className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition shrink-0 self-start sm:self-center"
                  title="Озвучити вираз"
                >
                  <Volume2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Actions */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-4 border-t border-slate-800">
          {mistakesCount > 0 ? (
            <button
              onClick={handleRetakeMistakes}
              className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs transition flex items-center justify-center gap-1.5"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Опрацювати помилки ({mistakesCount})</span>
            </button>
          ) : (
            <div className="text-xs text-emerald-400 font-bold flex items-center gap-1">
              <Check className="w-4 h-4" /> Бездоганний результат! Жодної помилки!
            </div>
          )}

          <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
            <button
              onClick={() => handleStartTest()}
              className="flex-1 sm:flex-none px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs transition flex items-center justify-center gap-1.5"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Новий тест</span>
            </button>

            <button
              onClick={() => setIsTestStarted(false)}
              className="flex-1 sm:flex-none px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition"
            >
              Змінити налаштування
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Active question screen
  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-7 space-y-6 max-w-2xl mx-auto shadow-2xl">
      {/* Top Bar: Progress, Streak, Exit */}
      <div className="flex items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2">
          <span className="px-2.5 py-0.5 rounded-lg bg-indigo-500/20 text-indigo-300 font-bold">
            Питання {currentIndex + 1} з {questions.length}
          </span>
          <span className="text-slate-400 font-bold hidden sm:inline">
            {CATEGORY_LABELS[currentQ.chunkItem.category]}
          </span>
        </div>

        <div className="flex items-center gap-3">
          {streak > 1 && (
            <div className="flex items-center gap-1 px-2.5 py-0.5 rounded-lg bg-amber-500/20 text-amber-300 font-black animate-pulse">
              <Flame className="w-3.5 h-3.5 text-amber-400" />
              <span>{streak} підряд!</span>
            </div>
          )}
          <span className="font-bold text-emerald-400">Рахунок: {score}</span>
          <button
            onClick={() => setIsTestStarted(false)}
            className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white transition"
            title="Завершити тест"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
        <div
          className="bg-gradient-to-r from-indigo-500 to-sky-400 h-full transition-all duration-300"
          style={{ width: `${((currentIndex + 1) / questions.length) * 100}%` }}
        />
      </div>

      {/* Prompt Card */}
      <div className="space-y-3 text-center py-2">
        <div className="space-y-1">
          <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-400">
            {currentQ.prompt}
          </span>
          {currentQ.subPrompt && (
            <p className="text-xs text-slate-400 font-medium">{currentQ.subPrompt}</p>
          )}
        </div>

        <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-2">
          <h3 className="text-lg sm:text-xl font-black text-white tracking-wide">
            {currentQ.questionSentence}
          </h3>
          <button
            onClick={() => speakEnglish(currentQ.chunkItem.exampleSent || currentQ.chunkItem.chunk)}
            className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition"
          >
            <Volume2 className="w-3.5 h-3.5 text-indigo-400" />
            <span>Прослухати контекст</span>
          </button>
        </div>
      </div>

      {/* Options Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
        {currentQ.options.map((option) => {
          const isSelected = selectedAnswer === option;
          const isCorrect = option.trim().toLowerCase() === currentQ.correctAnswer.trim().toLowerCase();

          let btnClass = 'w-full p-4 rounded-2xl border text-sm font-bold text-left transition relative flex items-center justify-between ';

          if (!isAnswerChecked) {
            btnClass += isSelected
              ? 'bg-indigo-600/30 border-indigo-500 text-white shadow-lg shadow-indigo-500/10'
              : 'bg-slate-800/80 border-slate-700/80 text-slate-200 hover:bg-slate-800 hover:border-slate-600';
          } else {
            if (isCorrect) {
              btnClass += 'bg-emerald-950/60 border-emerald-500 text-emerald-200 shadow-lg shadow-emerald-500/10';
            } else if (isSelected && !isCorrect) {
              btnClass += 'bg-rose-950/60 border-rose-500 text-rose-200';
            } else {
              btnClass += 'bg-slate-800/40 border-slate-800 text-slate-500 opacity-60';
            }
          }

          return (
            <button
              key={option}
              disabled={isAnswerChecked}
              onClick={() => handleSelectOption(option)}
              className={btnClass}
            >
              <span>{option}</span>
              {isAnswerChecked && isCorrect && <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0" />}
              {isAnswerChecked && isSelected && !isCorrect && (
                <XCircle className="w-5 h-5 text-rose-400 shrink-0" />
              )}
            </button>
          );
        })}
      </div>

      {/* Explanation Banner (after check) */}
      {isAnswerChecked && (
        <div className="p-4 rounded-2xl bg-indigo-950/40 border border-indigo-500/30 space-y-2 text-xs">
          <div className="flex items-center gap-1.5 font-bold text-indigo-300">
            <Lightbulb className="w-4 h-4 text-amber-300" />
            <span>Чому саме так?</span>
          </div>
          <p className="text-slate-200 leading-relaxed">{currentQ.explanation}</p>
          <div className="text-[11px] text-slate-400 italic">
            Приклад у мовленні: "{currentQ.chunkItem.exampleSent}"
          </div>
        </div>
      )}

      {/* Bottom Controls */}
      <div className="flex items-center justify-between gap-3 pt-2">
        <span className="text-xs text-slate-500">
          {!isAnswerChecked ? 'Оберіть варіант і натисніть Перевірити' : 'Перегляньте пояснення та рухайтесь далі'}
        </span>

        {!isAnswerChecked ? (
          <button
            disabled={!selectedAnswer}
            onClick={handleCheckAnswer}
            className={`px-6 py-3 rounded-2xl font-black text-xs transition flex items-center gap-2 ${
              selectedAnswer
                ? 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-600/25'
                : 'bg-slate-800 text-slate-500 cursor-not-allowed'
            }`}
          >
            <span>Перевірити</span>
            <Check className="w-4 h-4" />
          </button>
        ) : (
          <button
            onClick={handleNextQuestion}
            className="px-6 py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs shadow-lg shadow-emerald-600/25 transition flex items-center gap-2"
          >
            <span>{currentIndex + 1 < questions.length ? 'Наступне питання' : 'Переглянути результати'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        )}
      </div>
    </div>
  );
};
