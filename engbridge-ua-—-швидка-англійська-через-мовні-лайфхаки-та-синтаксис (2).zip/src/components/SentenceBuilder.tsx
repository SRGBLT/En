import React, { useState, useEffect, useMemo } from 'react';
import {
  LayoutGrid,
  RotateCcw,
  Volume2,
  Check,
  ArrowRight,
  ArrowLeft,
  CheckCircle,
  AlertCircle,
  X,
  Sparkles,
  Info,
  Sliders,
  HelpCircle,
  Shuffle,
  ChevronLeft,
  ChevronRight,
  Lock,
  Unlock,
  Trophy,
  Award,
} from 'lucide-react';
import { LEVEL_SYNTAX_INFO, SENTENCE_PUZZLES } from '../data/hacks';
import { CefrLevel, SentencePuzzle } from '../types';
import { playSound, speakEnglish } from '../utils/audio';

interface SentenceBuilderProps {
  initialLevel?: CefrLevel;
  onRewardXP: (amount: number) => void;
  onToast: (msg: string, type: 'info' | 'success' | 'error') => void;
  onRecordMistake?: (puzzle: SentencePuzzle, userSentence: string) => void;
}

const UNLOCK_THRESHOLD = 28; // Require at least 28 out of 30 correct puzzles to unlock next level
const CEFR_LEVELS_ORDER: CefrLevel[] = ['A1', 'A2', 'B1', 'B2', 'C1'];

const LEVEL_RULES_NAMES: Record<CefrLevel, string> = {
  A1: 'Формула SVOMPT & Present Simple',
  A2: 'Past Simple, Modals & Conjunctions',
  B1: 'Present Perfect & Conditionals',
  B2: 'Mixed Conditionals, Inversion & Passive',
  C1: 'Майстер Інверсії, Subjunctive & Cleft',
};

const ROLE_COLORS: Record<string, string> = {
  Subject: 'bg-blue-500/20 text-blue-300 border-blue-500/40',
  Verb: 'bg-purple-500/20 text-purple-300 border-purple-500/40',
  Object: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
  Manner: 'bg-amber-500/20 text-amber-300 border-amber-500/40',
  Place: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40',
  Time: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/40',
  Connector: 'bg-rose-500/20 text-rose-300 border-rose-500/40',
  Modal: 'bg-fuchsia-500/20 text-fuchsia-300 border-fuchsia-500/40',
  Condition: 'bg-orange-500/20 text-orange-300 border-orange-500/40',
  Auxiliary: 'bg-teal-500/20 text-teal-300 border-teal-500/40',
};

// Sandbox components for the live SVOMPT builder playground
const SANDBOX_SUBJECTS = [
  'We',
  'They',
  'My friend',
  'The team',
  'She',
  'He',
  'Software engineers',
  'Our manager',
  'Ukrainian developers',
  'The scientists',
];
const SANDBOX_VERBS = [
  'create',
  'develop',
  'test',
  'drink',
  'discuss',
  'read',
  'prepare',
  'launch',
  'deliver',
  'analyze',
];
const SANDBOX_OBJECTS = [
  'innovative apps',
  'fresh coffee',
  'new strategies',
  'important reports',
  'clever solutions',
  'modern websites',
  'complex algorithms',
  'delicious dinners',
];
const SANDBOX_PLACES = [
  'at the office',
  'at home',
  'in the laboratory',
  'online',
  'in Ukraine',
  'in the conference room',
  'in the city center',
];
const SANDBOX_TIMES = [
  'every morning',
  'on weekdays',
  'right now',
  'every day',
  'after lunch',
  'before the release',
  'late at night',
];

export const SentenceBuilder: React.FC<SentenceBuilderProps> = ({
  initialLevel = 'A1',
  onRewardXP,
  onToast,
  onRecordMistake,
}) => {
  const [level, setLevel] = useState<CefrLevel>(initialLevel);
  const [modeTab, setModeTab] = useState<'puzzles' | 'sandbox'>('puzzles');
  const [categoryFilter, setCategoryFilter] = useState<'all' | 'affirmative' | 'negative' | 'question' | 'conditional' | 'advanced'>('all');
  const [puzzleIndex, setPuzzleIndex] = useState(0);
  const [selectedWords, setSelectedWords] = useState<string[]>([]);
  const [availableWords, setAvailableWords] = useState<string[]>([]);
  const [isChecked, setIsChecked] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [showRoleTags, setShowRoleTags] = useState(true);

  // Solved puzzles persistent tracking: { A1: ['a1-1', ...], A2: [...] }
  const [solvedPuzzles, setSolvedPuzzles] = useState<Record<CefrLevel, string[]>>(() => {
    try {
      const saved = localStorage.getItem('sentence_builder_solved_v1');
      if (saved) return JSON.parse(saved);
    } catch {}
    return { A1: [], A2: [], B1: [], B2: [], C1: [] };
  });

  // Test / dev override toggle
  const [unlockAllDev, setUnlockAllDev] = useState(false);

  // Sync solved to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('sentence_builder_solved_v1', JSON.stringify(solvedPuzzles));
    } catch {}
  }, [solvedPuzzles]);

  // Check if a level is unlocked
  const isLevelUnlocked = (lvl: CefrLevel): boolean => {
    if (lvl === 'A1') return true;
    const idx = CEFR_LEVELS_ORDER.indexOf(lvl);
    if (idx <= 0) return true;
    const prevLevel = CEFR_LEVELS_ORDER[idx - 1];
    return isLevelUnlocked(prevLevel) && (solvedPuzzles[prevLevel]?.length || 0) >= UNLOCK_THRESHOLD;
  };

  const isLevelAccessible = (lvl: CefrLevel): boolean => {
    return unlockAllDev || isLevelUnlocked(lvl);
  };

  // Sandbox state
  const [sandboxSubject, setSandboxSubject] = useState(SANDBOX_SUBJECTS[0]);
  const [sandboxVerb, setSandboxVerb] = useState(SANDBOX_VERBS[0]);
  const [sandboxObject, setSandboxObject] = useState(SANDBOX_OBJECTS[0]);
  const [sandboxPlace, setSandboxPlace] = useState(SANDBOX_PLACES[0]);
  const [sandboxTime, setSandboxTime] = useState(SANDBOX_TIMES[0]);

  const allPuzzlesForLevel = SENTENCE_PUZZLES[level] || SENTENCE_PUZZLES.A1;

  // Dynamic category counts for current level
  const categoryCounts = useMemo(() => {
    const counts = { all: allPuzzlesForLevel.length, affirmative: 0, negative: 0, question: 0, conditional: 0, advanced: 0 };
    allPuzzlesForLevel.forEach((p) => {
      const cat = p.category as keyof typeof counts;
      if (cat && cat in counts) {
        counts[cat]++;
      }
    });
    return counts;
  }, [allPuzzlesForLevel]);

  const filteredPuzzles = allPuzzlesForLevel.filter((p) => {
    if (categoryFilter === 'all') return true;
    return p.category === categoryFilter;
  });

  const effectivePuzzles = filteredPuzzles.length > 0 ? filteredPuzzles : allPuzzlesForLevel;
  const safeIndex = puzzleIndex % effectivePuzzles.length;
  const currentPuzzle: SentencePuzzle = effectivePuzzles[safeIndex];
  const syntaxInfo = LEVEL_SYNTAX_INFO[level];

  // Initialize or reload puzzle
  useEffect(() => {
    if (!currentPuzzle) return;
    setSelectedWords([]);
    setIsChecked(false);
    setIsCorrect(false);
    const shuffled = [...currentPuzzle.words].sort(() => 0.5 - Math.random());
    setAvailableWords(shuffled);
  }, [level, puzzleIndex, categoryFilter]);

  const currentLevelSolvedCount = solvedPuzzles[level]?.length || 0;

  const nextLevelToUnlock = useMemo(() => {
    const idx = CEFR_LEVELS_ORDER.indexOf(level);
    return idx < CEFR_LEVELS_ORDER.length - 1 ? CEFR_LEVELS_ORDER[idx + 1] : null;
  }, [level]);

  const prevLevelForActive = useMemo(() => {
    const idx = CEFR_LEVELS_ORDER.indexOf(level);
    return idx > 0 ? CEFR_LEVELS_ORDER[idx - 1] : null;
  }, [level]);

  const handleSelectLevel = (newLevel: CefrLevel) => {
    playSound('click');
    if (!isLevelAccessible(newLevel)) {
      const idx = CEFR_LEVELS_ORDER.indexOf(newLevel);
      const prevLvl = idx > 0 ? CEFR_LEVELS_ORDER[idx - 1] : 'A1';
      const prevCount = solvedPuzzles[prevLvl]?.length || 0;
      onToast(
        `🔒 Рівень ${newLevel} (${LEVEL_RULES_NAMES[newLevel]}) заблоковано! Вирішіть щонайменше ${UNLOCK_THRESHOLD} з 30 завдань рівня ${prevLvl} (зараз: ${prevCount}/${UNLOCK_THRESHOLD})`,
        'error'
      );
      return;
    }
    setLevel(newLevel);
    setPuzzleIndex(0);
  };

  const handlePickWord = (word: string, index: number) => {
    if (isChecked) return;
    playSound('click');
    const newAvail = [...availableWords];
    newAvail.splice(index, 1);
    setAvailableWords(newAvail);
    setSelectedWords([...selectedWords, word]);
  };

  const handleRemoveWord = (index: number) => {
    if (isChecked) return;
    playSound('click');
    const word = selectedWords[index];
    const newSelected = [...selectedWords];
    newSelected.splice(index, 1);
    setSelectedWords(newSelected);
    setAvailableWords([...availableWords, word]);
  };

  const handleReset = () => {
    if (isChecked || !currentPuzzle) return;
    playSound('click');
    setSelectedWords([]);
    setAvailableWords([...currentPuzzle.words].sort(() => 0.5 - Math.random()));
  };

  const handleCheckOrder = () => {
    if (selectedWords.length === 0 || !currentPuzzle) {
      onToast('Спочатку складіть речення зі слів!', 'info');
      return;
    }

    const correctSentence = currentPuzzle.words.join(' ').trim().toLowerCase();
    const userSentence = selectedWords.join(' ').trim().toLowerCase();

    // Check primary order or any accepted alternative order
    let matched = userSentence === correctSentence;
    if (!matched && currentPuzzle.alternativeOrders) {
      for (const alt of currentPuzzle.alternativeOrders) {
        if (userSentence === alt.join(' ').trim().toLowerCase()) {
          matched = true;
          break;
        }
      }
    }

    setIsChecked(true);
    setIsCorrect(matched);

    if (matched) {
      playSound('correct');
      onRewardXP(15);

      const currentSolved = solvedPuzzles[level] || [];
      const puzzleId = currentPuzzle.id || `puzzle-${safeIndex}`;
      if (!currentSolved.includes(puzzleId)) {
        const updated = [...currentSolved, puzzleId];
        setSolvedPuzzles((prev) => ({
          ...prev,
          [level]: updated,
        }));

        // Check if user hit the 28 milestone to unlock the next level
        if (updated.length === UNLOCK_THRESHOLD) {
          playSound('combo');
          const nextLevelIdx = CEFR_LEVELS_ORDER.indexOf(level) + 1;
          if (nextLevelIdx < CEFR_LEVELS_ORDER.length) {
            const nextLvl = CEFR_LEVELS_ORDER[nextLevelIdx];
            onToast(
              `🎉 Браво! Ви правильно вирішили ${UNLOCK_THRESHOLD} з 30 завдань! Рівень ${nextLvl} (${LEVEL_RULES_NAMES[nextLvl]}) відкрито! (+100 XP бонус)`,
              'success'
            );
            onRewardXP(100);
          } else {
            onToast(
              `🏆 Неймовірно! Ви опанували ${UNLOCK_THRESHOLD} з 30 завдань найвищого рівня ${level}! (+100 XP бонус)`,
              'success'
            );
            onRewardXP(100);
          }
        } else {
          onToast(
            `Бездоганно! Правильний порядок (+15 XP) • Розв'язано: ${updated.length}/30 (${updated.length < UNLOCK_THRESHOLD ? `ще ${UNLOCK_THRESHOLD - updated.length} до наступного рівня` : 'Рівень відкрито ✓'})`,
            'success'
          );
        }
      } else {
        onToast('Бездоганно! Правильний синтаксичний порядок (+15 XP)', 'success');
      }
    } else {
      playSound('wrong');
      if (onRecordMistake && currentPuzzle) {
        onRecordMistake(currentPuzzle, userSentence);
      }
    }
  };

  const handleNext = () => {
    playSound('click');
    setPuzzleIndex((prev) => (prev + 1) % effectivePuzzles.length);
  };

  const handlePrev = () => {
    playSound('click');
    setPuzzleIndex((prev) => (prev - 1 + effectivePuzzles.length) % effectivePuzzles.length);
  };

  const handleRandom = () => {
    playSound('click');
    if (effectivePuzzles.length <= 1) return;
    let nextIdx = safeIndex;
    while (nextIdx === safeIndex) {
      nextIdx = Math.floor(Math.random() * effectivePuzzles.length);
    }
    setPuzzleIndex(nextIdx);
  };

  const handleSpeakWord = (word: string, e: React.MouseEvent) => {
    e.stopPropagation();
    speakEnglish(word);
  };

  const handleSpeakFullSentence = () => {
    if (!currentPuzzle) return;
    speakEnglish(currentPuzzle.words.join(' '));
  };

  // Sandbox built sentence
  const sandboxSentence = `${sandboxSubject} ${sandboxVerb} ${sandboxObject} ${sandboxPlace} ${sandboxTime}.`;

  const handleSpeakSandbox = () => {
    speakEnglish(sandboxSentence);
  };

  const handleSaveSandboxSentence = () => {
    playSound('correct');
    onRewardXP(10);
    onToast(`Речення збудовано та озвучено! (+10 XP)`, 'success');
  };

  return (
    <section className="space-y-8">
      {/* Builder Intro Header */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-sky-950/70 via-slate-900 to-slate-950 border border-sky-500/30 p-6 sm:p-10 shadow-2xl">
        <div className="max-w-3xl space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-sky-500/20 text-sky-300 border border-sky-500/30 text-xs font-bold">
            <LayoutGrid className="w-3.5 h-3.5" />
            <span>Максимальний тренажер синтаксису: SVOMPT, Пасивний стан, Інверсія</span>
          </div>
          <h2 className="text-2xl sm:text-4xl font-black text-white tracking-tight">
            Конструктор Речень:{' '}
            <span className="bg-gradient-to-r from-sky-400 via-blue-300 to-indigo-200 bg-clip-text text-transparent">
              Говоріть як носій
            </span>
          </h2>
          <p className="text-slate-300 text-sm leading-relaxed">
            В українській мові порядок слів довільний (<em>«Вранці я п'ю каву вдома»</em>). В англійській це викликає
            грубі граматичні русизми. Тренуйте залізний порядок слів за всіма рівнями складності з інтерактивними
            ролями слів.
          </p>

          <div className="flex flex-wrap gap-2 pt-2">
            <button
              onClick={() => setModeTab('puzzles')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
                modeTab === 'puzzles'
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/25'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <LayoutGrid className="w-4 h-4" />
              <span>Режим завдань (A1–C1)</span>
            </button>
            <button
              onClick={() => setModeTab('sandbox')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
                modeTab === 'sandbox'
                  ? 'bg-sky-600 text-white shadow-lg shadow-sky-500/25'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <Sliders className="w-4 h-4" />
              <span>Вільна пісочниця SVOMPT</span>
            </button>
          </div>
        </div>
      </div>

      {modeTab === 'puzzles' ? (
        <>
          {/* Level Selector & Category Filters */}
          <div className="space-y-3 bg-slate-900 p-4 rounded-3xl border border-slate-800">
            <div className="flex items-center justify-between flex-wrap gap-3">
              <div className="flex items-center gap-2">
                <span className="text-xs font-black uppercase tracking-wider text-slate-400">
                  Рівні складності:
                </span>
                <span className="text-[11px] text-amber-400 font-bold bg-amber-500/10 border border-amber-500/25 px-2.5 py-0.5 rounded-full flex items-center gap-1">
                  <Lock className="w-3 h-3 text-amber-400" />
                  <span>28/30 для відкриття наступного</span>
                </span>
              </div>
              <div className="flex items-center gap-2 overflow-x-auto no-scrollbar">
                {(['A1', 'A2', 'B1', 'B2', 'C1'] as CefrLevel[]).map((lvl, idx) => {
                  const isAccessible = isLevelAccessible(lvl);
                  const solvedCount = solvedPuzzles[lvl]?.length || 0;
                  const prevLvl = idx > 0 ? CEFR_LEVELS_ORDER[idx - 1] : null;
                  const prevSolved = prevLvl ? (solvedPuzzles[prevLvl]?.length || 0) : 0;

                  return (
                    <button
                      key={lvl}
                      onClick={() => handleSelectLevel(lvl)}
                      className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition whitespace-nowrap flex items-center gap-1.5 ${
                        level === lvl
                          ? 'bg-blue-600 text-white shadow shadow-blue-500/30'
                          : isAccessible
                          ? solvedCount >= UNLOCK_THRESHOLD
                            ? 'bg-emerald-950/60 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-900/60'
                            : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                          : 'bg-slate-800/40 text-slate-500 border border-slate-800 hover:bg-slate-800/70 hover:text-slate-400'
                      }`}
                    >
                      {!isAccessible ? (
                        <>
                          <Lock className="w-3.5 h-3.5 text-amber-500/70" />
                          <span>{lvl}</span>
                          <span className="text-[10px] opacity-75 font-normal">({prevSolved}/28)</span>
                        </>
                      ) : (
                        <>
                          {solvedCount >= UNLOCK_THRESHOLD ? (
                            <Trophy className="w-3.5 h-3.5 text-amber-400" />
                          ) : (
                            <Unlock className="w-3 h-3 text-sky-400" />
                          )}
                          <span>{lvl}</span>
                          <span className="text-[10px] opacity-80 font-normal">({solvedCount}/30)</span>
                        </>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Sentence Type Filter */}
            <div className="flex items-center justify-between flex-wrap gap-2 pt-2 border-t border-slate-800/80">
              <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar text-xs">
                <span className="text-slate-400 font-medium mr-1">Тип речення:</span>
                <button
                  onClick={() => {
                    setCategoryFilter('all');
                    setPuzzleIndex(0);
                  }}
                  className={`px-2.5 py-1 rounded-lg font-bold transition ${
                    categoryFilter === 'all'
                      ? 'bg-slate-700 text-white'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Усі ({categoryCounts.all})
                </button>
                <button
                  onClick={() => {
                    setCategoryFilter('affirmative');
                    setPuzzleIndex(0);
                  }}
                  className={`px-2.5 py-1 rounded-lg font-bold transition ${
                    categoryFilter === 'affirmative'
                      ? 'bg-slate-700 text-white'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Ствердження ({categoryCounts.affirmative})
                </button>
                <button
                  onClick={() => {
                    setCategoryFilter('negative');
                    setPuzzleIndex(0);
                  }}
                  className={`px-2.5 py-1 rounded-lg font-bold transition ${
                    categoryFilter === 'negative'
                      ? 'bg-slate-700 text-white'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Заперечення ({categoryCounts.negative})
                </button>
                <button
                  onClick={() => {
                    setCategoryFilter('question');
                    setPuzzleIndex(0);
                  }}
                  className={`px-2.5 py-1 rounded-lg font-bold transition ${
                    categoryFilter === 'question'
                      ? 'bg-slate-700 text-white'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Питання ({categoryCounts.question})
                </button>
                <button
                  onClick={() => {
                    setCategoryFilter('conditional');
                    setPuzzleIndex(0);
                  }}
                  className={`px-2.5 py-1 rounded-lg font-bold transition ${
                    categoryFilter === 'conditional'
                      ? 'bg-slate-700 text-white'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Умовні ({categoryCounts.conditional})
                </button>
                <button
                  onClick={() => {
                    setCategoryFilter('advanced');
                    setPuzzleIndex(0);
                  }}
                  className={`px-2.5 py-1 rounded-lg font-bold transition ${
                    categoryFilter === 'advanced'
                      ? 'bg-slate-700 text-white'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Просунуті ({categoryCounts.advanced})
                </button>
              </div>

              <button
                onClick={() => setShowRoleTags(!showRoleTags)}
                className={`text-xs font-semibold px-2.5 py-1 rounded-lg transition border ${
                  showRoleTags
                    ? 'border-blue-500/40 text-blue-300 bg-blue-500/10'
                    : 'border-slate-700 text-slate-400 hover:text-slate-200'
                }`}
              >
                {showRoleTags ? 'Підсвічувати ролі: Увімк' : 'Підсвічувати ролі: Вимк'}
              </button>
            </div>
          </div>

          {/* Level Unlock Progress Banner */}
          <div className="p-4 sm:p-5 rounded-3xl bg-slate-900 border border-slate-800 space-y-3 shadow-lg">
            <div className="flex items-center justify-between text-xs flex-wrap gap-2">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-bold text-white flex items-center gap-1.5">
                  <Trophy className="w-4 h-4 text-amber-400" />
                  <span>
                    Прогрес рівня <strong className="text-sky-300">{level}</strong>:
                  </span>
                </span>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-black bg-blue-500/20 text-blue-300 border border-blue-500/30">
                  {currentLevelSolvedCount} з 30 розв'язано правильно
                </span>
                {currentLevelSolvedCount >= UNLOCK_THRESHOLD && (
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-black bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                    <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Освоєно 28+ ✓</span>
                  </span>
                )}
              </div>

              <div className="text-xs text-slate-300 flex items-center gap-3">
                {nextLevelToUnlock ? (
                  currentLevelSolvedCount >= UNLOCK_THRESHOLD ? (
                    <span className="text-emerald-400 font-bold flex items-center gap-1.5">
                      <Unlock className="w-3.5 h-3.5" />
                      <span>Рівень {nextLevelToUnlock} розблоковано!</span>
                    </span>
                  ) : (
                    <span className="text-amber-300 font-semibold flex items-center gap-1.5">
                      <Lock className="w-3.5 h-3.5 text-amber-400" />
                      <span>
                        Ще {UNLOCK_THRESHOLD - currentLevelSolvedCount} для відкриття {nextLevelToUnlock}
                      </span>
                    </span>
                  )
                ) : (
                  <span className="text-amber-300 font-bold flex items-center gap-1.5">
                    <Trophy className="w-4 h-4 text-amber-400" />
                    <span>Максимальний рівень C1 завершено!</span>
                  </span>
                )}

                <button
                  onClick={() => setUnlockAllDev((prev) => !prev)}
                  title="Швидкий тестовий режим для випробування всіх рівнів"
                  className="text-[11px] text-slate-500 hover:text-slate-300 transition underline underline-offset-2 ml-1"
                >
                  {unlockAllDev ? '🔒 Блокування увімк' : '🔓 Тест: відкрити все'}
                </button>
              </div>
            </div>

            {/* Threshold Progress Bar with 28/30 Pin */}
            <div className="space-y-1.5">
              <div className="relative w-full bg-slate-950 rounded-full h-3 overflow-hidden border border-slate-800">
                <div
                  className={`h-full transition-all duration-500 rounded-full ${
                    currentLevelSolvedCount >= UNLOCK_THRESHOLD
                      ? 'bg-gradient-to-r from-emerald-500 via-teal-400 to-cyan-400'
                      : 'bg-gradient-to-r from-sky-500 via-blue-500 to-indigo-500'
                  }`}
                  style={{ width: `${Math.min(100, Math.round((currentLevelSolvedCount / 30) * 100))}%` }}
                />
                {/* 28/30 threshold pin indicator */}
                <div
                  className="absolute top-0 bottom-0 w-1 bg-amber-400 z-10 shadow-md shadow-amber-400/50"
                  style={{ left: `${(28 / 30) * 100}%` }}
                  title="Поріг переходу: 28 з 30 правильних відповідей"
                />
              </div>

              <div className="flex items-center justify-between text-[11px] text-slate-400">
                <span>0 розв'язано</span>
                <span className="text-amber-400/90 font-bold">
                  {currentLevelSolvedCount >= UNLOCK_THRESHOLD
                    ? `✓ Вимогу 28 з 30 виконано (відкрито ${nextLevelToUnlock || 'C1'})`
                    : `🎯 Необхідно вирішити 28 з 30 речень для відкриття ${nextLevelToUnlock || 'фіналу'}`}
                </span>
                <span>30 речень</span>
              </div>
            </div>
          </div>

          {!isLevelAccessible(level) ? (
            /* Locked Level Screen */
            <div className="max-w-2xl mx-auto bg-slate-900 rounded-3xl border border-slate-800 p-8 sm:p-12 text-center space-y-6 shadow-2xl">
              <div className="w-16 h-16 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-400 flex items-center justify-center mx-auto shadow-lg shadow-amber-500/10">
                <Lock className="w-8 h-8" />
              </div>
              <div className="space-y-2">
                <span className="text-xs font-bold uppercase tracking-wider text-amber-400">
                  Правило синтаксису заблоковано
                </span>
                <h3 className="text-2xl sm:text-3xl font-black text-white">
                  Рівень {level}: {LEVEL_RULES_NAMES[level]}
                </h3>
                <p className="text-sm text-slate-300 max-w-md mx-auto leading-relaxed pt-1">
                  Правила та конструкції цього рівня відкриваються поетапно. Для переходу необхідно правильно скласти щонайменше{' '}
                  <strong className="text-amber-400">28 з 30 речень</strong> попереднього рівня{' '}
                  <strong className="text-sky-300">{prevLevelForActive}</strong>.
                </p>
                <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 inline-block text-xs font-semibold text-slate-400 mt-2">
                  Ваш поточний прогрес у {prevLevelForActive}:{' '}
                  <strong className="text-sky-400 text-sm">
                    {prevLevelForActive ? solvedPuzzles[prevLevelForActive]?.length || 0 : 0} з {UNLOCK_THRESHOLD}
                  </strong>{' '}
                  речень
                </div>
              </div>
              <div className="pt-2">
                <button
                  onClick={() => {
                    if (prevLevelForActive) handleSelectLevel(prevLevelForActive);
                  }}
                  className="px-6 py-3.5 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm shadow-lg shadow-blue-500/25 transition flex items-center gap-2 mx-auto transform active:scale-95"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Повернутися до рівня {prevLevelForActive}</span>
                </button>
              </div>
            </div>
          ) : (
            <>
              {/* Formula Banner */}
              <div className="p-4 sm:p-5 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded-lg text-[10px] font-black uppercase tracking-wider bg-sky-500/20 text-sky-300 border border-sky-500/30">
                      {syntaxInfo.badge}
                    </span>
                    <span className="text-xs font-bold text-slate-400">Рівень {level}</span>
                    {currentPuzzle?.categoryLabel && (
                      <span className="text-xs text-indigo-400 font-semibold">
                        • {currentPuzzle.categoryLabel}
                      </span>
                    )}
                  </div>
                  <h4 className="text-sm sm:text-base font-black text-white">{syntaxInfo.formula}</h4>
                  <p className="text-xs text-amber-300 font-medium">⚠️ Пастка: {syntaxInfo.trapNote}</p>
                </div>
              </div>

              {/* Puzzle Playground */}
              {currentPuzzle && (
                <div className="max-w-3xl mx-auto bg-slate-900 rounded-3xl border border-slate-800 p-6 sm:p-8 shadow-2xl space-y-6">
              {/* Target Sentence Prompt */}
              <div className="space-y-3">
                <div className="flex items-center justify-between text-xs font-bold text-slate-400 flex-wrap gap-2">
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={handlePrev}
                      title="Попереднє речення"
                      className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition border border-slate-700 active:scale-95"
                    >
                      <ChevronLeft className="w-4 h-4" />
                    </button>
                    <span className="font-bold text-slate-200">
                      Речення {safeIndex + 1} з {effectivePuzzles.length}
                    </span>
                    <button
                      onClick={handleNext}
                      title="Наступне речення"
                      className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition border border-slate-700 active:scale-95"
                    >
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleRandom}
                      title="Випадкове речення з поточного списку"
                      className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-[11px] font-bold transition flex items-center gap-1.5 border border-slate-700 active:scale-95"
                    >
                      <Shuffle className="w-3.5 h-3.5 text-sky-400" />
                      <span>Випадкове</span>
                    </button>
                    <span className="px-2.5 py-0.5 rounded-lg bg-sky-500/20 text-sky-300 border border-sky-500/30 font-black">
                      Рівень {level}
                    </span>
                  </div>
                </div>

                {/* Progress bar */}
                <div className="w-full bg-slate-800/80 rounded-full h-1.5 overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-sky-500 to-blue-500 h-1.5 rounded-full transition-all duration-300"
                    style={{ width: `${Math.round(((safeIndex + 1) / effectivePuzzles.length) * 100)}%` }}
                  />
                </div>

                {/* Quick Jump Number Strip */}
                <div className="flex items-center gap-1 overflow-x-auto no-scrollbar py-1">
                  {effectivePuzzles.map((p, i) => {
                    const isSolved = (solvedPuzzles[level] || []).includes(p.id || '');
                    return (
                      <button
                        key={i}
                        onClick={() => {
                          playSound('click');
                          setPuzzleIndex(i);
                        }}
                        title={`Речення ${i + 1}${isSolved ? ' (Правильно розв\'язано ✓)' : ''}`}
                        className={`min-w-6.5 h-6.5 px-1 rounded-md text-[10px] font-bold transition shrink-0 flex items-center justify-center gap-0.5 ${
                          i === safeIndex
                            ? 'bg-blue-600 text-white shadow shadow-blue-500/40 ring-1 ring-white/60 scale-105'
                            : isSolved
                            ? 'bg-emerald-950/70 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-900/60'
                            : 'bg-slate-800/80 text-slate-400 hover:bg-slate-700 hover:text-slate-200'
                        }`}
                      >
                        <span>{i + 1}</span>
                        {isSolved && <span className="text-[9px] text-emerald-400">✓</span>}
                      </button>
                    );
                  })}
                </div>

                <div className="text-center pt-1 space-y-1">
                  <span className="text-[11px] uppercase tracking-wider font-extrabold text-slate-500 block">
                    Українська думка:
                  </span>
                  <h3 className="text-xl sm:text-2xl font-black text-white">{currentPuzzle.ukr}</h3>
                  <p className="text-xs text-slate-400">Складіть правильне англійське речення, клікаючи на слова:</p>
                </div>
              </div>

              {/* Selected Words Area */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs font-bold text-slate-400">
                  <span>Ваше англійське речення:</span>
                  {!isChecked && (
                    <button
                      onClick={handleReset}
                      className="text-xs text-rose-400 hover:text-rose-300 transition flex items-center gap-1"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Очистити</span>
                    </button>
                  )}
                </div>
                <div className="min-h-[76px] p-4 rounded-2xl bg-slate-950/80 border-2 border-dashed border-slate-700 flex flex-wrap items-center gap-2.5 transition">
                  {selectedWords.length === 0 ? (
                    <span className="text-xs text-slate-500 italic select-none">
                      Натисніть на слова нижче, щоб додати їх сюди...
                    </span>
                  ) : (
                    selectedWords.map((word, idx) => {
                      const slot = currentPuzzle.slots?.find((s) => s.word === word);
                      const roleColor = slot && showRoleTags ? ROLE_COLORS[slot.role] : '';

                      return (
                        <div
                          key={`${word}-${idx}`}
                          className="flex flex-col items-center gap-1 animate-fadeIn"
                        >
                          <button
                            disabled={isChecked}
                            onClick={() => handleRemoveWord(idx)}
                            className={`px-3.5 py-2 rounded-xl font-bold text-xs sm:text-sm shadow-md transition flex items-center gap-1.5 group transform active:scale-95 disabled:opacity-90 ${
                              roleColor
                                ? `${roleColor} border`
                                : 'bg-blue-600 hover:bg-rose-600 text-white'
                            }`}
                          >
                            <span>{word}</span>
                            {!isChecked && <X className="w-3.5 h-3.5 opacity-60 group-hover:opacity-100" />}
                          </button>
                          {showRoleTags && slot && (
                            <span className="text-[9px] uppercase tracking-wider font-extrabold text-slate-400">
                              {slot.role}
                            </span>
                          )}
                        </div>
                      );
                    })
                  )}
                </div>
              </div>

              {/* Available Words Pool */}
              <div className="space-y-2">
                <span className="text-xs font-bold text-slate-400 block">Доступні слова (перемішані):</span>
                <div className="p-4 rounded-2xl bg-slate-800/50 border border-slate-700/60 flex flex-wrap gap-2.5 min-h-[64px]">
                  {availableWords.map((word, idx) => (
                    <div key={`${word}-${idx}`} className="flex items-center gap-1">
                      <button
                        disabled={isChecked}
                        onClick={() => handlePickWord(word, idx)}
                        className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white font-bold text-xs sm:text-sm border border-slate-700 hover:border-sky-500 shadow transition transform active:scale-95 disabled:opacity-40"
                      >
                        {word}
                      </button>
                      <button
                        title="Вимова слова"
                        onClick={(e) => handleSpeakWord(word, e)}
                        className="p-1 rounded-lg text-slate-500 hover:text-slate-300 transition"
                      >
                        <Volume2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Feedback Box */}
              {isChecked && (
                <div
                  className={`p-4 rounded-2xl text-xs sm:text-sm font-semibold transition space-y-1 ${
                    isCorrect
                      ? 'bg-emerald-950/60 border border-emerald-500/50 text-emerald-300'
                      : 'bg-rose-950/60 border border-rose-500/50 text-rose-300'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    {isCorrect ? (
                      <>
                        <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0" />
                        <strong className="text-sm">Бездоганно! Правильний порядок (+15 XP)</strong>
                      </>
                    ) : (
                      <>
                        <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />
                        <strong className="text-sm">Помилка у порядку слів!</strong>
                      </>
                    )}
                  </div>
                  {!isCorrect && (
                    <p className="text-xs text-white leading-relaxed">
                      Правильний варіант:{' '}
                      <span className="font-bold underline">{currentPuzzle.words.join(' ')}</span>
                    </p>
                  )}
                  <p className="text-xs opacity-90 leading-relaxed font-normal">{currentPuzzle.rule}</p>
                </div>
              )}

              {/* Action Controls */}
              <div className="flex items-center justify-between gap-3 pt-2 flex-wrap">
                <div className="flex items-center gap-2">
                  <button
                    onClick={handlePrev}
                    className="px-3.5 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs flex items-center gap-1.5 border border-slate-700 transition"
                    title="Попереднє речення"
                  >
                    <ChevronLeft className="w-4 h-4" />
                    <span className="hidden sm:inline">Попереднє</span>
                  </button>
                  <button
                    onClick={handleSpeakFullSentence}
                    disabled={!isChecked}
                    className="px-4 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs flex items-center gap-2 border border-slate-700 transition disabled:opacity-40"
                  >
                    <Volume2 className="w-4 h-4" />
                    <span>Вимова речення</span>
                  </button>
                </div>
                <div className="flex items-center gap-2">
                  {!isChecked ? (
                    <button
                      onClick={handleCheckOrder}
                      className="px-6 py-3 rounded-2xl bg-sky-600 hover:bg-sky-500 text-white font-black text-xs sm:text-sm flex items-center gap-2 shadow-lg shadow-sky-500/20 transition transform active:scale-95"
                    >
                      <Check className="w-4 h-4" />
                      <span>Перевірити порядок</span>
                    </button>
                  ) : (
                    <button
                      onClick={handleNext}
                      className="px-5 py-3 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs sm:text-sm flex items-center gap-2 transition"
                    >
                      <span>
                        Наступне ({safeIndex + 2 <= effectivePuzzles.length ? safeIndex + 2 : 1}/{effectivePuzzles.length})
                      </span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}
        </>
      )}
    </>
  ) : (
        /* Free Sandbox Mode */
        <div className="max-w-3xl mx-auto bg-slate-900 rounded-3xl border border-slate-800 p-6 sm:p-8 shadow-2xl space-y-6">
          <div className="space-y-1">
            <span className="px-2.5 py-0.5 rounded-lg text-[10px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              Вільний конструктор
            </span>
            <h3 className="text-xl font-black text-white">Пісочниця побудови речень SVOMPT</h3>
            <p className="text-xs text-slate-400">
              Скомбінуйте власний варіант за класичною англійською синтаксичною формулою:
            </p>
          </div>

          {/* Slots selector */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {/* Subject */}
            <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700 space-y-1.5">
              <span className="text-[10px] uppercase font-black tracking-wider text-blue-400 block">
                1. Subject (Хто?)
              </span>
              <select
                value={sandboxSubject}
                onChange={(e) => setSandboxSubject(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 text-xs font-bold text-white rounded-lg p-2 focus:outline-none focus:border-blue-500"
              >
                {SANDBOX_SUBJECTS.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            </div>

            {/* Verb */}
            <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700 space-y-1.5">
              <span className="text-[10px] uppercase font-black tracking-wider text-purple-400 block">
                2. Verb (Що робить?)
              </span>
              <select
                value={sandboxVerb}
                onChange={(e) => setSandboxVerb(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 text-xs font-bold text-white rounded-lg p-2 focus:outline-none focus:border-purple-500"
              >
                {SANDBOX_VERBS.map((v) => (
                  <option key={v} value={v}>
                    {v}
                  </option>
                ))}
              </select>
            </div>

            {/* Object */}
            <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700 space-y-1.5">
              <span className="text-[10px] uppercase font-black tracking-wider text-emerald-400 block">
                3. Object (Кого/Що?)
              </span>
              <select
                value={sandboxObject}
                onChange={(e) => setSandboxObject(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 text-xs font-bold text-white rounded-lg p-2 focus:outline-none focus:border-emerald-500"
              >
                {SANDBOX_OBJECTS.map((o) => (
                  <option key={o} value={o}>
                    {o}
                  </option>
                ))}
              </select>
            </div>

            {/* Place */}
            <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700 space-y-1.5">
              <span className="text-[10px] uppercase font-black tracking-wider text-cyan-400 block">
                4. Place (Де?)
              </span>
              <select
                value={sandboxPlace}
                onChange={(e) => setSandboxPlace(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 text-xs font-bold text-white rounded-lg p-2 focus:outline-none focus:border-cyan-500"
              >
                {SANDBOX_PLACES.map((p) => (
                  <option key={p} value={p}>
                    {p}
                  </option>
                ))}
              </select>
            </div>

            {/* Time */}
            <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700 space-y-1.5">
              <span className="text-[10px] uppercase font-black tracking-wider text-indigo-400 block">
                5. Time (Коли?)
              </span>
              <select
                value={sandboxTime}
                onChange={(e) => setSandboxTime(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 text-xs font-bold text-white rounded-lg p-2 focus:outline-none focus:border-indigo-500"
              >
                {SANDBOX_TIMES.map((t) => (
                  <option key={t} value={t}>
                    {t}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Generated Result Card */}
          <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
            <span className="text-xs font-bold text-slate-400">Згенероване англійське речення:</span>
            <h4 className="text-xl sm:text-2xl font-black text-sky-400">{sandboxSentence}</h4>
            <div className="flex flex-wrap gap-2 text-[11px] font-mono text-slate-400">
              <span className="px-2 py-0.5 rounded bg-blue-500/10 text-blue-300">
                [S]: {sandboxSubject}
              </span>
              <span className="px-2 py-0.5 rounded bg-purple-500/10 text-purple-300">
                [V]: {sandboxVerb}
              </span>
              <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-300">
                [O]: {sandboxObject}
              </span>
              <span className="px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-300">
                [P]: {sandboxPlace}
              </span>
              <span className="px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-300">
                [T]: {sandboxTime}
              </span>
            </div>
          </div>

          {/* Sandbox Actions */}
          <div className="flex items-center justify-between gap-3 pt-2">
            <button
              onClick={handleSpeakSandbox}
              className="px-5 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs sm:text-sm flex items-center gap-2 border border-slate-700 transition"
            >
              <Volume2 className="w-4 h-4" />
              <span>Озвучити речення</span>
            </button>
            <button
              onClick={handleSaveSandboxSentence}
              className="px-5 py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm flex items-center gap-2 shadow-lg shadow-emerald-500/20 transition transform active:scale-95"
            >
              <Check className="w-4 h-4" />
              <span>Зберегти практику (+10 XP)</span>
            </button>
          </div>
        </div>
      )}
    </section>
  );
};
