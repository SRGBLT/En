import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  Gamepad2,
  Zap,
  Flag,
  Infinity,
  AlertTriangle,
  Flame,
  CheckCircle,
  Volume2,
  ArrowRight,
  RotateCcw,
  Layers,
  Check,
  X,
  Sparkles,
  BookOpen,
} from 'lucide-react';
import { ALL_VOCABULARY, VOCAB_MATRIX } from '../data/hacks';
import {
  ALL_THEMATIC_VOCAB_ITEMS,
  THEMATIC_CATEGORIES,
  getWordsByCategory,
  toVocabItem,
} from '../data/thematicWords';
import { MistakeRecord, VocabItem } from '../types';
import { playSound, speakEnglish, speakEnglishSlow } from '../utils/audio';

interface QuizTrainerProps {
  initialCategory?: string;
  onRecordAnswer: (isCorrect: boolean, points: number, item: VocabItem, selectedWrongAnswer?: string) => void;
  onSelectTab: (tab: any) => void;
  comboCount: number;
  totalScore: number;
  userMistakes?: MistakeRecord[];
}

type QuizMode = 'blitz' | 'marathon' | 'endless' | 'traps';

function cleanWord(str: string): string {
  if (!str) return '';
  return str.replace(/\(.*?\)/g, '').trim();
}

const FALSE_FRIEND_PAIRS: Record<string, string[]> = {
  store: ['magazine', 'shop', 'market'],
  shop: ['magazine', 'store', 'market'],
  magazine: ['store', 'shop', 'journal'],
  fabric: ['factory', 'plant', 'material'],
  factory: ['fabric', 'mill', 'plant'],
  accurate: ['neat', 'tidy', 'punctual'],
  neat: ['accurate', 'exact', 'precise'],
  chef: ['chief', 'boss', 'cook'],
  boss: ['chef', 'cook', 'master'],
  sympathetic: ['attractive', 'pretty', 'cute'],
  attractive: ['sympathetic', 'kind', 'friendly'],
  actual: ['relevant', 'current', 'modern'],
  relevant: ['actual', 'real', 'factual'],
  recipe: ['receipt', 'prescription', 'menu'],
  receipt: ['recipe', 'ticket', 'bill'],
  pretend: ['claim', 'apply', 'demand'],
  insult: ['stroke', 'attack', 'offense'],
  artist: ['actor', 'performer', 'painter'],
  sensible: ['sensitive', 'emotional', 'nervous'],
  sensitive: ['sensible', 'rational', 'reasonable'],
};

/**
 * Builds 4 genuine, non-repeating, plausible options for any target vocabulary item.
 * Strictly uses real English words without leaking hints or corrupting strings.
 */
function buildUniqueQuizOptions(correctWord: string, pool: VocabItem[]): string[] {
  const options = new Set<string>();
  const normalizedCorrect = cleanWord(correctWord);
  if (normalizedCorrect) {
    options.add(normalizedCorrect);
  }

  // 1. If this word is a known false friend trap, include its specific tricky counterpart!
  const lowerTarget = normalizedCorrect.toLowerCase();
  if (FALSE_FRIEND_PAIRS[lowerTarget]) {
    for (const tricky of FALSE_FRIEND_PAIRS[lowerTarget]) {
      if (options.size >= 4) break;
      options.add(tricky);
    }
  }

  const isValidDistractor = (str: string) => {
    const s = cleanWord(str).toLowerCase();
    return s && s !== lowerTarget && s.length >= 2 && !/concept_|core_|advanced_|practical_|term_\d|_\d+$/.test(s);
  };

  // 2. Pick authentic distractors from the current pool/category
  const poolItems = [...pool]
    .filter((item) => isValidDistractor(item.eng))
    .sort(() => 0.5 - Math.random());

  for (const item of poolItems) {
    if (options.size >= 4) break;
    options.add(cleanWord(item.eng));
  }

  // 3. If pool is small (e.g. False Friends or Mistakes), supplement from all combined vocabulary
  if (options.size < 4) {
    const allVocabShuffled = [...ALL_VOCABULARY, ...ALL_THEMATIC_VOCAB_ITEMS]
      .filter((item) => isValidDistractor(item.eng) && !options.has(cleanWord(item.eng)))
      .sort(() => 0.5 - Math.random());

    for (const item of allVocabShuffled) {
      if (options.size >= 4) break;
      options.add(cleanWord(item.eng));
    }
  }

  // 4. Fallback high-utility authentic distractors if still under 4
  const emergencyFallbacks = [
    'actual', 'receipt', 'recipe', 'sympathetic', 'sensitive',
    'sensible', 'accurate', 'relevant', 'current', 'information',
    'situation', 'tradition', 'wireless', 'careless', 'restart',
    'rewrite', 'decision', 'attention', 'attractive', 'creative',
  ];

  for (const fb of emergencyFallbacks) {
    if (options.size >= 4) break;
    if (cleanWord(fb).toLowerCase() !== lowerTarget && !options.has(fb)) {
      options.add(fb);
    }
  }

  return Array.from(options).slice(0, 4).sort(() => 0.5 - Math.random());
}

export const QuizTrainer: React.FC<QuizTrainerProps> = ({
  initialCategory = 'all',
  onRecordAnswer,
  onSelectTab,
  comboCount,
  totalScore,
  userMistakes = [],
}) => {
  const [mode, setMode] = useState<QuizMode>('blitz');
  const [category, setCategory] = useState<string>(initialCategory);
  const [currentIndex, setCurrentIndex] = useState(1);
  const [activeItem, setActiveItem] = useState<VocabItem | null>(null);
  const [options, setOptions] = useState<string[]>([]);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [isFinished, setIsFinished] = useState(false);
  const [sessionCorrect, setSessionCorrect] = useState(0);
  const [sessionTotal, setSessionTotal] = useState(0);
  const [questionQueue, setQuestionQueue] = useState<VocabItem[]>([]);
  const [usedWordKeys, setUsedWordKeys] = useState<Set<string>>(new Set());

  // Store userMistakes in a ref to avoid resetting the entire quiz when mistake counts update during play
  const userMistakesRef = useRef(userMistakes);
  useEffect(() => {
    userMistakesRef.current = userMistakes;
  }, [userMistakes]);

  // Synchronize category if initialCategory changes from an external tab/click
  useEffect(() => {
    if (initialCategory && initialCategory !== category) {
      setCategory(initialCategory);
    }
  }, [initialCategory]);

  const unmasteredMistakes = userMistakes.filter((m) => !m.isMastered);
  const unmasteredCount = unmasteredMistakes.length;

  const maxQuestions =
    category === 'mistakes'
      ? Math.max(1, unmasteredCount)
      : mode === 'blitz'
      ? 10
      : mode === 'marathon'
      ? 50
      : mode === 'traps'
      ? 15
      : 999999;

  const getFilteredPool = useCallback(
    (targetCat: string) => {
      if (targetCat === 'mistakes') {
        const unmastered = userMistakesRef.current.filter((m) => !m.isMastered);
        if (unmastered.length > 0) {
          return unmastered.map(
            (m) =>
              m.vocabItem || {
                ukr: m.prompt,
                eng: m.correctAnswer,
                ipa: '',
                rule: m.explanation || 'Робота над помилкою',
                trap: m.mnemonicHint,
                category: m.category || 'mistakes',
              }
          );
        }
        return [];
      }
      if (THEMATIC_CATEGORIES.some((c) => c.id === targetCat)) {
        return getWordsByCategory(targetCat).map(toVocabItem);
      }
      if (targetCat === 'all') return [...ALL_VOCABULARY, ...ALL_THEMATIC_VOCAB_ITEMS];
      return VOCAB_MATRIX[targetCat] || [...ALL_VOCABULARY, ...ALL_THEMATIC_VOCAB_ITEMS];
    },
    [] // stable, reads from ref
  );

  // Restart quiz strictly when mode or category changes (or manual restart)
  const restartQuiz = useCallback(() => {
    setCurrentIndex(1);
    setSessionCorrect(0);
    setSessionTotal(0);
    setIsFinished(false);

    const pool = getFilteredPool(category);

    if (category === 'mistakes' && pool.length === 0) {
      setActiveItem(null);
      setQuestionQueue([]);
      setOptions([]);
      return;
    }

    // Shuffle primary category pool
    let shuffledCat = [...pool].sort(() => 0.5 - Math.random());

    // Intelligent Spaced Review: In general modes, interleave 1-2 unmastered mistakes early on
    const currentUnmastered = userMistakesRef.current.filter((m) => !m.isMastered);
    if (category !== 'mistakes' && currentUnmastered.length > 0) {
      const mistakeItems: VocabItem[] = currentUnmastered.slice(0, 3).map((m) =>
        m.vocabItem || {
          ukr: m.prompt,
          eng: m.correctAnswer,
          ipa: '',
          rule: `Закріплення помилки (${m.category || 'Складне'})`,
          trap: m.mnemonicHint,
          category: 'mistake_review',
        }
      );
      for (const mItem of mistakeItems) {
        if (!shuffledCat.some((c) => cleanWord(c.eng).toLowerCase() === cleanWord(mItem.eng).toLowerCase())) {
          shuffledCat.splice(Math.min(1, shuffledCat.length), 0, mItem);
        }
      }
    }

    // Ensure fallback pool so marathon/endless modes never exhaust without repeats
    const fallbackShuffled = [...ALL_VOCABULARY]
      .filter((w) => !shuffledCat.some((c) => cleanWord(c.eng).toLowerCase() === cleanWord(w.eng).toLowerCase()))
      .sort(() => 0.5 - Math.random());

    const combinedNonRepeating = [...shuffledCat, ...fallbackShuffled];

    if (combinedNonRepeating.length > 0) {
      const firstItem = combinedNonRepeating[0];
      setQuestionQueue(combinedNonRepeating.slice(1));
      setActiveItem(firstItem);
      setOptions(buildUniqueQuizOptions(firstItem.eng, pool.length > 0 ? pool : ALL_VOCABULARY));
      setSelectedAnswer(null);
      setUsedWordKeys(new Set([cleanWord(firstItem.eng).toLowerCase()]));
    }
  }, [category, getFilteredPool]);

  // Restart ONLY on mode or category changes, NEVER on userMistakes array updates
  useEffect(() => {
    restartQuiz();
  }, [mode, category, restartQuiz]);

  const handleSelectAnswer = (opt: string) => {
    if (selectedAnswer !== null || !activeItem) return;
    setSelectedAnswer(opt);
    const isCorrect = cleanWord(opt).toLowerCase() === cleanWord(activeItem.eng).toLowerCase();

    setSessionTotal((prev) => prev + 1);
    if (isCorrect) {
      playSound('correct');
      setSessionCorrect((prev) => prev + 1);
      const points = 10 + comboCount * 2;
      onRecordAnswer(true, points, activeItem);
    } else {
      playSound('wrong');
      onRecordAnswer(false, 0, activeItem, opt);
    }
  };

  const handleNext = () => {
    playSound('click');
    if (mode !== 'endless' && currentIndex >= maxQuestions) {
      playSound('combo');
      setIsFinished(true);
      return;
    }

    const pool = getFilteredPool(category);
    // Filter queue to ensure zero repeats in this active session
    let nextQueue = questionQueue.filter((w) => !usedWordKeys.has(cleanWord(w.eng).toLowerCase()));

    if (nextQueue.length === 0) {
      // If queue is fully exhausted without repeats, supplement from ALL_VOCABULARY
      nextQueue = ALL_VOCABULARY.filter((w) => !usedWordKeys.has(cleanWord(w.eng).toLowerCase())).sort(
        () => 0.5 - Math.random()
      );
    }

    if (nextQueue.length > 0) {
      const nextItem = nextQueue[0];
      setQuestionQueue(nextQueue.slice(1));
      setActiveItem(nextItem);
      setOptions(buildUniqueQuizOptions(nextItem.eng, pool.length > 0 ? pool : ALL_VOCABULARY));
      setSelectedAnswer(null);
      setUsedWordKeys((prev) => new Set([...prev, cleanWord(nextItem.eng).toLowerCase()]));
      setCurrentIndex((prev) => prev + 1);
    } else {
      playSound('combo');
      setIsFinished(true);
    }
  };

  const handleModeChange = (newMode: QuizMode) => {
    playSound('click');
    setMode(newMode);
    if (newMode === 'traps') {
      setCategory('false_friends');
    }
  };

  // Keyboard controls (1, 2, 3, 4, Enter, Space)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (['input', 'textarea', 'select'].includes((e.target as HTMLElement).tagName.toLowerCase())) {
        return;
      }
      if (['1', '2', '3', '4'].includes(e.key)) {
        const idx = parseInt(e.key, 10) - 1;
        if (options[idx] && selectedAnswer === null) {
          e.preventDefault();
          handleSelectAnswer(options[idx]);
        }
      } else if (e.key === ' ' || e.key === 'Enter') {
        if (selectedAnswer !== null && !isFinished) {
          e.preventDefault();
          handleNext();
        } else if (isFinished && (e.key === 'Enter' || e.key === ' ')) {
          e.preventDefault();
          restartQuiz();
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [options, selectedAnswer, isFinished, handleNext, restartQuiz]);

  const getCategoryHeaderLabel = () => {
    if (category === 'mistakes') return '🎯 Закріплення складного матеріалу';
    if (category === 'false_friends' || mode === 'traps') return '⚠️ Фальшиві друзі перекладача (Пастки)';
    const thematic = THEMATIC_CATEGORIES.find((c) => c.id === category);
    if (thematic) return `${thematic.icon} ${thematic.title} (${thematic.engTitle})`;
    if (['re', 'over'].includes(category)) return 'Префіксальні алгоритми англійської';
    if (category === 'all') return 'Змішаний мовний тренажер (3,000+ слів)';
    return 'Суфіксальні мовні мости';
  };

  const handleSpeakActive = (rate: number = 0.9) => {
    if (!activeItem) return;
    // Extract first clear word if text has slashes like "relevant / current"
    const textToSpeak = cleanWord(activeItem.eng).split('/')[0].trim();
    if (rate < 0.8) {
      speakEnglishSlow(textToSpeak);
    } else {
      speakEnglish(textToSpeak);
    }
  };

  return (
    <section className="space-y-6">
      {/* Quiz Header & Settings Bar */}
      <div className="bg-slate-900 rounded-3xl border border-slate-800 p-4 sm:p-6 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
              <Gamepad2 className="w-6 h-6 text-emerald-400" />
              <span>Експрес-Тренажер 3,000+</span>
            </h2>
            <p className="text-xs sm:text-sm text-slate-400">Оберіть режим або тренуйте конкретну категорію</p>
          </div>

          {/* Mode Selector Chips */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
            <button
              onClick={() => handleModeChange('blitz')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                mode === 'blitz' && category !== 'mistakes'
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <Zap className="w-3.5 h-3.5 text-amber-300" /> Бліц (10)
            </button>
            <button
              onClick={() => handleModeChange('marathon')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                mode === 'marathon' && category !== 'mistakes'
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <Flag className="w-3.5 h-3.5" /> Марафон (50)
            </button>
            <button
              onClick={() => handleModeChange('endless')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                mode === 'endless' && category !== 'mistakes'
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <Infinity className="w-3.5 h-3.5 text-emerald-400" /> Нескінченний
            </button>
            <button
              onClick={() => handleModeChange('traps')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                mode === 'traps' || category === 'false_friends'
                  ? 'bg-rose-600 text-white shadow-md shadow-rose-600/30'
                  : 'bg-slate-800 text-amber-300 hover:bg-slate-700'
              }`}
            >
              <AlertTriangle className="w-3.5 h-3.5" /> Пастки
            </button>
            {unmasteredCount > 0 && (
              <button
                onClick={() => setCategory('mistakes')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                  category === 'mistakes'
                    ? 'bg-rose-600 text-white ring-2 ring-rose-400 shadow-lg shadow-rose-600/30'
                    : 'bg-rose-950/60 text-rose-300 border border-rose-700/60 hover:bg-rose-900/60'
                }`}
              >
                <AlertTriangle className="w-3.5 h-3.5" /> Мої помилки ({unmasteredCount})
              </button>
            )}
          </div>
        </div>

        {/* Adaptive Mistake Notification Banner */}
        {unmasteredCount > 0 && category !== 'mistakes' && (
          <div className="bg-gradient-to-r from-rose-950/50 via-slate-900 to-amber-950/30 border border-rose-500/30 rounded-2xl p-3 sm:p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2.5">
              <span className="w-8 h-8 rounded-xl bg-rose-500/20 text-rose-300 flex items-center justify-center shrink-0">
                <AlertTriangle className="w-4 h-4 text-rose-400" />
              </span>
              <div>
                <p className="font-bold text-white">
                  У вас є {unmasteredCount} {unmasteredCount === 1 ? 'активна помилка' : 'активних помилок'}, що потребують уваги
                </p>
                <p className="text-slate-400 text-[11px]">
                  Алгоритм автоматично підмішує їх у поточні питання для безперешкодного закріплення.
                </p>
              </div>
            </div>
            <button
              onClick={() => setCategory('mistakes')}
              className="px-3.5 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold whitespace-nowrap transition cursor-pointer self-start sm:self-auto"
            >
              Сфокусуватися на помилках ({unmasteredCount}) →
            </button>
          </div>
        )}

        {/* Category Dropdown & Quick Stats */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-800/80">
          <div className="flex items-center gap-2">
            <span className="text-xs font-medium text-slate-400">Тема:</span>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="bg-slate-800 border border-slate-700 text-slate-200 text-xs font-bold rounded-xl px-3 py-1.5 focus:outline-none focus:border-blue-500 cursor-pointer"
            >
              <option value="all">Усі теми та правила (Повний мікс 3,000+)</option>
              {unmasteredCount > 0 && (
                <option value="mistakes">
                  🎯 Мої складні помилки ({unmasteredCount})
                </option>
              )}
              <optgroup label="🐾 Тематичні сфери слів">
                {THEMATIC_CATEGORIES.map((cat) => (
                  <option key={cat.id} value={cat.id}>
                    {cat.icon} {cat.title} ({cat.engTitle})
                  </option>
                ))}
              </optgroup>
              <optgroup label="⚡ Мовні мости (суфікси / префікси)">
                <option value="tion">-ція ➔ -tion / -sion</option>
                <option value="less">без- ➔ -less / ir-</option>
                <option value="ic">-чний ➔ -ic / -ical</option>
                <option value="ity">-ість ➔ -ity / -ness</option>
                <option value="re">пере- (повтор) ➔ re-</option>
                <option value="over">пере- (надлишок) ➔ over-</option>
                <option value="al">-альний ➔ -al</option>
                <option value="ive">-ивний ➔ -ive</option>
                <option value="ist">Діячі ➔ -ist / -or / -er</option>
                <option value="able">-абельний ➔ -able / -ible</option>
                <option value="ment">Іменники дій ➔ -ment</option>
                <option value="false_friends">⚠️ Фальшиві друзі (Пастки)</option>
              </optgroup>
            </select>
          </div>

          <div className="flex items-center gap-4 text-xs font-bold">
            <div className="flex items-center gap-1.5 text-amber-400">
              <Flame className="w-4 h-4" />
              <span>Серія: {comboCount}</span>
            </div>
            <div className="flex items-center gap-1.5 text-emerald-400">
              <CheckCircle className="w-4 h-4" />
              <span>Бали: {totalScore}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Empty State when category is 'mistakes' but user has 0 mistakes */}
      {category === 'mistakes' && unmasteredCount === 0 && !isFinished && (
        <div className="max-w-xl mx-auto bg-slate-900 rounded-3xl border border-slate-800 p-8 text-center space-y-4">
          <div className="w-16 h-16 rounded-2xl bg-emerald-950/60 border border-emerald-500/30 text-emerald-400 flex items-center justify-center mx-auto">
            <CheckCircle className="w-8 h-8" />
          </div>
          <div className="space-y-1">
            <h3 className="text-lg font-bold text-white">Всі помилки успішно засвоєно!</h3>
            <p className="text-xs text-slate-400">
              У вас немає активних нерозібраних помилок. Продовжуйте тренуватися на загальних правилах або спробуйте слова-пастки.
            </p>
          </div>
          <div className="flex flex-wrap justify-center gap-3 pt-2">
            <button
              onClick={() => {
                setCategory('all');
                setMode('blitz');
              }}
              className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs transition cursor-pointer"
            >
              Запустити Бліц (10)
            </button>
            <button
              onClick={() => {
                setCategory('false_friends');
                setMode('traps');
              }}
              className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs transition cursor-pointer"
            >
              Слова-пастки
            </button>
            <button
              onClick={() => onSelectTab('mistakes')}
              className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-rose-300 font-bold text-xs transition cursor-pointer"
            >
              Студія помилок (SRS)
            </button>
          </div>
        </div>
      )}

      {/* Main Quiz Interactive Card */}
      {!isFinished && activeItem && (
        <div className="max-w-2xl mx-auto bg-slate-900/90 rounded-3xl border border-slate-800 p-6 sm:p-8 shadow-2xl relative overflow-hidden">
          {/* Progress Bar */}
          <div className="space-y-1.5 mb-6">
            <div className="flex items-center justify-between text-xs font-bold">
              <span className="text-slate-400">
                {mode === 'endless'
                  ? `Питання #${currentIndex}`
                  : `Питання ${currentIndex} з ${maxQuestions}`}
              </span>
              <span className="text-blue-400 bg-blue-500/10 px-2.5 py-0.5 rounded-lg border border-blue-500/20 font-bold">
                {selectedAnswer === null ? 'Завдання' : activeItem.rule}
              </span>
            </div>
            <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
              <div
                className="bg-gradient-to-r from-blue-600 to-indigo-500 h-full rounded-full transition-all duration-300"
                style={{
                  width: `${
                    mode === 'endless'
                      ? 100
                      : Math.min(100, Math.round((currentIndex / maxQuestions) * 100))
                  }%`,
                }}
              />
            </div>
          </div>

          {/* Question Prompt */}
          <div className="text-center py-4 space-y-2">
            {(activeItem.category === 'mistakes' || activeItem.category === 'mistake_review') && (
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30 text-xs font-bold mx-auto mb-1">
                <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
                <span>Цільове закріплення вашої попередньої помилки</span>
              </div>
            )}
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block">
              {getCategoryHeaderLabel()}
            </span>
            <h3 className="text-3xl sm:text-4xl font-black text-white tracking-tight">{activeItem.ukr}</h3>
            <p className="text-xs sm:text-sm text-slate-400">
              Оберіть правильний англійський відповідник:
            </p>
          </div>

          {/* 4 Unique Interactive Options */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 my-6">
            {options.map((opt, idx) => {
              const isSelected = selectedAnswer === opt;
              const isCorrectAnswer = cleanWord(opt).toLowerCase() === cleanWord(activeItem.eng).toLowerCase();

              let btnClasses =
                'p-4 rounded-2xl border-2 text-left font-bold flex items-center justify-between transition group ';
              if (selectedAnswer === null) {
                btnClasses += 'bg-slate-800 hover:bg-slate-700/80 border-slate-700/80 text-slate-100 cursor-pointer';
              } else if (isCorrectAnswer) {
                btnClasses += 'bg-emerald-950/60 border-emerald-500 text-emerald-300 shadow-md shadow-emerald-950/30';
              } else if (isSelected && !isCorrectAnswer) {
                btnClasses += 'bg-rose-950/60 border-rose-500 text-rose-300 shadow-md shadow-rose-950/30';
              } else {
                btnClasses += 'bg-slate-800/40 border-slate-800 text-slate-500 opacity-60';
              }

              return (
                <button
                  key={`${opt}-${idx}`}
                  disabled={selectedAnswer !== null}
                  onClick={() => handleSelectAnswer(opt)}
                  className={btnClasses}
                >
                  <div className="flex items-center gap-3">
                    <span className="w-6 h-6 rounded-lg bg-slate-700 text-slate-300 text-xs flex items-center justify-center font-mono">
                      {idx + 1}
                    </span>
                    <span className="text-sm sm:text-base">{cleanWord(opt)}</span>
                  </div>
                  <div className="w-5 h-5 rounded-full flex items-center justify-center shrink-0">
                    {selectedAnswer !== null && isCorrectAnswer && (
                      <div className="w-5 h-5 rounded-full bg-emerald-500 flex items-center justify-center text-white">
                        <Check className="w-3.5 h-3.5" />
                      </div>
                    )}
                    {selectedAnswer !== null && isSelected && !isCorrectAnswer && (
                      <div className="w-5 h-5 rounded-full bg-rose-500 flex items-center justify-center text-white">
                        <X className="w-3.5 h-3.5" />
                      </div>
                    )}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Feedback Box */}
          {selectedAnswer !== null && (
            <div
              className={`p-4 rounded-2xl mb-4 text-xs sm:text-sm font-semibold flex items-center gap-3 ${
                cleanWord(selectedAnswer).toLowerCase() === cleanWord(activeItem.eng).toLowerCase()
                  ? 'bg-emerald-950/50 border border-emerald-500/40 text-emerald-300'
                  : 'bg-rose-950/50 border border-rose-500/40 text-rose-300'
              }`}
            >
              {cleanWord(selectedAnswer).toLowerCase() === cleanWord(activeItem.eng).toLowerCase() ? (
                <>
                  <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0" />
                  <div>
                    <strong>Відмінно! +{10 + comboCount * 2} XP</strong>
                    <p className="text-xs text-emerald-400/80 font-normal mt-0.5">
                      Правило: {activeItem.rule} {activeItem.ipa ? `• ${activeItem.ipa}` : ''}
                    </p>
                  </div>
                </>
              ) : (
                <>
                  <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0" />
                  <div className="space-y-1">
                    <strong>Не зовсім так! Правильна відповідь: «{activeItem.eng}»</strong>
                    <p className="text-xs text-rose-300/80 font-normal">Логіка: {activeItem.rule}</p>
                    {activeItem.trap && (
                      <p className="text-xs text-amber-300/90 font-medium pt-1 border-t border-rose-500/20">
                        💡 Підказка пам'яті: {activeItem.trap}
                      </p>
                    )}
                  </div>
                </>
              )}
            </div>
          )}

          {/* Action Buttons: Next Word and Pronunciation Audio Controls */}
          <div className="flex flex-wrap items-center gap-2.5">
            {selectedAnswer !== null && (
              <button
                onClick={handleNext}
                className="flex-1 py-3.5 px-6 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-black text-sm flex items-center justify-center gap-2 shadow-lg shadow-blue-500/20 transition transform active:scale-95 cursor-pointer"
              >
                <span>Наступне питання</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}

            <div className="flex items-center gap-2">
              <button
                onClick={() => handleSpeakActive(0.9)}
                className="py-3.5 px-4 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-bold text-xs flex items-center gap-1.5 border border-slate-700 transition cursor-pointer"
                title="Озвучити зі звичайною швидкістю"
              >
                <Volume2 className="w-4 h-4 text-emerald-400" />
                <span>1.0x</span>
              </button>
              <button
                onClick={() => handleSpeakActive(0.7)}
                className="py-3.5 px-4 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-bold text-xs flex items-center gap-1.5 border border-slate-700 transition cursor-pointer"
                title="Повільна вимова (для складних звуків)"
              >
                <Volume2 className="w-4 h-4 text-sky-400" />
                <span>0.7x</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Quiz Finished Screen */}
      {isFinished && (
        <div className="max-w-xl mx-auto bg-slate-900 rounded-3xl border border-slate-800 p-8 shadow-2xl text-center space-y-6">
          <div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-amber-400 to-orange-500 text-slate-950 font-black text-3xl flex items-center justify-center mx-auto shadow-xl shadow-orange-500/20">
            🏆
          </div>
          <div className="space-y-2">
            <h3 className="text-2xl sm:text-3xl font-black text-white">Вітаємо з проходженням!</h3>
            <p className="text-slate-400 text-sm">Ви чудово закріпили мовні шаблони. Ось ваш результат:</p>
          </div>
          <div className="grid grid-cols-3 gap-3 py-2">
            <div className="p-3.5 rounded-2xl bg-slate-800/80 border border-slate-700">
              <span className="text-slate-400 text-xs block">Точність</span>
              <span className="text-xl font-black text-emerald-400">
                {sessionTotal > 0 ? Math.round((sessionCorrect / sessionTotal) * 100) : 100}%
              </span>
            </div>
            <div className="p-3.5 rounded-2xl bg-slate-800/80 border border-slate-700">
              <span className="text-slate-400 text-xs block">Бали</span>
              <span className="text-xl font-black text-blue-400">{totalScore}</span>
            </div>
            <div className="p-3.5 rounded-2xl bg-slate-800/80 border border-slate-700">
              <span className="text-slate-400 text-xs block">Правильних</span>
              <span className="text-xl font-black text-amber-400">
                {sessionCorrect} / {sessionTotal}
              </span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 justify-center pt-2">
            <button
              onClick={restartQuiz}
              className="px-6 py-3.5 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-blue-500/20 transition cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Пройти ще раз</span>
            </button>
            <button
              onClick={() => onSelectTab('cards')}
              className="px-6 py-3.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-sm border border-slate-700 flex items-center justify-center gap-2 transition cursor-pointer"
            >
              <Layers className="w-4 h-4" />
              <span>Перейти до карток</span>
            </button>
            {unmasteredCount > 0 && (
              <button
                onClick={() => onSelectTab('mistakes')}
                className="px-6 py-3.5 rounded-2xl bg-rose-950/60 hover:bg-rose-900/60 text-rose-300 font-bold text-sm border border-rose-700/60 flex items-center justify-center gap-2 transition cursor-pointer"
              >
                <AlertTriangle className="w-4 h-4" />
                <span>Студія помилок ({unmasteredCount})</span>
              </button>
            )}
          </div>
        </div>
      )}
    </section>
  );
};
