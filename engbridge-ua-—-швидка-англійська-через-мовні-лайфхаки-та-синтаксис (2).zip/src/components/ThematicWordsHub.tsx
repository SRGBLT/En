import React, { useState, useMemo, useEffect } from 'react';
import {
  Sparkles,
  Search,
  Volume2,
  BookmarkCheck,
  BookmarkPlus,
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  RotateCw,
  Layers,
  Zap,
  HelpCircle,
  Lightbulb,
  Check,
  X,
  Play,
  RotateCcw,
  BookOpen,
  Filter,
  CheckCheck,
  Compass,
  Trophy,
  GraduationCap,
  Flame,
  Headphones,
  Target,
  Award,
  Eye,
  EyeOff,
  Lock,
  Unlock,
  Star,
  ShieldCheck,
  ChevronRight,
  BellRing,
  Brain,
  Clock,
} from 'lucide-react';
import {
  THEMATIC_CATEGORIES,
  THEMATIC_WORDS,
  getWordsByCategory,
  toVocabItem,
} from '../data/thematicWords';
import { ThematicWord, VocabItem, CefrLevel, TopicReviewRecord } from '../types';
import { speakEnglish, playSound } from '../utils/audio';
import {
  recordTopicReview,
  loadTopicReviews,
  computeTopicRetentionStatuses,
} from '../utils/reminderEngine';

interface ThematicWordsHubProps {
  learnedWords: VocabItem[];
  onToggleLearned: (item: VocabItem) => void;
  onRewardXP: (amount: number) => void;
  onToast: (msg: string, type: 'info' | 'success' | 'error') => void;
  onRecordMistake?: (vocabItem: VocabItem, wrongAnswer: string) => void;
  onNavigateToQuiz?: (category: string) => void;
  initialCategoryId?: string | null;
  initialPackNumber?: number | null;
  onOpenRemindersModal?: () => void;
}

type StudyMode = 'sprint' | 'cards' | 'flashcards' | 'quiz' | 'spelling' | 'cloze';
type SprintPhase = 'learn' | 'test' | 'results';

interface SprintQuestion {
  word: ThematicWord;
  type: 'uk_to_en' | 'en_to_uk' | 'audio_listen' | 'context_cloze';
  questionPrompt: string;
  correctAnswer: string;
  options: string[];
  contextSentence?: string;
}

export const ThematicWordsHub: React.FC<ThematicWordsHubProps> = ({
  learnedWords,
  onToggleLearned,
  onRewardXP,
  onToast,
  onRecordMistake,
  onNavigateToQuiz,
  initialCategoryId,
  initialPackNumber,
  onOpenRemindersModal,
}) => {
  const [selectedCategoryId, setSelectedCategoryId] = useState<string | null>(initialCategoryId || null);
  const [searchQuery, setSearchQuery] = useState('');
  const [studyMode, setStudyMode] = useState<StudyMode>('sprint');
  const [selectedLevelFilter, setSelectedLevelFilter] = useState<'all' | CefrLevel>('all');
  const [topicRecords, setTopicRecords] = useState<Record<string, TopicReviewRecord>>(loadTopicReviews);

  // ================= PROGRESSIVE SEQUENTIAL UNLOCKING =================
  // Stores highest unlocked pack per category: e.g. { animals: 2, home: 1 }
  const [unlockedPacks, setUnlockedPacks] = useState<Record<string, number>>(() => {
    try {
      const saved = localStorage.getItem('unlocked_thematic_packs_v1');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  // Stores test high scores: { [`${catId}_${pack}`]: { score: number, total: number } }
  const [packHighScores, setPackHighScores] = useState<Record<string, { score: number; total: number }>>(() => {
    try {
      const saved = localStorage.getItem('thematic_pack_scores_v1');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  // Optional teacher/expert override to unlock all packs
  const [unlockAllOverride, setUnlockAllOverride] = useState<boolean>(() => {
    try {
      return localStorage.getItem('thematic_unlock_all_override') === 'true';
    } catch {
      return false;
    }
  });

  // Currently active pack for the selected category (1 to 30)
  const [activePackNumber, setActivePackNumber] = useState<number>(1);
  const [packStageFilter, setPackStageFilter] = useState<'all' | 'stage1' | 'stage2' | 'stage3'>('all');

  // Level-up celebration state
  const [justUnlockedPack, setJustUnlockedPack] = useState<number | null>(null);

  // Sync initial navigation from reminders modal or external triggers
  useEffect(() => {
    if (initialCategoryId) {
      setSelectedCategoryId(initialCategoryId);
      if (initialPackNumber) {
        setActivePackNumber(initialPackNumber);
      }
    }
  }, [initialCategoryId, initialPackNumber]);

  // Compute live retention status for categories based on Ebbinghaus curve
  const liveRetentionStatuses = computeTopicRetentionStatuses(
    THEMATIC_CATEGORIES,
    learnedWords,
    topicRecords,
    unlockedPacks
  );
  const decayingTopics = liveRetentionStatuses.filter(
    (t) => t.urgency === 'critical' || t.urgency === 'high'
  );

  // ================= SPRINT STATE ("Спочатку вчимо -> потім тест") =================
  const [sprintPhase, setSprintPhase] = useState<SprintPhase>('learn');
  const [sprintLearnIndex, setSprintLearnIndex] = useState(0);
  const [isHideTranslation, setIsHideTranslation] = useState(false);
  const [sprintLearnedIds, setSprintLearnedIds] = useState<Set<string>>(new Set());

  // Sprint Test state
  const [sprintQuestions, setSprintQuestions] = useState<SprintQuestion[]>([]);
  const [sprintTestIndex, setSprintTestIndex] = useState(0);
  const [sprintSelectedOption, setSprintSelectedOption] = useState<string | null>(null);
  const [sprintIsChecked, setSprintIsChecked] = useState(false);
  const [sprintScore, setSprintScore] = useState(0);
  const [sprintTestResults, setSprintTestResults] = useState<{
    word: ThematicWord;
    isCorrect: boolean;
    userAnswer: string;
    correctAnswer: string;
  }[]>([]);

  // ================= FLASHCARDS STATE =================
  const [flashcardIndex, setFlashcardIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);

  // ================= BLITZ QUIZ STATE =================
  const [quizIndex, setQuizIndex] = useState(0);
  const [quizScore, setQuizScore] = useState(0);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [isAnswerChecked, setIsAnswerChecked] = useState(false);
  const [isQuizCompleted, setIsQuizCompleted] = useState(false);

  // ================= SPELLING STATE =================
  const [spellingIndex, setSpellingIndex] = useState(0);
  const [spellingLetters, setSpellingLetters] = useState<string[]>([]);
  const [availableTiles, setAvailableTiles] = useState<{ id: string; char: string }[]>([]);
  const [isSpellingCorrect, setIsSpellingCorrect] = useState<boolean | null>(null);

  // ================= CLOZE STATE =================
  const [clozeIndex, setClozeIndex] = useState(0);
  const [clozeSelected, setClozeSelected] = useState<string | null>(null);
  const [isClozeChecked, setIsClozeChecked] = useState(false);

  // Active Category & Filtered Words
  const activeCategory = useMemo(() => {
    return THEMATIC_CATEGORIES.find((c) => c.id === selectedCategoryId) || null;
  }, [selectedCategoryId]);

  const categoryWords = useMemo(() => {
    if (!selectedCategoryId) return THEMATIC_WORDS;
    return getWordsByCategory(selectedCategoryId);
  }, [selectedCategoryId]);

  // Available packs for this category (30 packs of 10 words each)
  // Available packs for this category
  const categoryPacks = useMemo(() => {
    if (!selectedCategoryId) return [1];
    const packs = Array.from(new Set(categoryWords.map((w) => w.pack || 1))).sort((a, b) => a - b);
    return packs.length > 0 ? packs : [1];
  }, [categoryWords, selectedCategoryId]);

  const displayedPacks = useMemo(() => {
    let filtered = categoryPacks;
    if (packStageFilter === 'stage1') filtered = categoryPacks.filter((p) => p >= 1 && p <= 10);
    else if (packStageFilter === 'stage2') filtered = categoryPacks.filter((p) => p >= 11 && p <= 20);
    else if (packStageFilter === 'stage3') filtered = categoryPacks.filter((p) => p >= 21 && p <= 30);
    return filtered.length > 0 ? filtered : categoryPacks;
  }, [categoryPacks, packStageFilter]);

  // Check if a pack is unlocked for the given category
  const isPackUnlocked = (catId: string, packNum: number) => {
    if (unlockAllOverride) return true;
    if (packNum === 1) return true; // Level 1 is always unlocked
    const currentMax = unlockedPacks[catId] || 1;
    return packNum <= currentMax;
  };

  // Words used specifically for the active sprint batch (focused pack of 10 words)
  const sprintWords = useMemo(() => {
    if (!selectedCategoryId) return categoryWords.slice(0, 10);
    const packWords = categoryWords.filter((w) => (w.pack || 1) === activePackNumber);
    return packWords.length > 0 ? packWords : categoryWords.slice(0, 10);
  }, [categoryWords, activePackNumber, selectedCategoryId]);

  const filteredWords = useMemo(() => {
    return categoryWords.filter((w) => {
      const matchesSearch =
        !searchQuery ||
        w.eng.toLowerCase().includes(searchQuery.toLowerCase().trim()) ||
        w.ukr.toLowerCase().includes(searchQuery.toLowerCase().trim());
      const matchesLevel =
        selectedLevelFilter === 'all' || w.level === selectedLevelFilter;
      return matchesSearch && matchesLevel;
    });
  }, [categoryWords, searchQuery, selectedLevelFilter]);

  // Check learned status in user profile
  const isWordLearned = (wordEng: string) => {
    return learnedWords.some((w) => w.eng.toLowerCase() === wordEng.toLowerCase());
  };

  const handleToggleWord = (word: ThematicWord) => {
    const vocab = toVocabItem(word);
    const wasLearned = isWordLearned(word.eng);
    onToggleLearned(vocab);
    if (!wasLearned) {
      playSound('correct');
      onRewardXP(10);
      onToast(`«${word.eng}» збережено у Скарбничку! (+10 XP)`, 'success');
    } else {
      playSound('click');
      onToast(`«${word.eng}» видалено зі Скарбнички`, 'info');
    }
  };

  // Pronunciation
  const handleSpeak = (text: string, rate: number = 0.9) => {
    speakEnglish(text, rate);
  };

  // Switch category
  const handleSelectCategory = (catId: string | null, targetMode: StudyMode = 'sprint') => {
    playSound('click');
    setSelectedCategoryId(catId);
    setStudyMode(targetMode);
    setSearchQuery('');
    setFlashcardIndex(0);
    setIsFlipped(false);
    resetQuiz();
    initSpelling(catId);
    resetCloze();

    // Default active pack to the highest unlocked (up to 30) or 1
    if (catId) {
      const maxUnlocked = unlockedPacks[catId] || 1;
      setActivePackNumber(Math.min(maxUnlocked, 30));
    } else {
      setActivePackNumber(1);
    }
    setJustUnlockedPack(null);
    resetSprint();
  };

  // Switch active pack within category
  const handleSelectPack = (packNum: number) => {
    if (!selectedCategoryId) return;
    if (!isPackUnlocked(selectedCategoryId, packNum)) {
      playSound('wrong');
      onToast(`🔒 Блок ${packNum} заблоковано! Складіть тест Блоку ${packNum - 1} (мінімум 70%), щоб відкрити його.`, 'error');
      return;
    }
    playSound('click');
    setActivePackNumber(packNum);
    setJustUnlockedPack(null);
    resetSprint();
  };

  // Toggle unlock all override
  const handleToggleUnlockAll = () => {
    const nextVal = !unlockAllOverride;
    setUnlockAllOverride(nextVal);
    try {
      localStorage.setItem('thematic_unlock_all_override', String(nextVal));
    } catch {}
    playSound('click');
    onToast(
      nextVal
        ? '🔓 Вільний режим активовано! Усі блоки та слова відкрито.'
        : '🔒 Послідовний режим увімкнено! Блоки відкриваються по черзі.',
      'info'
    );
  };

  // Reset progress for this category
  const handleResetCategoryProgress = () => {
    if (!selectedCategoryId) return;
    playSound('click');
    setUnlockedPacks((prev) => {
      const updated = { ...prev, [selectedCategoryId]: 1 };
      try {
        localStorage.setItem('unlocked_thematic_packs_v1', JSON.stringify(updated));
      } catch {}
      return updated;
    });
    setActivePackNumber(1);
    resetSprint();
    onToast('Прогрес теми скинуто до Блоку 1.', 'info');
  };

  // ================= SPRINT CONTROLS =================
  const resetSprint = () => {
    setSprintPhase('learn');
    setSprintLearnIndex(0);
    setIsHideTranslation(false);
    setSprintLearnedIds(new Set());
    setSprintTestIndex(0);
    setSprintSelectedOption(null);
    setSprintIsChecked(false);
    setSprintScore(0);
    setSprintTestResults([]);
  };

  const currentSprintLearnWord = sprintWords[sprintLearnIndex] || sprintWords[0] || null;

  // Mark word as learned in sprint and advance
  const handleMarkSprintWordLearned = (word: ThematicWord) => {
    playSound('correct');
    setSprintLearnedIds((prev) => new Set(prev).add(word.id));
    onRewardXP(10);
    onToast(`«${word.eng}» вивчено! (+10 XP)`, 'success');

    if (sprintLearnIndex + 1 < sprintWords.length) {
      setSprintLearnIndex((prev) => prev + 1);
      setIsHideTranslation(false);
    }
  };

  // Build the Test Questions for the active pack
  const generateSprintQuestions = (words: ThematicWord[]): SprintQuestion[] => {
    const currentCatWords = categoryWords.filter((w) => w.eng && w.ukr);
    const allThematic = THEMATIC_WORDS;

    return words.map((word, idx) => {
      const typeIndex = idx % 4;
      let type: SprintQuestion['type'] = 'uk_to_en';
      let prompt = '';
      let correctAnswer = '';
      let options: string[] = [];
      let contextSentence: string | undefined = undefined;

      const normEng = word.eng.trim();
      const normUkr = word.ukr.trim();

      if (typeIndex === 0) {
        // Ukrainian -> English translation test
        type = 'uk_to_en';
        prompt = 'Оберіть точний англійський переклад:';
        correctAnswer = normEng;

        const distractorSet = new Set<string>();
        const usedLower = new Set<string>([normEng.toLowerCase()]);

        // Prioritize distractors from the current category
        const sameCatShuffled = [...currentCatWords].sort(() => Math.random() - 0.5);
        for (const w of sameCatShuffled) {
          const wEng = w.eng.trim();
          if (wEng && !usedLower.has(wEng.toLowerCase())) {
            distractorSet.add(wEng);
            usedLower.add(wEng.toLowerCase());
            if (distractorSet.size >= 3) break;
          }
        }

        // Supplement from all thematic words if needed
        if (distractorSet.size < 3) {
          const allShuffled = [...allThematic].sort(() => Math.random() - 0.5);
          for (const w of allShuffled) {
            const wEng = w.eng.trim();
            if (wEng && !usedLower.has(wEng.toLowerCase())) {
              distractorSet.add(wEng);
              usedLower.add(wEng.toLowerCase());
              if (distractorSet.size >= 3) break;
            }
          }
        }

        options = [correctAnswer, ...Array.from(distractorSet)].sort(() => Math.random() - 0.5);
      } else if (typeIndex === 1) {
        // English -> Ukrainian translation test
        type = 'en_to_uk';
        prompt = 'Оберіть правильний український переклад:';
        correctAnswer = normUkr;

        const distractorSet = new Set<string>();
        const usedLower = new Set<string>([normUkr.toLowerCase()]);

        const sameCatShuffled = [...currentCatWords].sort(() => Math.random() - 0.5);
        for (const w of sameCatShuffled) {
          const wUkr = w.ukr.trim();
          if (wUkr && !usedLower.has(wUkr.toLowerCase())) {
            distractorSet.add(wUkr);
            usedLower.add(wUkr.toLowerCase());
            if (distractorSet.size >= 3) break;
          }
        }

        if (distractorSet.size < 3) {
          const allShuffled = [...allThematic].sort(() => Math.random() - 0.5);
          for (const w of allShuffled) {
            const wUkr = w.ukr.trim();
            if (wUkr && !usedLower.has(wUkr.toLowerCase())) {
              distractorSet.add(wUkr);
              usedLower.add(wUkr.toLowerCase());
              if (distractorSet.size >= 3) break;
            }
          }
        }

        options = [correctAnswer, ...Array.from(distractorSet)].sort(() => Math.random() - 0.5);
      } else if (typeIndex === 2) {
        // Audio Listening -> Ukrainian translation
        type = 'audio_listen';
        prompt = 'Послухайте вимову та оберіть значення слова:';
        correctAnswer = normUkr;

        const distractorSet = new Set<string>();
        const usedLower = new Set<string>([normUkr.toLowerCase()]);

        const sameCatShuffled = [...currentCatWords].sort(() => Math.random() - 0.5);
        for (const w of sameCatShuffled) {
          const wUkr = w.ukr.trim();
          if (wUkr && !usedLower.has(wUkr.toLowerCase())) {
            distractorSet.add(wUkr);
            usedLower.add(wUkr.toLowerCase());
            if (distractorSet.size >= 3) break;
          }
        }

        if (distractorSet.size < 3) {
          const allShuffled = [...allThematic].sort(() => Math.random() - 0.5);
          for (const w of allShuffled) {
            const wUkr = w.ukr.trim();
            if (wUkr && !usedLower.has(wUkr.toLowerCase())) {
              distractorSet.add(wUkr);
              usedLower.add(wUkr.toLowerCase());
              if (distractorSet.size >= 3) break;
            }
          }
        }

        options = [correctAnswer, ...Array.from(distractorSet)].sort(() => Math.random() - 0.5);
      } else {
        // Context Cloze fill-in-the-blank
        type = 'context_cloze';
        prompt = 'Вставте пропущене слово за контекстом речення:';
        correctAnswer = normEng;

        // Smart cloze sentence masking
        const rawExample = word.exampleEn || '';
        const escaped = normEng.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        let maskedSentence = rawExample.replace(new RegExp(`\\b${escaped}\\b`, 'gi'), '_______');

        if (!maskedSentence.includes('_______')) {
          maskedSentence = rawExample.replace(new RegExp(escaped, 'gi'), '_______');
        }

        if (!maskedSentence.includes('_______') && normEng.length >= 4) {
          const stem = normEng.slice(0, Math.min(normEng.length - 1, 5)).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
          maskedSentence = rawExample.replace(new RegExp(`\\b${stem}[a-z]*\\b`, 'gi'), '_______');
        }

        if (!maskedSentence.includes('_______')) {
          maskedSentence = `${rawExample.replace(/[.,!?]$/, '')} — [ _______ ].`;
        }

        contextSentence = maskedSentence;

        const distractorSet = new Set<string>();
        const usedLower = new Set<string>([normEng.toLowerCase()]);

        const sameCatShuffled = [...currentCatWords].sort(() => Math.random() - 0.5);
        for (const w of sameCatShuffled) {
          const wEng = w.eng.trim();
          if (wEng && !usedLower.has(wEng.toLowerCase())) {
            distractorSet.add(wEng);
            usedLower.add(wEng.toLowerCase());
            if (distractorSet.size >= 3) break;
          }
        }

        if (distractorSet.size < 3) {
          const allShuffled = [...allThematic].sort(() => Math.random() - 0.5);
          for (const w of allShuffled) {
            const wEng = w.eng.trim();
            if (wEng && !usedLower.has(wEng.toLowerCase())) {
              distractorSet.add(wEng);
              usedLower.add(wEng.toLowerCase());
              if (distractorSet.size >= 3) break;
            }
          }
        }

        options = [correctAnswer, ...Array.from(distractorSet)].sort(() => Math.random() - 0.5);
      }

      return {
        word,
        type,
        questionPrompt: prompt,
        correctAnswer,
        options,
        contextSentence,
      };
    });
  };

  // Launch the Test Phase of the Sprint
  const handleStartSprintTest = () => {
    playSound('click');
    const questions = generateSprintQuestions(sprintWords);
    setSprintQuestions(questions);
    setSprintTestIndex(0);
    setSprintScore(0);
    setSprintSelectedOption(null);
    setSprintIsChecked(false);
    setSprintTestResults([]);
    setSprintPhase('test');

    if (questions[0] && questions[0].type === 'audio_listen') {
      setTimeout(() => speakEnglish(questions[0].word.eng), 400);
    }
  };

  // Handle Answer in Sprint Test
  const handleSprintSelectAnswer = (option: string) => {
    if (sprintIsChecked) return;
    const currentQ = sprintQuestions[sprintTestIndex];
    if (!currentQ) return;

    setSprintSelectedOption(option);
    setSprintIsChecked(true);

    const isCorrect = option.toLowerCase().trim() === currentQ.correctAnswer.toLowerCase().trim();

    if (isCorrect) {
      playSound('correct');
      setSprintScore((prev) => prev + 1);
      onRewardXP(15);
      onToast('Чудово! Правильна відповідь (+15 XP)', 'success');
    } else {
      playSound('wrong');
      if (onRecordMistake) {
        onRecordMistake(toVocabItem(currentQ.word), option);
      }
      onToast(`Помилка! Правильно: «${currentQ.correctAnswer}»`, 'error');
    }

    setSprintTestResults((prev) => [
      ...prev,
      {
        word: currentQ.word,
        isCorrect,
        userAnswer: option,
        correctAnswer: currentQ.correctAnswer,
      },
    ]);
  };

  const handleSprintNextQuestion = () => {
    if (sprintTestIndex + 1 < sprintQuestions.length) {
      const nextIdx = sprintTestIndex + 1;
      setSprintTestIndex(nextIdx);
      setSprintSelectedOption(null);
      setSprintIsChecked(false);

      const nextQ = sprintQuestions[nextIdx];
      if (nextQ && nextQ.type === 'audio_listen') {
        setTimeout(() => speakEnglish(nextQ.word.eng), 300);
      }
    } else {
      // Completed Sprint! Check for Sequential Level Unlock!
      playSound('correct');
      const passingThreshold = Math.ceil(sprintQuestions.length * 0.7); // 70%+
      const isPassed = sprintScore >= passingThreshold;
      const totalQ = sprintQuestions.length;

      // Update High Scores
      if (selectedCategoryId) {
        const scoreKey = `${selectedCategoryId}_${activePackNumber}`;
        setPackHighScores((prev) => {
          const prevScore = prev[scoreKey]?.score || 0;
          const updated = {
            ...prev,
            [scoreKey]: { score: Math.max(prevScore, sprintScore), total: totalQ },
          };
          try {
            localStorage.setItem('thematic_pack_scores_v1', JSON.stringify(updated));
          } catch {}
          return updated;
        });

        // If passed and was on highest unlocked pack, unlock next pack!
        const currentUnlockedMax = unlockedPacks[selectedCategoryId] || 1;
        if (isPassed && activePackNumber >= currentUnlockedMax && activePackNumber < categoryPacks.length) {
          const nextPack = activePackNumber + 1;
          setUnlockedPacks((prev) => {
            const updated = { ...prev, [selectedCategoryId]: nextPack };
            try {
              localStorage.setItem('unlocked_thematic_packs_v1', JSON.stringify(updated));
            } catch {}
            return updated;
          });
          setJustUnlockedPack(nextPack);
          onRewardXP(50);
          onToast(`🎉 Вітаємо! Розблоковано Блок ${nextPack} (+50 XP)! 🏆`, 'success');
        } else {
          const bonusXP = isPassed ? 40 : 20;
          onRewardXP(bonusXP);
          onToast(`Тест завершено! +${bonusXP} XP`, 'success');
        }

        // Record topic review for Ebbinghaus retention tracking
        const updatedRecords = recordTopicReview(selectedCategoryId, activePackNumber);
        setTopicRecords(updatedRecords);
      }

      setSprintPhase('results');
    }
  };

  // Save all sprint words to dictionary
  const handleSaveAllSprintWords = () => {
    playSound('correct');
    sprintWords.forEach((word) => {
      if (!isWordLearned(word.eng)) {
        onToggleLearned(toVocabItem(word));
      }
    });
    onRewardXP(sprintWords.length * 5);
    onToast(`Усі ${sprintWords.length} слів збережено у Скарбничку!`, 'success');
  };

  // Advance to next Category
  const handleGoToNextCategory = () => {
    if (!selectedCategoryId) return;
    const currentIdx = THEMATIC_CATEGORIES.findIndex((c) => c.id === selectedCategoryId);
    const nextCat = THEMATIC_CATEGORIES[(currentIdx + 1) % THEMATIC_CATEGORIES.length];
    handleSelectCategory(nextCat.id, 'sprint');
  };

  // ================= BLITZ QUIZ LOGIC =================
  const resetQuiz = () => {
    setQuizIndex(0);
    setQuizScore(0);
    setSelectedOption(null);
    setIsAnswerChecked(false);
    setIsQuizCompleted(false);
  };

  const currentQuizWord = filteredWords[quizIndex] || null;
  const quizOptions = useMemo(() => {
    if (!currentQuizWord) return [];
    const pool = categoryWords.length > 3 ? categoryWords : THEMATIC_WORDS;
    const usedEng = new Set<string>([currentQuizWord.eng.toLowerCase()]);
    const chosen: ThematicWord[] = [currentQuizWord];

    const shuffledCategory = [...pool].sort(() => Math.random() - 0.5);
    for (const w of shuffledCategory) {
      if (!usedEng.has(w.eng.toLowerCase())) {
        chosen.push(w);
        usedEng.add(w.eng.toLowerCase());
        if (chosen.length >= 4) break;
      }
    }

    if (chosen.length < 4) {
      const allShuffled = [...THEMATIC_WORDS].sort(() => Math.random() - 0.5);
      for (const w of allShuffled) {
        if (!usedEng.has(w.eng.toLowerCase())) {
          chosen.push(w);
          usedEng.add(w.eng.toLowerCase());
          if (chosen.length >= 4) break;
        }
      }
    }

    return chosen.sort(() => Math.random() - 0.5);
  }, [currentQuizWord, categoryWords]);

  const handleQuizAnswer = (optionEng: string) => {
    if (isAnswerChecked || !currentQuizWord) return;
    setSelectedOption(optionEng);
    setIsAnswerChecked(true);

    const isCorrect = optionEng === currentQuizWord.eng;
    if (isCorrect) {
      playSound('correct');
      setQuizScore((prev) => prev + 1);
      onRewardXP(15);
      onToast('Чудово! Правильна відповідь (+15 XP)', 'success');
    } else {
      playSound('wrong');
      if (onRecordMistake) {
        onRecordMistake(toVocabItem(currentQuizWord), optionEng);
      }
      onToast(`Помилка! Правильно: «${currentQuizWord.eng}»`, 'error');
    }
  };

  const handleNextQuizQuestion = () => {
    if (quizIndex + 1 < filteredWords.length && quizIndex + 1 < 10) {
      setQuizIndex((prev) => prev + 1);
      setSelectedOption(null);
      setIsAnswerChecked(false);
    } else {
      setIsQuizCompleted(true);
    }
  };

  // ================= SPELLING LOGIC =================
  const initSpelling = (catId: string | null) => {
    const pool = catId ? getWordsByCategory(catId) : THEMATIC_WORDS;
    if (pool.length > 0) {
      const current = pool[0];
      const cleanWord = current.eng.toLowerCase().replace(/[^a-z]/g, '');
      const chars = cleanWord.split('');
      const scrambled = [...chars]
        .map((char, idx) => ({ id: `${char}-${idx}`, char }))
        .sort(() => Math.random() - 0.5);
      setSpellingIndex(0);
      setSpellingLetters([]);
      setAvailableTiles(scrambled);
      setIsSpellingCorrect(null);
    }
  };

  const handleSelectTile = (tile: { id: string; char: string }) => {
    if (isSpellingCorrect !== null) return;
    playSound('click');
    setSpellingLetters((prev) => [...prev, tile.char]);
    setAvailableTiles((prev) => prev.filter((t) => t.id !== tile.id));
  };

  const handleRemoveLetter = (index: number) => {
    if (isSpellingCorrect !== null) return;
    playSound('click');
    const char = spellingLetters[index];
    const newLetters = [...spellingLetters];
    newLetters.splice(index, 1);
    setSpellingLetters(newLetters);
    setAvailableTiles((prev) => [...prev, { id: `${char}-${Date.now()}-${Math.random()}`, char }]);
  };

  const handleCheckSpelling = () => {
    const currentWord = filteredWords[spellingIndex];
    if (!currentWord) return;
    const target = currentWord.eng.toLowerCase().replace(/[^a-z]/g, '');
    const current = spellingLetters.join('').toLowerCase();

    if (current === target) {
      playSound('correct');
      setIsSpellingCorrect(true);
      onRewardXP(20);
      onToast('Блискуче! Слово складено правильно (+20 XP)', 'success');
    } else {
      playSound('wrong');
      setIsSpellingCorrect(false);
      if (onRecordMistake) {
        onRecordMistake(toVocabItem(currentWord), current);
      }
      onToast(`Спробуйте ще раз! Зверніть увагу на порядок літер.`, 'error');
    }
  };

  const handleNextSpellingWord = () => {
    const nextIdx = (spellingIndex + 1) % filteredWords.length;
    setSpellingIndex(nextIdx);
    const nextWord = filteredWords[nextIdx];
    if (nextWord) {
      const clean = nextWord.eng.toLowerCase().replace(/[^a-z]/g, '');
      const chars = clean.split('');
      const scrambled = [...chars]
        .map((char, idx) => ({ id: `${char}-${idx}`, char }))
        .sort(() => Math.random() - 0.5);
      setSpellingLetters([]);
      setAvailableTiles(scrambled);
      setIsSpellingCorrect(null);
    }
  };

  // ================= CLOZE LOGIC =================
  const resetCloze = () => {
    setClozeIndex(0);
    setClozeSelected(null);
    setIsClozeChecked(false);
  };

  const currentClozeWord = filteredWords[clozeIndex] || null;
  const clozeOptions = useMemo(() => {
    if (!currentClozeWord) return [];
    const pool = categoryWords.length > 3 ? categoryWords : THEMATIC_WORDS;
    const usedEng = new Set<string>([currentClozeWord.eng.toLowerCase()]);
    const chosen: ThematicWord[] = [currentClozeWord];

    const shuffledCategory = [...pool].sort(() => Math.random() - 0.5);
    for (const w of shuffledCategory) {
      if (!usedEng.has(w.eng.toLowerCase())) {
        chosen.push(w);
        usedEng.add(w.eng.toLowerCase());
        if (chosen.length >= 4) break;
      }
    }

    if (chosen.length < 4) {
      const allShuffled = [...THEMATIC_WORDS].sort(() => Math.random() - 0.5);
      for (const w of allShuffled) {
        if (!usedEng.has(w.eng.toLowerCase())) {
          chosen.push(w);
          usedEng.add(w.eng.toLowerCase());
          if (chosen.length >= 4) break;
        }
      }
    }

    return chosen.sort(() => Math.random() - 0.5);
  }, [currentClozeWord, categoryWords]);

  const handleSelectClozeOption = (wordEng: string) => {
    if (isClozeChecked || !currentClozeWord) return;
    setClozeSelected(wordEng);
    setIsClozeChecked(true);

    const isCorrect = wordEng === currentClozeWord.eng;
    if (isCorrect) {
      playSound('correct');
      onRewardXP(20);
      onToast('Вірно! Ви вставили потрібне слово в контекст (+20 XP)', 'success');
    } else {
      playSound('wrong');
      if (onRecordMistake) {
        onRecordMistake(toVocabItem(currentClozeWord), wordEng);
      }
      onToast(`Не зовсім так. Правильно: «${currentClozeWord.eng}»`, 'error');
    }
  };

  const handleNextCloze = () => {
    if (clozeIndex + 1 < filteredWords.length) {
      setClozeIndex((prev) => prev + 1);
      setClozeSelected(null);
      setIsClozeChecked(false);
    } else {
      setClozeIndex(0);
      setClozeSelected(null);
      setIsClozeChecked(false);
    }
  };

  // Overall stats
  const totalCategoryWordsCount = categoryWords.length;
  const learnedCountInCategory = categoryWords.filter((w) => isWordLearned(w.eng)).length;
  const categoryMasteryPercent =
    totalCategoryWordsCount > 0
      ? Math.round((learnedCountInCategory / totalCategoryWordsCount) * 100)
      : 0;

  return (
    <section className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-900/90 to-indigo-950/40 border border-slate-800 rounded-3xl p-6 sm:p-8 relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-xl bg-blue-500/10 text-blue-400 border border-blue-500/20 text-xs font-bold tracking-wide">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Покрокова система рівнів слів</span>
            </div>
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black text-white tracking-tight">
              Слова за Категоріями з Послідовним Розблокуванням
            </h1>
            <p className="text-sm sm:text-base text-slate-300 max-w-2xl leading-relaxed">
              Величезний банк практичної лексики ({THEMATIC_WORDS.length}+ слів у 16 темах). Слова розбиті на покрокові <strong className="text-amber-300 font-bold">Блоки (Рівні)</strong>: спочатку вивчаємо слова блоку ➔ складаємо тест ➔ <strong className="text-emerald-300 font-bold">розблоковується наступний рівень!</strong>
            </p>
          </div>

          <div className="flex sm:flex-col gap-3 sm:items-end shrink-0">
            <div className="bg-slate-950/60 border border-slate-800/80 px-4 py-3 rounded-2xl flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center justify-center font-black text-lg">
                {THEMATIC_WORDS.length}
              </div>
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">
                  Всього в базі
                </span>
                <span className="text-xs text-slate-200 font-semibold">{THEMATIC_CATEGORIES.length} тем по 300 слів (30 блоків)</span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleToggleUnlockAll}
                className={`px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition border ${
                  unlockAllOverride
                    ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                    : 'bg-slate-800/80 text-slate-400 border-slate-700 hover:text-slate-200'
                }`}
                title="Перемкнути вільний доступ або послідовне проходження"
              >
                {unlockAllOverride ? <Unlock className="w-3.5 h-3.5 text-amber-400" /> : <Lock className="w-3.5 h-3.5" />}
                <span>{unlockAllOverride ? 'Всі блоки відкрито' : 'Послідовні рівні'}</span>
              </button>

              {onNavigateToQuiz && (
                <button
                  onClick={() => onNavigateToQuiz(selectedCategoryId || 'animals')}
                  className="px-3 py-2 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-bold text-xs flex items-center gap-1.5 hover:from-blue-500 hover:to-indigo-500 transition shadow-lg shadow-blue-600/20"
                >
                  <Zap className="w-3.5 h-3.5 text-amber-300" />
                  <span>Тренажер</span>
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Categories Bar / Chips */}
        <div className="mt-6 pt-5 border-t border-slate-800/80">
          <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-thin">
            <button
              onClick={() => handleSelectCategory(null)}
              className={`px-4 py-2 rounded-2xl text-xs font-bold transition flex items-center gap-2 whitespace-nowrap ${
                selectedCategoryId === null
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/25'
                  : 'bg-slate-900/80 text-slate-400 hover:text-white hover:bg-slate-800 border border-slate-800'
              }`}
            >
              <span>🌐</span>
              <span>Всі теми ({THEMATIC_CATEGORIES.length})</span>
            </button>

            {THEMATIC_CATEGORIES.map((cat) => {
              const count = getWordsByCategory(cat.id).length;
              const isSelected = selectedCategoryId === cat.id;
              const maxUnlocked = unlockedPacks[cat.id] || 1;

              return (
                <button
                  key={cat.id}
                  onClick={() => handleSelectCategory(cat.id, 'sprint')}
                  className={`px-3.5 py-2 rounded-2xl text-xs font-bold transition flex items-center gap-2 whitespace-nowrap ${
                    isSelected
                      ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/25'
                      : 'bg-slate-900/80 text-slate-400 hover:text-white hover:bg-slate-800 border border-slate-800'
                  }`}
                >
                  <span>{cat.icon}</span>
                  <span>{cat.title.split(' ')[0]}</span>
                  <span
                    className={`text-[10px] px-1.5 py-0.5 rounded-full ${
                      isSelected ? 'bg-blue-800 text-blue-100' : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    Блок {unlockAllOverride ? '30/30' : `${Math.min(maxUnlocked, 30)}/30`}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* ================= CATEGORY OVERVIEW CARDS (WHEN NO CATEGORY SELECTED) ================= */}
      {!selectedCategoryId && (
        <div className="space-y-6">
          {/* Ebbinghaus Forgetting Curve Alert & Reminder Banner */}
          {decayingTopics.length > 0 && (
            <div className="p-5 rounded-3xl bg-gradient-to-r from-rose-950/60 via-slate-900 to-indigo-950/60 border border-rose-500/30 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex items-center gap-3.5">
                <div className="w-12 h-12 rounded-2xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400 shrink-0">
                  <BellRing className="w-6 h-6 animate-bounce" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-black text-white">
                      Час освіжити знання! {decayingTopics.length} {decayingTopics.length === 1 ? 'тема' : 'теми'} під загрозою забування
                    </h3>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-rose-500/20 text-rose-300 border border-rose-500/30">
                      Крива Еббінгауза
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 mt-0.5">
                    {decayingTopics.map((t) => t.title).slice(0, 3).join(', ')}
                    {decayingTopics.length > 3 ? ` та ще ${decayingTopics.length - 3}` : ''}: регулярне 3-хвилинне повторення повертає пам’ять до 100%.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                {onOpenRemindersModal && (
                  <button
                    onClick={onOpenRemindersModal}
                    className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-md shadow-blue-500/20 flex items-center gap-2 transition cursor-pointer"
                  >
                    <Brain className="w-4 h-4 text-amber-300" />
                    <span>Відкрити центр повторень</span>
                  </button>
                )}
              </div>
            </div>
          )}

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-lg font-black text-white flex items-center gap-2">
                <Compass className="w-5 h-5 text-blue-400" />
                <span>Оберіть тему для занурення:</span>
              </h2>
              <p className="text-xs text-slate-400">
                Кожна тема містить 3 покрокові блоки по 6 слів: від базового до майстерності!
              </p>
            </div>
            <span className="text-xs text-slate-400 bg-slate-900 px-3 py-1.5 rounded-xl border border-slate-800">
              {THEMATIC_CATEGORIES.length} тематичних напрямків
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {THEMATIC_CATEGORIES.map((cat) => {
              const words = getWordsByCategory(cat.id);
              const learned = words.filter((w) => isWordLearned(w.eng)).length;
              const percent = words.length > 0 ? Math.round((learned / words.length) * 100) : 0;
              const maxUnlocked = unlockedPacks[cat.id] || 1;
              const retStatus = liveRetentionStatuses.find((r) => r.categoryId === cat.id);

              return (
                <div
                  key={cat.id}
                  className="group relative p-5 rounded-3xl border border-slate-800 bg-slate-900/70 hover:bg-slate-850 hover:border-slate-700 transition flex flex-col justify-between overflow-hidden shadow-lg"
                >
                  <div
                    className={`absolute inset-0 bg-gradient-to-br ${cat.color} opacity-30 group-hover:opacity-50 transition pointer-events-none`}
                  />

                  <div className="relative z-10 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="w-11 h-11 rounded-2xl bg-slate-800/80 border border-slate-700/80 flex items-center justify-center text-2xl shadow-inner">
                        {cat.icon}
                      </div>
                      <span className={`px-2.5 py-0.5 rounded-xl text-[10px] font-bold border ${cat.badgeBg}`}>
                        {cat.levelRange}
                      </span>
                    </div>

                    <div>
                      <h3 className="text-base font-black text-white group-hover:text-blue-300 transition">
                        {cat.title}
                      </h3>
                      <p className="text-xs font-semibold text-slate-400">{cat.engTitle}</p>
                    </div>

                    <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
                      {cat.description}
                    </p>
                  </div>

                  {/* Level Pack progression indicator (30 packs) */}
                  <div className="relative z-10 pt-3 mt-3 border-t border-slate-800/80 space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-400">Рівні слів (по 10 слів):</span>
                      <span className="font-black text-amber-300 text-xs">
                        {unlockAllOverride ? '30 з 30' : `${Math.min(maxUnlocked, 30)} з 30`} блоків
                      </span>
                    </div>
                    <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                      <div
                        className="bg-gradient-to-r from-amber-500 via-orange-500 to-emerald-500 h-full rounded-full transition-all duration-500"
                        style={{ width: `${(Math.min(unlockAllOverride ? 30 : maxUnlocked, 30) / 30) * 100}%` }}
                      />
                    </div>

                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-[11px]">
                        <span className="text-slate-400">Засвоєно слів:</span>
                        <span className="font-bold text-slate-200">
                          {learned} / {words.length} ({percent}%)
                        </span>
                      </div>
                      <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                        <div
                          className="bg-emerald-500 h-full rounded-full transition-all duration-500"
                          style={{ width: `${percent}%` }}
                        />
                      </div>

                      {retStatus && retStatus.lastReviewedAt > 0 && (
                        <div className="flex items-center justify-between text-[11px] pt-1.5 border-t border-slate-800/60">
                          <span className="text-slate-400 flex items-center gap-1">
                            <Brain className="w-3 h-3 text-amber-400" />
                            <span>Пам’ять:</span>
                          </span>
                          <span
                            className={`font-black ${
                              retStatus.urgency === 'critical'
                                ? 'text-rose-400'
                                : retStatus.urgency === 'high'
                                ? 'text-amber-400'
                                : 'text-emerald-400'
                            }`}
                          >
                            {retStatus.retentionPercent}% ({retStatus.statusLabel})
                          </span>
                        </div>
                      )}
                    </div>

                    <div className="flex items-center gap-2 pt-1">
                      <button
                        onClick={() => handleSelectCategory(cat.id, 'sprint')}
                        className="flex-1 py-2 px-3 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-xs flex items-center justify-center gap-1.5 transition shadow-md shadow-orange-500/20"
                      >
                        <Flame className="w-3.5 h-3.5" />
                        <span>Вчимо Блок {unlockAllOverride ? '1' : maxUnlocked}</span>
                      </button>
                      <button
                        onClick={() => handleSelectCategory(cat.id, 'cards')}
                        className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs transition"
                        title="Усі картки"
                      >
                        <BookOpen className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ================= SELECTED CATEGORY STUDY AREA ================= */}
      {selectedCategoryId && activeCategory && (
        <div className="space-y-6">
          {/* Active Category Header Bar */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <button
                onClick={() => handleSelectCategory(null)}
                className="w-10 h-10 rounded-2xl bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 flex items-center justify-center transition shrink-0"
                title="Повернутися до каталогу тем"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-2xl">{activeCategory.icon}</span>
                  <h2 className="text-xl font-black text-white">{activeCategory.title}</h2>
                  <span className={`px-2 py-0.5 rounded-lg text-xs font-bold border ${activeCategory.badgeBg}`}>
                    {activeCategory.levelRange}
                  </span>
                </div>
                <p className="text-xs text-slate-400">{activeCategory.description}</p>
              </div>
            </div>

            {/* Category Stats & Reset Option */}
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-3 bg-slate-950/60 px-4 py-2.5 rounded-2xl border border-slate-800 shrink-0">
                <div className="text-right">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                    Засвоєння теми
                  </span>
                  <span className="text-xs font-black text-emerald-400">
                    {learnedCountInCategory} з {totalCategoryWordsCount} слів ({categoryMasteryPercent}%)
                  </span>
                </div>
                <div className="w-11 h-11 rounded-full border-2 border-slate-700 flex items-center justify-center relative bg-slate-900">
                  <span className="text-xs font-black text-white">{categoryMasteryPercent}%</span>
                </div>
              </div>

              <button
                onClick={handleResetCategoryProgress}
                className="p-2.5 rounded-2xl bg-slate-800/80 text-slate-400 hover:text-amber-300 hover:bg-slate-700 transition"
                title="Скинути прогрес блоків теми до Блоку 1"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* ================= INTERACTIVE LEVEL PACK PROGRESSION BAR ================= */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-amber-400" />
                <h3 className="text-sm font-black text-white uppercase tracking-wider">
                  Послідовні рівні слів цієї теми (відкриваються по черзі)
                </h3>
              </div>
              <span className="text-xs text-slate-400">
                Складіть тест кожного блоку (≥70%), щоб відкрити наступний!
              </span>
            </div>

            {/* Stage filter navigation tabs for 30 packs */}
            <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-950/60 rounded-2xl border border-slate-800">
              <button
                onClick={() => setPackStageFilter('all')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                  packStageFilter === 'all'
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                Усі 30 блоків (1–30)
              </button>
              <button
                onClick={() => setPackStageFilter('stage1')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                  packStageFilter === 'stage1'
                    ? 'bg-emerald-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                <span>🌱 Етап 1 (Блоки 1–10 • A1/A2)</span>
              </button>
              <button
                onClick={() => setPackStageFilter('stage2')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                  packStageFilter === 'stage2'
                    ? 'bg-indigo-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                <span>🚀 Етап 2 (Блоки 11–20 • B1)</span>
              </button>
              <button
                onClick={() => setPackStageFilter('stage3')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                  packStageFilter === 'stage3'
                    ? 'bg-purple-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                <span>👑 Етап 3 (Блоки 21–30 • B2/C1)</span>
              </button>
            </div>

            {/* Pack Level Buttons Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-2.5 max-h-[380px] overflow-y-auto pr-1">
              {displayedPacks.map((packNum) => {
                const isUnlocked = isPackUnlocked(selectedCategoryId, packNum);
                const isActive = activePackNumber === packNum;
                const scoreData = packHighScores[`${selectedCategoryId}_${packNum}`];
                const hasPassed = (scoreData?.score || 0) >= 7;
                const packWordsCount = categoryWords.filter((w) => (w.pack || 1) === packNum).length;

                let tierLabel = 'A1';
                let tierBadge = 'text-emerald-400';
                if (packNum <= 5) {
                  tierLabel = 'A1 • База';
                  tierBadge = 'text-emerald-400';
                } else if (packNum <= 10) {
                  tierLabel = 'A2 • Закріплення';
                  tierBadge = 'text-teal-400';
                } else if (packNum <= 20) {
                  tierLabel = 'B1 • Розмовна';
                  tierBadge = 'text-blue-400';
                } else if (packNum <= 25) {
                  tierLabel = 'B2 • Просунутий';
                  tierBadge = 'text-indigo-400';
                } else {
                  tierLabel = 'C1 • Майстерність';
                  tierBadge = 'text-purple-400';
                }

                return (
                  <button
                    key={packNum}
                    onClick={() => handleSelectPack(packNum)}
                    className={`p-3 rounded-2xl border text-left transition relative flex flex-col justify-between gap-2.5 ${
                      isActive
                        ? 'bg-gradient-to-br from-amber-500/20 via-orange-500/10 to-slate-900 border-amber-500/70 shadow-lg shadow-orange-500/15 ring-2 ring-amber-400/40'
                        : isUnlocked
                        ? 'bg-slate-950/70 border-slate-800 hover:border-slate-700 hover:bg-slate-850'
                        : 'bg-slate-950/40 border-slate-800/60 opacity-60 hover:opacity-80'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-2">
                        <div
                          className={`w-7 h-7 rounded-lg flex items-center justify-center font-black text-xs shrink-0 ${
                            hasPassed
                              ? 'bg-emerald-500 text-slate-950'
                              : isUnlocked
                              ? 'bg-blue-600 text-white'
                              : 'bg-slate-800 text-slate-500'
                          }`}
                        >
                          {hasPassed ? '⭐' : packNum}
                        </div>
                        <div>
                          <span className="text-xs font-black text-white block">Блок {packNum}</span>
                          <span className={`text-[10px] font-semibold ${tierBadge}`}>{tierLabel}</span>
                        </div>
                      </div>

                      {/* Lock / Star status badge */}
                      <div>
                        {hasPassed ? (
                          <span className="px-1.5 py-0.5 rounded-md text-[9px] font-black bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-0.5">
                            <Check className="w-2.5 h-2.5" />
                            <span>{scoreData.score}/{scoreData.total}</span>
                          </span>
                        ) : isUnlocked ? (
                          <span className="px-1.5 py-0.5 rounded-md text-[9px] font-bold bg-blue-500/10 text-blue-300 border border-blue-500/20">
                            Відкрито
                          </span>
                        ) : (
                          <span className="px-1.5 py-0.5 rounded-md text-[9px] font-bold bg-slate-800 text-slate-400 border border-slate-700 flex items-center gap-0.5">
                            <Lock className="w-2.5 h-2.5" />
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-[10px] pt-1 border-t border-slate-800/80">
                      <span className="text-slate-400">{packWordsCount} слів</span>
                      {isActive ? (
                        <span className="text-amber-400 font-bold flex items-center gap-0.5">
                          <span>Вибрано</span>
                          <ChevronRight className="w-3 h-3" />
                        </span>
                      ) : (
                        <span className="text-slate-500">
                          {isUnlocked ? 'Обрати' : 'Заблоковано'}
                        </span>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Mode Switcher Buttons */}
          <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900/60 p-2 rounded-2xl border border-slate-800">
            <div className="flex flex-wrap items-center gap-1.5">
              {/* PRIMARY RECOMMENDED MODE: SPRINT */}
              <button
                onClick={() => {
                  setStudyMode('sprint');
                  resetSprint();
                }}
                className={`px-4 py-2.5 rounded-xl text-xs font-black transition flex items-center gap-2 ${
                  studyMode === 'sprint'
                    ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 shadow-lg shadow-orange-500/25 ring-2 ring-amber-400/50'
                    : 'bg-amber-500/10 text-amber-300 hover:bg-amber-500/20 border border-amber-500/30'
                }`}
              >
                <Flame className="w-4 h-4" />
                <span>🎯 Блок {activePackNumber}: Вчимо ➔ Тест</span>
              </button>

              <button
                onClick={() => setStudyMode('cards')}
                className={`px-3 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                  studyMode === 'cards'
                    ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                <BookOpen className="w-3.5 h-3.5" />
                <span>Всі картки ({filteredWords.length})</span>
              </button>

              <button
                onClick={() => {
                  setStudyMode('flashcards');
                  setIsFlipped(false);
                }}
                className={`px-3 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                  studyMode === 'flashcards'
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                <span>3D Флеш-картки</span>
              </button>

              <button
                onClick={() => {
                  setStudyMode('quiz');
                  resetQuiz();
                }}
                className={`px-3 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                  studyMode === 'quiz'
                    ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                <Zap className="w-3.5 h-3.5 text-amber-300" />
                <span>Бліц-тест</span>
              </button>

              <button
                onClick={() => {
                  setStudyMode('spelling');
                  initSpelling(selectedCategoryId);
                }}
                className={`px-3 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                  studyMode === 'spelling'
                    ? 'bg-amber-600 text-white shadow-md shadow-amber-600/30'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Спелінг</span>
              </button>

              <button
                onClick={() => {
                  setStudyMode('cloze');
                  resetCloze();
                }}
                className={`px-3 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                  studyMode === 'cloze'
                    ? 'bg-violet-600 text-white shadow-md shadow-violet-600/30'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                <HelpCircle className="w-3.5 h-3.5" />
                <span>У контексті</span>
              </button>
            </div>

            {/* Quick search input */}
            <div className="relative min-w-[180px] flex-1 sm:flex-initial">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Пошук у темі..."
                className="w-full pl-8 pr-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          {/* ================= MODE 0: SPRINT FOR ACTIVE PACK ================= */}
          {studyMode === 'sprint' && (
            <div className="space-y-6">
              {/* Sprint 3-Step Flow Pipeline */}
              <div className="grid grid-cols-3 gap-2 sm:gap-4 bg-slate-900/80 p-3 rounded-2xl border border-slate-800">
                <div
                  className={`p-3 rounded-xl flex items-center gap-3 transition ${
                    sprintPhase === 'learn'
                      ? 'bg-blue-600/20 border border-blue-500/40 text-blue-300'
                      : sprintLearnedIds.size >= sprintWords.length
                      ? 'bg-emerald-950/20 border border-emerald-500/30 text-emerald-300'
                      : 'text-slate-500'
                  }`}
                >
                  <div
                    className={`w-7 h-7 rounded-lg flex items-center justify-center font-black text-xs shrink-0 ${
                      sprintPhase === 'learn'
                        ? 'bg-blue-600 text-white'
                        : sprintLearnedIds.size >= sprintWords.length
                        ? 'bg-emerald-500 text-slate-950'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    1
                  </div>
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider block">Етап 1</span>
                    <span className="text-xs font-black hidden sm:inline">Вчимо Блок {activePackNumber} ({sprintLearnedIds.size}/{sprintWords.length})</span>
                    <span className="text-xs font-black sm:hidden">Вчимо</span>
                  </div>
                </div>

                <div
                  className={`p-3 rounded-xl flex items-center gap-3 transition ${
                    sprintPhase === 'test'
                      ? 'bg-amber-600/20 border border-amber-500/40 text-amber-300'
                      : sprintPhase === 'results'
                      ? 'bg-emerald-950/20 border border-emerald-500/30 text-emerald-300'
                      : 'text-slate-500'
                  }`}
                >
                  <div
                    className={`w-7 h-7 rounded-lg flex items-center justify-center font-black text-xs shrink-0 ${
                      sprintPhase === 'test'
                        ? 'bg-amber-500 text-slate-950'
                        : sprintPhase === 'results'
                        ? 'bg-emerald-500 text-slate-950'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    2
                  </div>
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider block">Етап 2</span>
                    <span className="text-xs font-black hidden sm:inline">Контрольний тест</span>
                    <span className="text-xs font-black sm:hidden">Тест</span>
                  </div>
                </div>

                <div
                  className={`p-3 rounded-xl flex items-center gap-3 transition ${
                    sprintPhase === 'results'
                      ? 'bg-emerald-600/20 border border-emerald-500/40 text-emerald-300'
                      : 'text-slate-500'
                  }`}
                >
                  <div
                    className={`w-7 h-7 rounded-lg flex items-center justify-center font-black text-xs shrink-0 ${
                      sprintPhase === 'results'
                        ? 'bg-emerald-500 text-slate-950'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    3
                  </div>
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider block">Етап 3</span>
                    <span className="text-xs font-black hidden sm:inline">Розблокування</span>
                    <span className="text-xs font-black sm:hidden">Фініш</span>
                  </div>
                </div>
              </div>

              {/* ---------- SUB-PHASE 1: STUDY PHASE ---------- */}
              {sprintPhase === 'learn' && currentSprintLearnWord && (
                <div className="space-y-6 max-w-3xl mx-auto">
                  {/* Step progress info */}
                  <div className="flex items-center justify-between text-xs text-slate-400 px-1">
                    <span className="font-bold text-slate-200">
                      Слово {sprintLearnIndex + 1} з {sprintWords.length} (Блок {activePackNumber})
                    </span>
                    <div className="flex items-center gap-1.5">
                      {sprintWords.map((w, idx) => (
                        <button
                          key={w.id}
                          onClick={() => {
                            setSprintLearnIndex(idx);
                            setIsHideTranslation(false);
                          }}
                          className={`w-2.5 h-2.5 rounded-full transition-all ${
                            idx === sprintLearnIndex
                              ? 'bg-amber-400 scale-125'
                              : sprintLearnedIds.has(w.id)
                              ? 'bg-emerald-500'
                              : 'bg-slate-700 hover:bg-slate-500'
                          }`}
                          title={w.eng}
                        />
                      ))}
                    </div>
                  </div>

                  {/* Main Interactive Word Study Card */}
                  <div className="bg-gradient-to-b from-slate-900 to-slate-950 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden space-y-6">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex items-center gap-4">
                        <span className="text-4xl sm:text-5xl p-3 rounded-2xl bg-slate-800/80 border border-slate-700 shadow-inner">
                          {currentSprintLearnWord.emoji}
                        </span>
                        <div>
                          <div className="flex items-center gap-3">
                            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                              {currentSprintLearnWord.eng}
                            </h2>
                            <span className="px-2.5 py-0.5 rounded-lg text-xs font-bold bg-blue-500/10 text-blue-400 border border-blue-500/20">
                              {currentSprintLearnWord.level}
                            </span>
                          </div>
                          <p className="text-sm font-mono text-slate-400 mt-0.5">
                            {currentSprintLearnWord.ipa}
                          </p>
                        </div>
                      </div>

                      {/* Audio buttons */}
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleSpeak(currentSprintLearnWord.eng, 0.9)}
                          className="p-3 rounded-2xl bg-blue-600 text-white hover:bg-blue-500 transition shadow-lg shadow-blue-600/30 flex items-center gap-1.5"
                          title="Слухати вимову"
                        >
                          <Volume2 className="w-5 h-5" />
                          <span className="text-xs font-bold hidden sm:inline">Вимова</span>
                        </button>
                        <button
                          onClick={() => handleSpeak(currentSprintLearnWord.eng, 0.65)}
                          className="px-2.5 py-3 rounded-2xl bg-slate-800 text-slate-300 hover:text-amber-300 hover:bg-slate-700 transition text-xs font-bold"
                          title="Повільно (0.6x)"
                        >
                          0.6x
                        </button>
                      </div>
                    </div>

                    {/* Ukrainian Translation Block with Self-Check Toggle */}
                    <div className="bg-slate-950/70 border border-slate-800/80 rounded-2xl p-5 flex items-center justify-between gap-4">
                      <div>
                        <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                          Український переклад:
                        </span>
                        {isHideTranslation ? (
                          <div className="inline-flex items-center gap-2 text-slate-500 italic text-sm">
                            <span>(Переклад приховано для самоперевірки)</span>
                          </div>
                        ) : (
                          <div className="text-xl sm:text-2xl font-black text-emerald-400 tracking-tight">
                            {currentSprintLearnWord.ukr}
                          </div>
                        )}
                      </div>

                      <button
                        onClick={() => setIsHideTranslation(!isHideTranslation)}
                        className="px-3 py-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition text-xs font-bold flex items-center gap-1.5 shrink-0"
                      >
                        {isHideTranslation ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                        <span>{isHideTranslation ? 'Показати' : 'Приховати'}</span>
                      </button>
                    </div>

                    {/* Mnemonic Hook Banner */}
                    <div className="bg-gradient-to-r from-amber-500/15 via-orange-500/10 to-transparent border border-amber-500/30 rounded-2xl p-4.5 sm:p-5 flex items-start gap-3.5">
                      <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-300 flex items-center justify-center shrink-0 border border-amber-500/30">
                        <Lightbulb className="w-5 h-5" />
                      </div>
                      <div className="space-y-1">
                        <span className="text-xs font-black uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
                          <span>Секрет швидкого запамʼятовування (Мнемоніка)</span>
                        </span>
                        <p className="text-sm text-slate-200 leading-relaxed font-medium">
                          {currentSprintLearnWord.mnemonicHook}
                        </p>
                      </div>
                    </div>

                    {/* Example in Real Life Sentence */}
                    <div className="bg-slate-950/60 border border-slate-800/80 rounded-2xl p-5 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                          <BookOpen className="w-3.5 h-3.5 text-blue-400" />
                          <span>Приклад у живому контексті:</span>
                        </span>
                        <button
                          onClick={() => handleSpeak(currentSprintLearnWord.exampleEn, 0.85)}
                          className="text-xs text-blue-400 hover:text-blue-300 flex items-center gap-1 font-bold"
                        >
                          <Volume2 className="w-3.5 h-3.5" />
                          <span>Озвучити речення</span>
                        </button>
                      </div>
                      <p className="text-sm sm:text-base text-slate-100 font-semibold leading-relaxed">
                        “{currentSprintLearnWord.exampleEn}”
                      </p>
                      <p className="text-xs sm:text-sm text-slate-400 italic">
                        «{currentSprintLearnWord.exampleUa}»
                      </p>
                    </div>

                    {/* Collocations */}
                    {currentSprintLearnWord.collocations && currentSprintLearnWord.collocations.length > 0 && (
                      <div className="space-y-2">
                        <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">
                          Часті словосполучення:
                        </span>
                        <div className="flex flex-wrap gap-2">
                          {currentSprintLearnWord.collocations.map((col, idx) => (
                            <button
                              key={idx}
                              onClick={() => handleSpeak(col)}
                              className="px-3 py-1.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 border border-slate-700/80 text-xs font-medium text-slate-200 hover:text-white transition flex items-center gap-1.5"
                            >
                              <Volume2 className="w-3 h-3 text-slate-400" />
                              <span>{col}</span>
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Learn Step Controls */}
                    <div className="pt-4 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-4">
                      <button
                        onClick={() => {
                          if (sprintLearnIndex > 0) {
                            setSprintLearnIndex((prev) => prev - 1);
                            setIsHideTranslation(false);
                          }
                        }}
                        disabled={sprintLearnIndex === 0}
                        className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-300 font-bold text-xs flex items-center justify-center gap-2 transition"
                      >
                        <ArrowLeft className="w-4 h-4" />
                        <span>Попереднє слово</span>
                      </button>

                      <div className="flex items-center gap-2 w-full sm:w-auto">
                        <button
                          onClick={() => handleToggleWord(currentSprintLearnWord)}
                          className={`p-2.5 rounded-xl border transition ${
                            isWordLearned(currentSprintLearnWord.eng)
                              ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                              : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-white'
                          }`}
                          title="Зберегти в Скарбничку"
                        >
                          {isWordLearned(currentSprintLearnWord.eng) ? (
                            <BookmarkCheck className="w-4 h-4 text-emerald-400" />
                          ) : (
                            <BookmarkPlus className="w-4 h-4" />
                          )}
                        </button>

                        <button
                          onClick={() => handleMarkSprintWordLearned(currentSprintLearnWord)}
                          className="flex-1 sm:flex-initial px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-xs flex items-center justify-center gap-2 transition shadow-lg shadow-emerald-600/25"
                        >
                          <Check className="w-4 h-4" />
                          <span>Я запам'ятав це слово (+10 XP)</span>
                        </button>

                        {sprintLearnIndex + 1 < sprintWords.length ? (
                          <button
                            onClick={() => {
                              setSprintLearnIndex((prev) => prev + 1);
                              setIsHideTranslation(false);
                            }}
                            className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs flex items-center justify-center gap-2 transition"
                          >
                            <span>Далі</span>
                            <ArrowRight className="w-4 h-4" />
                          </button>
                        ) : null}
                      </div>
                    </div>
                  </div>

                  {/* Ready to Test Prompt Banner */}
                  <div className="bg-gradient-to-r from-blue-900/40 via-indigo-900/40 to-slate-900 border border-blue-500/30 rounded-3xl p-6 sm:p-7 flex flex-col sm:flex-row items-center justify-between gap-5 shadow-xl">
                    <div className="space-y-1 text-center sm:text-left">
                      <div className="inline-flex items-center gap-1.5 text-xs font-black text-amber-400 uppercase tracking-wide">
                        <Flame className="w-4 h-4" />
                        <span>Контрольний тест Блоку {activePackNumber}</span>
                      </div>
                      <h3 className="text-lg font-black text-white">
                        Готові перевірити ці {sprintWords.length} слів та розблокувати далі?
                      </h3>
                      <p className="text-xs text-slate-300">
                        Наберіть від 70% у тесті, щоб підтвердити засвоєння і відкрити наступний блок слів!
                      </p>
                    </div>

                    <button
                      onClick={handleStartSprintTest}
                      className="w-full sm:w-auto px-6 py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-sm flex items-center justify-center gap-2 transition shadow-xl shadow-orange-500/25 shrink-0 transform hover:scale-[1.02] active:scale-[0.98]"
                    >
                      <Zap className="w-4 h-4" />
                      <span>Розпочати контрольний тест ({sprintWords.length} питань) ➔</span>
                    </button>
                  </div>
                </div>
              )}

              {/* ---------- SUB-PHASE 2: SPRINT TEST PHASE ---------- */}
              {sprintPhase === 'test' && sprintQuestions.length > 0 && (
                <div className="max-w-2xl mx-auto space-y-6">
                  {/* Test progress indicator */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs text-slate-400">
                      <span className="font-bold text-slate-200">
                        Блок {activePackNumber} • Питання {sprintTestIndex + 1} з {sprintQuestions.length}
                      </span>
                      <span className="font-black text-emerald-400">
                        Правильно: {sprintScore} з {sprintTestIndex + (sprintIsChecked ? 1 : 0)}
                      </span>
                    </div>
                    <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                      <div
                        className="bg-gradient-to-r from-amber-500 to-orange-500 h-full rounded-full transition-all duration-300"
                        style={{
                          width: `${((sprintTestIndex + 1) / sprintQuestions.length) * 100}%`,
                        }}
                      />
                    </div>
                  </div>

                  {/* Question Card */}
                  {sprintQuestions[sprintTestIndex] && (() => {
                    const currentQ = sprintQuestions[sprintTestIndex];
                    return (
                      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl relative">
                        {/* Question Badge & Type */}
                        <div className="flex items-center justify-between">
                          <span className="px-3 py-1 rounded-xl text-xs font-black bg-blue-500/10 text-blue-400 border border-blue-500/20 flex items-center gap-1.5">
                            {currentQ.type === 'audio_listen' && <Headphones className="w-3.5 h-3.5 text-amber-400" />}
                            {currentQ.type === 'context_cloze' && <HelpCircle className="w-3.5 h-3.5 text-violet-400" />}
                            {currentQ.type === 'uk_to_en' && <Target className="w-3.5 h-3.5 text-emerald-400" />}
                            {currentQ.type === 'en_to_uk' && <Zap className="w-3.5 h-3.5 text-sky-400" />}
                            <span>
                              {currentQ.type === 'audio_listen' && 'Аудіо-тест на слух'}
                              {currentQ.type === 'context_cloze' && 'Речення з пропуском'}
                              {currentQ.type === 'uk_to_en' && 'Переклад на англійську'}
                              {currentQ.type === 'en_to_uk' && 'Переклад на українську'}
                            </span>
                          </span>

                          <span className="text-2xl">{currentQ.word.emoji}</span>
                        </div>

                        {/* Prompt */}
                        <div className="space-y-2 text-center sm:text-left">
                          <p className="text-sm text-slate-400 font-medium">{currentQ.questionPrompt}</p>

                          {/* Large Display depending on type */}
                          {currentQ.type === 'uk_to_en' && (
                            <div className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                              «{currentQ.word.ukr}»
                            </div>
                          )}

                          {currentQ.type === 'en_to_uk' && (
                            <div className="text-2xl sm:text-3xl font-black text-white tracking-tight flex items-center gap-3">
                              <span>«{currentQ.word.eng}»</span>
                              <button
                                onClick={() => handleSpeak(currentQ.word.eng)}
                                className="p-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white"
                                title="Слухати"
                              >
                                <Volume2 className="w-4 h-4" />
                              </button>
                            </div>
                          )}

                          {currentQ.type === 'audio_listen' && (
                            <div className="py-4 flex flex-col items-center justify-center gap-2">
                              <button
                                onClick={() => handleSpeak(currentQ.word.eng)}
                                className="px-6 py-4 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-black text-sm flex items-center gap-2 shadow-lg shadow-blue-600/30 transition transform hover:scale-105"
                              >
                                <Volume2 className="w-6 h-6 animate-pulse" />
                                <span>Прослухати вимову ще раз</span>
                              </button>
                              <span className="text-xs text-slate-500">Натисніть для повтору вимови</span>
                            </div>
                          )}

                          {currentQ.type === 'context_cloze' && currentQ.contextSentence && (
                            <div className="space-y-2">
                              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 text-base sm:text-lg text-slate-100 font-semibold leading-relaxed">
                                “{currentQ.contextSentence}”
                              </div>
                              <div className="text-xs text-slate-400">
                                💡 Значення слова: <span className="text-amber-300 font-bold">«{currentQ.word.ukr}»</span>
                              </div>
                            </div>
                          )}
                        </div>

                        {/* Options Buttons */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                          {currentQ.options.map((opt, idx) => {
                            const isSelected = sprintSelectedOption === opt;
                            const isCorrectOpt = opt.toLowerCase().trim() === currentQ.correctAnswer.toLowerCase().trim();

                            let btnStyle =
                              'bg-slate-800/80 hover:bg-slate-800 border-slate-700/80 text-slate-200 hover:border-slate-600';

                            if (sprintIsChecked) {
                              if (isCorrectOpt) {
                                btnStyle =
                                  'bg-emerald-600/20 border-emerald-500 text-emerald-300 font-black shadow-lg shadow-emerald-500/20 ring-1 ring-emerald-500';
                              } else if (isSelected) {
                                btnStyle =
                                  'bg-rose-600/20 border-rose-500 text-rose-300 font-bold shadow-lg shadow-rose-500/20';
                              } else {
                                btnStyle = 'opacity-40 border-slate-800 text-slate-500';
                              }
                            }

                            return (
                              <button
                                key={idx}
                                disabled={sprintIsChecked}
                                onClick={() => handleSprintSelectAnswer(opt)}
                                className={`p-4 rounded-2xl border text-sm sm:text-base font-semibold text-left transition flex items-center justify-between gap-3 ${btnStyle}`}
                              >
                                <span>{opt}</span>
                                {sprintIsChecked && isCorrectOpt && (
                                  <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                                )}
                                {sprintIsChecked && isSelected && !isCorrectOpt && (
                                  <X className="w-5 h-5 text-rose-400 shrink-0" />
                                )}
                              </button>
                            );
                          })}
                        </div>

                        {/* Checked explanation banner if answered incorrectly */}
                        {sprintIsChecked && (
                          <div className="space-y-4 pt-2">
                            {sprintSelectedOption?.toLowerCase().trim() !== currentQ.correctAnswer.toLowerCase().trim() ? (
                              <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-xs sm:text-sm text-slate-200 space-y-1">
                                <span className="font-black text-rose-400 block">
                                  Правильна відповідь: «{currentQ.correctAnswer}»
                                </span>
                                <p className="text-slate-300">{currentQ.word.mnemonicHook}</p>
                              </div>
                            ) : (
                              <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-xs sm:text-sm text-emerald-300 font-bold flex items-center gap-2">
                                <Check className="w-4 h-4 text-emerald-400" />
                                <span>Відмінно! Слово міцно закріплено в пам'яті.</span>
                              </div>
                            )}

                            {/* Continue button */}
                            <div className="flex justify-end">
                              <button
                                onClick={handleSprintNextQuestion}
                                className="px-6 py-3 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-black text-xs sm:text-sm flex items-center gap-2 transition shadow-lg shadow-blue-600/30"
                              >
                                <span>
                                  {sprintTestIndex + 1 < sprintQuestions.length
                                    ? 'Наступне питання'
                                    : 'Побачити результат тесту'}
                                </span>
                                <ArrowRight className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })()}
                </div>
              )}

              {/* ---------- SUB-PHASE 3: SPRINT RESULTS & UNLOCKING SCREEN ---------- */}
              {sprintPhase === 'results' && (
                <div className="max-w-2xl mx-auto space-y-6">
                  <div className="bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 border border-slate-800 rounded-3xl p-6 sm:p-8 text-center space-y-5 shadow-2xl relative overflow-hidden">
                    <div className="w-16 h-16 rounded-2xl bg-amber-500/10 text-amber-400 border border-amber-500/20 flex items-center justify-center mx-auto text-3xl shadow-lg">
                      <Trophy className="w-8 h-8 text-amber-400" />
                    </div>

                    <div className="space-y-1">
                      <h2 className="text-2xl sm:text-3xl font-black text-white">
                        {sprintScore === sprintQuestions.length
                          ? '🏆 Ідеально! 100% результат!'
                          : sprintScore >= Math.ceil(sprintQuestions.length * 0.7)
                          ? '🎉 Рівень успішно складено!'
                          : '💪 Потрібно ще трохи практики'}
                      </h2>
                      <p className="text-sm text-slate-300">
                        Правильних відповідей: <strong className="text-amber-400 font-black">{sprintScore}</strong> з{' '}
                        <strong>{sprintQuestions.length}</strong> (
                        {Math.round((sprintScore / (sprintQuestions.length || 1)) * 100)}%).
                      </p>
                    </div>

                    {/* Sequential Unlock Celebration Banner */}
                    {justUnlockedPack && (
                      <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-500/20 via-teal-500/20 to-blue-500/20 border border-emerald-500/40 text-emerald-200 text-sm font-bold flex items-center justify-between gap-3 shadow-lg">
                        <div className="flex items-center gap-2.5">
                          <span className="text-2xl">🔓</span>
                          <div className="text-left">
                            <span className="block font-black text-white">
                              Розблоковано Блок {justUnlockedPack}!
                            </span>
                            <span className="text-xs text-emerald-300">
                              Нові 6 слів цієї теми тепер доступні для вивчення (+50 XP)!
                            </span>
                          </div>
                        </div>

                        <button
                          onClick={() => handleSelectPack(justUnlockedPack)}
                          className="px-4 py-2 rounded-xl bg-emerald-500 text-slate-950 font-black text-xs hover:bg-emerald-400 transition shrink-0"
                        >
                          Перейти до Блоку {justUnlockedPack} ➔
                        </button>
                      </div>
                    )}

                    {/* Score summary chips */}
                    <div className="grid grid-cols-2 gap-3 py-2">
                      <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-3">
                        <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">
                          Поточний Блок
                        </span>
                        <span className="text-xl font-black text-blue-400">Блок {activePackNumber} з {categoryPacks.length}</span>
                      </div>
                      <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-3">
                        <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">
                          Статус тесту
                        </span>
                        <span
                          className={`text-xl font-black ${
                            sprintScore >= Math.ceil(sprintQuestions.length * 0.7)
                              ? 'text-emerald-400'
                              : 'text-rose-400'
                          }`}
                        >
                          {sprintScore >= Math.ceil(sprintQuestions.length * 0.7) ? 'Складено ⭐' : 'Спробуйте знову'}
                        </span>
                      </div>
                    </div>

                    {/* Word by word breakdown list */}
                    <div className="text-left space-y-2 pt-2">
                      <span className="text-xs font-black uppercase tracking-wider text-slate-400 block">
                        Результати за словами:
                      </span>
                      <div className="space-y-1.5 max-h-60 overflow-y-auto pr-1">
                        {sprintTestResults.map((res, idx) => (
                          <div
                            key={idx}
                            className={`p-3 rounded-xl border flex items-center justify-between text-xs font-semibold ${
                              res.isCorrect
                                ? 'bg-emerald-950/15 border-emerald-500/25 text-slate-200'
                                : 'bg-rose-950/15 border-rose-500/25 text-slate-300'
                            }`}
                          >
                            <div className="flex items-center gap-2.5">
                              <span>{res.word.emoji}</span>
                              <div>
                                <span className="font-bold text-white">{res.word.eng}</span>
                                <span className="text-slate-400 ml-1.5">({res.word.ukr})</span>
                              </div>
                            </div>

                            <div className="flex items-center gap-2">
                              <button
                                onClick={() => handleSpeak(res.word.eng)}
                                className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white"
                                title="Слухати"
                              >
                                <Volume2 className="w-3.5 h-3.5" />
                              </button>
                              {res.isCorrect ? (
                                <span className="text-emerald-400 font-bold flex items-center gap-1">
                                  <Check className="w-3.5 h-3.5" /> Засвоєно
                                </span>
                              ) : (
                                <span className="text-rose-400 font-bold flex items-center gap-1">
                                  <X className="w-3.5 h-3.5" /> Помилка
                                </span>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Action buttons */}
                    <div className="pt-4 border-t border-slate-800/80 flex flex-wrap items-center justify-center gap-3">
                      <button
                        onClick={handleStartSprintTest}
                        className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs flex items-center gap-1.5 transition"
                      >
                        <RotateCcw className="w-4 h-4" />
                        <span>Пройти тест ще раз</span>
                      </button>

                      <button
                        onClick={() => resetSprint()}
                        className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs flex items-center gap-1.5 transition"
                      >
                        <BookOpen className="w-4 h-4" />
                        <span>Повторити картки слів</span>
                      </button>

                      <button
                        onClick={handleSaveAllSprintWords}
                        className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 transition shadow-md shadow-emerald-600/20"
                      >
                        <BookmarkCheck className="w-4 h-4" />
                        <span>Зберегти ці слова до Скарбнички</span>
                      </button>

                      {/* If next pack exists and unlocked */}
                      {activePackNumber < categoryPacks.length && isPackUnlocked(selectedCategoryId, activePackNumber + 1) && (
                        <button
                          onClick={() => handleSelectPack(activePackNumber + 1)}
                          className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 font-black text-xs flex items-center gap-1.5 transition shadow-lg shadow-orange-500/20"
                        >
                          <span>Наступний Блок {activePackNumber + 1} з {categoryPacks.length}</span>
                          <ArrowRight className="w-4 h-4" />
                        </button>
                      )}

                      {/* If finished all packs of this category */}
                      {activePackNumber === categoryPacks.length && (
                        <button
                          onClick={handleGoToNextCategory}
                          className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-black text-xs flex items-center gap-1.5 transition shadow-lg shadow-blue-600/20"
                        >
                          <span>Всі 30 блоків пройдено! Наступна тема</span>
                          <ArrowRight className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ================= MODE 1: WORD CARDS & MNEMONICS ================= */}
          {studyMode === 'cards' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredWords.map((word) => {
                  const learned = isWordLearned(word.eng);
                  return (
                    <div
                      key={word.id}
                      className={`p-6 rounded-3xl border transition flex flex-col justify-between space-y-4 shadow-lg ${
                        learned
                          ? 'bg-emerald-950/15 border-emerald-500/30'
                          : 'bg-slate-900/90 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      {/* Top Bar */}
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-center gap-3">
                          <span className="text-3xl p-2 rounded-2xl bg-slate-800/80 border border-slate-700/60 shadow-inner">
                            {word.emoji}
                          </span>
                          <div>
                            <div className="flex items-center gap-2">
                              <h3 className="text-xl font-black text-white tracking-tight">{word.eng}</h3>
                              <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-blue-500/10 text-blue-400 border border-blue-500/20">
                                {word.level}
                              </span>
                              {word.pack && (
                                <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-amber-500/10 text-amber-300 border border-amber-500/20">
                                  Блок {word.pack}
                                </span>
                              )}
                            </div>
                            <span className="text-xs text-slate-400 font-mono">{word.ipa}</span>
                          </div>
                        </div>

                        {/* Pronunciation & Learned Toggle */}
                        <div className="flex items-center gap-1.5">
                          <button
                            onClick={() => handleSpeak(word.eng, 0.9)}
                            className="p-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white hover:bg-blue-600 transition"
                            title="Слухати вимову (1.0x)"
                          >
                            <Volume2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleSpeak(word.eng, 0.65)}
                            className="px-2 py-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-amber-300 hover:bg-slate-700 transition text-[10px] font-bold"
                            title="Повільна вимова (0.65x)"
                          >
                            0.6x
                          </button>
                          <button
                            onClick={() => handleToggleWord(word)}
                            className={`p-2 rounded-xl border transition ${
                              learned
                                ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                                : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-white'
                            }`}
                            title={learned ? 'Засвоєно (видалити зі Скарбнички)' : 'Зберегти у Скарбничку'}
                          >
                            {learned ? (
                              <BookmarkCheck className="w-4 h-4 text-emerald-400" />
                            ) : (
                              <BookmarkPlus className="w-4 h-4" />
                            )}
                          </button>
                        </div>
                      </div>

                      {/* Translation */}
                      <div>
                        <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-0.5">
                          Переклад:
                        </span>
                        <span className="text-lg font-black text-emerald-400">{word.ukr}</span>
                      </div>

                      {/* Mnemonic Hook Banner */}
                      <div className="bg-amber-500/10 border border-amber-500/20 rounded-2xl p-3.5 flex items-start gap-2.5">
                        <Lightbulb className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                        <div>
                          <span className="text-[11px] font-black uppercase tracking-wider text-amber-300 block mb-0.5">
                            Мнемонічна асоціація:
                          </span>
                          <p className="text-xs text-slate-200 leading-relaxed font-medium">
                            {word.mnemonicHook}
                          </p>
                        </div>
                      </div>

                      {/* Example sentence */}
                      <div className="bg-slate-950/60 rounded-2xl p-3.5 border border-slate-800/80 space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                            У реченні:
                          </span>
                          <button
                            onClick={() => handleSpeak(word.exampleEn, 0.85)}
                            className="text-[11px] text-blue-400 hover:text-blue-300 flex items-center gap-1 font-bold"
                          >
                            <Volume2 className="w-3 h-3" />
                            <span>Озвучити</span>
                          </button>
                        </div>
                        <p className="text-xs text-slate-200 font-semibold leading-relaxed">
                          "{word.exampleEn}"
                        </p>
                        <p className="text-xs text-slate-400 italic">«{word.exampleUa}»</p>
                      </div>

                      {/* Collocations */}
                      {word.collocations && word.collocations.length > 0 && (
                        <div className="space-y-1.5 pt-1">
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                            Колокації:
                          </span>
                          <div className="flex flex-wrap gap-1.5">
                            {word.collocations.map((col, idx) => (
                              <button
                                key={idx}
                                onClick={() => handleSpeak(col)}
                                className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-[11px] text-slate-300 hover:text-white transition font-medium"
                              >
                                {col}
                              </button>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* ================= MODE 2: 3D FLASHCARDS ================= */}
          {studyMode === 'flashcards' && filteredWords.length > 0 && (
            <div className="max-w-xl mx-auto space-y-6">
              <div className="flex items-center justify-between text-xs text-slate-400 px-1">
                <span>Картка {flashcardIndex + 1} з {filteredWords.length}</span>
                <span className="font-bold text-slate-200">Клікніть для перевороту</span>
              </div>

              {(() => {
                const card = filteredWords[flashcardIndex];
                if (!card) return null;
                const learned = isWordLearned(card.eng);

                return (
                  <div
                    onClick={() => {
                      playSound('click');
                      setIsFlipped(!isFlipped);
                      if (!isFlipped) handleSpeak(card.eng);
                    }}
                    className="relative h-96 w-full cursor-pointer perspective-1000 select-none"
                  >
                    <div
                      className={`relative w-full h-full duration-500 transform-style-3d transition-transform ${
                        isFlipped ? 'rotate-y-180' : ''
                      }`}
                    >
                      {/* FRONT FACE (English) */}
                      <div className="absolute inset-0 backface-hidden bg-gradient-to-br from-slate-900 via-slate-850 to-slate-900 border-2 border-slate-700/80 rounded-3xl p-8 flex flex-col justify-between items-center text-center shadow-2xl">
                        <div className="w-full flex items-center justify-between text-xs">
                          <span className="px-2.5 py-1 rounded-xl bg-blue-500/10 text-blue-400 border border-blue-500/20 font-bold">
                            {card.level}
                          </span>
                          <span className="text-slate-400">Натисніть для перекладу 🔄</span>
                        </div>

                        <div className="space-y-4 my-auto">
                          <span className="text-6xl filter drop-shadow-md">{card.emoji}</span>
                          <h3 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
                            {card.eng}
                          </h3>
                          <p className="text-sm font-mono text-slate-400">{card.ipa}</p>
                        </div>

                        <div className="w-full flex items-center justify-between pt-4 border-t border-slate-800">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleSpeak(card.eng);
                            }}
                            className="p-3 rounded-2xl bg-blue-600/20 text-blue-300 border border-blue-500/30 hover:bg-blue-600 hover:text-white transition flex items-center gap-2 text-xs font-bold"
                          >
                            <Volume2 className="w-4 h-4" />
                            <span>Вимова</span>
                          </button>
                          <span className="text-xs text-slate-500">English ➔ Українська</span>
                        </div>
                      </div>

                      {/* BACK FACE (Ukrainian & Mnemonic) */}
                      <div className="absolute inset-0 backface-hidden rotate-y-180 bg-gradient-to-br from-indigo-950 via-slate-900 to-slate-900 border-2 border-indigo-500/50 rounded-3xl p-8 flex flex-col justify-between items-center text-center shadow-2xl">
                        <div className="w-full flex items-center justify-between text-xs">
                          <span className="text-indigo-400 font-bold">Зворотна сторона</span>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleToggleWord(card);
                            }}
                            className={`p-2 rounded-xl border transition ${
                              learned
                                ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                                : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-white'
                            }`}
                          >
                            {learned ? <BookmarkCheck className="w-4 h-4" /> : <BookmarkPlus className="w-4 h-4" />}
                          </button>
                        </div>

                        <div className="space-y-4 my-auto">
                          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                            Значення:
                          </span>
                          <h4 className="text-3xl font-black text-emerald-400">{card.ukr}</h4>

                          <div className="bg-amber-500/10 border border-amber-500/20 rounded-2xl p-4 max-w-sm mx-auto text-left">
                            <span className="text-[10px] font-black uppercase tracking-wider text-amber-300 block mb-1">
                              💡 Мнемоніка:
                            </span>
                            <p className="text-xs text-slate-200 leading-relaxed font-medium">
                              {card.mnemonicHook}
                            </p>
                          </div>
                        </div>

                        <div className="w-full text-xs text-slate-400 pt-3 border-t border-slate-800 italic">
                          "{card.exampleEn}"
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })()}

              {/* Navigation buttons */}
              <div className="flex items-center justify-between gap-4">
                <button
                  onClick={() => {
                    playSound('click');
                    setIsFlipped(false);
                    setFlashcardIndex((prev) => (prev - 1 + filteredWords.length) % filteredWords.length);
                  }}
                  className="px-5 py-3 rounded-2xl bg-slate-900 border border-slate-800 text-slate-200 hover:bg-slate-800 font-bold text-xs flex items-center gap-2 transition"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Попередня</span>
                </button>

                <button
                  onClick={() => {
                    playSound('click');
                    setIsFlipped(false);
                    setFlashcardIndex((prev) => (prev + 1) % filteredWords.length);
                  }}
                  className="px-6 py-3 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center gap-2 transition shadow-lg shadow-blue-600/30"
                >
                  <span>Наступна</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* ================= MODE 3: BLITZ QUIZ ================= */}
          {studyMode === 'quiz' && (
            <div className="max-w-xl mx-auto space-y-6">
              {!isQuizCompleted && currentQuizWord && (
                <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl">
                  <div className="flex items-center justify-between text-xs text-slate-400">
                    <span>Питання {quizIndex + 1} з {Math.min(filteredWords.length, 10)}</span>
                    <span className="font-black text-emerald-400">Рахунок: {quizScore}</span>
                  </div>

                  <div className="text-center space-y-2 py-4">
                    <span className="text-5xl block">{currentQuizWord.emoji}</span>
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                      Як перекладається українською?
                    </span>
                    <h3 className="text-3xl font-black text-white">{currentQuizWord.eng}</h3>
                    <p className="text-xs font-mono text-slate-400">{currentQuizWord.ipa}</p>
                  </div>

                  <div className="grid grid-cols-1 gap-2.5">
                    {quizOptions.map((opt) => {
                      const isSelected = selectedOption === opt.eng;
                      const isCorrect = opt.eng === currentQuizWord.eng;

                      let btnStyle =
                        'bg-slate-800/80 hover:bg-slate-800 border-slate-700 text-slate-200 hover:border-slate-600';

                      if (isAnswerChecked) {
                        if (isCorrect) {
                          btnStyle = 'bg-emerald-600/20 border-emerald-500 text-emerald-300 font-bold';
                        } else if (isSelected) {
                          btnStyle = 'bg-rose-600/20 border-rose-500 text-rose-300 font-bold';
                        } else {
                          btnStyle = 'opacity-40 border-slate-800 text-slate-500';
                        }
                      }

                      return (
                        <button
                          key={opt.id}
                          disabled={isAnswerChecked}
                          onClick={() => handleQuizAnswer(opt.eng)}
                          className={`p-4 rounded-2xl border text-sm font-semibold text-left transition flex items-center justify-between ${btnStyle}`}
                        >
                          <span>{opt.ukr}</span>
                          {isAnswerChecked && isCorrect && <Check className="w-5 h-5 text-emerald-400" />}
                          {isAnswerChecked && isSelected && !isCorrect && (
                            <X className="w-5 h-5 text-rose-400" />
                          )}
                        </button>
                      );
                    })}
                  </div>

                  {isAnswerChecked && (
                    <div className="pt-2 flex justify-end">
                      <button
                        onClick={handleNextQuizQuestion}
                        className="px-6 py-3 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center gap-2 transition"
                      >
                        <span>Наступне питання</span>
                        <ArrowRight className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                </div>
              )}

              {isQuizCompleted && (
                <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 text-center space-y-4 shadow-2xl">
                  <Trophy className="w-12 h-12 text-amber-400 mx-auto" />
                  <h3 className="text-2xl font-black text-white">Тест завершено!</h3>
                  <p className="text-sm text-slate-300">
                    Ваш результат: <strong className="text-emerald-400">{quizScore}</strong> з{' '}
                    <strong>{Math.min(filteredWords.length, 10)}</strong> правильних відповідей.
                  </p>
                  <button
                    onClick={resetQuiz}
                    className="px-6 py-3 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs inline-flex items-center gap-2 transition"
                  >
                    <RotateCcw className="w-4 h-4" />
                    <span>Спробувати ще раз</span>
                  </button>
                </div>
              )}
            </div>
          )}

          {/* ================= MODE 4: SPELLING TILES ================= */}
          {studyMode === 'spelling' && filteredWords.length > 0 && (
            <div className="max-w-xl mx-auto space-y-6">
              {(() => {
                const currentWord = filteredWords[spellingIndex];
                if (!currentWord) return null;

                return (
                  <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl text-center">
                    <div className="space-y-2">
                      <span className="text-5xl block">{currentWord.emoji}</span>
                      <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                        Складіть англійське слово з літер:
                      </span>
                      <h3 className="text-2xl font-black text-emerald-400">«{currentWord.ukr}»</h3>
                      <p className="text-xs text-slate-400 italic font-mono">{currentWord.ipa}</p>
                    </div>

                    {/* Target Slots */}
                    <div className="min-h-16 p-4 rounded-2xl bg-slate-950 border border-slate-800 flex flex-wrap items-center justify-center gap-2">
                      {spellingLetters.map((char, idx) => (
                        <button
                          key={idx}
                          onClick={() => handleRemoveLetter(idx)}
                          className="w-10 h-10 rounded-xl bg-blue-600 text-white font-black text-lg flex items-center justify-center shadow-md transform hover:scale-105 transition"
                        >
                          {char.toUpperCase()}
                        </button>
                      ))}
                      {spellingLetters.length === 0 && (
                        <span className="text-xs text-slate-500">Клікайте на літери нижче...</span>
                      )}
                    </div>

                    {/* Available Tiles */}
                    <div className="flex flex-wrap items-center justify-center gap-2 py-2">
                      {availableTiles.map((tile) => (
                        <button
                          key={tile.id}
                          onClick={() => handleSelectTile(tile)}
                          className="w-10 h-10 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-lg flex items-center justify-center border border-slate-700 shadow transition transform active:scale-95"
                        >
                          {tile.char.toUpperCase()}
                        </button>
                      ))}
                    </div>

                    {/* Controls */}
                    <div className="flex items-center justify-center gap-3 pt-4 border-t border-slate-800">
                      <button
                        onClick={handleCheckSpelling}
                        className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-2 transition"
                      >
                        <Check className="w-4 h-4" />
                        <span>Перевірити</span>
                      </button>

                      <button
                        onClick={handleNextSpellingWord}
                        className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs flex items-center gap-2 transition"
                      >
                        <span>Наступне слово</span>
                        <ArrowRight className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })()}
            </div>
          )}

          {/* ================= MODE 5: CLOZE IN CONTEXT ================= */}
          {studyMode === 'cloze' && currentClozeWord && (
            <div className="max-w-xl mx-auto space-y-6">
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl">
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <span>Речення {clozeIndex + 1} з {filteredWords.length}</span>
                  <span className="text-2xl">{currentClozeWord.emoji}</span>
                </div>

                <div className="space-y-3">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block">
                    Вставте правильне слово в речення:
                  </span>
                  <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 text-base sm:text-lg text-slate-100 font-semibold leading-relaxed">
                    “
                    {currentClozeWord.exampleEn.replace(
                      new RegExp(`\\b${currentClozeWord.eng}\\b`, 'gi'),
                      '_______'
                    )}
                    ”
                  </div>
                  <p className="text-xs text-slate-400 italic">«{currentClozeWord.exampleUa}»</p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2">
                  {clozeOptions.map((opt) => {
                    const isSelected = clozeSelected === opt.eng;
                    const isCorrect = opt.eng === currentClozeWord.eng;

                    let btnStyle =
                      'bg-slate-800/80 hover:bg-slate-800 border-slate-700 text-slate-200 hover:border-slate-600';

                    if (isClozeChecked) {
                      if (isCorrect) {
                        btnStyle = 'bg-emerald-600/20 border-emerald-500 text-emerald-300 font-bold';
                      } else if (isSelected) {
                        btnStyle = 'bg-rose-600/20 border-rose-500 text-rose-300 font-bold';
                      } else {
                        btnStyle = 'opacity-40 border-slate-800 text-slate-500';
                      }
                    }

                    return (
                      <button
                        key={opt.id}
                        disabled={isClozeChecked}
                        onClick={() => handleSelectClozeOption(opt.eng)}
                        className={`p-3.5 rounded-2xl border text-sm font-semibold text-left transition flex items-center justify-between ${btnStyle}`}
                      >
                        <span>{opt.eng}</span>
                        {isClozeChecked && isCorrect && <Check className="w-4 h-4 text-emerald-400" />}
                      </button>
                    );
                  })}
                </div>

                {isClozeChecked && (
                  <div className="pt-2 flex justify-end">
                    <button
                      onClick={handleNextCloze}
                      className="px-6 py-2.5 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center gap-2 transition"
                    >
                      <span>Наступне речення</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}
    </section>
  );
};
