# Batch 1 generator
import sys
sys.path.insert(0, '.')
from scripts.batch1_helper import process_batch_category, existing_all

print('run_batch1 starting')
