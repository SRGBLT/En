import sys, os
sys.path.insert(0, '.')
from scripts.builder import get_existing_words, save_category_file

print("Starting Batch 1 generation...")
