from scripts.builder import get_existing_words, save_category_file

existing = get_existing_words()
print("Available existing categories:", list(existing.keys()))
