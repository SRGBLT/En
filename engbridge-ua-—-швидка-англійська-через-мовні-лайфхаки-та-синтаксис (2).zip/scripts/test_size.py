# Test script size handling
print("Ready to create batch runner")
