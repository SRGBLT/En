import re
import os
import json

def get_existing_words():
    with open('src/data/thematicWords.ts', 'r', encoding='utf-8') as f:
        text = f.read()

    start = text.find('export const THEMATIC_WORDS: ThematicWord[] = [')
    end = text.find('export function getWordsByCategory', start)
    arr_text = text[start:end]

    blocks = re.findall(r'\{\s*id:\s*\'[^\']+\',[\s\S]*?mnemonicHook:\s*\'[^\']+\'[\s\S]*?\}', arr_text)

    def parse_block(b):
        item = {}
        for key in ['id', 'category', 'ukr', 'eng', 'ipa', 'rule', 'level', 'emoji', 'exampleEn', 'exampleUa', 'mnemonicHook']:
            m = re.search(r"""%s:\s*'(.*?)'""" % key, b)
            if m:
                item[key] = m.group(1).replace("\\'", "'")
        m_pack = re.search(r'pack:\s*(\d+)', b)
        if m_pack:
            item['pack'] = int(m_pack.group(1))
        m_cols = re.search(r'collocations:\s*\[(.*?)\]', b)
        if m_cols:
            item['collocations'] = [c.strip().strip("'").strip('"') for c in m_cols.group(1).split(',') if c.strip()]
        return item

    parsed = [parse_block(b) for b in blocks]
    by_cat = {}
    for item in parsed:
        cat = item.get('category')
        if cat:
            by_cat.setdefault(cat, []).append(item)
    return by_cat

def save_category_file(category_id, words):
    # Ensure exactly 300 words
    assert len(words) == 300, f"Expected 300 words for {category_id}, got {len(words)}"
    
    # Update pack numbers: pack 1 (words 1..10), pack 2 (words 11..20), ..., pack 30 (words 291..300)
    for i, w in enumerate(words):
        w['pack'] = (i // 10) + 1
        w['id'] = f"{category_id[:4]}-{i + 1}"
    
    lines = [
        "import { ThematicWord } from '../../types';",
        "",
        f"export const {category_id.upper()}_WORDS: ThematicWord[] = ["
    ]
    
    for i, w in enumerate(words):
        pack_num = w['pack']
        if i % 10 == 0:
            lines.append(f"  // --- Блок (Рівень) {pack_num} ---")
        
        # Escape quotes safely for TS string literals
        def esc(s):
            return str(s).replace('\\', '\\\\').replace("'", "\\'")
        
        cols_str = ", ".join([f"'{esc(c)}'" for c in w.get('collocations', [])])
        
        lines.append("  {")
        lines.append(f"    id: '{esc(w['id'])}',")
        lines.append(f"    category: '{esc(w['category'])}',")
        lines.append(f"    pack: {pack_num},")
        lines.append(f"    ukr: '{esc(w['ukr'])}',")
        lines.append(f"    eng: '{esc(w['eng'])}',")
        lines.append(f"    ipa: '{esc(w['ipa'])}',")
        lines.append(f"    rule: '{esc(w['rule'])}',")
        lines.append(f"    level: '{esc(w['level'])}',")
        lines.append(f"    emoji: '{esc(w['emoji'])}',")
        lines.append(f"    exampleEn: '{esc(w['exampleEn'])}',")
        lines.append(f"    exampleUa: '{esc(w['exampleUa'])}',")
        lines.append(f"    collocations: [{cols_str}],")
        lines.append(f"    mnemonicHook: '{esc(w['mnemonicHook'])}',")
        lines.append("  },")
        
    lines.append("];")
    lines.append("")
    
    out_path = f"src/data/thematic/{category_id}.ts"
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, 'w', encoding='utf-8') as f:
        f.write("\n".join(lines))
    print(f"Saved {out_path} with {len(words)} words in 30 packs.")
