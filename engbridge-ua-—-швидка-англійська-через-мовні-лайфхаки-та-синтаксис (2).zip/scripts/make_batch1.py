import sys, os
sys.path.insert(0, '.')
from scripts.batch1_helper import process_batch_category, existing_all

print('make_batch1 initialized')
