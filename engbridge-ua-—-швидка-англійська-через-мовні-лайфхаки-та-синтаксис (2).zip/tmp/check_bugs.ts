import fs from 'fs';
import path from 'path';

// Check all thematic files for:
// 1. Placeholder / synthetic fake words
// 2. Cloze masking bugs
// 3. Duplicate words or weird options

const dir = './src/data/thematic';
const files = fs.readdirSync(dir).filter(f => f.endsWith('.ts'));

for (const file of files) {
  const content = fs.readFileSync(path.join(dir, file), 'utf8');
  const matches = [...content.matchAll(/eng:\s*'([^']+)'/g)].map(m => m[1]);
  const fake = matches.filter(w => /concept_|core_|advanced_|practical_|term_\d|_\d+$/.test(w));
  if (fake.length > 0) {
    console.log(`[FAKE] ${file}: ${fake.length} fake words found!`);
  }
}
